﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;

namespace HierarchyIterator
{
	class Program
	{
		static Stack<Hierarchy> ToDo = new Stack<Hierarchy>();

		static string OutFilename = @"C:\Temporary\HierarchyIterator.txt";
		static StreamWriter sw = null;

		static void Main(string[] args)
		{
			// open an output file for diagnostics purposes
			try { sw = new StreamWriter(OutFilename); }
			catch (Exception ex)
			{
				Console.WriteLine("Output file error: {0}", ex.Message);
				return;
			}
			// create test data
			Hierarchy Top;
			CreateHierarchy(out Top);
			// process the data iteratively
			ToDo.Push(Top);
			while (ToDo.Count > 0)
			{
				// show the stack for diagnostic purposes
				StringBuilder sb = new StringBuilder();
				foreach (Hierarchy t in ToDo)
					sw.Write(t.Name + ' ');
				sw.WriteLine();
				// pop and process an item
				Hierarchy h = ToDo.Pop();
				Put(h, ToDo);
			}
			sw.Flush();
			// now do it recursively
			ToDo.Push(Top);
			PutRecursively(Top, 0);
		}

		private static void Put(Hierarchy h, Stack<Hierarchy> ToDo)
		{
			// first count how many parents there are
			int Level = 0;
			Hierarchy p = h.Parent;
			while (p != null)
			{
				++Level;
				p = p.Parent;
			}
			// format the output with tabs to show the level
			string tabs = new string('\t', Level);
			Console.WriteLine("{0}{1}", tabs, h.Name);
			// store the children in the to do stack
			if (h.Children == null)
				return;
			// since the stack is LIFO, the objects will be popped off in
			// reverse order from what they are pushed, so we will push
			// in reverse order 
			for (int i = h.Children.Count - 1; i >= 0; --i)
				ToDo.Push(h.Children[i]);
		}

		/// <summary>
		/// This will create the test data.
		/// </summary>
		/// <param name="Top"></param>
		private static void CreateHierarchy(out Hierarchy Top)
		{
			Top = new Hierarchy("Top", null);
			Top.Children.Add(new Hierarchy("First", Top));
			Top.Children[0].Children.Add(new Hierarchy("First-1", Top.Children[0]));
			Top.Children[0].Children[0].Children.Add(new Hierarchy("John", Top.Children[0].Children[0]));
			Top.Children[0].Children[0].Children.Add(new Hierarchy("Mike", Top.Children[0].Children[0]));
			Top.Children[0].Children[0].Children.Add(new Hierarchy("Steve", Top.Children[0].Children[0]));
			Top.Children[0].Children.Add(new Hierarchy("First-2", Top.Children[0]));
			Top.Children[0].Children[1].Children.Add(new Hierarchy("Susan", Top.Children[0].Children[1]));
			Top.Children[0].Children[1].Children.Add(new Hierarchy("Julie", Top.Children[0].Children[1]));
			Top.Children[0].Children[1].Children.Add(new Hierarchy("Kara", Top.Children[0].Children[1]));
			Top.Children[0].Children.Add(new Hierarchy("First-3", Top.Children[0]));
			Top.Children[0].Children[2].Children.Add(new Hierarchy("Kim", Top.Children[0].Children[2]));
			Top.Children[0].Children[2].Children.Add(new Hierarchy("Kelly", Top.Children[0].Children[2]));
			Top.Children[0].Children[2].Children.Add(new Hierarchy("Pat", Top.Children[0].Children[2]));
			Top.Children.Add(new Hierarchy("Second", Top));
			Top.Children[1].Children.Add(new Hierarchy("Second-1", Top.Children[1]));
			Top.Children[1].Children.Add(new Hierarchy("Second-2", Top.Children[1]));
			Top.Children[1].Children.Add(new Hierarchy("Second-3", Top.Children[1]));
		}

		private static void PutRecursively(Hierarchy h, int Level)
		{
			string tabs = new string('\t', Level);
			Console.WriteLine("{0}{1}", tabs, h.Name);
			// store the children in the to do stack
			if (h.Children == null)
				return;
			++Level;
			foreach (Hierarchy child in h.Children)
				PutRecursively(child, Level);
		}
	}

	class Hierarchy
	{
		public string Name;
		public List<Hierarchy> Children = new List<Hierarchy>();
		public Hierarchy Parent = null;

		public Hierarchy(string Name, Hierarchy Parent)
		{
			this.Name = Name;
			this.Parent = Parent;
		}
	}
}
