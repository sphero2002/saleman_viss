// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/css.h"

#include "base/bind.h"

namespace headless {

namespace css {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("CSS.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("CSS.disable", std::move(callback));
}

void Domain::GetMatchedStylesForNode(std::unique_ptr<GetMatchedStylesForNodeParams> params, base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)> callback) {
  dispatcher_->SendMessage("CSS.getMatchedStylesForNode", params->Serialize(), base::Bind(&Domain::HandleGetMatchedStylesForNodeResponse, callback));
}

void Domain::GetInlineStylesForNode(std::unique_ptr<GetInlineStylesForNodeParams> params, base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)> callback) {
  dispatcher_->SendMessage("CSS.getInlineStylesForNode", params->Serialize(), base::Bind(&Domain::HandleGetInlineStylesForNodeResponse, callback));
}

void Domain::GetComputedStyleForNode(std::unique_ptr<GetComputedStyleForNodeParams> params, base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)> callback) {
  dispatcher_->SendMessage("CSS.getComputedStyleForNode", params->Serialize(), base::Bind(&Domain::HandleGetComputedStyleForNodeResponse, callback));
}

void Domain::GetPlatformFontsForNode(std::unique_ptr<GetPlatformFontsForNodeParams> params, base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)> callback) {
  dispatcher_->SendMessage("CSS.getPlatformFontsForNode", params->Serialize(), base::Bind(&Domain::HandleGetPlatformFontsForNodeResponse, callback));
}

void Domain::GetStyleSheetText(std::unique_ptr<GetStyleSheetTextParams> params, base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)> callback) {
  dispatcher_->SendMessage("CSS.getStyleSheetText", params->Serialize(), base::Bind(&Domain::HandleGetStyleSheetTextResponse, callback));
}

void Domain::SetStyleSheetText(std::unique_ptr<SetStyleSheetTextParams> params, base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)> callback) {
  dispatcher_->SendMessage("CSS.setStyleSheetText", params->Serialize(), base::Bind(&Domain::HandleSetStyleSheetTextResponse, callback));
}

void Domain::SetRuleSelector(std::unique_ptr<SetRuleSelectorParams> params, base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)> callback) {
  dispatcher_->SendMessage("CSS.setRuleSelector", params->Serialize(), base::Bind(&Domain::HandleSetRuleSelectorResponse, callback));
}

void Domain::SetKeyframeKey(std::unique_ptr<SetKeyframeKeyParams> params, base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)> callback) {
  dispatcher_->SendMessage("CSS.setKeyframeKey", params->Serialize(), base::Bind(&Domain::HandleSetKeyframeKeyResponse, callback));
}

void Domain::SetStyleTexts(std::unique_ptr<SetStyleTextsParams> params, base::Callback<void(std::unique_ptr<SetStyleTextsResult>)> callback) {
  dispatcher_->SendMessage("CSS.setStyleTexts", params->Serialize(), base::Bind(&Domain::HandleSetStyleTextsResponse, callback));
}

void Domain::SetMediaText(std::unique_ptr<SetMediaTextParams> params, base::Callback<void(std::unique_ptr<SetMediaTextResult>)> callback) {
  dispatcher_->SendMessage("CSS.setMediaText", params->Serialize(), base::Bind(&Domain::HandleSetMediaTextResponse, callback));
}

void Domain::CreateStyleSheet(std::unique_ptr<CreateStyleSheetParams> params, base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)> callback) {
  dispatcher_->SendMessage("CSS.createStyleSheet", params->Serialize(), base::Bind(&Domain::HandleCreateStyleSheetResponse, callback));
}

void Domain::AddRule(std::unique_ptr<AddRuleParams> params, base::Callback<void(std::unique_ptr<AddRuleResult>)> callback) {
  dispatcher_->SendMessage("CSS.addRule", params->Serialize(), base::Bind(&Domain::HandleAddRuleResponse, callback));
}

void Domain::ForcePseudoState(std::unique_ptr<ForcePseudoStateParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("CSS.forcePseudoState", params->Serialize(), std::move(callback));
}

void Domain::GetMediaQueries(base::Callback<void(std::unique_ptr<GetMediaQueriesResult>)> callback) {
  dispatcher_->SendMessage("CSS.getMediaQueries", base::Bind(&Domain::HandleGetMediaQueriesResponse, callback));
}

void Domain::SetEffectivePropertyValueForNode(std::unique_ptr<SetEffectivePropertyValueForNodeParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("CSS.setEffectivePropertyValueForNode", params->Serialize(), std::move(callback));
}

void Domain::GetBackgroundColors(std::unique_ptr<GetBackgroundColorsParams> params, base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)> callback) {
  dispatcher_->SendMessage("CSS.getBackgroundColors", params->Serialize(), base::Bind(&Domain::HandleGetBackgroundColorsResponse, callback));
}


// static
void Domain::HandleGetMatchedStylesForNodeResponse(base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetMatchedStylesForNodeResult> result = GetMatchedStylesForNodeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetInlineStylesForNodeResponse(base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetInlineStylesForNodeResult> result = GetInlineStylesForNodeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetComputedStyleForNodeResponse(base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetComputedStyleForNodeResult> result = GetComputedStyleForNodeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetPlatformFontsForNodeResponse(base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetPlatformFontsForNodeResult> result = GetPlatformFontsForNodeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetStyleSheetTextResponse(base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetStyleSheetTextResult> result = GetStyleSheetTextResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetStyleSheetTextResponse(base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetStyleSheetTextResult> result = SetStyleSheetTextResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetRuleSelectorResponse(base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetRuleSelectorResult> result = SetRuleSelectorResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetKeyframeKeyResponse(base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetKeyframeKeyResult> result = SetKeyframeKeyResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetStyleTextsResponse(base::Callback<void(std::unique_ptr<SetStyleTextsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetStyleTextsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetStyleTextsResult> result = SetStyleTextsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetMediaTextResponse(base::Callback<void(std::unique_ptr<SetMediaTextResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetMediaTextResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetMediaTextResult> result = SetMediaTextResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCreateStyleSheetResponse(base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CreateStyleSheetResult> result = CreateStyleSheetResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleAddRuleResponse(base::Callback<void(std::unique_ptr<AddRuleResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<AddRuleResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<AddRuleResult> result = AddRuleResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetMediaQueriesResponse(base::Callback<void(std::unique_ptr<GetMediaQueriesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetMediaQueriesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetMediaQueriesResult> result = GetMediaQueriesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetBackgroundColorsResponse(base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetBackgroundColorsResult> result = GetBackgroundColorsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace css

} // namespace headless
