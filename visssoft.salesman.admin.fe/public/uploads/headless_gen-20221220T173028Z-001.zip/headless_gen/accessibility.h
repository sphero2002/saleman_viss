// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_ACCESSIBILITY_H_
#define HEADLESS_PUBLIC_DOMAINS_ACCESSIBILITY_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace accessibility {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Fetches the accessibility node for this DOM node, if it exists.
  void GetAXNode(std::unique_ptr<GetAXNodeParams> params, base::Callback<void(std::unique_ptr<GetAXNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetAXNodeResult>)>());
  void GetAXNode(int nodeId, base::Callback<void(std::unique_ptr<GetAXNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetAXNodeResult>)>());
 private:
  static void HandleGetAXNodeResponse(base::Callback<void(std::unique_ptr<GetAXNodeResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace accessibility
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_ACCESSIBILITY_H_
