// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/cache_storage.h"

#include "base/bind.h"

namespace headless {

namespace cache_storage {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::RequestCacheNames(std::unique_ptr<RequestCacheNamesParams> params, base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)> callback) {
  dispatcher_->SendMessage("CacheStorage.requestCacheNames", params->Serialize(), base::Bind(&Domain::HandleRequestCacheNamesResponse, callback));
}

void Domain::RequestEntries(std::unique_ptr<RequestEntriesParams> params, base::Callback<void(std::unique_ptr<RequestEntriesResult>)> callback) {
  dispatcher_->SendMessage("CacheStorage.requestEntries", params->Serialize(), base::Bind(&Domain::HandleRequestEntriesResponse, callback));
}

void Domain::DeleteCache(std::unique_ptr<DeleteCacheParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("CacheStorage.deleteCache", params->Serialize(), std::move(callback));
}

void Domain::DeleteEntry(std::unique_ptr<DeleteEntryParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("CacheStorage.deleteEntry", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleRequestCacheNamesResponse(base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RequestCacheNamesResult> result = RequestCacheNamesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleRequestEntriesResponse(base::Callback<void(std::unique_ptr<RequestEntriesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RequestEntriesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RequestEntriesResult> result = RequestEntriesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace cache_storage

} // namespace headless
