// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_WORKER_H_
#define HEADLESS_PUBLIC_DOMAINS_WORKER_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace worker {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  void SendMessageToWorker(std::unique_ptr<SendMessageToWorkerParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SendMessageToWorker(std::string workerId, std::string message, base::Callback<void()> callback = base::Callback<void()>());
  void SetWaitForDebuggerOnStart(std::unique_ptr<SetWaitForDebuggerOnStartParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetWaitForDebuggerOnStart(bool value, base::Callback<void()> callback = base::Callback<void()>());
 private:

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace worker
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_WORKER_H_
