// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_SERVICE_WORKER_H_
#define HEADLESS_PUBLIC_DOMAINS_SERVICE_WORKER_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace service_worker {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  void SendMessage(std::unique_ptr<SendMessageParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SendMessage(std::string workerId, std::string message, base::Callback<void()> callback = base::Callback<void()>());
  void Stop(std::unique_ptr<StopParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void Stop(std::string workerId, base::Callback<void()> callback = base::Callback<void()>());
  void Unregister(std::unique_ptr<UnregisterParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void Unregister(std::string scopeURL, base::Callback<void()> callback = base::Callback<void()>());
  void UpdateRegistration(std::unique_ptr<UpdateRegistrationParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void UpdateRegistration(std::string scopeURL, base::Callback<void()> callback = base::Callback<void()>());
  void StartWorker(std::unique_ptr<StartWorkerParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void StartWorker(std::string scopeURL, base::Callback<void()> callback = base::Callback<void()>());
  void StopWorker(std::unique_ptr<StopWorkerParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void StopWorker(std::string versionId, base::Callback<void()> callback = base::Callback<void()>());
  void InspectWorker(std::unique_ptr<InspectWorkerParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void InspectWorker(std::string versionId, base::Callback<void()> callback = base::Callback<void()>());
  void SetForceUpdateOnPageLoad(std::unique_ptr<SetForceUpdateOnPageLoadParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetForceUpdateOnPageLoad(bool forceUpdateOnPageLoad, base::Callback<void()> callback = base::Callback<void()>());
  void DeliverPushMessage(std::unique_ptr<DeliverPushMessageParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DeliverPushMessage(std::string origin, std::string registrationId, std::string data, base::Callback<void()> callback = base::Callback<void()>());
  void GetTargetInfo(std::unique_ptr<GetTargetInfoParams> params, base::Callback<void(std::unique_ptr<GetTargetInfoResult>)> callback = base::Callback<void(std::unique_ptr<GetTargetInfoResult>)>());
  void GetTargetInfo(std::string targetId, base::Callback<void(std::unique_ptr<GetTargetInfoResult>)> callback = base::Callback<void(std::unique_ptr<GetTargetInfoResult>)>());
  void ActivateTarget(std::unique_ptr<ActivateTargetParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ActivateTarget(std::string targetId, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleGetTargetInfoResponse(base::Callback<void(std::unique_ptr<GetTargetInfoResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace service_worker
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_SERVICE_WORKER_H_
