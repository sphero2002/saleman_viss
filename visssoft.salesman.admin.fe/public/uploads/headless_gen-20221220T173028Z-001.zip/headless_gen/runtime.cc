// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/runtime.h"

#include "base/bind.h"

namespace headless {

namespace runtime {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Evaluate(std::unique_ptr<EvaluateParams> params, base::Callback<void(std::unique_ptr<EvaluateResult>)> callback) {
  dispatcher_->SendMessage("Runtime.evaluate", params->Serialize(), base::Bind(&Domain::HandleEvaluateResponse, callback));
}

void Domain::CallFunctionOn(std::unique_ptr<CallFunctionOnParams> params, base::Callback<void(std::unique_ptr<CallFunctionOnResult>)> callback) {
  dispatcher_->SendMessage("Runtime.callFunctionOn", params->Serialize(), base::Bind(&Domain::HandleCallFunctionOnResponse, callback));
}

void Domain::GetProperties(std::unique_ptr<GetPropertiesParams> params, base::Callback<void(std::unique_ptr<GetPropertiesResult>)> callback) {
  dispatcher_->SendMessage("Runtime.getProperties", params->Serialize(), base::Bind(&Domain::HandleGetPropertiesResponse, callback));
}

void Domain::ReleaseObject(std::unique_ptr<ReleaseObjectParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Runtime.releaseObject", params->Serialize(), std::move(callback));
}

void Domain::ReleaseObjectGroup(std::unique_ptr<ReleaseObjectGroupParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Runtime.releaseObjectGroup", params->Serialize(), std::move(callback));
}

void Domain::Run(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Runtime.run", std::move(callback));
}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Runtime.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Runtime.disable", std::move(callback));
}

void Domain::SetCustomObjectFormatterEnabled(std::unique_ptr<SetCustomObjectFormatterEnabledParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Runtime.setCustomObjectFormatterEnabled", params->Serialize(), std::move(callback));
}

void Domain::CompileScript(std::unique_ptr<CompileScriptParams> params, base::Callback<void(std::unique_ptr<CompileScriptResult>)> callback) {
  dispatcher_->SendMessage("Runtime.compileScript", params->Serialize(), base::Bind(&Domain::HandleCompileScriptResponse, callback));
}

void Domain::RunScript(std::unique_ptr<RunScriptParams> params, base::Callback<void(std::unique_ptr<RunScriptResult>)> callback) {
  dispatcher_->SendMessage("Runtime.runScript", params->Serialize(), base::Bind(&Domain::HandleRunScriptResponse, callback));
}


// static
void Domain::HandleEvaluateResponse(base::Callback<void(std::unique_ptr<EvaluateResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<EvaluateResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<EvaluateResult> result = EvaluateResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCallFunctionOnResponse(base::Callback<void(std::unique_ptr<CallFunctionOnResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CallFunctionOnResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CallFunctionOnResult> result = CallFunctionOnResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetPropertiesResponse(base::Callback<void(std::unique_ptr<GetPropertiesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetPropertiesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetPropertiesResult> result = GetPropertiesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCompileScriptResponse(base::Callback<void(std::unique_ptr<CompileScriptResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CompileScriptResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CompileScriptResult> result = CompileScriptResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleRunScriptResponse(base::Callback<void(std::unique_ptr<RunScriptResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RunScriptResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RunScriptResult> result = RunScriptResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace runtime

} // namespace headless
