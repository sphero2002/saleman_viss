// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_DOM_DEBUGGER_H_
#define HEADLESS_PUBLIC_DOMAINS_DOM_DEBUGGER_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace dom_debugger {

// DOM debugging allows setting breakpoints on particular DOM operations and events. JavaScript execution will stop on these operations as if there was a regular breakpoint set.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Sets breakpoint on particular operation with DOM.
  void SetDOMBreakpoint(std::unique_ptr<SetDOMBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetDOMBreakpoint(int nodeId, headless::dom_debugger::DOMBreakpointType type, base::Callback<void()> callback = base::Callback<void()>());
  // Removes DOM breakpoint that was set using <code>setDOMBreakpoint</code>.
  void RemoveDOMBreakpoint(std::unique_ptr<RemoveDOMBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveDOMBreakpoint(int nodeId, headless::dom_debugger::DOMBreakpointType type, base::Callback<void()> callback = base::Callback<void()>());
  // Sets breakpoint on particular DOM event.
  void SetEventListenerBreakpoint(std::unique_ptr<SetEventListenerBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetEventListenerBreakpoint(std::string eventName, base::Callback<void()> callback = base::Callback<void()>());
  // Removes breakpoint on particular DOM event.
  void RemoveEventListenerBreakpoint(std::unique_ptr<RemoveEventListenerBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveEventListenerBreakpoint(std::string eventName, base::Callback<void()> callback = base::Callback<void()>());
  // Sets breakpoint on particular native event.
  void SetInstrumentationBreakpoint(std::unique_ptr<SetInstrumentationBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetInstrumentationBreakpoint(std::string eventName, base::Callback<void()> callback = base::Callback<void()>());
  // Removes breakpoint on particular native event.
  void RemoveInstrumentationBreakpoint(std::unique_ptr<RemoveInstrumentationBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveInstrumentationBreakpoint(std::string eventName, base::Callback<void()> callback = base::Callback<void()>());
  // Sets breakpoint on XMLHttpRequest.
  void SetXHRBreakpoint(std::unique_ptr<SetXHRBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetXHRBreakpoint(std::string url, base::Callback<void()> callback = base::Callback<void()>());
  // Removes breakpoint from XMLHttpRequest.
  void RemoveXHRBreakpoint(std::unique_ptr<RemoveXHRBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveXHRBreakpoint(std::string url, base::Callback<void()> callback = base::Callback<void()>());
  // Returns event listeners of the given object.
  void GetEventListeners(std::unique_ptr<GetEventListenersParams> params, base::Callback<void(std::unique_ptr<GetEventListenersResult>)> callback = base::Callback<void(std::unique_ptr<GetEventListenersResult>)>());
  void GetEventListeners(std::string objectId, base::Callback<void(std::unique_ptr<GetEventListenersResult>)> callback = base::Callback<void(std::unique_ptr<GetEventListenersResult>)>());
 private:
  static void HandleGetEventListenersResponse(base::Callback<void(std::unique_ptr<GetEventListenersResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace dom_debugger
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_DOM_DEBUGGER_H_
