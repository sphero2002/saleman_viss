// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/service_worker.h"

#include "base/bind.h"

namespace headless {

namespace service_worker {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.disable", std::move(callback));
}

void Domain::SendMessage(std::unique_ptr<SendMessageParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.sendMessage", params->Serialize(), std::move(callback));
}

void Domain::Stop(std::unique_ptr<StopParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.stop", params->Serialize(), std::move(callback));
}

void Domain::Unregister(std::unique_ptr<UnregisterParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.unregister", params->Serialize(), std::move(callback));
}

void Domain::UpdateRegistration(std::unique_ptr<UpdateRegistrationParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.updateRegistration", params->Serialize(), std::move(callback));
}

void Domain::StartWorker(std::unique_ptr<StartWorkerParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.startWorker", params->Serialize(), std::move(callback));
}

void Domain::StopWorker(std::unique_ptr<StopWorkerParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.stopWorker", params->Serialize(), std::move(callback));
}

void Domain::InspectWorker(std::unique_ptr<InspectWorkerParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.inspectWorker", params->Serialize(), std::move(callback));
}

void Domain::SetForceUpdateOnPageLoad(std::unique_ptr<SetForceUpdateOnPageLoadParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.setForceUpdateOnPageLoad", params->Serialize(), std::move(callback));
}

void Domain::DeliverPushMessage(std::unique_ptr<DeliverPushMessageParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.deliverPushMessage", params->Serialize(), std::move(callback));
}

void Domain::GetTargetInfo(std::unique_ptr<GetTargetInfoParams> params, base::Callback<void(std::unique_ptr<GetTargetInfoResult>)> callback) {
  dispatcher_->SendMessage("ServiceWorker.getTargetInfo", params->Serialize(), base::Bind(&Domain::HandleGetTargetInfoResponse, callback));
}

void Domain::ActivateTarget(std::unique_ptr<ActivateTargetParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("ServiceWorker.activateTarget", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleGetTargetInfoResponse(base::Callback<void(std::unique_ptr<GetTargetInfoResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetTargetInfoResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetTargetInfoResult> result = GetTargetInfoResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace service_worker

} // namespace headless
