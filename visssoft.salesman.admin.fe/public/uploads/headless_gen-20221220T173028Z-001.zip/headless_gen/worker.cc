// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/worker.h"

#include "base/bind.h"

namespace headless {

namespace worker {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Worker.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Worker.disable", std::move(callback));
}

void Domain::SendMessageToWorker(std::unique_ptr<SendMessageToWorkerParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Worker.sendMessageToWorker", params->Serialize(), std::move(callback));
}

void Domain::SetWaitForDebuggerOnStart(std::unique_ptr<SetWaitForDebuggerOnStartParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Worker.setWaitForDebuggerOnStart", params->Serialize(), std::move(callback));
}


}  // namespace worker

} // namespace headless
