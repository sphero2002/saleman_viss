// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_EMULATION_H_
#define HEADLESS_PUBLIC_DOMAINS_EMULATION_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace emulation {

// This domain emulates different environments for the page.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Overrides the values of device screen dimensions (window.screen.width, window.screen.height, window.innerWidth, window.innerHeight, and "device-width"/"device-height"-related CSS media query results).
  void SetDeviceMetricsOverride(std::unique_ptr<SetDeviceMetricsOverrideParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetDeviceMetricsOverride(int width, int height, double deviceScaleFactor, bool mobile, bool fitWindow, base::Callback<void()> callback = base::Callback<void()>());
  // Clears the overriden device metrics.
  void ClearDeviceMetricsOverride(base::Callback<void()> callback = base::Callback<void()>());
  // Requests that page scale factor is reset to initial values.
  void ResetPageScaleFactor(base::Callback<void()> callback = base::Callback<void()>());
  // Sets a specified page scale factor.
  void SetPageScaleFactor(std::unique_ptr<SetPageScaleFactorParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetPageScaleFactor(double pageScaleFactor, base::Callback<void()> callback = base::Callback<void()>());
  // Switches script execution in the page.
  void SetScriptExecutionDisabled(std::unique_ptr<SetScriptExecutionDisabledParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetScriptExecutionDisabled(bool value, base::Callback<void()> callback = base::Callback<void()>());
  // Overrides the Geolocation Position or Error. Omitting any of the parameters emulates position unavailable.
  void SetGeolocationOverride(std::unique_ptr<SetGeolocationOverrideParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetGeolocationOverride(base::Callback<void()> callback = base::Callback<void()>());
  // Clears the overriden Geolocation Position and Error.
  void ClearGeolocationOverride(base::Callback<void()> callback = base::Callback<void()>());
  // Toggles mouse event-based touch event emulation.
  void SetTouchEmulationEnabled(std::unique_ptr<SetTouchEmulationEnabledParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetTouchEmulationEnabled(bool enabled, base::Callback<void()> callback = base::Callback<void()>());
  // Emulates the given media for CSS media queries.
  void SetEmulatedMedia(std::unique_ptr<SetEmulatedMediaParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetEmulatedMedia(std::string media, base::Callback<void()> callback = base::Callback<void()>());
  // Enables CPU throttling to emulate slow CPUs.
  void SetCPUThrottlingRate(std::unique_ptr<SetCPUThrottlingRateParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetCPUThrottlingRate(double rate, base::Callback<void()> callback = base::Callback<void()>());
  // Tells whether emulation is supported.
  void CanEmulate(base::Callback<void(std::unique_ptr<CanEmulateResult>)> callback = base::Callback<void(std::unique_ptr<CanEmulateResult>)>());
 private:
  static void HandleCanEmulateResponse(base::Callback<void(std::unique_ptr<CanEmulateResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace emulation
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_EMULATION_H_
