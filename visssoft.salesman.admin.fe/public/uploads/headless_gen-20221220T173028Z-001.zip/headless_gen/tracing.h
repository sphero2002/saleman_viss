// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_TRACING_H_
#define HEADLESS_PUBLIC_DOMAINS_TRACING_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace tracing {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Start trace events collection.
  void Start(std::unique_ptr<StartParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void Start(base::Callback<void()> callback = base::Callback<void()>());
  // Stop trace events collection.
  void End(base::Callback<void()> callback = base::Callback<void()>());
  // Gets supported tracing categories.
  void GetCategories(base::Callback<void(std::unique_ptr<GetCategoriesResult>)> callback = base::Callback<void(std::unique_ptr<GetCategoriesResult>)>());
  // Request a global memory dump.
  void RequestMemoryDump(base::Callback<void(std::unique_ptr<RequestMemoryDumpResult>)> callback = base::Callback<void(std::unique_ptr<RequestMemoryDumpResult>)>());
  // Record a clock sync marker in the trace.
  void RecordClockSyncMarker(std::unique_ptr<RecordClockSyncMarkerParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RecordClockSyncMarker(std::string syncId, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleGetCategoriesResponse(base::Callback<void(std::unique_ptr<GetCategoriesResult>)> callback, const base::Value& response);
  static void HandleRequestMemoryDumpResponse(base::Callback<void(std::unique_ptr<RequestMemoryDumpResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace tracing
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_TRACING_H_
