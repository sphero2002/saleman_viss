// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/database.h"

#include "base/bind.h"

namespace headless {

namespace database {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Database.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Database.disable", std::move(callback));
}

void Domain::GetDatabaseTableNames(std::unique_ptr<GetDatabaseTableNamesParams> params, base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)> callback) {
  dispatcher_->SendMessage("Database.getDatabaseTableNames", params->Serialize(), base::Bind(&Domain::HandleGetDatabaseTableNamesResponse, callback));
}

void Domain::ExecuteSQL(std::unique_ptr<ExecuteSQLParams> params, base::Callback<void(std::unique_ptr<ExecuteSQLResult>)> callback) {
  dispatcher_->SendMessage("Database.executeSQL", params->Serialize(), base::Bind(&Domain::HandleExecuteSQLResponse, callback));
}


// static
void Domain::HandleGetDatabaseTableNamesResponse(base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetDatabaseTableNamesResult> result = GetDatabaseTableNamesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleExecuteSQLResponse(base::Callback<void(std::unique_ptr<ExecuteSQLResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<ExecuteSQLResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<ExecuteSQLResult> result = ExecuteSQLResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace database

} // namespace headless
