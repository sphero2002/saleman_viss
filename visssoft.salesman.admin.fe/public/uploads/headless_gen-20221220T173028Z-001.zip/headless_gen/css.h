// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_CSS_H_
#define HEADLESS_PUBLIC_DOMAINS_CSS_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace css {

// This domain exposes CSS read/write operations. All CSS objects (stylesheets, rules, and styles) have an associated <code>id</code> used in subsequent operations on the related object. Each object type has a specific <code>id</code> structure, and those are not interchangeable between objects of different kinds. CSS objects can be loaded using the <code>get*ForNode()</code> calls (which accept a DOM node id). A client can also discover all the existing stylesheets with the <code>getAllStyleSheets()</code> method (or keeping track of the <code>styleSheetAdded</code>/<code>styleSheetRemoved</code> events) and subsequently load the required stylesheet contents using the <code>getStyleSheet[Text]()</code> methods.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables the CSS agent for the given page. Clients should not assume that the CSS agent has been enabled until the result of this command is received.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables the CSS agent for the given page.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Returns requested styles for a DOM node identified by <code>nodeId</code>.
  void GetMatchedStylesForNode(std::unique_ptr<GetMatchedStylesForNodeParams> params, base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)>());
  void GetMatchedStylesForNode(int nodeId, base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)>());
  // Returns the styles defined inline (explicitly in the "style" attribute and implicitly, using DOM attributes) for a DOM node identified by <code>nodeId</code>.
  void GetInlineStylesForNode(std::unique_ptr<GetInlineStylesForNodeParams> params, base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)>());
  void GetInlineStylesForNode(int nodeId, base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)>());
  // Returns the computed style for a DOM node identified by <code>nodeId</code>.
  void GetComputedStyleForNode(std::unique_ptr<GetComputedStyleForNodeParams> params, base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)>());
  void GetComputedStyleForNode(int nodeId, base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)>());
  // Requests information about platform fonts which we used to render child TextNodes in the given node.
  void GetPlatformFontsForNode(std::unique_ptr<GetPlatformFontsForNodeParams> params, base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)>());
  void GetPlatformFontsForNode(int nodeId, base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)> callback = base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)>());
  // Returns the current textual content and the URL for a stylesheet.
  void GetStyleSheetText(std::unique_ptr<GetStyleSheetTextParams> params, base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)> callback = base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)>());
  void GetStyleSheetText(std::string styleSheetId, base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)> callback = base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)>());
  // Sets the new stylesheet text.
  void SetStyleSheetText(std::unique_ptr<SetStyleSheetTextParams> params, base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)> callback = base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)>());
  void SetStyleSheetText(std::string styleSheetId, std::string text, base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)> callback = base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)>());
  // Modifies the rule selector.
  void SetRuleSelector(std::unique_ptr<SetRuleSelectorParams> params, base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)> callback = base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)>());
  void SetRuleSelector(std::string styleSheetId, std::unique_ptr<headless::css::SourceRange> range, std::string selector, base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)> callback = base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)>());
  // Modifies the keyframe rule key text.
  void SetKeyframeKey(std::unique_ptr<SetKeyframeKeyParams> params, base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)> callback = base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)>());
  void SetKeyframeKey(std::string styleSheetId, std::unique_ptr<headless::css::SourceRange> range, std::string keyText, base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)> callback = base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)>());
  // Applies specified style edits one after another in the given order.
  void SetStyleTexts(std::unique_ptr<SetStyleTextsParams> params, base::Callback<void(std::unique_ptr<SetStyleTextsResult>)> callback = base::Callback<void(std::unique_ptr<SetStyleTextsResult>)>());
  void SetStyleTexts(std::vector<std::unique_ptr<headless::css::StyleDeclarationEdit>> edits, base::Callback<void(std::unique_ptr<SetStyleTextsResult>)> callback = base::Callback<void(std::unique_ptr<SetStyleTextsResult>)>());
  // Modifies the rule selector.
  void SetMediaText(std::unique_ptr<SetMediaTextParams> params, base::Callback<void(std::unique_ptr<SetMediaTextResult>)> callback = base::Callback<void(std::unique_ptr<SetMediaTextResult>)>());
  void SetMediaText(std::string styleSheetId, std::unique_ptr<headless::css::SourceRange> range, std::string text, base::Callback<void(std::unique_ptr<SetMediaTextResult>)> callback = base::Callback<void(std::unique_ptr<SetMediaTextResult>)>());
  // Creates a new special "via-inspector" stylesheet in the frame with given <code>frameId</code>.
  void CreateStyleSheet(std::unique_ptr<CreateStyleSheetParams> params, base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)> callback = base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)>());
  void CreateStyleSheet(std::string frameId, base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)> callback = base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)>());
  // Inserts a new rule with the given <code>ruleText</code> in a stylesheet with given <code>styleSheetId</code>, at the position specified by <code>location</code>.
  void AddRule(std::unique_ptr<AddRuleParams> params, base::Callback<void(std::unique_ptr<AddRuleResult>)> callback = base::Callback<void(std::unique_ptr<AddRuleResult>)>());
  void AddRule(std::string styleSheetId, std::string ruleText, std::unique_ptr<headless::css::SourceRange> location, base::Callback<void(std::unique_ptr<AddRuleResult>)> callback = base::Callback<void(std::unique_ptr<AddRuleResult>)>());
  // Ensures that the given node will have specified pseudo-classes whenever its style is computed by the browser.
  void ForcePseudoState(std::unique_ptr<ForcePseudoStateParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ForcePseudoState(int nodeId, std::vector<std::string> forcedPseudoClasses, base::Callback<void()> callback = base::Callback<void()>());
  // Returns all media queries parsed by the rendering engine.
  void GetMediaQueries(base::Callback<void(std::unique_ptr<GetMediaQueriesResult>)> callback = base::Callback<void(std::unique_ptr<GetMediaQueriesResult>)>());
  // Find a rule with the given active property for the given node and set the new value for this property
  void SetEffectivePropertyValueForNode(std::unique_ptr<SetEffectivePropertyValueForNodeParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetEffectivePropertyValueForNode(int nodeId, std::string propertyName, std::string value, base::Callback<void()> callback = base::Callback<void()>());
  void GetBackgroundColors(std::unique_ptr<GetBackgroundColorsParams> params, base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)> callback = base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)>());
  void GetBackgroundColors(int nodeId, base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)> callback = base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)>());
 private:
  static void HandleGetMatchedStylesForNodeResponse(base::Callback<void(std::unique_ptr<GetMatchedStylesForNodeResult>)> callback, const base::Value& response);
  static void HandleGetInlineStylesForNodeResponse(base::Callback<void(std::unique_ptr<GetInlineStylesForNodeResult>)> callback, const base::Value& response);
  static void HandleGetComputedStyleForNodeResponse(base::Callback<void(std::unique_ptr<GetComputedStyleForNodeResult>)> callback, const base::Value& response);
  static void HandleGetPlatformFontsForNodeResponse(base::Callback<void(std::unique_ptr<GetPlatformFontsForNodeResult>)> callback, const base::Value& response);
  static void HandleGetStyleSheetTextResponse(base::Callback<void(std::unique_ptr<GetStyleSheetTextResult>)> callback, const base::Value& response);
  static void HandleSetStyleSheetTextResponse(base::Callback<void(std::unique_ptr<SetStyleSheetTextResult>)> callback, const base::Value& response);
  static void HandleSetRuleSelectorResponse(base::Callback<void(std::unique_ptr<SetRuleSelectorResult>)> callback, const base::Value& response);
  static void HandleSetKeyframeKeyResponse(base::Callback<void(std::unique_ptr<SetKeyframeKeyResult>)> callback, const base::Value& response);
  static void HandleSetStyleTextsResponse(base::Callback<void(std::unique_ptr<SetStyleTextsResult>)> callback, const base::Value& response);
  static void HandleSetMediaTextResponse(base::Callback<void(std::unique_ptr<SetMediaTextResult>)> callback, const base::Value& response);
  static void HandleCreateStyleSheetResponse(base::Callback<void(std::unique_ptr<CreateStyleSheetResult>)> callback, const base::Value& response);
  static void HandleAddRuleResponse(base::Callback<void(std::unique_ptr<AddRuleResult>)> callback, const base::Value& response);
  static void HandleGetMediaQueriesResponse(base::Callback<void(std::unique_ptr<GetMediaQueriesResult>)> callback, const base::Value& response);
  static void HandleGetBackgroundColorsResponse(base::Callback<void(std::unique_ptr<GetBackgroundColorsResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace css
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_CSS_H_
