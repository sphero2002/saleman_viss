// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_PAGE_H_
#define HEADLESS_PUBLIC_DOMAINS_PAGE_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace page {

// Actions and events related to the inspected page belong to the page domain.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables page domain notifications.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables page domain notifications.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  void AddScriptToEvaluateOnLoad(std::unique_ptr<AddScriptToEvaluateOnLoadParams> params, base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)> callback = base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)>());
  void AddScriptToEvaluateOnLoad(std::string scriptSource, base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)> callback = base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)>());
  void RemoveScriptToEvaluateOnLoad(std::unique_ptr<RemoveScriptToEvaluateOnLoadParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveScriptToEvaluateOnLoad(std::string identifier, base::Callback<void()> callback = base::Callback<void()>());
  // Controls whether browser will open a new inspector window for connected pages.
  void SetAutoAttachToCreatedPages(std::unique_ptr<SetAutoAttachToCreatedPagesParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetAutoAttachToCreatedPages(bool autoAttach, base::Callback<void()> callback = base::Callback<void()>());
  // Reloads given page optionally ignoring the cache.
  void Reload(std::unique_ptr<ReloadParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void Reload(base::Callback<void()> callback = base::Callback<void()>());
  // Navigates current page to the given URL.
  void Navigate(std::unique_ptr<NavigateParams> params, base::Callback<void(std::unique_ptr<NavigateResult>)> callback = base::Callback<void(std::unique_ptr<NavigateResult>)>());
  void Navigate(std::string url, base::Callback<void(std::unique_ptr<NavigateResult>)> callback = base::Callback<void(std::unique_ptr<NavigateResult>)>());
  // Returns navigation history for the current page.
  void GetNavigationHistory(base::Callback<void(std::unique_ptr<GetNavigationHistoryResult>)> callback = base::Callback<void(std::unique_ptr<GetNavigationHistoryResult>)>());
  // Navigates current page to the given history entry.
  void NavigateToHistoryEntry(std::unique_ptr<NavigateToHistoryEntryParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void NavigateToHistoryEntry(int entryId, base::Callback<void()> callback = base::Callback<void()>());
  // Returns present frame / resource tree structure.
  void GetResourceTree(base::Callback<void(std::unique_ptr<GetResourceTreeResult>)> callback = base::Callback<void(std::unique_ptr<GetResourceTreeResult>)>());
  // Returns content of the given resource.
  void GetResourceContent(std::unique_ptr<GetResourceContentParams> params, base::Callback<void(std::unique_ptr<GetResourceContentResult>)> callback = base::Callback<void(std::unique_ptr<GetResourceContentResult>)>());
  void GetResourceContent(std::string frameId, std::string url, base::Callback<void(std::unique_ptr<GetResourceContentResult>)> callback = base::Callback<void(std::unique_ptr<GetResourceContentResult>)>());
  // Searches for given string in resource content.
  void SearchInResource(std::unique_ptr<SearchInResourceParams> params, base::Callback<void(std::unique_ptr<SearchInResourceResult>)> callback = base::Callback<void(std::unique_ptr<SearchInResourceResult>)>());
  void SearchInResource(std::string frameId, std::string url, std::string query, base::Callback<void(std::unique_ptr<SearchInResourceResult>)> callback = base::Callback<void(std::unique_ptr<SearchInResourceResult>)>());
  // Sets given markup as the document's HTML.
  void SetDocumentContent(std::unique_ptr<SetDocumentContentParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetDocumentContent(std::string frameId, std::string html, base::Callback<void()> callback = base::Callback<void()>());
  // Capture page screenshot.
  void CaptureScreenshot(base::Callback<void(std::unique_ptr<CaptureScreenshotResult>)> callback = base::Callback<void(std::unique_ptr<CaptureScreenshotResult>)>());
  // Starts sending each frame using the <code>screencastFrame</code> event.
  void StartScreencast(std::unique_ptr<StartScreencastParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void StartScreencast(base::Callback<void()> callback = base::Callback<void()>());
  // Stops sending each frame in the <code>screencastFrame</code>.
  void StopScreencast(base::Callback<void()> callback = base::Callback<void()>());
  // Acknowledges that a screencast frame has been received by the frontend.
  void ScreencastFrameAck(std::unique_ptr<ScreencastFrameAckParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ScreencastFrameAck(int sessionId, base::Callback<void()> callback = base::Callback<void()>());
  // Accepts or dismisses a JavaScript initiated dialog (alert, confirm, prompt, or onbeforeunload).
  void HandleJavaScriptDialog(std::unique_ptr<HandleJavaScriptDialogParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void HandleJavaScriptDialog(bool accept, base::Callback<void()> callback = base::Callback<void()>());
  // Shows / hides color picker
  void SetColorPickerEnabled(std::unique_ptr<SetColorPickerEnabledParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetColorPickerEnabled(bool enabled, base::Callback<void()> callback = base::Callback<void()>());
  // Sets overlay message.
  void SetOverlayMessage(std::unique_ptr<SetOverlayMessageParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetOverlayMessage(base::Callback<void()> callback = base::Callback<void()>());
  void RequestAppBanner(base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleAddScriptToEvaluateOnLoadResponse(base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)> callback, const base::Value& response);
  static void HandleNavigateResponse(base::Callback<void(std::unique_ptr<NavigateResult>)> callback, const base::Value& response);
  static void HandleGetNavigationHistoryResponse(base::Callback<void(std::unique_ptr<GetNavigationHistoryResult>)> callback, const base::Value& response);
  static void HandleGetCookiesResponse(base::Callback<void(std::unique_ptr<GetCookiesResult>)> callback, const base::Value& response);
  static void HandleGetResourceTreeResponse(base::Callback<void(std::unique_ptr<GetResourceTreeResult>)> callback, const base::Value& response);
  static void HandleGetResourceContentResponse(base::Callback<void(std::unique_ptr<GetResourceContentResult>)> callback, const base::Value& response);
  static void HandleSearchInResourceResponse(base::Callback<void(std::unique_ptr<SearchInResourceResult>)> callback, const base::Value& response);
  static void HandleCaptureScreenshotResponse(base::Callback<void(std::unique_ptr<CaptureScreenshotResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace page
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_PAGE_H_
