// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/network.h"

#include "base/bind.h"

namespace headless {

namespace network {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(std::unique_ptr<EnableParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.enable", params->Serialize(), std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.disable", std::move(callback));
}

void Domain::SetUserAgentOverride(std::unique_ptr<SetUserAgentOverrideParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.setUserAgentOverride", params->Serialize(), std::move(callback));
}

void Domain::SetExtraHTTPHeaders(std::unique_ptr<SetExtraHTTPHeadersParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.setExtraHTTPHeaders", params->Serialize(), std::move(callback));
}

void Domain::GetResponseBody(std::unique_ptr<GetResponseBodyParams> params, base::Callback<void(std::unique_ptr<GetResponseBodyResult>)> callback) {
  dispatcher_->SendMessage("Network.getResponseBody", params->Serialize(), base::Bind(&Domain::HandleGetResponseBodyResponse, callback));
}

void Domain::AddBlockedURL(std::unique_ptr<AddBlockedURLParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.addBlockedURL", params->Serialize(), std::move(callback));
}

void Domain::RemoveBlockedURL(std::unique_ptr<RemoveBlockedURLParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.removeBlockedURL", params->Serialize(), std::move(callback));
}

void Domain::ReplayXHR(std::unique_ptr<ReplayXHRParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.replayXHR", params->Serialize(), std::move(callback));
}

void Domain::SetMonitoringXHREnabled(std::unique_ptr<SetMonitoringXHREnabledParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.setMonitoringXHREnabled", params->Serialize(), std::move(callback));
}

void Domain::CanClearBrowserCache(base::Callback<void(std::unique_ptr<CanClearBrowserCacheResult>)> callback) {
  dispatcher_->SendMessage("Network.canClearBrowserCache", base::Bind(&Domain::HandleCanClearBrowserCacheResponse, callback));
}

void Domain::ClearBrowserCache(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.clearBrowserCache", std::move(callback));
}

void Domain::CanClearBrowserCookies(base::Callback<void(std::unique_ptr<CanClearBrowserCookiesResult>)> callback) {
  dispatcher_->SendMessage("Network.canClearBrowserCookies", base::Bind(&Domain::HandleCanClearBrowserCookiesResponse, callback));
}

void Domain::ClearBrowserCookies(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.clearBrowserCookies", std::move(callback));
}

void Domain::GetCookies(base::Callback<void(std::unique_ptr<GetCookiesResult>)> callback) {
  dispatcher_->SendMessage("Network.getCookies", base::Bind(&Domain::HandleGetCookiesResponse, callback));
}

void Domain::DeleteCookie(std::unique_ptr<DeleteCookieParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.deleteCookie", params->Serialize(), std::move(callback));
}

void Domain::CanEmulateNetworkConditions(base::Callback<void(std::unique_ptr<CanEmulateNetworkConditionsResult>)> callback) {
  dispatcher_->SendMessage("Network.canEmulateNetworkConditions", base::Bind(&Domain::HandleCanEmulateNetworkConditionsResponse, callback));
}

void Domain::EmulateNetworkConditions(std::unique_ptr<EmulateNetworkConditionsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.emulateNetworkConditions", params->Serialize(), std::move(callback));
}

void Domain::SetCacheDisabled(std::unique_ptr<SetCacheDisabledParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.setCacheDisabled", params->Serialize(), std::move(callback));
}

void Domain::SetDataSizeLimitsForTest(std::unique_ptr<SetDataSizeLimitsForTestParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.setDataSizeLimitsForTest", params->Serialize(), std::move(callback));
}

void Domain::GetCertificateDetails(std::unique_ptr<GetCertificateDetailsParams> params, base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)> callback) {
  dispatcher_->SendMessage("Network.getCertificateDetails", params->Serialize(), base::Bind(&Domain::HandleGetCertificateDetailsResponse, callback));
}

void Domain::ShowCertificateViewer(std::unique_ptr<ShowCertificateViewerParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Network.showCertificateViewer", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleGetResponseBodyResponse(base::Callback<void(std::unique_ptr<GetResponseBodyResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetResponseBodyResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetResponseBodyResult> result = GetResponseBodyResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCanClearBrowserCacheResponse(base::Callback<void(std::unique_ptr<CanClearBrowserCacheResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CanClearBrowserCacheResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CanClearBrowserCacheResult> result = CanClearBrowserCacheResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCanClearBrowserCookiesResponse(base::Callback<void(std::unique_ptr<CanClearBrowserCookiesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CanClearBrowserCookiesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CanClearBrowserCookiesResult> result = CanClearBrowserCookiesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetCookiesResponse(base::Callback<void(std::unique_ptr<GetCookiesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetCookiesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetCookiesResult> result = GetCookiesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCanEmulateNetworkConditionsResponse(base::Callback<void(std::unique_ptr<CanEmulateNetworkConditionsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CanEmulateNetworkConditionsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CanEmulateNetworkConditionsResult> result = CanEmulateNetworkConditionsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetCertificateDetailsResponse(base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetCertificateDetailsResult> result = GetCertificateDetailsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace network

} // namespace headless
