// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_IO_H_
#define HEADLESS_PUBLIC_DOMAINS_IO_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace io {

// Input/Output operations for streams produced by DevTools.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Read a chunk of the stream
  void Read(std::unique_ptr<ReadParams> params, base::Callback<void(std::unique_ptr<ReadResult>)> callback = base::Callback<void(std::unique_ptr<ReadResult>)>());
  void Read(std::string handle, base::Callback<void(std::unique_ptr<ReadResult>)> callback = base::Callback<void(std::unique_ptr<ReadResult>)>());
  // Close the stream, discard any temporary backing storage.
  void Close(std::unique_ptr<CloseParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void Close(std::string handle, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleReadResponse(base::Callback<void(std::unique_ptr<ReadResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace io
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_IO_H_
