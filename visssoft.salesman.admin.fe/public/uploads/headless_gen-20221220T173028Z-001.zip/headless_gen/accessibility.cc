// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/accessibility.h"

#include "base/bind.h"

namespace headless {

namespace accessibility {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::GetAXNode(std::unique_ptr<GetAXNodeParams> params, base::Callback<void(std::unique_ptr<GetAXNodeResult>)> callback) {
  dispatcher_->SendMessage("Accessibility.getAXNode", params->Serialize(), base::Bind(&Domain::HandleGetAXNodeResponse, callback));
}


// static
void Domain::HandleGetAXNodeResponse(base::Callback<void(std::unique_ptr<GetAXNodeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetAXNodeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetAXNodeResult> result = GetAXNodeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace accessibility

} // namespace headless
