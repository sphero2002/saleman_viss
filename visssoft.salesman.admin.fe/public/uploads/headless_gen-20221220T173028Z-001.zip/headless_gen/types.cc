// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/types.h"

#include "base/memory/ptr_util.h"
#include "headless/public/domains/type_conversions.h"

namespace headless {

// ------------- Enum values from types.


namespace inspector {
}  // namespace inspector

namespace memory {

std::unique_ptr<GetDOMCountersResult> GetDOMCountersResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetDOMCountersResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetDOMCountersResult> result(new GetDOMCountersResult());
  errors->Push();
  errors->SetName("GetDOMCountersResult");
  const base::Value* documents_value;
  if (object->Get("documents", &documents_value)) {
    errors->SetName("documents");
    result->documents_ = internal::FromValue<int>::Parse(*documents_value, errors);
  } else {
    errors->AddError("required property missing: documents");
  }
  const base::Value* nodes_value;
  if (object->Get("nodes", &nodes_value)) {
    errors->SetName("nodes");
    result->nodes_ = internal::FromValue<int>::Parse(*nodes_value, errors);
  } else {
    errors->AddError("required property missing: nodes");
  }
  const base::Value* js_event_listeners_value;
  if (object->Get("jsEventListeners", &js_event_listeners_value)) {
    errors->SetName("jsEventListeners");
    result->js_event_listeners_ = internal::FromValue<int>::Parse(*js_event_listeners_value, errors);
  } else {
    errors->AddError("required property missing: jsEventListeners");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetDOMCountersResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("documents", internal::ToValue(documents_));
  result->Set("nodes", internal::ToValue(nodes_));
  result->Set("jsEventListeners", internal::ToValue(js_event_listeners_));
  return std::move(result);
}

std::unique_ptr<GetDOMCountersResult> GetDOMCountersResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetDOMCountersResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetPressureNotificationsSuppressedParams> SetPressureNotificationsSuppressedParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetPressureNotificationsSuppressedParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetPressureNotificationsSuppressedParams> result(new SetPressureNotificationsSuppressedParams());
  errors->Push();
  errors->SetName("SetPressureNotificationsSuppressedParams");
  const base::Value* suppressed_value;
  if (object->Get("suppressed", &suppressed_value)) {
    errors->SetName("suppressed");
    result->suppressed_ = internal::FromValue<bool>::Parse(*suppressed_value, errors);
  } else {
    errors->AddError("required property missing: suppressed");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetPressureNotificationsSuppressedParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("suppressed", internal::ToValue(suppressed_));
  return std::move(result);
}

std::unique_ptr<SetPressureNotificationsSuppressedParams> SetPressureNotificationsSuppressedParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetPressureNotificationsSuppressedParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SimulatePressureNotificationParams> SimulatePressureNotificationParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SimulatePressureNotificationParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SimulatePressureNotificationParams> result(new SimulatePressureNotificationParams());
  errors->Push();
  errors->SetName("SimulatePressureNotificationParams");
  const base::Value* level_value;
  if (object->Get("level", &level_value)) {
    errors->SetName("level");
    result->level_ = internal::FromValue<headless::memory::PressureLevel>::Parse(*level_value, errors);
  } else {
    errors->AddError("required property missing: level");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SimulatePressureNotificationParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("level", internal::ToValue(level_));
  return std::move(result);
}

std::unique_ptr<SimulatePressureNotificationParams> SimulatePressureNotificationParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SimulatePressureNotificationParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace memory

namespace page {

std::unique_ptr<Frame> Frame::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Frame");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Frame> result(new Frame());
  errors->Push();
  errors->SetName("Frame");
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<std::string>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  const base::Value* parent_id_value;
  if (object->Get("parentId", &parent_id_value)) {
    errors->SetName("parentId");
    result->parent_id_ = Just(internal::FromValue<std::string>::Parse(*parent_id_value, errors));
  }
  const base::Value* loader_id_value;
  if (object->Get("loaderId", &loader_id_value)) {
    errors->SetName("loaderId");
    result->loader_id_ = internal::FromValue<std::string>::Parse(*loader_id_value, errors);
  } else {
    errors->AddError("required property missing: loaderId");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = Just(internal::FromValue<std::string>::Parse(*name_value, errors));
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  const base::Value* mime_type_value;
  if (object->Get("mimeType", &mime_type_value)) {
    errors->SetName("mimeType");
    result->mime_type_ = internal::FromValue<std::string>::Parse(*mime_type_value, errors);
  } else {
    errors->AddError("required property missing: mimeType");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Frame::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("id", internal::ToValue(id_));
  if (parent_id_.IsJust())
    result->Set("parentId", internal::ToValue(parent_id_.FromJust()));
  result->Set("loaderId", internal::ToValue(loader_id_));
  if (name_.IsJust())
    result->Set("name", internal::ToValue(name_.FromJust()));
  result->Set("url", internal::ToValue(url_));
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  result->Set("mimeType", internal::ToValue(mime_type_));
  return std::move(result);
}

std::unique_ptr<Frame> Frame::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Frame> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<FrameResource> FrameResource::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("FrameResource");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<FrameResource> result(new FrameResource());
  errors->Push();
  errors->SetName("FrameResource");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::page::ResourceType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* mime_type_value;
  if (object->Get("mimeType", &mime_type_value)) {
    errors->SetName("mimeType");
    result->mime_type_ = internal::FromValue<std::string>::Parse(*mime_type_value, errors);
  } else {
    errors->AddError("required property missing: mimeType");
  }
  const base::Value* failed_value;
  if (object->Get("failed", &failed_value)) {
    errors->SetName("failed");
    result->failed_ = Just(internal::FromValue<bool>::Parse(*failed_value, errors));
  }
  const base::Value* canceled_value;
  if (object->Get("canceled", &canceled_value)) {
    errors->SetName("canceled");
    result->canceled_ = Just(internal::FromValue<bool>::Parse(*canceled_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> FrameResource::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  result->Set("type", internal::ToValue(type_));
  result->Set("mimeType", internal::ToValue(mime_type_));
  if (failed_.IsJust())
    result->Set("failed", internal::ToValue(failed_.FromJust()));
  if (canceled_.IsJust())
    result->Set("canceled", internal::ToValue(canceled_.FromJust()));
  return std::move(result);
}

std::unique_ptr<FrameResource> FrameResource::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<FrameResource> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<FrameResourceTree> FrameResourceTree::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("FrameResourceTree");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<FrameResourceTree> result(new FrameResourceTree());
  errors->Push();
  errors->SetName("FrameResourceTree");
  const base::Value* frame_value;
  if (object->Get("frame", &frame_value)) {
    errors->SetName("frame");
    result->frame_ = internal::FromValue<headless::page::Frame>::Parse(*frame_value, errors);
  } else {
    errors->AddError("required property missing: frame");
  }
  const base::Value* child_frames_value;
  if (object->Get("childFrames", &child_frames_value)) {
    errors->SetName("childFrames");
    result->child_frames_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::page::FrameResourceTree>>>::Parse(*child_frames_value, errors));
  }
  const base::Value* resources_value;
  if (object->Get("resources", &resources_value)) {
    errors->SetName("resources");
    result->resources_ = internal::FromValue<std::vector<std::unique_ptr<headless::page::FrameResource>>>::Parse(*resources_value, errors);
  } else {
    errors->AddError("required property missing: resources");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> FrameResourceTree::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frame", internal::ToValue(*frame_));
  if (child_frames_.IsJust())
    result->Set("childFrames", internal::ToValue(child_frames_.FromJust()));
  result->Set("resources", internal::ToValue(resources_));
  return std::move(result);
}

std::unique_ptr<FrameResourceTree> FrameResourceTree::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<FrameResourceTree> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<NavigationEntry> NavigationEntry::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("NavigationEntry");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<NavigationEntry> result(new NavigationEntry());
  errors->Push();
  errors->SetName("NavigationEntry");
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<int>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* title_value;
  if (object->Get("title", &title_value)) {
    errors->SetName("title");
    result->title_ = internal::FromValue<std::string>::Parse(*title_value, errors);
  } else {
    errors->AddError("required property missing: title");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> NavigationEntry::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("id", internal::ToValue(id_));
  result->Set("url", internal::ToValue(url_));
  result->Set("title", internal::ToValue(title_));
  return std::move(result);
}

std::unique_ptr<NavigationEntry> NavigationEntry::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<NavigationEntry> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ScreencastFrameMetadata> ScreencastFrameMetadata::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ScreencastFrameMetadata");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ScreencastFrameMetadata> result(new ScreencastFrameMetadata());
  errors->Push();
  errors->SetName("ScreencastFrameMetadata");
  const base::Value* offset_top_value;
  if (object->Get("offsetTop", &offset_top_value)) {
    errors->SetName("offsetTop");
    result->offset_top_ = internal::FromValue<double>::Parse(*offset_top_value, errors);
  } else {
    errors->AddError("required property missing: offsetTop");
  }
  const base::Value* page_scale_factor_value;
  if (object->Get("pageScaleFactor", &page_scale_factor_value)) {
    errors->SetName("pageScaleFactor");
    result->page_scale_factor_ = internal::FromValue<double>::Parse(*page_scale_factor_value, errors);
  } else {
    errors->AddError("required property missing: pageScaleFactor");
  }
  const base::Value* device_width_value;
  if (object->Get("deviceWidth", &device_width_value)) {
    errors->SetName("deviceWidth");
    result->device_width_ = internal::FromValue<double>::Parse(*device_width_value, errors);
  } else {
    errors->AddError("required property missing: deviceWidth");
  }
  const base::Value* device_height_value;
  if (object->Get("deviceHeight", &device_height_value)) {
    errors->SetName("deviceHeight");
    result->device_height_ = internal::FromValue<double>::Parse(*device_height_value, errors);
  } else {
    errors->AddError("required property missing: deviceHeight");
  }
  const base::Value* scroll_offsetx_value;
  if (object->Get("scrollOffsetX", &scroll_offsetx_value)) {
    errors->SetName("scrollOffsetX");
    result->scroll_offsetx_ = internal::FromValue<double>::Parse(*scroll_offsetx_value, errors);
  } else {
    errors->AddError("required property missing: scrollOffsetX");
  }
  const base::Value* scroll_offsety_value;
  if (object->Get("scrollOffsetY", &scroll_offsety_value)) {
    errors->SetName("scrollOffsetY");
    result->scroll_offsety_ = internal::FromValue<double>::Parse(*scroll_offsety_value, errors);
  } else {
    errors->AddError("required property missing: scrollOffsetY");
  }
  const base::Value* timestamp_value;
  if (object->Get("timestamp", &timestamp_value)) {
    errors->SetName("timestamp");
    result->timestamp_ = Just(internal::FromValue<double>::Parse(*timestamp_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ScreencastFrameMetadata::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("offsetTop", internal::ToValue(offset_top_));
  result->Set("pageScaleFactor", internal::ToValue(page_scale_factor_));
  result->Set("deviceWidth", internal::ToValue(device_width_));
  result->Set("deviceHeight", internal::ToValue(device_height_));
  result->Set("scrollOffsetX", internal::ToValue(scroll_offsetx_));
  result->Set("scrollOffsetY", internal::ToValue(scroll_offsety_));
  if (timestamp_.IsJust())
    result->Set("timestamp", internal::ToValue(timestamp_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ScreencastFrameMetadata> ScreencastFrameMetadata::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ScreencastFrameMetadata> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AddScriptToEvaluateOnLoadParams> AddScriptToEvaluateOnLoadParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AddScriptToEvaluateOnLoadParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AddScriptToEvaluateOnLoadParams> result(new AddScriptToEvaluateOnLoadParams());
  errors->Push();
  errors->SetName("AddScriptToEvaluateOnLoadParams");
  const base::Value* script_source_value;
  if (object->Get("scriptSource", &script_source_value)) {
    errors->SetName("scriptSource");
    result->script_source_ = internal::FromValue<std::string>::Parse(*script_source_value, errors);
  } else {
    errors->AddError("required property missing: scriptSource");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AddScriptToEvaluateOnLoadParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptSource", internal::ToValue(script_source_));
  return std::move(result);
}

std::unique_ptr<AddScriptToEvaluateOnLoadParams> AddScriptToEvaluateOnLoadParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AddScriptToEvaluateOnLoadParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AddScriptToEvaluateOnLoadResult> AddScriptToEvaluateOnLoadResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AddScriptToEvaluateOnLoadResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AddScriptToEvaluateOnLoadResult> result(new AddScriptToEvaluateOnLoadResult());
  errors->Push();
  errors->SetName("AddScriptToEvaluateOnLoadResult");
  const base::Value* identifier_value;
  if (object->Get("identifier", &identifier_value)) {
    errors->SetName("identifier");
    result->identifier_ = internal::FromValue<std::string>::Parse(*identifier_value, errors);
  } else {
    errors->AddError("required property missing: identifier");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AddScriptToEvaluateOnLoadResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("identifier", internal::ToValue(identifier_));
  return std::move(result);
}

std::unique_ptr<AddScriptToEvaluateOnLoadResult> AddScriptToEvaluateOnLoadResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AddScriptToEvaluateOnLoadResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveScriptToEvaluateOnLoadParams> RemoveScriptToEvaluateOnLoadParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveScriptToEvaluateOnLoadParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveScriptToEvaluateOnLoadParams> result(new RemoveScriptToEvaluateOnLoadParams());
  errors->Push();
  errors->SetName("RemoveScriptToEvaluateOnLoadParams");
  const base::Value* identifier_value;
  if (object->Get("identifier", &identifier_value)) {
    errors->SetName("identifier");
    result->identifier_ = internal::FromValue<std::string>::Parse(*identifier_value, errors);
  } else {
    errors->AddError("required property missing: identifier");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveScriptToEvaluateOnLoadParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("identifier", internal::ToValue(identifier_));
  return std::move(result);
}

std::unique_ptr<RemoveScriptToEvaluateOnLoadParams> RemoveScriptToEvaluateOnLoadParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveScriptToEvaluateOnLoadParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetAutoAttachToCreatedPagesParams> SetAutoAttachToCreatedPagesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetAutoAttachToCreatedPagesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetAutoAttachToCreatedPagesParams> result(new SetAutoAttachToCreatedPagesParams());
  errors->Push();
  errors->SetName("SetAutoAttachToCreatedPagesParams");
  const base::Value* auto_attach_value;
  if (object->Get("autoAttach", &auto_attach_value)) {
    errors->SetName("autoAttach");
    result->auto_attach_ = internal::FromValue<bool>::Parse(*auto_attach_value, errors);
  } else {
    errors->AddError("required property missing: autoAttach");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetAutoAttachToCreatedPagesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("autoAttach", internal::ToValue(auto_attach_));
  return std::move(result);
}

std::unique_ptr<SetAutoAttachToCreatedPagesParams> SetAutoAttachToCreatedPagesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetAutoAttachToCreatedPagesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReloadParams> ReloadParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReloadParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReloadParams> result(new ReloadParams());
  errors->Push();
  errors->SetName("ReloadParams");
  const base::Value* ignore_cache_value;
  if (object->Get("ignoreCache", &ignore_cache_value)) {
    errors->SetName("ignoreCache");
    result->ignore_cache_ = Just(internal::FromValue<bool>::Parse(*ignore_cache_value, errors));
  }
  const base::Value* script_to_evaluate_on_load_value;
  if (object->Get("scriptToEvaluateOnLoad", &script_to_evaluate_on_load_value)) {
    errors->SetName("scriptToEvaluateOnLoad");
    result->script_to_evaluate_on_load_ = Just(internal::FromValue<std::string>::Parse(*script_to_evaluate_on_load_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReloadParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (ignore_cache_.IsJust())
    result->Set("ignoreCache", internal::ToValue(ignore_cache_.FromJust()));
  if (script_to_evaluate_on_load_.IsJust())
    result->Set("scriptToEvaluateOnLoad", internal::ToValue(script_to_evaluate_on_load_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ReloadParams> ReloadParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReloadParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<NavigateParams> NavigateParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("NavigateParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<NavigateParams> result(new NavigateParams());
  errors->Push();
  errors->SetName("NavigateParams");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> NavigateParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<NavigateParams> NavigateParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<NavigateParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<NavigateResult> NavigateResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("NavigateResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<NavigateResult> result(new NavigateResult());
  errors->Push();
  errors->SetName("NavigateResult");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> NavigateResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  return std::move(result);
}

std::unique_ptr<NavigateResult> NavigateResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<NavigateResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetNavigationHistoryResult> GetNavigationHistoryResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetNavigationHistoryResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetNavigationHistoryResult> result(new GetNavigationHistoryResult());
  errors->Push();
  errors->SetName("GetNavigationHistoryResult");
  const base::Value* current_index_value;
  if (object->Get("currentIndex", &current_index_value)) {
    errors->SetName("currentIndex");
    result->current_index_ = internal::FromValue<int>::Parse(*current_index_value, errors);
  } else {
    errors->AddError("required property missing: currentIndex");
  }
  const base::Value* entries_value;
  if (object->Get("entries", &entries_value)) {
    errors->SetName("entries");
    result->entries_ = internal::FromValue<std::vector<std::unique_ptr<headless::page::NavigationEntry>>>::Parse(*entries_value, errors);
  } else {
    errors->AddError("required property missing: entries");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetNavigationHistoryResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("currentIndex", internal::ToValue(current_index_));
  result->Set("entries", internal::ToValue(entries_));
  return std::move(result);
}

std::unique_ptr<GetNavigationHistoryResult> GetNavigationHistoryResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetNavigationHistoryResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<NavigateToHistoryEntryParams> NavigateToHistoryEntryParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("NavigateToHistoryEntryParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<NavigateToHistoryEntryParams> result(new NavigateToHistoryEntryParams());
  errors->Push();
  errors->SetName("NavigateToHistoryEntryParams");
  const base::Value* entry_id_value;
  if (object->Get("entryId", &entry_id_value)) {
    errors->SetName("entryId");
    result->entry_id_ = internal::FromValue<int>::Parse(*entry_id_value, errors);
  } else {
    errors->AddError("required property missing: entryId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> NavigateToHistoryEntryParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("entryId", internal::ToValue(entry_id_));
  return std::move(result);
}

std::unique_ptr<NavigateToHistoryEntryParams> NavigateToHistoryEntryParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<NavigateToHistoryEntryParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCookiesResult> GetCookiesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCookiesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCookiesResult> result(new GetCookiesResult());
  errors->Push();
  errors->SetName("GetCookiesResult");
  const base::Value* cookies_value;
  if (object->Get("cookies", &cookies_value)) {
    errors->SetName("cookies");
    result->cookies_ = internal::FromValue<std::vector<std::unique_ptr<headless::network::Cookie>>>::Parse(*cookies_value, errors);
  } else {
    errors->AddError("required property missing: cookies");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCookiesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cookies", internal::ToValue(cookies_));
  return std::move(result);
}

std::unique_ptr<GetCookiesResult> GetCookiesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCookiesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DeleteCookieParams> DeleteCookieParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DeleteCookieParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DeleteCookieParams> result(new DeleteCookieParams());
  errors->Push();
  errors->SetName("DeleteCookieParams");
  const base::Value* cookie_name_value;
  if (object->Get("cookieName", &cookie_name_value)) {
    errors->SetName("cookieName");
    result->cookie_name_ = internal::FromValue<std::string>::Parse(*cookie_name_value, errors);
  } else {
    errors->AddError("required property missing: cookieName");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DeleteCookieParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cookieName", internal::ToValue(cookie_name_));
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<DeleteCookieParams> DeleteCookieParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DeleteCookieParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetResourceTreeResult> GetResourceTreeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetResourceTreeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetResourceTreeResult> result(new GetResourceTreeResult());
  errors->Push();
  errors->SetName("GetResourceTreeResult");
  const base::Value* frame_tree_value;
  if (object->Get("frameTree", &frame_tree_value)) {
    errors->SetName("frameTree");
    result->frame_tree_ = internal::FromValue<headless::page::FrameResourceTree>::Parse(*frame_tree_value, errors);
  } else {
    errors->AddError("required property missing: frameTree");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetResourceTreeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameTree", internal::ToValue(*frame_tree_));
  return std::move(result);
}

std::unique_ptr<GetResourceTreeResult> GetResourceTreeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetResourceTreeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetResourceContentParams> GetResourceContentParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetResourceContentParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetResourceContentParams> result(new GetResourceContentParams());
  errors->Push();
  errors->SetName("GetResourceContentParams");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetResourceContentParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<GetResourceContentParams> GetResourceContentParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetResourceContentParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetResourceContentResult> GetResourceContentResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetResourceContentResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetResourceContentResult> result(new GetResourceContentResult());
  errors->Push();
  errors->SetName("GetResourceContentResult");
  const base::Value* content_value;
  if (object->Get("content", &content_value)) {
    errors->SetName("content");
    result->content_ = internal::FromValue<std::string>::Parse(*content_value, errors);
  } else {
    errors->AddError("required property missing: content");
  }
  const base::Value* base64_encoded_value;
  if (object->Get("base64Encoded", &base64_encoded_value)) {
    errors->SetName("base64Encoded");
    result->base64_encoded_ = internal::FromValue<bool>::Parse(*base64_encoded_value, errors);
  } else {
    errors->AddError("required property missing: base64Encoded");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetResourceContentResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("content", internal::ToValue(content_));
  result->Set("base64Encoded", internal::ToValue(base64_encoded_));
  return std::move(result);
}

std::unique_ptr<GetResourceContentResult> GetResourceContentResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetResourceContentResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SearchInResourceParams> SearchInResourceParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SearchInResourceParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SearchInResourceParams> result(new SearchInResourceParams());
  errors->Push();
  errors->SetName("SearchInResourceParams");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* query_value;
  if (object->Get("query", &query_value)) {
    errors->SetName("query");
    result->query_ = internal::FromValue<std::string>::Parse(*query_value, errors);
  } else {
    errors->AddError("required property missing: query");
  }
  const base::Value* case_sensitive_value;
  if (object->Get("caseSensitive", &case_sensitive_value)) {
    errors->SetName("caseSensitive");
    result->case_sensitive_ = Just(internal::FromValue<bool>::Parse(*case_sensitive_value, errors));
  }
  const base::Value* is_regex_value;
  if (object->Get("isRegex", &is_regex_value)) {
    errors->SetName("isRegex");
    result->is_regex_ = Just(internal::FromValue<bool>::Parse(*is_regex_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SearchInResourceParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  result->Set("url", internal::ToValue(url_));
  result->Set("query", internal::ToValue(query_));
  if (case_sensitive_.IsJust())
    result->Set("caseSensitive", internal::ToValue(case_sensitive_.FromJust()));
  if (is_regex_.IsJust())
    result->Set("isRegex", internal::ToValue(is_regex_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SearchInResourceParams> SearchInResourceParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SearchInResourceParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SearchInResourceResult> SearchInResourceResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SearchInResourceResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SearchInResourceResult> result(new SearchInResourceResult());
  errors->Push();
  errors->SetName("SearchInResourceResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::SearchMatch>>>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SearchInResourceResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<SearchInResourceResult> SearchInResourceResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SearchInResourceResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetDocumentContentParams> SetDocumentContentParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDocumentContentParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDocumentContentParams> result(new SetDocumentContentParams());
  errors->Push();
  errors->SetName("SetDocumentContentParams");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  const base::Value* html_value;
  if (object->Get("html", &html_value)) {
    errors->SetName("html");
    result->html_ = internal::FromValue<std::string>::Parse(*html_value, errors);
  } else {
    errors->AddError("required property missing: html");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDocumentContentParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  result->Set("html", internal::ToValue(html_));
  return std::move(result);
}

std::unique_ptr<SetDocumentContentParams> SetDocumentContentParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDocumentContentParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetDeviceMetricsOverrideParams> SetDeviceMetricsOverrideParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDeviceMetricsOverrideParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDeviceMetricsOverrideParams> result(new SetDeviceMetricsOverrideParams());
  errors->Push();
  errors->SetName("SetDeviceMetricsOverrideParams");
  const base::Value* width_value;
  if (object->Get("width", &width_value)) {
    errors->SetName("width");
    result->width_ = internal::FromValue<int>::Parse(*width_value, errors);
  } else {
    errors->AddError("required property missing: width");
  }
  const base::Value* height_value;
  if (object->Get("height", &height_value)) {
    errors->SetName("height");
    result->height_ = internal::FromValue<int>::Parse(*height_value, errors);
  } else {
    errors->AddError("required property missing: height");
  }
  const base::Value* device_scale_factor_value;
  if (object->Get("deviceScaleFactor", &device_scale_factor_value)) {
    errors->SetName("deviceScaleFactor");
    result->device_scale_factor_ = internal::FromValue<double>::Parse(*device_scale_factor_value, errors);
  } else {
    errors->AddError("required property missing: deviceScaleFactor");
  }
  const base::Value* mobile_value;
  if (object->Get("mobile", &mobile_value)) {
    errors->SetName("mobile");
    result->mobile_ = internal::FromValue<bool>::Parse(*mobile_value, errors);
  } else {
    errors->AddError("required property missing: mobile");
  }
  const base::Value* fit_window_value;
  if (object->Get("fitWindow", &fit_window_value)) {
    errors->SetName("fitWindow");
    result->fit_window_ = internal::FromValue<bool>::Parse(*fit_window_value, errors);
  } else {
    errors->AddError("required property missing: fitWindow");
  }
  const base::Value* scale_value;
  if (object->Get("scale", &scale_value)) {
    errors->SetName("scale");
    result->scale_ = Just(internal::FromValue<double>::Parse(*scale_value, errors));
  }
  const base::Value* offsetx_value;
  if (object->Get("offsetX", &offsetx_value)) {
    errors->SetName("offsetX");
    result->offsetx_ = Just(internal::FromValue<double>::Parse(*offsetx_value, errors));
  }
  const base::Value* offsety_value;
  if (object->Get("offsetY", &offsety_value)) {
    errors->SetName("offsetY");
    result->offsety_ = Just(internal::FromValue<double>::Parse(*offsety_value, errors));
  }
  const base::Value* screen_width_value;
  if (object->Get("screenWidth", &screen_width_value)) {
    errors->SetName("screenWidth");
    result->screen_width_ = Just(internal::FromValue<int>::Parse(*screen_width_value, errors));
  }
  const base::Value* screen_height_value;
  if (object->Get("screenHeight", &screen_height_value)) {
    errors->SetName("screenHeight");
    result->screen_height_ = Just(internal::FromValue<int>::Parse(*screen_height_value, errors));
  }
  const base::Value* positionx_value;
  if (object->Get("positionX", &positionx_value)) {
    errors->SetName("positionX");
    result->positionx_ = Just(internal::FromValue<int>::Parse(*positionx_value, errors));
  }
  const base::Value* positiony_value;
  if (object->Get("positionY", &positiony_value)) {
    errors->SetName("positionY");
    result->positiony_ = Just(internal::FromValue<int>::Parse(*positiony_value, errors));
  }
  const base::Value* screen_orientation_value;
  if (object->Get("screenOrientation", &screen_orientation_value)) {
    errors->SetName("screenOrientation");
    result->screen_orientation_ = Just(internal::FromValue<headless::emulation::ScreenOrientation>::Parse(*screen_orientation_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDeviceMetricsOverrideParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("width", internal::ToValue(width_));
  result->Set("height", internal::ToValue(height_));
  result->Set("deviceScaleFactor", internal::ToValue(device_scale_factor_));
  result->Set("mobile", internal::ToValue(mobile_));
  result->Set("fitWindow", internal::ToValue(fit_window_));
  if (scale_.IsJust())
    result->Set("scale", internal::ToValue(scale_.FromJust()));
  if (offsetx_.IsJust())
    result->Set("offsetX", internal::ToValue(offsetx_.FromJust()));
  if (offsety_.IsJust())
    result->Set("offsetY", internal::ToValue(offsety_.FromJust()));
  if (screen_width_.IsJust())
    result->Set("screenWidth", internal::ToValue(screen_width_.FromJust()));
  if (screen_height_.IsJust())
    result->Set("screenHeight", internal::ToValue(screen_height_.FromJust()));
  if (positionx_.IsJust())
    result->Set("positionX", internal::ToValue(positionx_.FromJust()));
  if (positiony_.IsJust())
    result->Set("positionY", internal::ToValue(positiony_.FromJust()));
  if (screen_orientation_.IsJust())
    result->Set("screenOrientation", internal::ToValue(*screen_orientation_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetDeviceMetricsOverrideParams> SetDeviceMetricsOverrideParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDeviceMetricsOverrideParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetGeolocationOverrideParams> SetGeolocationOverrideParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetGeolocationOverrideParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetGeolocationOverrideParams> result(new SetGeolocationOverrideParams());
  errors->Push();
  errors->SetName("SetGeolocationOverrideParams");
  const base::Value* latitude_value;
  if (object->Get("latitude", &latitude_value)) {
    errors->SetName("latitude");
    result->latitude_ = Just(internal::FromValue<double>::Parse(*latitude_value, errors));
  }
  const base::Value* longitude_value;
  if (object->Get("longitude", &longitude_value)) {
    errors->SetName("longitude");
    result->longitude_ = Just(internal::FromValue<double>::Parse(*longitude_value, errors));
  }
  const base::Value* accuracy_value;
  if (object->Get("accuracy", &accuracy_value)) {
    errors->SetName("accuracy");
    result->accuracy_ = Just(internal::FromValue<double>::Parse(*accuracy_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetGeolocationOverrideParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (latitude_.IsJust())
    result->Set("latitude", internal::ToValue(latitude_.FromJust()));
  if (longitude_.IsJust())
    result->Set("longitude", internal::ToValue(longitude_.FromJust()));
  if (accuracy_.IsJust())
    result->Set("accuracy", internal::ToValue(accuracy_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetGeolocationOverrideParams> SetGeolocationOverrideParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetGeolocationOverrideParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetDeviceOrientationOverrideParams> SetDeviceOrientationOverrideParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDeviceOrientationOverrideParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDeviceOrientationOverrideParams> result(new SetDeviceOrientationOverrideParams());
  errors->Push();
  errors->SetName("SetDeviceOrientationOverrideParams");
  const base::Value* alpha_value;
  if (object->Get("alpha", &alpha_value)) {
    errors->SetName("alpha");
    result->alpha_ = internal::FromValue<double>::Parse(*alpha_value, errors);
  } else {
    errors->AddError("required property missing: alpha");
  }
  const base::Value* beta_value;
  if (object->Get("beta", &beta_value)) {
    errors->SetName("beta");
    result->beta_ = internal::FromValue<double>::Parse(*beta_value, errors);
  } else {
    errors->AddError("required property missing: beta");
  }
  const base::Value* gamma_value;
  if (object->Get("gamma", &gamma_value)) {
    errors->SetName("gamma");
    result->gamma_ = internal::FromValue<double>::Parse(*gamma_value, errors);
  } else {
    errors->AddError("required property missing: gamma");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDeviceOrientationOverrideParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("alpha", internal::ToValue(alpha_));
  result->Set("beta", internal::ToValue(beta_));
  result->Set("gamma", internal::ToValue(gamma_));
  return std::move(result);
}

std::unique_ptr<SetDeviceOrientationOverrideParams> SetDeviceOrientationOverrideParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDeviceOrientationOverrideParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetTouchEmulationEnabledParams> SetTouchEmulationEnabledParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetTouchEmulationEnabledParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetTouchEmulationEnabledParams> result(new SetTouchEmulationEnabledParams());
  errors->Push();
  errors->SetName("SetTouchEmulationEnabledParams");
  const base::Value* enabled_value;
  if (object->Get("enabled", &enabled_value)) {
    errors->SetName("enabled");
    result->enabled_ = internal::FromValue<bool>::Parse(*enabled_value, errors);
  } else {
    errors->AddError("required property missing: enabled");
  }
  const base::Value* configuration_value;
  if (object->Get("configuration", &configuration_value)) {
    errors->SetName("configuration");
    result->configuration_ = Just(internal::FromValue<headless::page::SetTouchEmulationEnabledConfiguration>::Parse(*configuration_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetTouchEmulationEnabledParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("enabled", internal::ToValue(enabled_));
  if (configuration_.IsJust())
    result->Set("configuration", internal::ToValue(configuration_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetTouchEmulationEnabledParams> SetTouchEmulationEnabledParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetTouchEmulationEnabledParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CaptureScreenshotResult> CaptureScreenshotResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CaptureScreenshotResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CaptureScreenshotResult> result(new CaptureScreenshotResult());
  errors->Push();
  errors->SetName("CaptureScreenshotResult");
  const base::Value* data_value;
  if (object->Get("data", &data_value)) {
    errors->SetName("data");
    result->data_ = internal::FromValue<std::string>::Parse(*data_value, errors);
  } else {
    errors->AddError("required property missing: data");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CaptureScreenshotResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("data", internal::ToValue(data_));
  return std::move(result);
}

std::unique_ptr<CaptureScreenshotResult> CaptureScreenshotResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CaptureScreenshotResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StartScreencastParams> StartScreencastParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StartScreencastParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StartScreencastParams> result(new StartScreencastParams());
  errors->Push();
  errors->SetName("StartScreencastParams");
  const base::Value* format_value;
  if (object->Get("format", &format_value)) {
    errors->SetName("format");
    result->format_ = Just(internal::FromValue<headless::page::StartScreencastFormat>::Parse(*format_value, errors));
  }
  const base::Value* quality_value;
  if (object->Get("quality", &quality_value)) {
    errors->SetName("quality");
    result->quality_ = Just(internal::FromValue<int>::Parse(*quality_value, errors));
  }
  const base::Value* max_width_value;
  if (object->Get("maxWidth", &max_width_value)) {
    errors->SetName("maxWidth");
    result->max_width_ = Just(internal::FromValue<int>::Parse(*max_width_value, errors));
  }
  const base::Value* max_height_value;
  if (object->Get("maxHeight", &max_height_value)) {
    errors->SetName("maxHeight");
    result->max_height_ = Just(internal::FromValue<int>::Parse(*max_height_value, errors));
  }
  const base::Value* every_nth_frame_value;
  if (object->Get("everyNthFrame", &every_nth_frame_value)) {
    errors->SetName("everyNthFrame");
    result->every_nth_frame_ = Just(internal::FromValue<int>::Parse(*every_nth_frame_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StartScreencastParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (format_.IsJust())
    result->Set("format", internal::ToValue(format_.FromJust()));
  if (quality_.IsJust())
    result->Set("quality", internal::ToValue(quality_.FromJust()));
  if (max_width_.IsJust())
    result->Set("maxWidth", internal::ToValue(max_width_.FromJust()));
  if (max_height_.IsJust())
    result->Set("maxHeight", internal::ToValue(max_height_.FromJust()));
  if (every_nth_frame_.IsJust())
    result->Set("everyNthFrame", internal::ToValue(every_nth_frame_.FromJust()));
  return std::move(result);
}

std::unique_ptr<StartScreencastParams> StartScreencastParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StartScreencastParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ScreencastFrameAckParams> ScreencastFrameAckParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ScreencastFrameAckParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ScreencastFrameAckParams> result(new ScreencastFrameAckParams());
  errors->Push();
  errors->SetName("ScreencastFrameAckParams");
  const base::Value* session_id_value;
  if (object->Get("sessionId", &session_id_value)) {
    errors->SetName("sessionId");
    result->session_id_ = internal::FromValue<int>::Parse(*session_id_value, errors);
  } else {
    errors->AddError("required property missing: sessionId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ScreencastFrameAckParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("sessionId", internal::ToValue(session_id_));
  return std::move(result);
}

std::unique_ptr<ScreencastFrameAckParams> ScreencastFrameAckParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ScreencastFrameAckParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<HandleJavaScriptDialogParams> HandleJavaScriptDialogParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("HandleJavaScriptDialogParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<HandleJavaScriptDialogParams> result(new HandleJavaScriptDialogParams());
  errors->Push();
  errors->SetName("HandleJavaScriptDialogParams");
  const base::Value* accept_value;
  if (object->Get("accept", &accept_value)) {
    errors->SetName("accept");
    result->accept_ = internal::FromValue<bool>::Parse(*accept_value, errors);
  } else {
    errors->AddError("required property missing: accept");
  }
  const base::Value* prompt_text_value;
  if (object->Get("promptText", &prompt_text_value)) {
    errors->SetName("promptText");
    result->prompt_text_ = Just(internal::FromValue<std::string>::Parse(*prompt_text_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> HandleJavaScriptDialogParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("accept", internal::ToValue(accept_));
  if (prompt_text_.IsJust())
    result->Set("promptText", internal::ToValue(prompt_text_.FromJust()));
  return std::move(result);
}

std::unique_ptr<HandleJavaScriptDialogParams> HandleJavaScriptDialogParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<HandleJavaScriptDialogParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetColorPickerEnabledParams> SetColorPickerEnabledParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetColorPickerEnabledParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetColorPickerEnabledParams> result(new SetColorPickerEnabledParams());
  errors->Push();
  errors->SetName("SetColorPickerEnabledParams");
  const base::Value* enabled_value;
  if (object->Get("enabled", &enabled_value)) {
    errors->SetName("enabled");
    result->enabled_ = internal::FromValue<bool>::Parse(*enabled_value, errors);
  } else {
    errors->AddError("required property missing: enabled");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetColorPickerEnabledParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("enabled", internal::ToValue(enabled_));
  return std::move(result);
}

std::unique_ptr<SetColorPickerEnabledParams> SetColorPickerEnabledParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetColorPickerEnabledParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetOverlayMessageParams> SetOverlayMessageParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetOverlayMessageParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetOverlayMessageParams> result(new SetOverlayMessageParams());
  errors->Push();
  errors->SetName("SetOverlayMessageParams");
  const base::Value* message_value;
  if (object->Get("message", &message_value)) {
    errors->SetName("message");
    result->message_ = Just(internal::FromValue<std::string>::Parse(*message_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetOverlayMessageParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (message_.IsJust())
    result->Set("message", internal::ToValue(message_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetOverlayMessageParams> SetOverlayMessageParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetOverlayMessageParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace page

namespace rendering {

std::unique_ptr<SetShowPaintRectsParams> SetShowPaintRectsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetShowPaintRectsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetShowPaintRectsParams> result(new SetShowPaintRectsParams());
  errors->Push();
  errors->SetName("SetShowPaintRectsParams");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<bool>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetShowPaintRectsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<SetShowPaintRectsParams> SetShowPaintRectsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetShowPaintRectsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetShowDebugBordersParams> SetShowDebugBordersParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetShowDebugBordersParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetShowDebugBordersParams> result(new SetShowDebugBordersParams());
  errors->Push();
  errors->SetName("SetShowDebugBordersParams");
  const base::Value* show_value;
  if (object->Get("show", &show_value)) {
    errors->SetName("show");
    result->show_ = internal::FromValue<bool>::Parse(*show_value, errors);
  } else {
    errors->AddError("required property missing: show");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetShowDebugBordersParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("show", internal::ToValue(show_));
  return std::move(result);
}

std::unique_ptr<SetShowDebugBordersParams> SetShowDebugBordersParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetShowDebugBordersParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetShowFPSCounterParams> SetShowFPSCounterParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetShowFPSCounterParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetShowFPSCounterParams> result(new SetShowFPSCounterParams());
  errors->Push();
  errors->SetName("SetShowFPSCounterParams");
  const base::Value* show_value;
  if (object->Get("show", &show_value)) {
    errors->SetName("show");
    result->show_ = internal::FromValue<bool>::Parse(*show_value, errors);
  } else {
    errors->AddError("required property missing: show");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetShowFPSCounterParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("show", internal::ToValue(show_));
  return std::move(result);
}

std::unique_ptr<SetShowFPSCounterParams> SetShowFPSCounterParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetShowFPSCounterParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetShowScrollBottleneckRectsParams> SetShowScrollBottleneckRectsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetShowScrollBottleneckRectsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetShowScrollBottleneckRectsParams> result(new SetShowScrollBottleneckRectsParams());
  errors->Push();
  errors->SetName("SetShowScrollBottleneckRectsParams");
  const base::Value* show_value;
  if (object->Get("show", &show_value)) {
    errors->SetName("show");
    result->show_ = internal::FromValue<bool>::Parse(*show_value, errors);
  } else {
    errors->AddError("required property missing: show");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetShowScrollBottleneckRectsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("show", internal::ToValue(show_));
  return std::move(result);
}

std::unique_ptr<SetShowScrollBottleneckRectsParams> SetShowScrollBottleneckRectsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetShowScrollBottleneckRectsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetShowViewportSizeOnResizeParams> SetShowViewportSizeOnResizeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetShowViewportSizeOnResizeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetShowViewportSizeOnResizeParams> result(new SetShowViewportSizeOnResizeParams());
  errors->Push();
  errors->SetName("SetShowViewportSizeOnResizeParams");
  const base::Value* show_value;
  if (object->Get("show", &show_value)) {
    errors->SetName("show");
    result->show_ = internal::FromValue<bool>::Parse(*show_value, errors);
  } else {
    errors->AddError("required property missing: show");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetShowViewportSizeOnResizeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("show", internal::ToValue(show_));
  return std::move(result);
}

std::unique_ptr<SetShowViewportSizeOnResizeParams> SetShowViewportSizeOnResizeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetShowViewportSizeOnResizeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace rendering

namespace emulation {

std::unique_ptr<ScreenOrientation> ScreenOrientation::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ScreenOrientation");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ScreenOrientation> result(new ScreenOrientation());
  errors->Push();
  errors->SetName("ScreenOrientation");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::emulation::ScreenOrientationType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* angle_value;
  if (object->Get("angle", &angle_value)) {
    errors->SetName("angle");
    result->angle_ = internal::FromValue<int>::Parse(*angle_value, errors);
  } else {
    errors->AddError("required property missing: angle");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ScreenOrientation::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  result->Set("angle", internal::ToValue(angle_));
  return std::move(result);
}

std::unique_ptr<ScreenOrientation> ScreenOrientation::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ScreenOrientation> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetDeviceMetricsOverrideParams> SetDeviceMetricsOverrideParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDeviceMetricsOverrideParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDeviceMetricsOverrideParams> result(new SetDeviceMetricsOverrideParams());
  errors->Push();
  errors->SetName("SetDeviceMetricsOverrideParams");
  const base::Value* width_value;
  if (object->Get("width", &width_value)) {
    errors->SetName("width");
    result->width_ = internal::FromValue<int>::Parse(*width_value, errors);
  } else {
    errors->AddError("required property missing: width");
  }
  const base::Value* height_value;
  if (object->Get("height", &height_value)) {
    errors->SetName("height");
    result->height_ = internal::FromValue<int>::Parse(*height_value, errors);
  } else {
    errors->AddError("required property missing: height");
  }
  const base::Value* device_scale_factor_value;
  if (object->Get("deviceScaleFactor", &device_scale_factor_value)) {
    errors->SetName("deviceScaleFactor");
    result->device_scale_factor_ = internal::FromValue<double>::Parse(*device_scale_factor_value, errors);
  } else {
    errors->AddError("required property missing: deviceScaleFactor");
  }
  const base::Value* mobile_value;
  if (object->Get("mobile", &mobile_value)) {
    errors->SetName("mobile");
    result->mobile_ = internal::FromValue<bool>::Parse(*mobile_value, errors);
  } else {
    errors->AddError("required property missing: mobile");
  }
  const base::Value* fit_window_value;
  if (object->Get("fitWindow", &fit_window_value)) {
    errors->SetName("fitWindow");
    result->fit_window_ = internal::FromValue<bool>::Parse(*fit_window_value, errors);
  } else {
    errors->AddError("required property missing: fitWindow");
  }
  const base::Value* scale_value;
  if (object->Get("scale", &scale_value)) {
    errors->SetName("scale");
    result->scale_ = Just(internal::FromValue<double>::Parse(*scale_value, errors));
  }
  const base::Value* offsetx_value;
  if (object->Get("offsetX", &offsetx_value)) {
    errors->SetName("offsetX");
    result->offsetx_ = Just(internal::FromValue<double>::Parse(*offsetx_value, errors));
  }
  const base::Value* offsety_value;
  if (object->Get("offsetY", &offsety_value)) {
    errors->SetName("offsetY");
    result->offsety_ = Just(internal::FromValue<double>::Parse(*offsety_value, errors));
  }
  const base::Value* screen_width_value;
  if (object->Get("screenWidth", &screen_width_value)) {
    errors->SetName("screenWidth");
    result->screen_width_ = Just(internal::FromValue<int>::Parse(*screen_width_value, errors));
  }
  const base::Value* screen_height_value;
  if (object->Get("screenHeight", &screen_height_value)) {
    errors->SetName("screenHeight");
    result->screen_height_ = Just(internal::FromValue<int>::Parse(*screen_height_value, errors));
  }
  const base::Value* positionx_value;
  if (object->Get("positionX", &positionx_value)) {
    errors->SetName("positionX");
    result->positionx_ = Just(internal::FromValue<int>::Parse(*positionx_value, errors));
  }
  const base::Value* positiony_value;
  if (object->Get("positionY", &positiony_value)) {
    errors->SetName("positionY");
    result->positiony_ = Just(internal::FromValue<int>::Parse(*positiony_value, errors));
  }
  const base::Value* screen_orientation_value;
  if (object->Get("screenOrientation", &screen_orientation_value)) {
    errors->SetName("screenOrientation");
    result->screen_orientation_ = Just(internal::FromValue<headless::emulation::ScreenOrientation>::Parse(*screen_orientation_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDeviceMetricsOverrideParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("width", internal::ToValue(width_));
  result->Set("height", internal::ToValue(height_));
  result->Set("deviceScaleFactor", internal::ToValue(device_scale_factor_));
  result->Set("mobile", internal::ToValue(mobile_));
  result->Set("fitWindow", internal::ToValue(fit_window_));
  if (scale_.IsJust())
    result->Set("scale", internal::ToValue(scale_.FromJust()));
  if (offsetx_.IsJust())
    result->Set("offsetX", internal::ToValue(offsetx_.FromJust()));
  if (offsety_.IsJust())
    result->Set("offsetY", internal::ToValue(offsety_.FromJust()));
  if (screen_width_.IsJust())
    result->Set("screenWidth", internal::ToValue(screen_width_.FromJust()));
  if (screen_height_.IsJust())
    result->Set("screenHeight", internal::ToValue(screen_height_.FromJust()));
  if (positionx_.IsJust())
    result->Set("positionX", internal::ToValue(positionx_.FromJust()));
  if (positiony_.IsJust())
    result->Set("positionY", internal::ToValue(positiony_.FromJust()));
  if (screen_orientation_.IsJust())
    result->Set("screenOrientation", internal::ToValue(*screen_orientation_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetDeviceMetricsOverrideParams> SetDeviceMetricsOverrideParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDeviceMetricsOverrideParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetPageScaleFactorParams> SetPageScaleFactorParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetPageScaleFactorParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetPageScaleFactorParams> result(new SetPageScaleFactorParams());
  errors->Push();
  errors->SetName("SetPageScaleFactorParams");
  const base::Value* page_scale_factor_value;
  if (object->Get("pageScaleFactor", &page_scale_factor_value)) {
    errors->SetName("pageScaleFactor");
    result->page_scale_factor_ = internal::FromValue<double>::Parse(*page_scale_factor_value, errors);
  } else {
    errors->AddError("required property missing: pageScaleFactor");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetPageScaleFactorParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("pageScaleFactor", internal::ToValue(page_scale_factor_));
  return std::move(result);
}

std::unique_ptr<SetPageScaleFactorParams> SetPageScaleFactorParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetPageScaleFactorParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetScriptExecutionDisabledParams> SetScriptExecutionDisabledParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetScriptExecutionDisabledParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetScriptExecutionDisabledParams> result(new SetScriptExecutionDisabledParams());
  errors->Push();
  errors->SetName("SetScriptExecutionDisabledParams");
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<bool>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetScriptExecutionDisabledParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<SetScriptExecutionDisabledParams> SetScriptExecutionDisabledParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetScriptExecutionDisabledParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetGeolocationOverrideParams> SetGeolocationOverrideParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetGeolocationOverrideParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetGeolocationOverrideParams> result(new SetGeolocationOverrideParams());
  errors->Push();
  errors->SetName("SetGeolocationOverrideParams");
  const base::Value* latitude_value;
  if (object->Get("latitude", &latitude_value)) {
    errors->SetName("latitude");
    result->latitude_ = Just(internal::FromValue<double>::Parse(*latitude_value, errors));
  }
  const base::Value* longitude_value;
  if (object->Get("longitude", &longitude_value)) {
    errors->SetName("longitude");
    result->longitude_ = Just(internal::FromValue<double>::Parse(*longitude_value, errors));
  }
  const base::Value* accuracy_value;
  if (object->Get("accuracy", &accuracy_value)) {
    errors->SetName("accuracy");
    result->accuracy_ = Just(internal::FromValue<double>::Parse(*accuracy_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetGeolocationOverrideParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (latitude_.IsJust())
    result->Set("latitude", internal::ToValue(latitude_.FromJust()));
  if (longitude_.IsJust())
    result->Set("longitude", internal::ToValue(longitude_.FromJust()));
  if (accuracy_.IsJust())
    result->Set("accuracy", internal::ToValue(accuracy_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetGeolocationOverrideParams> SetGeolocationOverrideParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetGeolocationOverrideParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetTouchEmulationEnabledParams> SetTouchEmulationEnabledParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetTouchEmulationEnabledParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetTouchEmulationEnabledParams> result(new SetTouchEmulationEnabledParams());
  errors->Push();
  errors->SetName("SetTouchEmulationEnabledParams");
  const base::Value* enabled_value;
  if (object->Get("enabled", &enabled_value)) {
    errors->SetName("enabled");
    result->enabled_ = internal::FromValue<bool>::Parse(*enabled_value, errors);
  } else {
    errors->AddError("required property missing: enabled");
  }
  const base::Value* configuration_value;
  if (object->Get("configuration", &configuration_value)) {
    errors->SetName("configuration");
    result->configuration_ = Just(internal::FromValue<headless::emulation::SetTouchEmulationEnabledConfiguration>::Parse(*configuration_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetTouchEmulationEnabledParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("enabled", internal::ToValue(enabled_));
  if (configuration_.IsJust())
    result->Set("configuration", internal::ToValue(configuration_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetTouchEmulationEnabledParams> SetTouchEmulationEnabledParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetTouchEmulationEnabledParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetEmulatedMediaParams> SetEmulatedMediaParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetEmulatedMediaParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetEmulatedMediaParams> result(new SetEmulatedMediaParams());
  errors->Push();
  errors->SetName("SetEmulatedMediaParams");
  const base::Value* media_value;
  if (object->Get("media", &media_value)) {
    errors->SetName("media");
    result->media_ = internal::FromValue<std::string>::Parse(*media_value, errors);
  } else {
    errors->AddError("required property missing: media");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetEmulatedMediaParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("media", internal::ToValue(media_));
  return std::move(result);
}

std::unique_ptr<SetEmulatedMediaParams> SetEmulatedMediaParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetEmulatedMediaParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetCPUThrottlingRateParams> SetCPUThrottlingRateParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetCPUThrottlingRateParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetCPUThrottlingRateParams> result(new SetCPUThrottlingRateParams());
  errors->Push();
  errors->SetName("SetCPUThrottlingRateParams");
  const base::Value* rate_value;
  if (object->Get("rate", &rate_value)) {
    errors->SetName("rate");
    result->rate_ = internal::FromValue<double>::Parse(*rate_value, errors);
  } else {
    errors->AddError("required property missing: rate");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetCPUThrottlingRateParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("rate", internal::ToValue(rate_));
  return std::move(result);
}

std::unique_ptr<SetCPUThrottlingRateParams> SetCPUThrottlingRateParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetCPUThrottlingRateParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CanEmulateResult> CanEmulateResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CanEmulateResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CanEmulateResult> result(new CanEmulateResult());
  errors->Push();
  errors->SetName("CanEmulateResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<bool>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CanEmulateResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<CanEmulateResult> CanEmulateResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CanEmulateResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace emulation

namespace runtime {

std::unique_ptr<RemoteObject> RemoteObject::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoteObject");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoteObject> result(new RemoteObject());
  errors->Push();
  errors->SetName("RemoteObject");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::runtime::RemoteObjectType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* subtype_value;
  if (object->Get("subtype", &subtype_value)) {
    errors->SetName("subtype");
    result->subtype_ = Just(internal::FromValue<headless::runtime::RemoteObjectSubtype>::Parse(*subtype_value, errors));
  }
  const base::Value* class_name_value;
  if (object->Get("className", &class_name_value)) {
    errors->SetName("className");
    result->class_name_ = Just(internal::FromValue<std::string>::Parse(*class_name_value, errors));
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<base::Value>::Parse(*value_value, errors));
  }
  const base::Value* description_value;
  if (object->Get("description", &description_value)) {
    errors->SetName("description");
    result->description_ = Just(internal::FromValue<std::string>::Parse(*description_value, errors));
  }
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = Just(internal::FromValue<std::string>::Parse(*object_id_value, errors));
  }
  const base::Value* preview_value;
  if (object->Get("preview", &preview_value)) {
    errors->SetName("preview");
    result->preview_ = Just(internal::FromValue<headless::runtime::ObjectPreview>::Parse(*preview_value, errors));
  }
  const base::Value* custom_preview_value;
  if (object->Get("customPreview", &custom_preview_value)) {
    errors->SetName("customPreview");
    result->custom_preview_ = Just(internal::FromValue<headless::runtime::CustomPreview>::Parse(*custom_preview_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoteObject::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (subtype_.IsJust())
    result->Set("subtype", internal::ToValue(subtype_.FromJust()));
  if (class_name_.IsJust())
    result->Set("className", internal::ToValue(class_name_.FromJust()));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(*value_.FromJust()));
  if (description_.IsJust())
    result->Set("description", internal::ToValue(description_.FromJust()));
  if (object_id_.IsJust())
    result->Set("objectId", internal::ToValue(object_id_.FromJust()));
  if (preview_.IsJust())
    result->Set("preview", internal::ToValue(*preview_.FromJust()));
  if (custom_preview_.IsJust())
    result->Set("customPreview", internal::ToValue(*custom_preview_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RemoteObject> RemoteObject::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoteObject> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CustomPreview> CustomPreview::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CustomPreview");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CustomPreview> result(new CustomPreview());
  errors->Push();
  errors->SetName("CustomPreview");
  const base::Value* header_value;
  if (object->Get("header", &header_value)) {
    errors->SetName("header");
    result->header_ = internal::FromValue<std::string>::Parse(*header_value, errors);
  } else {
    errors->AddError("required property missing: header");
  }
  const base::Value* has_body_value;
  if (object->Get("hasBody", &has_body_value)) {
    errors->SetName("hasBody");
    result->has_body_ = internal::FromValue<bool>::Parse(*has_body_value, errors);
  } else {
    errors->AddError("required property missing: hasBody");
  }
  const base::Value* formatter_object_id_value;
  if (object->Get("formatterObjectId", &formatter_object_id_value)) {
    errors->SetName("formatterObjectId");
    result->formatter_object_id_ = internal::FromValue<std::string>::Parse(*formatter_object_id_value, errors);
  } else {
    errors->AddError("required property missing: formatterObjectId");
  }
  const base::Value* config_object_id_value;
  if (object->Get("configObjectId", &config_object_id_value)) {
    errors->SetName("configObjectId");
    result->config_object_id_ = Just(internal::FromValue<std::string>::Parse(*config_object_id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CustomPreview::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("header", internal::ToValue(header_));
  result->Set("hasBody", internal::ToValue(has_body_));
  result->Set("formatterObjectId", internal::ToValue(formatter_object_id_));
  if (config_object_id_.IsJust())
    result->Set("configObjectId", internal::ToValue(config_object_id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CustomPreview> CustomPreview::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CustomPreview> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ObjectPreview> ObjectPreview::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ObjectPreview");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ObjectPreview> result(new ObjectPreview());
  errors->Push();
  errors->SetName("ObjectPreview");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::runtime::ObjectPreviewType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* subtype_value;
  if (object->Get("subtype", &subtype_value)) {
    errors->SetName("subtype");
    result->subtype_ = Just(internal::FromValue<headless::runtime::ObjectPreviewSubtype>::Parse(*subtype_value, errors));
  }
  const base::Value* description_value;
  if (object->Get("description", &description_value)) {
    errors->SetName("description");
    result->description_ = Just(internal::FromValue<std::string>::Parse(*description_value, errors));
  }
  const base::Value* lossless_value;
  if (object->Get("lossless", &lossless_value)) {
    errors->SetName("lossless");
    result->lossless_ = internal::FromValue<bool>::Parse(*lossless_value, errors);
  } else {
    errors->AddError("required property missing: lossless");
  }
  const base::Value* overflow_value;
  if (object->Get("overflow", &overflow_value)) {
    errors->SetName("overflow");
    result->overflow_ = internal::FromValue<bool>::Parse(*overflow_value, errors);
  } else {
    errors->AddError("required property missing: overflow");
  }
  const base::Value* properties_value;
  if (object->Get("properties", &properties_value)) {
    errors->SetName("properties");
    result->properties_ = internal::FromValue<std::vector<std::unique_ptr<headless::runtime::PropertyPreview>>>::Parse(*properties_value, errors);
  } else {
    errors->AddError("required property missing: properties");
  }
  const base::Value* entries_value;
  if (object->Get("entries", &entries_value)) {
    errors->SetName("entries");
    result->entries_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::runtime::EntryPreview>>>::Parse(*entries_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ObjectPreview::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (subtype_.IsJust())
    result->Set("subtype", internal::ToValue(subtype_.FromJust()));
  if (description_.IsJust())
    result->Set("description", internal::ToValue(description_.FromJust()));
  result->Set("lossless", internal::ToValue(lossless_));
  result->Set("overflow", internal::ToValue(overflow_));
  result->Set("properties", internal::ToValue(properties_));
  if (entries_.IsJust())
    result->Set("entries", internal::ToValue(entries_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ObjectPreview> ObjectPreview::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ObjectPreview> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PropertyPreview> PropertyPreview::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PropertyPreview");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PropertyPreview> result(new PropertyPreview());
  errors->Push();
  errors->SetName("PropertyPreview");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::runtime::PropertyPreviewType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<std::string>::Parse(*value_value, errors));
  }
  const base::Value* value_preview_value;
  if (object->Get("valuePreview", &value_preview_value)) {
    errors->SetName("valuePreview");
    result->value_preview_ = Just(internal::FromValue<headless::runtime::ObjectPreview>::Parse(*value_preview_value, errors));
  }
  const base::Value* subtype_value;
  if (object->Get("subtype", &subtype_value)) {
    errors->SetName("subtype");
    result->subtype_ = Just(internal::FromValue<headless::runtime::PropertyPreviewSubtype>::Parse(*subtype_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PropertyPreview::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("type", internal::ToValue(type_));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(value_.FromJust()));
  if (value_preview_.IsJust())
    result->Set("valuePreview", internal::ToValue(*value_preview_.FromJust()));
  if (subtype_.IsJust())
    result->Set("subtype", internal::ToValue(subtype_.FromJust()));
  return std::move(result);
}

std::unique_ptr<PropertyPreview> PropertyPreview::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PropertyPreview> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EntryPreview> EntryPreview::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EntryPreview");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EntryPreview> result(new EntryPreview());
  errors->Push();
  errors->SetName("EntryPreview");
  const base::Value* key_value;
  if (object->Get("key", &key_value)) {
    errors->SetName("key");
    result->key_ = Just(internal::FromValue<headless::runtime::ObjectPreview>::Parse(*key_value, errors));
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<headless::runtime::ObjectPreview>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EntryPreview::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (key_.IsJust())
    result->Set("key", internal::ToValue(*key_.FromJust()));
  result->Set("value", internal::ToValue(*value_));
  return std::move(result);
}

std::unique_ptr<EntryPreview> EntryPreview::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EntryPreview> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PropertyDescriptor> PropertyDescriptor::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PropertyDescriptor");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PropertyDescriptor> result(new PropertyDescriptor());
  errors->Push();
  errors->SetName("PropertyDescriptor");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*value_value, errors));
  }
  const base::Value* writable_value;
  if (object->Get("writable", &writable_value)) {
    errors->SetName("writable");
    result->writable_ = Just(internal::FromValue<bool>::Parse(*writable_value, errors));
  }
  const base::Value* get_value;
  if (object->Get("get", &get_value)) {
    errors->SetName("get");
    result->get_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*get_value, errors));
  }
  const base::Value* set_value;
  if (object->Get("set", &set_value)) {
    errors->SetName("set");
    result->set_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*set_value, errors));
  }
  const base::Value* configurable_value;
  if (object->Get("configurable", &configurable_value)) {
    errors->SetName("configurable");
    result->configurable_ = internal::FromValue<bool>::Parse(*configurable_value, errors);
  } else {
    errors->AddError("required property missing: configurable");
  }
  const base::Value* enumerable_value;
  if (object->Get("enumerable", &enumerable_value)) {
    errors->SetName("enumerable");
    result->enumerable_ = internal::FromValue<bool>::Parse(*enumerable_value, errors);
  } else {
    errors->AddError("required property missing: enumerable");
  }
  const base::Value* was_thrown_value;
  if (object->Get("wasThrown", &was_thrown_value)) {
    errors->SetName("wasThrown");
    result->was_thrown_ = Just(internal::FromValue<bool>::Parse(*was_thrown_value, errors));
  }
  const base::Value* is_own_value;
  if (object->Get("isOwn", &is_own_value)) {
    errors->SetName("isOwn");
    result->is_own_ = Just(internal::FromValue<bool>::Parse(*is_own_value, errors));
  }
  const base::Value* symbol_value;
  if (object->Get("symbol", &symbol_value)) {
    errors->SetName("symbol");
    result->symbol_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*symbol_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PropertyDescriptor::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(*value_.FromJust()));
  if (writable_.IsJust())
    result->Set("writable", internal::ToValue(writable_.FromJust()));
  if (get_.IsJust())
    result->Set("get", internal::ToValue(*get_.FromJust()));
  if (set_.IsJust())
    result->Set("set", internal::ToValue(*set_.FromJust()));
  result->Set("configurable", internal::ToValue(configurable_));
  result->Set("enumerable", internal::ToValue(enumerable_));
  if (was_thrown_.IsJust())
    result->Set("wasThrown", internal::ToValue(was_thrown_.FromJust()));
  if (is_own_.IsJust())
    result->Set("isOwn", internal::ToValue(is_own_.FromJust()));
  if (symbol_.IsJust())
    result->Set("symbol", internal::ToValue(*symbol_.FromJust()));
  return std::move(result);
}

std::unique_ptr<PropertyDescriptor> PropertyDescriptor::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PropertyDescriptor> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<InternalPropertyDescriptor> InternalPropertyDescriptor::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("InternalPropertyDescriptor");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<InternalPropertyDescriptor> result(new InternalPropertyDescriptor());
  errors->Push();
  errors->SetName("InternalPropertyDescriptor");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*value_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> InternalPropertyDescriptor::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(*value_.FromJust()));
  return std::move(result);
}

std::unique_ptr<InternalPropertyDescriptor> InternalPropertyDescriptor::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<InternalPropertyDescriptor> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CallArgument> CallArgument::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CallArgument");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CallArgument> result(new CallArgument());
  errors->Push();
  errors->SetName("CallArgument");
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<base::Value>::Parse(*value_value, errors));
  }
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = Just(internal::FromValue<std::string>::Parse(*object_id_value, errors));
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = Just(internal::FromValue<headless::runtime::CallArgumentType>::Parse(*type_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CallArgument::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (value_.IsJust())
    result->Set("value", internal::ToValue(*value_.FromJust()));
  if (object_id_.IsJust())
    result->Set("objectId", internal::ToValue(object_id_.FromJust()));
  if (type_.IsJust())
    result->Set("type", internal::ToValue(type_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CallArgument> CallArgument::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CallArgument> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ExecutionContextDescription> ExecutionContextDescription::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ExecutionContextDescription");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ExecutionContextDescription> result(new ExecutionContextDescription());
  errors->Push();
  errors->SetName("ExecutionContextDescription");
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<int>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  const base::Value* is_default_value;
  if (object->Get("isDefault", &is_default_value)) {
    errors->SetName("isDefault");
    result->is_default_ = internal::FromValue<bool>::Parse(*is_default_value, errors);
  } else {
    errors->AddError("required property missing: isDefault");
  }
  const base::Value* origin_value;
  if (object->Get("origin", &origin_value)) {
    errors->SetName("origin");
    result->origin_ = internal::FromValue<std::string>::Parse(*origin_value, errors);
  } else {
    errors->AddError("required property missing: origin");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ExecutionContextDescription::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("id", internal::ToValue(id_));
  result->Set("isDefault", internal::ToValue(is_default_));
  result->Set("origin", internal::ToValue(origin_));
  result->Set("name", internal::ToValue(name_));
  result->Set("frameId", internal::ToValue(frame_id_));
  return std::move(result);
}

std::unique_ptr<ExecutionContextDescription> ExecutionContextDescription::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ExecutionContextDescription> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ExceptionDetails> ExceptionDetails::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ExceptionDetails");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ExceptionDetails> result(new ExceptionDetails());
  errors->Push();
  errors->SetName("ExceptionDetails");
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = Just(internal::FromValue<std::string>::Parse(*url_value, errors));
  }
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = Just(internal::FromValue<std::string>::Parse(*script_id_value, errors));
  }
  const base::Value* line_value;
  if (object->Get("line", &line_value)) {
    errors->SetName("line");
    result->line_ = Just(internal::FromValue<int>::Parse(*line_value, errors));
  }
  const base::Value* column_value;
  if (object->Get("column", &column_value)) {
    errors->SetName("column");
    result->column_ = Just(internal::FromValue<int>::Parse(*column_value, errors));
  }
  const base::Value* stack_value;
  if (object->Get("stack", &stack_value)) {
    errors->SetName("stack");
    result->stack_ = Just(internal::FromValue<headless::runtime::StackTrace>::Parse(*stack_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ExceptionDetails::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("text", internal::ToValue(text_));
  if (url_.IsJust())
    result->Set("url", internal::ToValue(url_.FromJust()));
  if (script_id_.IsJust())
    result->Set("scriptId", internal::ToValue(script_id_.FromJust()));
  if (line_.IsJust())
    result->Set("line", internal::ToValue(line_.FromJust()));
  if (column_.IsJust())
    result->Set("column", internal::ToValue(column_.FromJust()));
  if (stack_.IsJust())
    result->Set("stack", internal::ToValue(*stack_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ExceptionDetails> ExceptionDetails::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ExceptionDetails> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CallFrame> CallFrame::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CallFrame");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CallFrame> result(new CallFrame());
  errors->Push();
  errors->SetName("CallFrame");
  const base::Value* function_name_value;
  if (object->Get("functionName", &function_name_value)) {
    errors->SetName("functionName");
    result->function_name_ = internal::FromValue<std::string>::Parse(*function_name_value, errors);
  } else {
    errors->AddError("required property missing: functionName");
  }
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<int>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* column_number_value;
  if (object->Get("columnNumber", &column_number_value)) {
    errors->SetName("columnNumber");
    result->column_number_ = internal::FromValue<int>::Parse(*column_number_value, errors);
  } else {
    errors->AddError("required property missing: columnNumber");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CallFrame::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("functionName", internal::ToValue(function_name_));
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("url", internal::ToValue(url_));
  result->Set("lineNumber", internal::ToValue(line_number_));
  result->Set("columnNumber", internal::ToValue(column_number_));
  return std::move(result);
}

std::unique_ptr<CallFrame> CallFrame::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CallFrame> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StackTrace> StackTrace::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StackTrace");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StackTrace> result(new StackTrace());
  errors->Push();
  errors->SetName("StackTrace");
  const base::Value* description_value;
  if (object->Get("description", &description_value)) {
    errors->SetName("description");
    result->description_ = Just(internal::FromValue<std::string>::Parse(*description_value, errors));
  }
  const base::Value* call_frames_value;
  if (object->Get("callFrames", &call_frames_value)) {
    errors->SetName("callFrames");
    result->call_frames_ = internal::FromValue<std::vector<std::unique_ptr<headless::runtime::CallFrame>>>::Parse(*call_frames_value, errors);
  } else {
    errors->AddError("required property missing: callFrames");
  }
  const base::Value* parent_value;
  if (object->Get("parent", &parent_value)) {
    errors->SetName("parent");
    result->parent_ = Just(internal::FromValue<headless::runtime::StackTrace>::Parse(*parent_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StackTrace::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (description_.IsJust())
    result->Set("description", internal::ToValue(description_.FromJust()));
  result->Set("callFrames", internal::ToValue(call_frames_));
  if (parent_.IsJust())
    result->Set("parent", internal::ToValue(*parent_.FromJust()));
  return std::move(result);
}

std::unique_ptr<StackTrace> StackTrace::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StackTrace> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EvaluateParams> EvaluateParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EvaluateParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EvaluateParams> result(new EvaluateParams());
  errors->Push();
  errors->SetName("EvaluateParams");
  const base::Value* expression_value;
  if (object->Get("expression", &expression_value)) {
    errors->SetName("expression");
    result->expression_ = internal::FromValue<std::string>::Parse(*expression_value, errors);
  } else {
    errors->AddError("required property missing: expression");
  }
  const base::Value* object_group_value;
  if (object->Get("objectGroup", &object_group_value)) {
    errors->SetName("objectGroup");
    result->object_group_ = Just(internal::FromValue<std::string>::Parse(*object_group_value, errors));
  }
  const base::Value* include_command_lineapi_value;
  if (object->Get("includeCommandLineAPI", &include_command_lineapi_value)) {
    errors->SetName("includeCommandLineAPI");
    result->include_command_lineapi_ = Just(internal::FromValue<bool>::Parse(*include_command_lineapi_value, errors));
  }
  const base::Value* do_not_pause_on_exceptions_and_mute_console_value;
  if (object->Get("doNotPauseOnExceptionsAndMuteConsole", &do_not_pause_on_exceptions_and_mute_console_value)) {
    errors->SetName("doNotPauseOnExceptionsAndMuteConsole");
    result->do_not_pause_on_exceptions_and_mute_console_ = Just(internal::FromValue<bool>::Parse(*do_not_pause_on_exceptions_and_mute_console_value, errors));
  }
  const base::Value* context_id_value;
  if (object->Get("contextId", &context_id_value)) {
    errors->SetName("contextId");
    result->context_id_ = Just(internal::FromValue<int>::Parse(*context_id_value, errors));
  }
  const base::Value* return_by_value_value;
  if (object->Get("returnByValue", &return_by_value_value)) {
    errors->SetName("returnByValue");
    result->return_by_value_ = Just(internal::FromValue<bool>::Parse(*return_by_value_value, errors));
  }
  const base::Value* generate_preview_value;
  if (object->Get("generatePreview", &generate_preview_value)) {
    errors->SetName("generatePreview");
    result->generate_preview_ = Just(internal::FromValue<bool>::Parse(*generate_preview_value, errors));
  }
  const base::Value* user_gesture_value;
  if (object->Get("userGesture", &user_gesture_value)) {
    errors->SetName("userGesture");
    result->user_gesture_ = Just(internal::FromValue<bool>::Parse(*user_gesture_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EvaluateParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("expression", internal::ToValue(expression_));
  if (object_group_.IsJust())
    result->Set("objectGroup", internal::ToValue(object_group_.FromJust()));
  if (include_command_lineapi_.IsJust())
    result->Set("includeCommandLineAPI", internal::ToValue(include_command_lineapi_.FromJust()));
  if (do_not_pause_on_exceptions_and_mute_console_.IsJust())
    result->Set("doNotPauseOnExceptionsAndMuteConsole", internal::ToValue(do_not_pause_on_exceptions_and_mute_console_.FromJust()));
  if (context_id_.IsJust())
    result->Set("contextId", internal::ToValue(context_id_.FromJust()));
  if (return_by_value_.IsJust())
    result->Set("returnByValue", internal::ToValue(return_by_value_.FromJust()));
  if (generate_preview_.IsJust())
    result->Set("generatePreview", internal::ToValue(generate_preview_.FromJust()));
  if (user_gesture_.IsJust())
    result->Set("userGesture", internal::ToValue(user_gesture_.FromJust()));
  return std::move(result);
}

std::unique_ptr<EvaluateParams> EvaluateParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EvaluateParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EvaluateResult> EvaluateResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EvaluateResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EvaluateResult> result(new EvaluateResult());
  errors->Push();
  errors->SetName("EvaluateResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  const base::Value* was_thrown_value;
  if (object->Get("wasThrown", &was_thrown_value)) {
    errors->SetName("wasThrown");
    result->was_thrown_ = Just(internal::FromValue<bool>::Parse(*was_thrown_value, errors));
  }
  const base::Value* exception_details_value;
  if (object->Get("exceptionDetails", &exception_details_value)) {
    errors->SetName("exceptionDetails");
    result->exception_details_ = Just(internal::FromValue<headless::runtime::ExceptionDetails>::Parse(*exception_details_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EvaluateResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(*result_));
  if (was_thrown_.IsJust())
    result->Set("wasThrown", internal::ToValue(was_thrown_.FromJust()));
  if (exception_details_.IsJust())
    result->Set("exceptionDetails", internal::ToValue(*exception_details_.FromJust()));
  return std::move(result);
}

std::unique_ptr<EvaluateResult> EvaluateResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EvaluateResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CallFunctionOnParams> CallFunctionOnParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CallFunctionOnParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CallFunctionOnParams> result(new CallFunctionOnParams());
  errors->Push();
  errors->SetName("CallFunctionOnParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  const base::Value* function_declaration_value;
  if (object->Get("functionDeclaration", &function_declaration_value)) {
    errors->SetName("functionDeclaration");
    result->function_declaration_ = internal::FromValue<std::string>::Parse(*function_declaration_value, errors);
  } else {
    errors->AddError("required property missing: functionDeclaration");
  }
  const base::Value* arguments_value;
  if (object->Get("arguments", &arguments_value)) {
    errors->SetName("arguments");
    result->arguments_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::runtime::CallArgument>>>::Parse(*arguments_value, errors));
  }
  const base::Value* do_not_pause_on_exceptions_and_mute_console_value;
  if (object->Get("doNotPauseOnExceptionsAndMuteConsole", &do_not_pause_on_exceptions_and_mute_console_value)) {
    errors->SetName("doNotPauseOnExceptionsAndMuteConsole");
    result->do_not_pause_on_exceptions_and_mute_console_ = Just(internal::FromValue<bool>::Parse(*do_not_pause_on_exceptions_and_mute_console_value, errors));
  }
  const base::Value* return_by_value_value;
  if (object->Get("returnByValue", &return_by_value_value)) {
    errors->SetName("returnByValue");
    result->return_by_value_ = Just(internal::FromValue<bool>::Parse(*return_by_value_value, errors));
  }
  const base::Value* generate_preview_value;
  if (object->Get("generatePreview", &generate_preview_value)) {
    errors->SetName("generatePreview");
    result->generate_preview_ = Just(internal::FromValue<bool>::Parse(*generate_preview_value, errors));
  }
  const base::Value* user_gesture_value;
  if (object->Get("userGesture", &user_gesture_value)) {
    errors->SetName("userGesture");
    result->user_gesture_ = Just(internal::FromValue<bool>::Parse(*user_gesture_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CallFunctionOnParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  result->Set("functionDeclaration", internal::ToValue(function_declaration_));
  if (arguments_.IsJust())
    result->Set("arguments", internal::ToValue(arguments_.FromJust()));
  if (do_not_pause_on_exceptions_and_mute_console_.IsJust())
    result->Set("doNotPauseOnExceptionsAndMuteConsole", internal::ToValue(do_not_pause_on_exceptions_and_mute_console_.FromJust()));
  if (return_by_value_.IsJust())
    result->Set("returnByValue", internal::ToValue(return_by_value_.FromJust()));
  if (generate_preview_.IsJust())
    result->Set("generatePreview", internal::ToValue(generate_preview_.FromJust()));
  if (user_gesture_.IsJust())
    result->Set("userGesture", internal::ToValue(user_gesture_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CallFunctionOnParams> CallFunctionOnParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CallFunctionOnParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CallFunctionOnResult> CallFunctionOnResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CallFunctionOnResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CallFunctionOnResult> result(new CallFunctionOnResult());
  errors->Push();
  errors->SetName("CallFunctionOnResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  const base::Value* was_thrown_value;
  if (object->Get("wasThrown", &was_thrown_value)) {
    errors->SetName("wasThrown");
    result->was_thrown_ = Just(internal::FromValue<bool>::Parse(*was_thrown_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CallFunctionOnResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(*result_));
  if (was_thrown_.IsJust())
    result->Set("wasThrown", internal::ToValue(was_thrown_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CallFunctionOnResult> CallFunctionOnResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CallFunctionOnResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetPropertiesParams> GetPropertiesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetPropertiesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetPropertiesParams> result(new GetPropertiesParams());
  errors->Push();
  errors->SetName("GetPropertiesParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  const base::Value* own_properties_value;
  if (object->Get("ownProperties", &own_properties_value)) {
    errors->SetName("ownProperties");
    result->own_properties_ = Just(internal::FromValue<bool>::Parse(*own_properties_value, errors));
  }
  const base::Value* accessor_properties_only_value;
  if (object->Get("accessorPropertiesOnly", &accessor_properties_only_value)) {
    errors->SetName("accessorPropertiesOnly");
    result->accessor_properties_only_ = Just(internal::FromValue<bool>::Parse(*accessor_properties_only_value, errors));
  }
  const base::Value* generate_preview_value;
  if (object->Get("generatePreview", &generate_preview_value)) {
    errors->SetName("generatePreview");
    result->generate_preview_ = Just(internal::FromValue<bool>::Parse(*generate_preview_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetPropertiesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  if (own_properties_.IsJust())
    result->Set("ownProperties", internal::ToValue(own_properties_.FromJust()));
  if (accessor_properties_only_.IsJust())
    result->Set("accessorPropertiesOnly", internal::ToValue(accessor_properties_only_.FromJust()));
  if (generate_preview_.IsJust())
    result->Set("generatePreview", internal::ToValue(generate_preview_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetPropertiesParams> GetPropertiesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetPropertiesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetPropertiesResult> GetPropertiesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetPropertiesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetPropertiesResult> result(new GetPropertiesResult());
  errors->Push();
  errors->SetName("GetPropertiesResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<std::vector<std::unique_ptr<headless::runtime::PropertyDescriptor>>>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  const base::Value* internal_properties_value;
  if (object->Get("internalProperties", &internal_properties_value)) {
    errors->SetName("internalProperties");
    result->internal_properties_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::runtime::InternalPropertyDescriptor>>>::Parse(*internal_properties_value, errors));
  }
  const base::Value* exception_details_value;
  if (object->Get("exceptionDetails", &exception_details_value)) {
    errors->SetName("exceptionDetails");
    result->exception_details_ = Just(internal::FromValue<headless::runtime::ExceptionDetails>::Parse(*exception_details_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetPropertiesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  if (internal_properties_.IsJust())
    result->Set("internalProperties", internal::ToValue(internal_properties_.FromJust()));
  if (exception_details_.IsJust())
    result->Set("exceptionDetails", internal::ToValue(*exception_details_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetPropertiesResult> GetPropertiesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetPropertiesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReleaseObjectParams> ReleaseObjectParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReleaseObjectParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReleaseObjectParams> result(new ReleaseObjectParams());
  errors->Push();
  errors->SetName("ReleaseObjectParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReleaseObjectParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  return std::move(result);
}

std::unique_ptr<ReleaseObjectParams> ReleaseObjectParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReleaseObjectParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReleaseObjectGroupParams> ReleaseObjectGroupParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReleaseObjectGroupParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReleaseObjectGroupParams> result(new ReleaseObjectGroupParams());
  errors->Push();
  errors->SetName("ReleaseObjectGroupParams");
  const base::Value* object_group_value;
  if (object->Get("objectGroup", &object_group_value)) {
    errors->SetName("objectGroup");
    result->object_group_ = internal::FromValue<std::string>::Parse(*object_group_value, errors);
  } else {
    errors->AddError("required property missing: objectGroup");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReleaseObjectGroupParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectGroup", internal::ToValue(object_group_));
  return std::move(result);
}

std::unique_ptr<ReleaseObjectGroupParams> ReleaseObjectGroupParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReleaseObjectGroupParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetCustomObjectFormatterEnabledParams> SetCustomObjectFormatterEnabledParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetCustomObjectFormatterEnabledParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetCustomObjectFormatterEnabledParams> result(new SetCustomObjectFormatterEnabledParams());
  errors->Push();
  errors->SetName("SetCustomObjectFormatterEnabledParams");
  const base::Value* enabled_value;
  if (object->Get("enabled", &enabled_value)) {
    errors->SetName("enabled");
    result->enabled_ = internal::FromValue<bool>::Parse(*enabled_value, errors);
  } else {
    errors->AddError("required property missing: enabled");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetCustomObjectFormatterEnabledParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("enabled", internal::ToValue(enabled_));
  return std::move(result);
}

std::unique_ptr<SetCustomObjectFormatterEnabledParams> SetCustomObjectFormatterEnabledParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetCustomObjectFormatterEnabledParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CompileScriptParams> CompileScriptParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CompileScriptParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CompileScriptParams> result(new CompileScriptParams());
  errors->Push();
  errors->SetName("CompileScriptParams");
  const base::Value* expression_value;
  if (object->Get("expression", &expression_value)) {
    errors->SetName("expression");
    result->expression_ = internal::FromValue<std::string>::Parse(*expression_value, errors);
  } else {
    errors->AddError("required property missing: expression");
  }
  const base::Value* sourceurl_value;
  if (object->Get("sourceURL", &sourceurl_value)) {
    errors->SetName("sourceURL");
    result->sourceurl_ = internal::FromValue<std::string>::Parse(*sourceurl_value, errors);
  } else {
    errors->AddError("required property missing: sourceURL");
  }
  const base::Value* persist_script_value;
  if (object->Get("persistScript", &persist_script_value)) {
    errors->SetName("persistScript");
    result->persist_script_ = internal::FromValue<bool>::Parse(*persist_script_value, errors);
  } else {
    errors->AddError("required property missing: persistScript");
  }
  const base::Value* execution_context_id_value;
  if (object->Get("executionContextId", &execution_context_id_value)) {
    errors->SetName("executionContextId");
    result->execution_context_id_ = internal::FromValue<int>::Parse(*execution_context_id_value, errors);
  } else {
    errors->AddError("required property missing: executionContextId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CompileScriptParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("expression", internal::ToValue(expression_));
  result->Set("sourceURL", internal::ToValue(sourceurl_));
  result->Set("persistScript", internal::ToValue(persist_script_));
  result->Set("executionContextId", internal::ToValue(execution_context_id_));
  return std::move(result);
}

std::unique_ptr<CompileScriptParams> CompileScriptParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CompileScriptParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CompileScriptResult> CompileScriptResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CompileScriptResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CompileScriptResult> result(new CompileScriptResult());
  errors->Push();
  errors->SetName("CompileScriptResult");
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = Just(internal::FromValue<std::string>::Parse(*script_id_value, errors));
  }
  const base::Value* exception_details_value;
  if (object->Get("exceptionDetails", &exception_details_value)) {
    errors->SetName("exceptionDetails");
    result->exception_details_ = Just(internal::FromValue<headless::runtime::ExceptionDetails>::Parse(*exception_details_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CompileScriptResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (script_id_.IsJust())
    result->Set("scriptId", internal::ToValue(script_id_.FromJust()));
  if (exception_details_.IsJust())
    result->Set("exceptionDetails", internal::ToValue(*exception_details_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CompileScriptResult> CompileScriptResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CompileScriptResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RunScriptParams> RunScriptParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RunScriptParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RunScriptParams> result(new RunScriptParams());
  errors->Push();
  errors->SetName("RunScriptParams");
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* execution_context_id_value;
  if (object->Get("executionContextId", &execution_context_id_value)) {
    errors->SetName("executionContextId");
    result->execution_context_id_ = internal::FromValue<int>::Parse(*execution_context_id_value, errors);
  } else {
    errors->AddError("required property missing: executionContextId");
  }
  const base::Value* object_group_value;
  if (object->Get("objectGroup", &object_group_value)) {
    errors->SetName("objectGroup");
    result->object_group_ = Just(internal::FromValue<std::string>::Parse(*object_group_value, errors));
  }
  const base::Value* do_not_pause_on_exceptions_and_mute_console_value;
  if (object->Get("doNotPauseOnExceptionsAndMuteConsole", &do_not_pause_on_exceptions_and_mute_console_value)) {
    errors->SetName("doNotPauseOnExceptionsAndMuteConsole");
    result->do_not_pause_on_exceptions_and_mute_console_ = Just(internal::FromValue<bool>::Parse(*do_not_pause_on_exceptions_and_mute_console_value, errors));
  }
  const base::Value* include_command_lineapi_value;
  if (object->Get("includeCommandLineAPI", &include_command_lineapi_value)) {
    errors->SetName("includeCommandLineAPI");
    result->include_command_lineapi_ = Just(internal::FromValue<bool>::Parse(*include_command_lineapi_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RunScriptParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("executionContextId", internal::ToValue(execution_context_id_));
  if (object_group_.IsJust())
    result->Set("objectGroup", internal::ToValue(object_group_.FromJust()));
  if (do_not_pause_on_exceptions_and_mute_console_.IsJust())
    result->Set("doNotPauseOnExceptionsAndMuteConsole", internal::ToValue(do_not_pause_on_exceptions_and_mute_console_.FromJust()));
  if (include_command_lineapi_.IsJust())
    result->Set("includeCommandLineAPI", internal::ToValue(include_command_lineapi_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RunScriptParams> RunScriptParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RunScriptParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RunScriptResult> RunScriptResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RunScriptResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RunScriptResult> result(new RunScriptResult());
  errors->Push();
  errors->SetName("RunScriptResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  const base::Value* exception_details_value;
  if (object->Get("exceptionDetails", &exception_details_value)) {
    errors->SetName("exceptionDetails");
    result->exception_details_ = Just(internal::FromValue<headless::runtime::ExceptionDetails>::Parse(*exception_details_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RunScriptResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(*result_));
  if (exception_details_.IsJust())
    result->Set("exceptionDetails", internal::ToValue(*exception_details_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RunScriptResult> RunScriptResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RunScriptResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace runtime

namespace console {

std::unique_ptr<ConsoleMessage> ConsoleMessage::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ConsoleMessage");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ConsoleMessage> result(new ConsoleMessage());
  errors->Push();
  errors->SetName("ConsoleMessage");
  const base::Value* source_value;
  if (object->Get("source", &source_value)) {
    errors->SetName("source");
    result->source_ = internal::FromValue<headless::console::ConsoleMessageSource>::Parse(*source_value, errors);
  } else {
    errors->AddError("required property missing: source");
  }
  const base::Value* level_value;
  if (object->Get("level", &level_value)) {
    errors->SetName("level");
    result->level_ = internal::FromValue<headless::console::ConsoleMessageLevel>::Parse(*level_value, errors);
  } else {
    errors->AddError("required property missing: level");
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = Just(internal::FromValue<headless::console::ConsoleMessageType>::Parse(*type_value, errors));
  }
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = Just(internal::FromValue<std::string>::Parse(*script_id_value, errors));
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = Just(internal::FromValue<std::string>::Parse(*url_value, errors));
  }
  const base::Value* line_value;
  if (object->Get("line", &line_value)) {
    errors->SetName("line");
    result->line_ = Just(internal::FromValue<int>::Parse(*line_value, errors));
  }
  const base::Value* column_value;
  if (object->Get("column", &column_value)) {
    errors->SetName("column");
    result->column_ = Just(internal::FromValue<int>::Parse(*column_value, errors));
  }
  const base::Value* repeat_count_value;
  if (object->Get("repeatCount", &repeat_count_value)) {
    errors->SetName("repeatCount");
    result->repeat_count_ = Just(internal::FromValue<int>::Parse(*repeat_count_value, errors));
  }
  const base::Value* parameters_value;
  if (object->Get("parameters", &parameters_value)) {
    errors->SetName("parameters");
    result->parameters_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::runtime::RemoteObject>>>::Parse(*parameters_value, errors));
  }
  const base::Value* stack_value;
  if (object->Get("stack", &stack_value)) {
    errors->SetName("stack");
    result->stack_ = Just(internal::FromValue<headless::runtime::StackTrace>::Parse(*stack_value, errors));
  }
  const base::Value* network_request_id_value;
  if (object->Get("networkRequestId", &network_request_id_value)) {
    errors->SetName("networkRequestId");
    result->network_request_id_ = Just(internal::FromValue<std::string>::Parse(*network_request_id_value, errors));
  }
  const base::Value* timestamp_value;
  if (object->Get("timestamp", &timestamp_value)) {
    errors->SetName("timestamp");
    result->timestamp_ = internal::FromValue<double>::Parse(*timestamp_value, errors);
  } else {
    errors->AddError("required property missing: timestamp");
  }
  const base::Value* execution_context_id_value;
  if (object->Get("executionContextId", &execution_context_id_value)) {
    errors->SetName("executionContextId");
    result->execution_context_id_ = Just(internal::FromValue<int>::Parse(*execution_context_id_value, errors));
  }
  const base::Value* message_id_value;
  if (object->Get("messageId", &message_id_value)) {
    errors->SetName("messageId");
    result->message_id_ = Just(internal::FromValue<int>::Parse(*message_id_value, errors));
  }
  const base::Value* related_message_id_value;
  if (object->Get("relatedMessageId", &related_message_id_value)) {
    errors->SetName("relatedMessageId");
    result->related_message_id_ = Just(internal::FromValue<int>::Parse(*related_message_id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ConsoleMessage::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("source", internal::ToValue(source_));
  result->Set("level", internal::ToValue(level_));
  result->Set("text", internal::ToValue(text_));
  if (type_.IsJust())
    result->Set("type", internal::ToValue(type_.FromJust()));
  if (script_id_.IsJust())
    result->Set("scriptId", internal::ToValue(script_id_.FromJust()));
  if (url_.IsJust())
    result->Set("url", internal::ToValue(url_.FromJust()));
  if (line_.IsJust())
    result->Set("line", internal::ToValue(line_.FromJust()));
  if (column_.IsJust())
    result->Set("column", internal::ToValue(column_.FromJust()));
  if (repeat_count_.IsJust())
    result->Set("repeatCount", internal::ToValue(repeat_count_.FromJust()));
  if (parameters_.IsJust())
    result->Set("parameters", internal::ToValue(parameters_.FromJust()));
  if (stack_.IsJust())
    result->Set("stack", internal::ToValue(*stack_.FromJust()));
  if (network_request_id_.IsJust())
    result->Set("networkRequestId", internal::ToValue(network_request_id_.FromJust()));
  result->Set("timestamp", internal::ToValue(timestamp_));
  if (execution_context_id_.IsJust())
    result->Set("executionContextId", internal::ToValue(execution_context_id_.FromJust()));
  if (message_id_.IsJust())
    result->Set("messageId", internal::ToValue(message_id_.FromJust()));
  if (related_message_id_.IsJust())
    result->Set("relatedMessageId", internal::ToValue(related_message_id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ConsoleMessage> ConsoleMessage::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ConsoleMessage> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace console

namespace security {

std::unique_ptr<SecurityStateExplanation> SecurityStateExplanation::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SecurityStateExplanation");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SecurityStateExplanation> result(new SecurityStateExplanation());
  errors->Push();
  errors->SetName("SecurityStateExplanation");
  const base::Value* security_state_value;
  if (object->Get("securityState", &security_state_value)) {
    errors->SetName("securityState");
    result->security_state_ = internal::FromValue<headless::security::SecurityState>::Parse(*security_state_value, errors);
  } else {
    errors->AddError("required property missing: securityState");
  }
  const base::Value* summary_value;
  if (object->Get("summary", &summary_value)) {
    errors->SetName("summary");
    result->summary_ = internal::FromValue<std::string>::Parse(*summary_value, errors);
  } else {
    errors->AddError("required property missing: summary");
  }
  const base::Value* description_value;
  if (object->Get("description", &description_value)) {
    errors->SetName("description");
    result->description_ = internal::FromValue<std::string>::Parse(*description_value, errors);
  } else {
    errors->AddError("required property missing: description");
  }
  const base::Value* certificate_id_value;
  if (object->Get("certificateId", &certificate_id_value)) {
    errors->SetName("certificateId");
    result->certificate_id_ = Just(internal::FromValue<int>::Parse(*certificate_id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SecurityStateExplanation::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("securityState", internal::ToValue(security_state_));
  result->Set("summary", internal::ToValue(summary_));
  result->Set("description", internal::ToValue(description_));
  if (certificate_id_.IsJust())
    result->Set("certificateId", internal::ToValue(certificate_id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SecurityStateExplanation> SecurityStateExplanation::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SecurityStateExplanation> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MixedContentStatus> MixedContentStatus::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MixedContentStatus");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MixedContentStatus> result(new MixedContentStatus());
  errors->Push();
  errors->SetName("MixedContentStatus");
  const base::Value* ran_insecure_content_value;
  if (object->Get("ranInsecureContent", &ran_insecure_content_value)) {
    errors->SetName("ranInsecureContent");
    result->ran_insecure_content_ = internal::FromValue<bool>::Parse(*ran_insecure_content_value, errors);
  } else {
    errors->AddError("required property missing: ranInsecureContent");
  }
  const base::Value* displayed_insecure_content_value;
  if (object->Get("displayedInsecureContent", &displayed_insecure_content_value)) {
    errors->SetName("displayedInsecureContent");
    result->displayed_insecure_content_ = internal::FromValue<bool>::Parse(*displayed_insecure_content_value, errors);
  } else {
    errors->AddError("required property missing: displayedInsecureContent");
  }
  const base::Value* ran_insecure_content_style_value;
  if (object->Get("ranInsecureContentStyle", &ran_insecure_content_style_value)) {
    errors->SetName("ranInsecureContentStyle");
    result->ran_insecure_content_style_ = internal::FromValue<headless::security::SecurityState>::Parse(*ran_insecure_content_style_value, errors);
  } else {
    errors->AddError("required property missing: ranInsecureContentStyle");
  }
  const base::Value* displayed_insecure_content_style_value;
  if (object->Get("displayedInsecureContentStyle", &displayed_insecure_content_style_value)) {
    errors->SetName("displayedInsecureContentStyle");
    result->displayed_insecure_content_style_ = internal::FromValue<headless::security::SecurityState>::Parse(*displayed_insecure_content_style_value, errors);
  } else {
    errors->AddError("required property missing: displayedInsecureContentStyle");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MixedContentStatus::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("ranInsecureContent", internal::ToValue(ran_insecure_content_));
  result->Set("displayedInsecureContent", internal::ToValue(displayed_insecure_content_));
  result->Set("ranInsecureContentStyle", internal::ToValue(ran_insecure_content_style_));
  result->Set("displayedInsecureContentStyle", internal::ToValue(displayed_insecure_content_style_));
  return std::move(result);
}

std::unique_ptr<MixedContentStatus> MixedContentStatus::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MixedContentStatus> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace security

namespace network {

std::unique_ptr<ResourceTiming> ResourceTiming::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ResourceTiming");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ResourceTiming> result(new ResourceTiming());
  errors->Push();
  errors->SetName("ResourceTiming");
  const base::Value* request_time_value;
  if (object->Get("requestTime", &request_time_value)) {
    errors->SetName("requestTime");
    result->request_time_ = internal::FromValue<double>::Parse(*request_time_value, errors);
  } else {
    errors->AddError("required property missing: requestTime");
  }
  const base::Value* proxy_start_value;
  if (object->Get("proxyStart", &proxy_start_value)) {
    errors->SetName("proxyStart");
    result->proxy_start_ = internal::FromValue<double>::Parse(*proxy_start_value, errors);
  } else {
    errors->AddError("required property missing: proxyStart");
  }
  const base::Value* proxy_end_value;
  if (object->Get("proxyEnd", &proxy_end_value)) {
    errors->SetName("proxyEnd");
    result->proxy_end_ = internal::FromValue<double>::Parse(*proxy_end_value, errors);
  } else {
    errors->AddError("required property missing: proxyEnd");
  }
  const base::Value* dns_start_value;
  if (object->Get("dnsStart", &dns_start_value)) {
    errors->SetName("dnsStart");
    result->dns_start_ = internal::FromValue<double>::Parse(*dns_start_value, errors);
  } else {
    errors->AddError("required property missing: dnsStart");
  }
  const base::Value* dns_end_value;
  if (object->Get("dnsEnd", &dns_end_value)) {
    errors->SetName("dnsEnd");
    result->dns_end_ = internal::FromValue<double>::Parse(*dns_end_value, errors);
  } else {
    errors->AddError("required property missing: dnsEnd");
  }
  const base::Value* connect_start_value;
  if (object->Get("connectStart", &connect_start_value)) {
    errors->SetName("connectStart");
    result->connect_start_ = internal::FromValue<double>::Parse(*connect_start_value, errors);
  } else {
    errors->AddError("required property missing: connectStart");
  }
  const base::Value* connect_end_value;
  if (object->Get("connectEnd", &connect_end_value)) {
    errors->SetName("connectEnd");
    result->connect_end_ = internal::FromValue<double>::Parse(*connect_end_value, errors);
  } else {
    errors->AddError("required property missing: connectEnd");
  }
  const base::Value* ssl_start_value;
  if (object->Get("sslStart", &ssl_start_value)) {
    errors->SetName("sslStart");
    result->ssl_start_ = internal::FromValue<double>::Parse(*ssl_start_value, errors);
  } else {
    errors->AddError("required property missing: sslStart");
  }
  const base::Value* ssl_end_value;
  if (object->Get("sslEnd", &ssl_end_value)) {
    errors->SetName("sslEnd");
    result->ssl_end_ = internal::FromValue<double>::Parse(*ssl_end_value, errors);
  } else {
    errors->AddError("required property missing: sslEnd");
  }
  const base::Value* worker_start_value;
  if (object->Get("workerStart", &worker_start_value)) {
    errors->SetName("workerStart");
    result->worker_start_ = internal::FromValue<double>::Parse(*worker_start_value, errors);
  } else {
    errors->AddError("required property missing: workerStart");
  }
  const base::Value* worker_ready_value;
  if (object->Get("workerReady", &worker_ready_value)) {
    errors->SetName("workerReady");
    result->worker_ready_ = internal::FromValue<double>::Parse(*worker_ready_value, errors);
  } else {
    errors->AddError("required property missing: workerReady");
  }
  const base::Value* send_start_value;
  if (object->Get("sendStart", &send_start_value)) {
    errors->SetName("sendStart");
    result->send_start_ = internal::FromValue<double>::Parse(*send_start_value, errors);
  } else {
    errors->AddError("required property missing: sendStart");
  }
  const base::Value* send_end_value;
  if (object->Get("sendEnd", &send_end_value)) {
    errors->SetName("sendEnd");
    result->send_end_ = internal::FromValue<double>::Parse(*send_end_value, errors);
  } else {
    errors->AddError("required property missing: sendEnd");
  }
  const base::Value* receive_headers_end_value;
  if (object->Get("receiveHeadersEnd", &receive_headers_end_value)) {
    errors->SetName("receiveHeadersEnd");
    result->receive_headers_end_ = internal::FromValue<double>::Parse(*receive_headers_end_value, errors);
  } else {
    errors->AddError("required property missing: receiveHeadersEnd");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ResourceTiming::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("requestTime", internal::ToValue(request_time_));
  result->Set("proxyStart", internal::ToValue(proxy_start_));
  result->Set("proxyEnd", internal::ToValue(proxy_end_));
  result->Set("dnsStart", internal::ToValue(dns_start_));
  result->Set("dnsEnd", internal::ToValue(dns_end_));
  result->Set("connectStart", internal::ToValue(connect_start_));
  result->Set("connectEnd", internal::ToValue(connect_end_));
  result->Set("sslStart", internal::ToValue(ssl_start_));
  result->Set("sslEnd", internal::ToValue(ssl_end_));
  result->Set("workerStart", internal::ToValue(worker_start_));
  result->Set("workerReady", internal::ToValue(worker_ready_));
  result->Set("sendStart", internal::ToValue(send_start_));
  result->Set("sendEnd", internal::ToValue(send_end_));
  result->Set("receiveHeadersEnd", internal::ToValue(receive_headers_end_));
  return std::move(result);
}

std::unique_ptr<ResourceTiming> ResourceTiming::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ResourceTiming> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Request> Request::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Request");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Request> result(new Request());
  errors->Push();
  errors->SetName("Request");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* method_value;
  if (object->Get("method", &method_value)) {
    errors->SetName("method");
    result->method_ = internal::FromValue<std::string>::Parse(*method_value, errors);
  } else {
    errors->AddError("required property missing: method");
  }
  const base::Value* headers_value;
  if (object->Get("headers", &headers_value)) {
    errors->SetName("headers");
    result->headers_ = internal::FromValue<base::DictionaryValue>::Parse(*headers_value, errors);
  } else {
    errors->AddError("required property missing: headers");
  }
  const base::Value* post_data_value;
  if (object->Get("postData", &post_data_value)) {
    errors->SetName("postData");
    result->post_data_ = Just(internal::FromValue<std::string>::Parse(*post_data_value, errors));
  }
  const base::Value* mixed_content_type_value;
  if (object->Get("mixedContentType", &mixed_content_type_value)) {
    errors->SetName("mixedContentType");
    result->mixed_content_type_ = Just(internal::FromValue<headless::network::RequestMixedContentType>::Parse(*mixed_content_type_value, errors));
  }
  const base::Value* initial_priority_value;
  if (object->Get("initialPriority", &initial_priority_value)) {
    errors->SetName("initialPriority");
    result->initial_priority_ = internal::FromValue<headless::network::ResourcePriority>::Parse(*initial_priority_value, errors);
  } else {
    errors->AddError("required property missing: initialPriority");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Request::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  result->Set("method", internal::ToValue(method_));
  result->Set("headers", internal::ToValue(*headers_));
  if (post_data_.IsJust())
    result->Set("postData", internal::ToValue(post_data_.FromJust()));
  if (mixed_content_type_.IsJust())
    result->Set("mixedContentType", internal::ToValue(mixed_content_type_.FromJust()));
  result->Set("initialPriority", internal::ToValue(initial_priority_));
  return std::move(result);
}

std::unique_ptr<Request> Request::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Request> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CertificateSubject> CertificateSubject::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CertificateSubject");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CertificateSubject> result(new CertificateSubject());
  errors->Push();
  errors->SetName("CertificateSubject");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* san_dns_names_value;
  if (object->Get("sanDnsNames", &san_dns_names_value)) {
    errors->SetName("sanDnsNames");
    result->san_dns_names_ = internal::FromValue<std::vector<std::string>>::Parse(*san_dns_names_value, errors);
  } else {
    errors->AddError("required property missing: sanDnsNames");
  }
  const base::Value* san_ip_addresses_value;
  if (object->Get("sanIpAddresses", &san_ip_addresses_value)) {
    errors->SetName("sanIpAddresses");
    result->san_ip_addresses_ = internal::FromValue<std::vector<std::string>>::Parse(*san_ip_addresses_value, errors);
  } else {
    errors->AddError("required property missing: sanIpAddresses");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CertificateSubject::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("sanDnsNames", internal::ToValue(san_dns_names_));
  result->Set("sanIpAddresses", internal::ToValue(san_ip_addresses_));
  return std::move(result);
}

std::unique_ptr<CertificateSubject> CertificateSubject::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CertificateSubject> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CertificateDetails> CertificateDetails::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CertificateDetails");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CertificateDetails> result(new CertificateDetails());
  errors->Push();
  errors->SetName("CertificateDetails");
  const base::Value* subject_value;
  if (object->Get("subject", &subject_value)) {
    errors->SetName("subject");
    result->subject_ = internal::FromValue<headless::network::CertificateSubject>::Parse(*subject_value, errors);
  } else {
    errors->AddError("required property missing: subject");
  }
  const base::Value* issuer_value;
  if (object->Get("issuer", &issuer_value)) {
    errors->SetName("issuer");
    result->issuer_ = internal::FromValue<std::string>::Parse(*issuer_value, errors);
  } else {
    errors->AddError("required property missing: issuer");
  }
  const base::Value* valid_from_value;
  if (object->Get("validFrom", &valid_from_value)) {
    errors->SetName("validFrom");
    result->valid_from_ = internal::FromValue<double>::Parse(*valid_from_value, errors);
  } else {
    errors->AddError("required property missing: validFrom");
  }
  const base::Value* valid_to_value;
  if (object->Get("validTo", &valid_to_value)) {
    errors->SetName("validTo");
    result->valid_to_ = internal::FromValue<double>::Parse(*valid_to_value, errors);
  } else {
    errors->AddError("required property missing: validTo");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CertificateDetails::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("subject", internal::ToValue(*subject_));
  result->Set("issuer", internal::ToValue(issuer_));
  result->Set("validFrom", internal::ToValue(valid_from_));
  result->Set("validTo", internal::ToValue(valid_to_));
  return std::move(result);
}

std::unique_ptr<CertificateDetails> CertificateDetails::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CertificateDetails> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CertificateValidationDetails> CertificateValidationDetails::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CertificateValidationDetails");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CertificateValidationDetails> result(new CertificateValidationDetails());
  errors->Push();
  errors->SetName("CertificateValidationDetails");
  const base::Value* num_unknown_scts_value;
  if (object->Get("numUnknownScts", &num_unknown_scts_value)) {
    errors->SetName("numUnknownScts");
    result->num_unknown_scts_ = internal::FromValue<int>::Parse(*num_unknown_scts_value, errors);
  } else {
    errors->AddError("required property missing: numUnknownScts");
  }
  const base::Value* num_invalid_scts_value;
  if (object->Get("numInvalidScts", &num_invalid_scts_value)) {
    errors->SetName("numInvalidScts");
    result->num_invalid_scts_ = internal::FromValue<int>::Parse(*num_invalid_scts_value, errors);
  } else {
    errors->AddError("required property missing: numInvalidScts");
  }
  const base::Value* num_valid_scts_value;
  if (object->Get("numValidScts", &num_valid_scts_value)) {
    errors->SetName("numValidScts");
    result->num_valid_scts_ = internal::FromValue<int>::Parse(*num_valid_scts_value, errors);
  } else {
    errors->AddError("required property missing: numValidScts");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CertificateValidationDetails::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("numUnknownScts", internal::ToValue(num_unknown_scts_));
  result->Set("numInvalidScts", internal::ToValue(num_invalid_scts_));
  result->Set("numValidScts", internal::ToValue(num_valid_scts_));
  return std::move(result);
}

std::unique_ptr<CertificateValidationDetails> CertificateValidationDetails::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CertificateValidationDetails> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SecurityDetails> SecurityDetails::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SecurityDetails");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SecurityDetails> result(new SecurityDetails());
  errors->Push();
  errors->SetName("SecurityDetails");
  const base::Value* protocol_value;
  if (object->Get("protocol", &protocol_value)) {
    errors->SetName("protocol");
    result->protocol_ = internal::FromValue<std::string>::Parse(*protocol_value, errors);
  } else {
    errors->AddError("required property missing: protocol");
  }
  const base::Value* key_exchange_value;
  if (object->Get("keyExchange", &key_exchange_value)) {
    errors->SetName("keyExchange");
    result->key_exchange_ = internal::FromValue<std::string>::Parse(*key_exchange_value, errors);
  } else {
    errors->AddError("required property missing: keyExchange");
  }
  const base::Value* cipher_value;
  if (object->Get("cipher", &cipher_value)) {
    errors->SetName("cipher");
    result->cipher_ = internal::FromValue<std::string>::Parse(*cipher_value, errors);
  } else {
    errors->AddError("required property missing: cipher");
  }
  const base::Value* mac_value;
  if (object->Get("mac", &mac_value)) {
    errors->SetName("mac");
    result->mac_ = Just(internal::FromValue<std::string>::Parse(*mac_value, errors));
  }
  const base::Value* certificate_id_value;
  if (object->Get("certificateId", &certificate_id_value)) {
    errors->SetName("certificateId");
    result->certificate_id_ = internal::FromValue<int>::Parse(*certificate_id_value, errors);
  } else {
    errors->AddError("required property missing: certificateId");
  }
  const base::Value* certificate_validation_details_value;
  if (object->Get("certificateValidationDetails", &certificate_validation_details_value)) {
    errors->SetName("certificateValidationDetails");
    result->certificate_validation_details_ = Just(internal::FromValue<headless::network::CertificateValidationDetails>::Parse(*certificate_validation_details_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SecurityDetails::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("protocol", internal::ToValue(protocol_));
  result->Set("keyExchange", internal::ToValue(key_exchange_));
  result->Set("cipher", internal::ToValue(cipher_));
  if (mac_.IsJust())
    result->Set("mac", internal::ToValue(mac_.FromJust()));
  result->Set("certificateId", internal::ToValue(certificate_id_));
  if (certificate_validation_details_.IsJust())
    result->Set("certificateValidationDetails", internal::ToValue(*certificate_validation_details_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SecurityDetails> SecurityDetails::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SecurityDetails> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Response> Response::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Response");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Response> result(new Response());
  errors->Push();
  errors->SetName("Response");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* status_value;
  if (object->Get("status", &status_value)) {
    errors->SetName("status");
    result->status_ = internal::FromValue<double>::Parse(*status_value, errors);
  } else {
    errors->AddError("required property missing: status");
  }
  const base::Value* status_text_value;
  if (object->Get("statusText", &status_text_value)) {
    errors->SetName("statusText");
    result->status_text_ = internal::FromValue<std::string>::Parse(*status_text_value, errors);
  } else {
    errors->AddError("required property missing: statusText");
  }
  const base::Value* headers_value;
  if (object->Get("headers", &headers_value)) {
    errors->SetName("headers");
    result->headers_ = internal::FromValue<base::DictionaryValue>::Parse(*headers_value, errors);
  } else {
    errors->AddError("required property missing: headers");
  }
  const base::Value* headers_text_value;
  if (object->Get("headersText", &headers_text_value)) {
    errors->SetName("headersText");
    result->headers_text_ = Just(internal::FromValue<std::string>::Parse(*headers_text_value, errors));
  }
  const base::Value* mime_type_value;
  if (object->Get("mimeType", &mime_type_value)) {
    errors->SetName("mimeType");
    result->mime_type_ = internal::FromValue<std::string>::Parse(*mime_type_value, errors);
  } else {
    errors->AddError("required property missing: mimeType");
  }
  const base::Value* request_headers_value;
  if (object->Get("requestHeaders", &request_headers_value)) {
    errors->SetName("requestHeaders");
    result->request_headers_ = Just(internal::FromValue<base::DictionaryValue>::Parse(*request_headers_value, errors));
  }
  const base::Value* request_headers_text_value;
  if (object->Get("requestHeadersText", &request_headers_text_value)) {
    errors->SetName("requestHeadersText");
    result->request_headers_text_ = Just(internal::FromValue<std::string>::Parse(*request_headers_text_value, errors));
  }
  const base::Value* connection_reused_value;
  if (object->Get("connectionReused", &connection_reused_value)) {
    errors->SetName("connectionReused");
    result->connection_reused_ = internal::FromValue<bool>::Parse(*connection_reused_value, errors);
  } else {
    errors->AddError("required property missing: connectionReused");
  }
  const base::Value* connection_id_value;
  if (object->Get("connectionId", &connection_id_value)) {
    errors->SetName("connectionId");
    result->connection_id_ = internal::FromValue<double>::Parse(*connection_id_value, errors);
  } else {
    errors->AddError("required property missing: connectionId");
  }
  const base::Value* remoteip_address_value;
  if (object->Get("remoteIPAddress", &remoteip_address_value)) {
    errors->SetName("remoteIPAddress");
    result->remoteip_address_ = Just(internal::FromValue<std::string>::Parse(*remoteip_address_value, errors));
  }
  const base::Value* remote_port_value;
  if (object->Get("remotePort", &remote_port_value)) {
    errors->SetName("remotePort");
    result->remote_port_ = Just(internal::FromValue<int>::Parse(*remote_port_value, errors));
  }
  const base::Value* from_disk_cache_value;
  if (object->Get("fromDiskCache", &from_disk_cache_value)) {
    errors->SetName("fromDiskCache");
    result->from_disk_cache_ = Just(internal::FromValue<bool>::Parse(*from_disk_cache_value, errors));
  }
  const base::Value* from_service_worker_value;
  if (object->Get("fromServiceWorker", &from_service_worker_value)) {
    errors->SetName("fromServiceWorker");
    result->from_service_worker_ = Just(internal::FromValue<bool>::Parse(*from_service_worker_value, errors));
  }
  const base::Value* encoded_data_length_value;
  if (object->Get("encodedDataLength", &encoded_data_length_value)) {
    errors->SetName("encodedDataLength");
    result->encoded_data_length_ = internal::FromValue<double>::Parse(*encoded_data_length_value, errors);
  } else {
    errors->AddError("required property missing: encodedDataLength");
  }
  const base::Value* timing_value;
  if (object->Get("timing", &timing_value)) {
    errors->SetName("timing");
    result->timing_ = Just(internal::FromValue<headless::network::ResourceTiming>::Parse(*timing_value, errors));
  }
  const base::Value* protocol_value;
  if (object->Get("protocol", &protocol_value)) {
    errors->SetName("protocol");
    result->protocol_ = Just(internal::FromValue<std::string>::Parse(*protocol_value, errors));
  }
  const base::Value* security_state_value;
  if (object->Get("securityState", &security_state_value)) {
    errors->SetName("securityState");
    result->security_state_ = internal::FromValue<headless::security::SecurityState>::Parse(*security_state_value, errors);
  } else {
    errors->AddError("required property missing: securityState");
  }
  const base::Value* security_details_value;
  if (object->Get("securityDetails", &security_details_value)) {
    errors->SetName("securityDetails");
    result->security_details_ = Just(internal::FromValue<headless::network::SecurityDetails>::Parse(*security_details_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Response::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  result->Set("status", internal::ToValue(status_));
  result->Set("statusText", internal::ToValue(status_text_));
  result->Set("headers", internal::ToValue(*headers_));
  if (headers_text_.IsJust())
    result->Set("headersText", internal::ToValue(headers_text_.FromJust()));
  result->Set("mimeType", internal::ToValue(mime_type_));
  if (request_headers_.IsJust())
    result->Set("requestHeaders", internal::ToValue(*request_headers_.FromJust()));
  if (request_headers_text_.IsJust())
    result->Set("requestHeadersText", internal::ToValue(request_headers_text_.FromJust()));
  result->Set("connectionReused", internal::ToValue(connection_reused_));
  result->Set("connectionId", internal::ToValue(connection_id_));
  if (remoteip_address_.IsJust())
    result->Set("remoteIPAddress", internal::ToValue(remoteip_address_.FromJust()));
  if (remote_port_.IsJust())
    result->Set("remotePort", internal::ToValue(remote_port_.FromJust()));
  if (from_disk_cache_.IsJust())
    result->Set("fromDiskCache", internal::ToValue(from_disk_cache_.FromJust()));
  if (from_service_worker_.IsJust())
    result->Set("fromServiceWorker", internal::ToValue(from_service_worker_.FromJust()));
  result->Set("encodedDataLength", internal::ToValue(encoded_data_length_));
  if (timing_.IsJust())
    result->Set("timing", internal::ToValue(*timing_.FromJust()));
  if (protocol_.IsJust())
    result->Set("protocol", internal::ToValue(protocol_.FromJust()));
  result->Set("securityState", internal::ToValue(security_state_));
  if (security_details_.IsJust())
    result->Set("securityDetails", internal::ToValue(*security_details_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Response> Response::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Response> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<WebSocketRequest> WebSocketRequest::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("WebSocketRequest");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<WebSocketRequest> result(new WebSocketRequest());
  errors->Push();
  errors->SetName("WebSocketRequest");
  const base::Value* headers_value;
  if (object->Get("headers", &headers_value)) {
    errors->SetName("headers");
    result->headers_ = internal::FromValue<base::DictionaryValue>::Parse(*headers_value, errors);
  } else {
    errors->AddError("required property missing: headers");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> WebSocketRequest::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("headers", internal::ToValue(*headers_));
  return std::move(result);
}

std::unique_ptr<WebSocketRequest> WebSocketRequest::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<WebSocketRequest> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<WebSocketResponse> WebSocketResponse::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("WebSocketResponse");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<WebSocketResponse> result(new WebSocketResponse());
  errors->Push();
  errors->SetName("WebSocketResponse");
  const base::Value* status_value;
  if (object->Get("status", &status_value)) {
    errors->SetName("status");
    result->status_ = internal::FromValue<double>::Parse(*status_value, errors);
  } else {
    errors->AddError("required property missing: status");
  }
  const base::Value* status_text_value;
  if (object->Get("statusText", &status_text_value)) {
    errors->SetName("statusText");
    result->status_text_ = internal::FromValue<std::string>::Parse(*status_text_value, errors);
  } else {
    errors->AddError("required property missing: statusText");
  }
  const base::Value* headers_value;
  if (object->Get("headers", &headers_value)) {
    errors->SetName("headers");
    result->headers_ = internal::FromValue<base::DictionaryValue>::Parse(*headers_value, errors);
  } else {
    errors->AddError("required property missing: headers");
  }
  const base::Value* headers_text_value;
  if (object->Get("headersText", &headers_text_value)) {
    errors->SetName("headersText");
    result->headers_text_ = Just(internal::FromValue<std::string>::Parse(*headers_text_value, errors));
  }
  const base::Value* request_headers_value;
  if (object->Get("requestHeaders", &request_headers_value)) {
    errors->SetName("requestHeaders");
    result->request_headers_ = Just(internal::FromValue<base::DictionaryValue>::Parse(*request_headers_value, errors));
  }
  const base::Value* request_headers_text_value;
  if (object->Get("requestHeadersText", &request_headers_text_value)) {
    errors->SetName("requestHeadersText");
    result->request_headers_text_ = Just(internal::FromValue<std::string>::Parse(*request_headers_text_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> WebSocketResponse::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("status", internal::ToValue(status_));
  result->Set("statusText", internal::ToValue(status_text_));
  result->Set("headers", internal::ToValue(*headers_));
  if (headers_text_.IsJust())
    result->Set("headersText", internal::ToValue(headers_text_.FromJust()));
  if (request_headers_.IsJust())
    result->Set("requestHeaders", internal::ToValue(*request_headers_.FromJust()));
  if (request_headers_text_.IsJust())
    result->Set("requestHeadersText", internal::ToValue(request_headers_text_.FromJust()));
  return std::move(result);
}

std::unique_ptr<WebSocketResponse> WebSocketResponse::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<WebSocketResponse> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<WebSocketFrame> WebSocketFrame::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("WebSocketFrame");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<WebSocketFrame> result(new WebSocketFrame());
  errors->Push();
  errors->SetName("WebSocketFrame");
  const base::Value* opcode_value;
  if (object->Get("opcode", &opcode_value)) {
    errors->SetName("opcode");
    result->opcode_ = internal::FromValue<double>::Parse(*opcode_value, errors);
  } else {
    errors->AddError("required property missing: opcode");
  }
  const base::Value* mask_value;
  if (object->Get("mask", &mask_value)) {
    errors->SetName("mask");
    result->mask_ = internal::FromValue<bool>::Parse(*mask_value, errors);
  } else {
    errors->AddError("required property missing: mask");
  }
  const base::Value* payload_data_value;
  if (object->Get("payloadData", &payload_data_value)) {
    errors->SetName("payloadData");
    result->payload_data_ = internal::FromValue<std::string>::Parse(*payload_data_value, errors);
  } else {
    errors->AddError("required property missing: payloadData");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> WebSocketFrame::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("opcode", internal::ToValue(opcode_));
  result->Set("mask", internal::ToValue(mask_));
  result->Set("payloadData", internal::ToValue(payload_data_));
  return std::move(result);
}

std::unique_ptr<WebSocketFrame> WebSocketFrame::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<WebSocketFrame> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CachedResource> CachedResource::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CachedResource");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CachedResource> result(new CachedResource());
  errors->Push();
  errors->SetName("CachedResource");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::page::ResourceType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* response_value;
  if (object->Get("response", &response_value)) {
    errors->SetName("response");
    result->response_ = Just(internal::FromValue<headless::network::Response>::Parse(*response_value, errors));
  }
  const base::Value* body_size_value;
  if (object->Get("bodySize", &body_size_value)) {
    errors->SetName("bodySize");
    result->body_size_ = internal::FromValue<double>::Parse(*body_size_value, errors);
  } else {
    errors->AddError("required property missing: bodySize");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CachedResource::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  result->Set("type", internal::ToValue(type_));
  if (response_.IsJust())
    result->Set("response", internal::ToValue(*response_.FromJust()));
  result->Set("bodySize", internal::ToValue(body_size_));
  return std::move(result);
}

std::unique_ptr<CachedResource> CachedResource::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CachedResource> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Initiator> Initiator::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Initiator");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Initiator> result(new Initiator());
  errors->Push();
  errors->SetName("Initiator");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::network::InitiatorType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* stack_value;
  if (object->Get("stack", &stack_value)) {
    errors->SetName("stack");
    result->stack_ = Just(internal::FromValue<headless::runtime::StackTrace>::Parse(*stack_value, errors));
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = Just(internal::FromValue<std::string>::Parse(*url_value, errors));
  }
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = Just(internal::FromValue<double>::Parse(*line_number_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Initiator::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (stack_.IsJust())
    result->Set("stack", internal::ToValue(*stack_.FromJust()));
  if (url_.IsJust())
    result->Set("url", internal::ToValue(url_.FromJust()));
  if (line_number_.IsJust())
    result->Set("lineNumber", internal::ToValue(line_number_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Initiator> Initiator::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Initiator> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Cookie> Cookie::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Cookie");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Cookie> result(new Cookie());
  errors->Push();
  errors->SetName("Cookie");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  const base::Value* domain_value;
  if (object->Get("domain", &domain_value)) {
    errors->SetName("domain");
    result->domain_ = internal::FromValue<std::string>::Parse(*domain_value, errors);
  } else {
    errors->AddError("required property missing: domain");
  }
  const base::Value* path_value;
  if (object->Get("path", &path_value)) {
    errors->SetName("path");
    result->path_ = internal::FromValue<std::string>::Parse(*path_value, errors);
  } else {
    errors->AddError("required property missing: path");
  }
  const base::Value* expires_value;
  if (object->Get("expires", &expires_value)) {
    errors->SetName("expires");
    result->expires_ = internal::FromValue<double>::Parse(*expires_value, errors);
  } else {
    errors->AddError("required property missing: expires");
  }
  const base::Value* size_value;
  if (object->Get("size", &size_value)) {
    errors->SetName("size");
    result->size_ = internal::FromValue<int>::Parse(*size_value, errors);
  } else {
    errors->AddError("required property missing: size");
  }
  const base::Value* http_only_value;
  if (object->Get("httpOnly", &http_only_value)) {
    errors->SetName("httpOnly");
    result->http_only_ = internal::FromValue<bool>::Parse(*http_only_value, errors);
  } else {
    errors->AddError("required property missing: httpOnly");
  }
  const base::Value* secure_value;
  if (object->Get("secure", &secure_value)) {
    errors->SetName("secure");
    result->secure_ = internal::FromValue<bool>::Parse(*secure_value, errors);
  } else {
    errors->AddError("required property missing: secure");
  }
  const base::Value* session_value;
  if (object->Get("session", &session_value)) {
    errors->SetName("session");
    result->session_ = internal::FromValue<bool>::Parse(*session_value, errors);
  } else {
    errors->AddError("required property missing: session");
  }
  const base::Value* same_site_value;
  if (object->Get("sameSite", &same_site_value)) {
    errors->SetName("sameSite");
    result->same_site_ = Just(internal::FromValue<headless::network::CookieSameSite>::Parse(*same_site_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Cookie::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("value", internal::ToValue(value_));
  result->Set("domain", internal::ToValue(domain_));
  result->Set("path", internal::ToValue(path_));
  result->Set("expires", internal::ToValue(expires_));
  result->Set("size", internal::ToValue(size_));
  result->Set("httpOnly", internal::ToValue(http_only_));
  result->Set("secure", internal::ToValue(secure_));
  result->Set("session", internal::ToValue(session_));
  if (same_site_.IsJust())
    result->Set("sameSite", internal::ToValue(same_site_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Cookie> Cookie::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Cookie> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EnableParams> EnableParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EnableParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EnableParams> result(new EnableParams());
  errors->Push();
  errors->SetName("EnableParams");
  const base::Value* max_total_buffer_size_value;
  if (object->Get("maxTotalBufferSize", &max_total_buffer_size_value)) {
    errors->SetName("maxTotalBufferSize");
    result->max_total_buffer_size_ = Just(internal::FromValue<int>::Parse(*max_total_buffer_size_value, errors));
  }
  const base::Value* max_resource_buffer_size_value;
  if (object->Get("maxResourceBufferSize", &max_resource_buffer_size_value)) {
    errors->SetName("maxResourceBufferSize");
    result->max_resource_buffer_size_ = Just(internal::FromValue<int>::Parse(*max_resource_buffer_size_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EnableParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (max_total_buffer_size_.IsJust())
    result->Set("maxTotalBufferSize", internal::ToValue(max_total_buffer_size_.FromJust()));
  if (max_resource_buffer_size_.IsJust())
    result->Set("maxResourceBufferSize", internal::ToValue(max_resource_buffer_size_.FromJust()));
  return std::move(result);
}

std::unique_ptr<EnableParams> EnableParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EnableParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetUserAgentOverrideParams> SetUserAgentOverrideParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetUserAgentOverrideParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetUserAgentOverrideParams> result(new SetUserAgentOverrideParams());
  errors->Push();
  errors->SetName("SetUserAgentOverrideParams");
  const base::Value* user_agent_value;
  if (object->Get("userAgent", &user_agent_value)) {
    errors->SetName("userAgent");
    result->user_agent_ = internal::FromValue<std::string>::Parse(*user_agent_value, errors);
  } else {
    errors->AddError("required property missing: userAgent");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetUserAgentOverrideParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("userAgent", internal::ToValue(user_agent_));
  return std::move(result);
}

std::unique_ptr<SetUserAgentOverrideParams> SetUserAgentOverrideParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetUserAgentOverrideParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetExtraHTTPHeadersParams> SetExtraHTTPHeadersParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetExtraHTTPHeadersParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetExtraHTTPHeadersParams> result(new SetExtraHTTPHeadersParams());
  errors->Push();
  errors->SetName("SetExtraHTTPHeadersParams");
  const base::Value* headers_value;
  if (object->Get("headers", &headers_value)) {
    errors->SetName("headers");
    result->headers_ = internal::FromValue<base::DictionaryValue>::Parse(*headers_value, errors);
  } else {
    errors->AddError("required property missing: headers");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetExtraHTTPHeadersParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("headers", internal::ToValue(*headers_));
  return std::move(result);
}

std::unique_ptr<SetExtraHTTPHeadersParams> SetExtraHTTPHeadersParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetExtraHTTPHeadersParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetResponseBodyParams> GetResponseBodyParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetResponseBodyParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetResponseBodyParams> result(new GetResponseBodyParams());
  errors->Push();
  errors->SetName("GetResponseBodyParams");
  const base::Value* request_id_value;
  if (object->Get("requestId", &request_id_value)) {
    errors->SetName("requestId");
    result->request_id_ = internal::FromValue<std::string>::Parse(*request_id_value, errors);
  } else {
    errors->AddError("required property missing: requestId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetResponseBodyParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("requestId", internal::ToValue(request_id_));
  return std::move(result);
}

std::unique_ptr<GetResponseBodyParams> GetResponseBodyParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetResponseBodyParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetResponseBodyResult> GetResponseBodyResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetResponseBodyResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetResponseBodyResult> result(new GetResponseBodyResult());
  errors->Push();
  errors->SetName("GetResponseBodyResult");
  const base::Value* body_value;
  if (object->Get("body", &body_value)) {
    errors->SetName("body");
    result->body_ = internal::FromValue<std::string>::Parse(*body_value, errors);
  } else {
    errors->AddError("required property missing: body");
  }
  const base::Value* base64_encoded_value;
  if (object->Get("base64Encoded", &base64_encoded_value)) {
    errors->SetName("base64Encoded");
    result->base64_encoded_ = internal::FromValue<bool>::Parse(*base64_encoded_value, errors);
  } else {
    errors->AddError("required property missing: base64Encoded");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetResponseBodyResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("body", internal::ToValue(body_));
  result->Set("base64Encoded", internal::ToValue(base64_encoded_));
  return std::move(result);
}

std::unique_ptr<GetResponseBodyResult> GetResponseBodyResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetResponseBodyResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AddBlockedURLParams> AddBlockedURLParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AddBlockedURLParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AddBlockedURLParams> result(new AddBlockedURLParams());
  errors->Push();
  errors->SetName("AddBlockedURLParams");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AddBlockedURLParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<AddBlockedURLParams> AddBlockedURLParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AddBlockedURLParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveBlockedURLParams> RemoveBlockedURLParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveBlockedURLParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveBlockedURLParams> result(new RemoveBlockedURLParams());
  errors->Push();
  errors->SetName("RemoveBlockedURLParams");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveBlockedURLParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<RemoveBlockedURLParams> RemoveBlockedURLParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveBlockedURLParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReplayXHRParams> ReplayXHRParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReplayXHRParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReplayXHRParams> result(new ReplayXHRParams());
  errors->Push();
  errors->SetName("ReplayXHRParams");
  const base::Value* request_id_value;
  if (object->Get("requestId", &request_id_value)) {
    errors->SetName("requestId");
    result->request_id_ = internal::FromValue<std::string>::Parse(*request_id_value, errors);
  } else {
    errors->AddError("required property missing: requestId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReplayXHRParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("requestId", internal::ToValue(request_id_));
  return std::move(result);
}

std::unique_ptr<ReplayXHRParams> ReplayXHRParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReplayXHRParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetMonitoringXHREnabledParams> SetMonitoringXHREnabledParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetMonitoringXHREnabledParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetMonitoringXHREnabledParams> result(new SetMonitoringXHREnabledParams());
  errors->Push();
  errors->SetName("SetMonitoringXHREnabledParams");
  const base::Value* enabled_value;
  if (object->Get("enabled", &enabled_value)) {
    errors->SetName("enabled");
    result->enabled_ = internal::FromValue<bool>::Parse(*enabled_value, errors);
  } else {
    errors->AddError("required property missing: enabled");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetMonitoringXHREnabledParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("enabled", internal::ToValue(enabled_));
  return std::move(result);
}

std::unique_ptr<SetMonitoringXHREnabledParams> SetMonitoringXHREnabledParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetMonitoringXHREnabledParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CanClearBrowserCacheResult> CanClearBrowserCacheResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CanClearBrowserCacheResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CanClearBrowserCacheResult> result(new CanClearBrowserCacheResult());
  errors->Push();
  errors->SetName("CanClearBrowserCacheResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<bool>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CanClearBrowserCacheResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<CanClearBrowserCacheResult> CanClearBrowserCacheResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CanClearBrowserCacheResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CanClearBrowserCookiesResult> CanClearBrowserCookiesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CanClearBrowserCookiesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CanClearBrowserCookiesResult> result(new CanClearBrowserCookiesResult());
  errors->Push();
  errors->SetName("CanClearBrowserCookiesResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<bool>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CanClearBrowserCookiesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<CanClearBrowserCookiesResult> CanClearBrowserCookiesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CanClearBrowserCookiesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCookiesResult> GetCookiesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCookiesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCookiesResult> result(new GetCookiesResult());
  errors->Push();
  errors->SetName("GetCookiesResult");
  const base::Value* cookies_value;
  if (object->Get("cookies", &cookies_value)) {
    errors->SetName("cookies");
    result->cookies_ = internal::FromValue<std::vector<std::unique_ptr<headless::network::Cookie>>>::Parse(*cookies_value, errors);
  } else {
    errors->AddError("required property missing: cookies");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCookiesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cookies", internal::ToValue(cookies_));
  return std::move(result);
}

std::unique_ptr<GetCookiesResult> GetCookiesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCookiesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DeleteCookieParams> DeleteCookieParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DeleteCookieParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DeleteCookieParams> result(new DeleteCookieParams());
  errors->Push();
  errors->SetName("DeleteCookieParams");
  const base::Value* cookie_name_value;
  if (object->Get("cookieName", &cookie_name_value)) {
    errors->SetName("cookieName");
    result->cookie_name_ = internal::FromValue<std::string>::Parse(*cookie_name_value, errors);
  } else {
    errors->AddError("required property missing: cookieName");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DeleteCookieParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cookieName", internal::ToValue(cookie_name_));
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<DeleteCookieParams> DeleteCookieParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DeleteCookieParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CanEmulateNetworkConditionsResult> CanEmulateNetworkConditionsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CanEmulateNetworkConditionsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CanEmulateNetworkConditionsResult> result(new CanEmulateNetworkConditionsResult());
  errors->Push();
  errors->SetName("CanEmulateNetworkConditionsResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<bool>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CanEmulateNetworkConditionsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<CanEmulateNetworkConditionsResult> CanEmulateNetworkConditionsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CanEmulateNetworkConditionsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EmulateNetworkConditionsParams> EmulateNetworkConditionsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EmulateNetworkConditionsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EmulateNetworkConditionsParams> result(new EmulateNetworkConditionsParams());
  errors->Push();
  errors->SetName("EmulateNetworkConditionsParams");
  const base::Value* offline_value;
  if (object->Get("offline", &offline_value)) {
    errors->SetName("offline");
    result->offline_ = internal::FromValue<bool>::Parse(*offline_value, errors);
  } else {
    errors->AddError("required property missing: offline");
  }
  const base::Value* latency_value;
  if (object->Get("latency", &latency_value)) {
    errors->SetName("latency");
    result->latency_ = internal::FromValue<double>::Parse(*latency_value, errors);
  } else {
    errors->AddError("required property missing: latency");
  }
  const base::Value* download_throughput_value;
  if (object->Get("downloadThroughput", &download_throughput_value)) {
    errors->SetName("downloadThroughput");
    result->download_throughput_ = internal::FromValue<double>::Parse(*download_throughput_value, errors);
  } else {
    errors->AddError("required property missing: downloadThroughput");
  }
  const base::Value* upload_throughput_value;
  if (object->Get("uploadThroughput", &upload_throughput_value)) {
    errors->SetName("uploadThroughput");
    result->upload_throughput_ = internal::FromValue<double>::Parse(*upload_throughput_value, errors);
  } else {
    errors->AddError("required property missing: uploadThroughput");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EmulateNetworkConditionsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("offline", internal::ToValue(offline_));
  result->Set("latency", internal::ToValue(latency_));
  result->Set("downloadThroughput", internal::ToValue(download_throughput_));
  result->Set("uploadThroughput", internal::ToValue(upload_throughput_));
  return std::move(result);
}

std::unique_ptr<EmulateNetworkConditionsParams> EmulateNetworkConditionsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EmulateNetworkConditionsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetCacheDisabledParams> SetCacheDisabledParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetCacheDisabledParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetCacheDisabledParams> result(new SetCacheDisabledParams());
  errors->Push();
  errors->SetName("SetCacheDisabledParams");
  const base::Value* cache_disabled_value;
  if (object->Get("cacheDisabled", &cache_disabled_value)) {
    errors->SetName("cacheDisabled");
    result->cache_disabled_ = internal::FromValue<bool>::Parse(*cache_disabled_value, errors);
  } else {
    errors->AddError("required property missing: cacheDisabled");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetCacheDisabledParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cacheDisabled", internal::ToValue(cache_disabled_));
  return std::move(result);
}

std::unique_ptr<SetCacheDisabledParams> SetCacheDisabledParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetCacheDisabledParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetDataSizeLimitsForTestParams> SetDataSizeLimitsForTestParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDataSizeLimitsForTestParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDataSizeLimitsForTestParams> result(new SetDataSizeLimitsForTestParams());
  errors->Push();
  errors->SetName("SetDataSizeLimitsForTestParams");
  const base::Value* max_total_size_value;
  if (object->Get("maxTotalSize", &max_total_size_value)) {
    errors->SetName("maxTotalSize");
    result->max_total_size_ = internal::FromValue<int>::Parse(*max_total_size_value, errors);
  } else {
    errors->AddError("required property missing: maxTotalSize");
  }
  const base::Value* max_resource_size_value;
  if (object->Get("maxResourceSize", &max_resource_size_value)) {
    errors->SetName("maxResourceSize");
    result->max_resource_size_ = internal::FromValue<int>::Parse(*max_resource_size_value, errors);
  } else {
    errors->AddError("required property missing: maxResourceSize");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDataSizeLimitsForTestParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("maxTotalSize", internal::ToValue(max_total_size_));
  result->Set("maxResourceSize", internal::ToValue(max_resource_size_));
  return std::move(result);
}

std::unique_ptr<SetDataSizeLimitsForTestParams> SetDataSizeLimitsForTestParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDataSizeLimitsForTestParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCertificateDetailsParams> GetCertificateDetailsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCertificateDetailsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCertificateDetailsParams> result(new GetCertificateDetailsParams());
  errors->Push();
  errors->SetName("GetCertificateDetailsParams");
  const base::Value* certificate_id_value;
  if (object->Get("certificateId", &certificate_id_value)) {
    errors->SetName("certificateId");
    result->certificate_id_ = internal::FromValue<int>::Parse(*certificate_id_value, errors);
  } else {
    errors->AddError("required property missing: certificateId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCertificateDetailsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("certificateId", internal::ToValue(certificate_id_));
  return std::move(result);
}

std::unique_ptr<GetCertificateDetailsParams> GetCertificateDetailsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCertificateDetailsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCertificateDetailsResult> GetCertificateDetailsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCertificateDetailsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCertificateDetailsResult> result(new GetCertificateDetailsResult());
  errors->Push();
  errors->SetName("GetCertificateDetailsResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<headless::network::CertificateDetails>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCertificateDetailsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(*result_));
  return std::move(result);
}

std::unique_ptr<GetCertificateDetailsResult> GetCertificateDetailsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCertificateDetailsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ShowCertificateViewerParams> ShowCertificateViewerParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ShowCertificateViewerParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ShowCertificateViewerParams> result(new ShowCertificateViewerParams());
  errors->Push();
  errors->SetName("ShowCertificateViewerParams");
  const base::Value* certificate_id_value;
  if (object->Get("certificateId", &certificate_id_value)) {
    errors->SetName("certificateId");
    result->certificate_id_ = internal::FromValue<int>::Parse(*certificate_id_value, errors);
  } else {
    errors->AddError("required property missing: certificateId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ShowCertificateViewerParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("certificateId", internal::ToValue(certificate_id_));
  return std::move(result);
}

std::unique_ptr<ShowCertificateViewerParams> ShowCertificateViewerParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ShowCertificateViewerParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace network

namespace database {

std::unique_ptr<Database> Database::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Database");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Database> result(new Database());
  errors->Push();
  errors->SetName("Database");
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<std::string>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  const base::Value* domain_value;
  if (object->Get("domain", &domain_value)) {
    errors->SetName("domain");
    result->domain_ = internal::FromValue<std::string>::Parse(*domain_value, errors);
  } else {
    errors->AddError("required property missing: domain");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* version_value;
  if (object->Get("version", &version_value)) {
    errors->SetName("version");
    result->version_ = internal::FromValue<std::string>::Parse(*version_value, errors);
  } else {
    errors->AddError("required property missing: version");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Database::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("id", internal::ToValue(id_));
  result->Set("domain", internal::ToValue(domain_));
  result->Set("name", internal::ToValue(name_));
  result->Set("version", internal::ToValue(version_));
  return std::move(result);
}

std::unique_ptr<Database> Database::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Database> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Error> Error::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Error");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Error> result(new Error());
  errors->Push();
  errors->SetName("Error");
  const base::Value* message_value;
  if (object->Get("message", &message_value)) {
    errors->SetName("message");
    result->message_ = internal::FromValue<std::string>::Parse(*message_value, errors);
  } else {
    errors->AddError("required property missing: message");
  }
  const base::Value* code_value;
  if (object->Get("code", &code_value)) {
    errors->SetName("code");
    result->code_ = internal::FromValue<int>::Parse(*code_value, errors);
  } else {
    errors->AddError("required property missing: code");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Error::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("message", internal::ToValue(message_));
  result->Set("code", internal::ToValue(code_));
  return std::move(result);
}

std::unique_ptr<Error> Error::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Error> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetDatabaseTableNamesParams> GetDatabaseTableNamesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetDatabaseTableNamesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetDatabaseTableNamesParams> result(new GetDatabaseTableNamesParams());
  errors->Push();
  errors->SetName("GetDatabaseTableNamesParams");
  const base::Value* database_id_value;
  if (object->Get("databaseId", &database_id_value)) {
    errors->SetName("databaseId");
    result->database_id_ = internal::FromValue<std::string>::Parse(*database_id_value, errors);
  } else {
    errors->AddError("required property missing: databaseId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetDatabaseTableNamesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("databaseId", internal::ToValue(database_id_));
  return std::move(result);
}

std::unique_ptr<GetDatabaseTableNamesParams> GetDatabaseTableNamesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetDatabaseTableNamesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetDatabaseTableNamesResult> GetDatabaseTableNamesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetDatabaseTableNamesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetDatabaseTableNamesResult> result(new GetDatabaseTableNamesResult());
  errors->Push();
  errors->SetName("GetDatabaseTableNamesResult");
  const base::Value* table_names_value;
  if (object->Get("tableNames", &table_names_value)) {
    errors->SetName("tableNames");
    result->table_names_ = internal::FromValue<std::vector<std::string>>::Parse(*table_names_value, errors);
  } else {
    errors->AddError("required property missing: tableNames");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetDatabaseTableNamesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("tableNames", internal::ToValue(table_names_));
  return std::move(result);
}

std::unique_ptr<GetDatabaseTableNamesResult> GetDatabaseTableNamesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetDatabaseTableNamesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ExecuteSQLParams> ExecuteSQLParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ExecuteSQLParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ExecuteSQLParams> result(new ExecuteSQLParams());
  errors->Push();
  errors->SetName("ExecuteSQLParams");
  const base::Value* database_id_value;
  if (object->Get("databaseId", &database_id_value)) {
    errors->SetName("databaseId");
    result->database_id_ = internal::FromValue<std::string>::Parse(*database_id_value, errors);
  } else {
    errors->AddError("required property missing: databaseId");
  }
  const base::Value* query_value;
  if (object->Get("query", &query_value)) {
    errors->SetName("query");
    result->query_ = internal::FromValue<std::string>::Parse(*query_value, errors);
  } else {
    errors->AddError("required property missing: query");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ExecuteSQLParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("databaseId", internal::ToValue(database_id_));
  result->Set("query", internal::ToValue(query_));
  return std::move(result);
}

std::unique_ptr<ExecuteSQLParams> ExecuteSQLParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ExecuteSQLParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ExecuteSQLResult> ExecuteSQLResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ExecuteSQLResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ExecuteSQLResult> result(new ExecuteSQLResult());
  errors->Push();
  errors->SetName("ExecuteSQLResult");
  const base::Value* column_names_value;
  if (object->Get("columnNames", &column_names_value)) {
    errors->SetName("columnNames");
    result->column_names_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*column_names_value, errors));
  }
  const base::Value* values_value;
  if (object->Get("values", &values_value)) {
    errors->SetName("values");
    result->values_ = Just(internal::FromValue<std::vector<std::unique_ptr<base::Value>>>::Parse(*values_value, errors));
  }
  const base::Value* sql_error_value;
  if (object->Get("sqlError", &sql_error_value)) {
    errors->SetName("sqlError");
    result->sql_error_ = Just(internal::FromValue<headless::database::Error>::Parse(*sql_error_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ExecuteSQLResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (column_names_.IsJust())
    result->Set("columnNames", internal::ToValue(column_names_.FromJust()));
  if (values_.IsJust())
    result->Set("values", internal::ToValue(values_.FromJust()));
  if (sql_error_.IsJust())
    result->Set("sqlError", internal::ToValue(*sql_error_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ExecuteSQLResult> ExecuteSQLResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ExecuteSQLResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace database

namespace indexeddb {

std::unique_ptr<DatabaseWithObjectStores> DatabaseWithObjectStores::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DatabaseWithObjectStores");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DatabaseWithObjectStores> result(new DatabaseWithObjectStores());
  errors->Push();
  errors->SetName("DatabaseWithObjectStores");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* version_value;
  if (object->Get("version", &version_value)) {
    errors->SetName("version");
    result->version_ = internal::FromValue<int>::Parse(*version_value, errors);
  } else {
    errors->AddError("required property missing: version");
  }
  const base::Value* object_stores_value;
  if (object->Get("objectStores", &object_stores_value)) {
    errors->SetName("objectStores");
    result->object_stores_ = internal::FromValue<std::vector<std::unique_ptr<headless::indexeddb::ObjectStore>>>::Parse(*object_stores_value, errors);
  } else {
    errors->AddError("required property missing: objectStores");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DatabaseWithObjectStores::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("version", internal::ToValue(version_));
  result->Set("objectStores", internal::ToValue(object_stores_));
  return std::move(result);
}

std::unique_ptr<DatabaseWithObjectStores> DatabaseWithObjectStores::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DatabaseWithObjectStores> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ObjectStore> ObjectStore::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ObjectStore");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ObjectStore> result(new ObjectStore());
  errors->Push();
  errors->SetName("ObjectStore");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* key_path_value;
  if (object->Get("keyPath", &key_path_value)) {
    errors->SetName("keyPath");
    result->key_path_ = internal::FromValue<headless::indexeddb::KeyPath>::Parse(*key_path_value, errors);
  } else {
    errors->AddError("required property missing: keyPath");
  }
  const base::Value* auto_increment_value;
  if (object->Get("autoIncrement", &auto_increment_value)) {
    errors->SetName("autoIncrement");
    result->auto_increment_ = internal::FromValue<bool>::Parse(*auto_increment_value, errors);
  } else {
    errors->AddError("required property missing: autoIncrement");
  }
  const base::Value* indexes_value;
  if (object->Get("indexes", &indexes_value)) {
    errors->SetName("indexes");
    result->indexes_ = internal::FromValue<std::vector<std::unique_ptr<headless::indexeddb::ObjectStoreIndex>>>::Parse(*indexes_value, errors);
  } else {
    errors->AddError("required property missing: indexes");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ObjectStore::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("keyPath", internal::ToValue(*key_path_));
  result->Set("autoIncrement", internal::ToValue(auto_increment_));
  result->Set("indexes", internal::ToValue(indexes_));
  return std::move(result);
}

std::unique_ptr<ObjectStore> ObjectStore::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ObjectStore> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ObjectStoreIndex> ObjectStoreIndex::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ObjectStoreIndex");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ObjectStoreIndex> result(new ObjectStoreIndex());
  errors->Push();
  errors->SetName("ObjectStoreIndex");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* key_path_value;
  if (object->Get("keyPath", &key_path_value)) {
    errors->SetName("keyPath");
    result->key_path_ = internal::FromValue<headless::indexeddb::KeyPath>::Parse(*key_path_value, errors);
  } else {
    errors->AddError("required property missing: keyPath");
  }
  const base::Value* unique_value;
  if (object->Get("unique", &unique_value)) {
    errors->SetName("unique");
    result->unique_ = internal::FromValue<bool>::Parse(*unique_value, errors);
  } else {
    errors->AddError("required property missing: unique");
  }
  const base::Value* multi_entry_value;
  if (object->Get("multiEntry", &multi_entry_value)) {
    errors->SetName("multiEntry");
    result->multi_entry_ = internal::FromValue<bool>::Parse(*multi_entry_value, errors);
  } else {
    errors->AddError("required property missing: multiEntry");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ObjectStoreIndex::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("keyPath", internal::ToValue(*key_path_));
  result->Set("unique", internal::ToValue(unique_));
  result->Set("multiEntry", internal::ToValue(multi_entry_));
  return std::move(result);
}

std::unique_ptr<ObjectStoreIndex> ObjectStoreIndex::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ObjectStoreIndex> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Key> Key::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Key");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Key> result(new Key());
  errors->Push();
  errors->SetName("Key");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::indexeddb::KeyType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* number_value;
  if (object->Get("number", &number_value)) {
    errors->SetName("number");
    result->number_ = Just(internal::FromValue<double>::Parse(*number_value, errors));
  }
  const base::Value* string_value;
  if (object->Get("string", &string_value)) {
    errors->SetName("string");
    result->string_ = Just(internal::FromValue<std::string>::Parse(*string_value, errors));
  }
  const base::Value* date_value;
  if (object->Get("date", &date_value)) {
    errors->SetName("date");
    result->date_ = Just(internal::FromValue<double>::Parse(*date_value, errors));
  }
  const base::Value* array_value;
  if (object->Get("array", &array_value)) {
    errors->SetName("array");
    result->array_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::indexeddb::Key>>>::Parse(*array_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Key::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (number_.IsJust())
    result->Set("number", internal::ToValue(number_.FromJust()));
  if (string_.IsJust())
    result->Set("string", internal::ToValue(string_.FromJust()));
  if (date_.IsJust())
    result->Set("date", internal::ToValue(date_.FromJust()));
  if (array_.IsJust())
    result->Set("array", internal::ToValue(array_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Key> Key::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Key> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<KeyRange> KeyRange::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("KeyRange");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<KeyRange> result(new KeyRange());
  errors->Push();
  errors->SetName("KeyRange");
  const base::Value* lower_value;
  if (object->Get("lower", &lower_value)) {
    errors->SetName("lower");
    result->lower_ = Just(internal::FromValue<headless::indexeddb::Key>::Parse(*lower_value, errors));
  }
  const base::Value* upper_value;
  if (object->Get("upper", &upper_value)) {
    errors->SetName("upper");
    result->upper_ = Just(internal::FromValue<headless::indexeddb::Key>::Parse(*upper_value, errors));
  }
  const base::Value* lower_open_value;
  if (object->Get("lowerOpen", &lower_open_value)) {
    errors->SetName("lowerOpen");
    result->lower_open_ = internal::FromValue<bool>::Parse(*lower_open_value, errors);
  } else {
    errors->AddError("required property missing: lowerOpen");
  }
  const base::Value* upper_open_value;
  if (object->Get("upperOpen", &upper_open_value)) {
    errors->SetName("upperOpen");
    result->upper_open_ = internal::FromValue<bool>::Parse(*upper_open_value, errors);
  } else {
    errors->AddError("required property missing: upperOpen");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> KeyRange::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (lower_.IsJust())
    result->Set("lower", internal::ToValue(*lower_.FromJust()));
  if (upper_.IsJust())
    result->Set("upper", internal::ToValue(*upper_.FromJust()));
  result->Set("lowerOpen", internal::ToValue(lower_open_));
  result->Set("upperOpen", internal::ToValue(upper_open_));
  return std::move(result);
}

std::unique_ptr<KeyRange> KeyRange::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<KeyRange> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DataEntry> DataEntry::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DataEntry");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DataEntry> result(new DataEntry());
  errors->Push();
  errors->SetName("DataEntry");
  const base::Value* key_value;
  if (object->Get("key", &key_value)) {
    errors->SetName("key");
    result->key_ = internal::FromValue<std::string>::Parse(*key_value, errors);
  } else {
    errors->AddError("required property missing: key");
  }
  const base::Value* primary_key_value;
  if (object->Get("primaryKey", &primary_key_value)) {
    errors->SetName("primaryKey");
    result->primary_key_ = internal::FromValue<std::string>::Parse(*primary_key_value, errors);
  } else {
    errors->AddError("required property missing: primaryKey");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DataEntry::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("key", internal::ToValue(key_));
  result->Set("primaryKey", internal::ToValue(primary_key_));
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<DataEntry> DataEntry::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DataEntry> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<KeyPath> KeyPath::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("KeyPath");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<KeyPath> result(new KeyPath());
  errors->Push();
  errors->SetName("KeyPath");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::indexeddb::KeyPathType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* string_value;
  if (object->Get("string", &string_value)) {
    errors->SetName("string");
    result->string_ = Just(internal::FromValue<std::string>::Parse(*string_value, errors));
  }
  const base::Value* array_value;
  if (object->Get("array", &array_value)) {
    errors->SetName("array");
    result->array_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*array_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> KeyPath::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (string_.IsJust())
    result->Set("string", internal::ToValue(string_.FromJust()));
  if (array_.IsJust())
    result->Set("array", internal::ToValue(array_.FromJust()));
  return std::move(result);
}

std::unique_ptr<KeyPath> KeyPath::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<KeyPath> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestDatabaseNamesParams> RequestDatabaseNamesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestDatabaseNamesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestDatabaseNamesParams> result(new RequestDatabaseNamesParams());
  errors->Push();
  errors->SetName("RequestDatabaseNamesParams");
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestDatabaseNamesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  return std::move(result);
}

std::unique_ptr<RequestDatabaseNamesParams> RequestDatabaseNamesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestDatabaseNamesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestDatabaseNamesResult> RequestDatabaseNamesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestDatabaseNamesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestDatabaseNamesResult> result(new RequestDatabaseNamesResult());
  errors->Push();
  errors->SetName("RequestDatabaseNamesResult");
  const base::Value* database_names_value;
  if (object->Get("databaseNames", &database_names_value)) {
    errors->SetName("databaseNames");
    result->database_names_ = internal::FromValue<std::vector<std::string>>::Parse(*database_names_value, errors);
  } else {
    errors->AddError("required property missing: databaseNames");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestDatabaseNamesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("databaseNames", internal::ToValue(database_names_));
  return std::move(result);
}

std::unique_ptr<RequestDatabaseNamesResult> RequestDatabaseNamesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestDatabaseNamesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestDatabaseParams> RequestDatabaseParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestDatabaseParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestDatabaseParams> result(new RequestDatabaseParams());
  errors->Push();
  errors->SetName("RequestDatabaseParams");
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  const base::Value* database_name_value;
  if (object->Get("databaseName", &database_name_value)) {
    errors->SetName("databaseName");
    result->database_name_ = internal::FromValue<std::string>::Parse(*database_name_value, errors);
  } else {
    errors->AddError("required property missing: databaseName");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestDatabaseParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  result->Set("databaseName", internal::ToValue(database_name_));
  return std::move(result);
}

std::unique_ptr<RequestDatabaseParams> RequestDatabaseParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestDatabaseParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestDatabaseResult> RequestDatabaseResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestDatabaseResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestDatabaseResult> result(new RequestDatabaseResult());
  errors->Push();
  errors->SetName("RequestDatabaseResult");
  const base::Value* database_with_object_stores_value;
  if (object->Get("databaseWithObjectStores", &database_with_object_stores_value)) {
    errors->SetName("databaseWithObjectStores");
    result->database_with_object_stores_ = internal::FromValue<headless::indexeddb::DatabaseWithObjectStores>::Parse(*database_with_object_stores_value, errors);
  } else {
    errors->AddError("required property missing: databaseWithObjectStores");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestDatabaseResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("databaseWithObjectStores", internal::ToValue(*database_with_object_stores_));
  return std::move(result);
}

std::unique_ptr<RequestDatabaseResult> RequestDatabaseResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestDatabaseResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestDataParams> RequestDataParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestDataParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestDataParams> result(new RequestDataParams());
  errors->Push();
  errors->SetName("RequestDataParams");
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  const base::Value* database_name_value;
  if (object->Get("databaseName", &database_name_value)) {
    errors->SetName("databaseName");
    result->database_name_ = internal::FromValue<std::string>::Parse(*database_name_value, errors);
  } else {
    errors->AddError("required property missing: databaseName");
  }
  const base::Value* object_store_name_value;
  if (object->Get("objectStoreName", &object_store_name_value)) {
    errors->SetName("objectStoreName");
    result->object_store_name_ = internal::FromValue<std::string>::Parse(*object_store_name_value, errors);
  } else {
    errors->AddError("required property missing: objectStoreName");
  }
  const base::Value* index_name_value;
  if (object->Get("indexName", &index_name_value)) {
    errors->SetName("indexName");
    result->index_name_ = internal::FromValue<std::string>::Parse(*index_name_value, errors);
  } else {
    errors->AddError("required property missing: indexName");
  }
  const base::Value* skip_count_value;
  if (object->Get("skipCount", &skip_count_value)) {
    errors->SetName("skipCount");
    result->skip_count_ = internal::FromValue<int>::Parse(*skip_count_value, errors);
  } else {
    errors->AddError("required property missing: skipCount");
  }
  const base::Value* page_size_value;
  if (object->Get("pageSize", &page_size_value)) {
    errors->SetName("pageSize");
    result->page_size_ = internal::FromValue<int>::Parse(*page_size_value, errors);
  } else {
    errors->AddError("required property missing: pageSize");
  }
  const base::Value* key_range_value;
  if (object->Get("keyRange", &key_range_value)) {
    errors->SetName("keyRange");
    result->key_range_ = Just(internal::FromValue<headless::indexeddb::KeyRange>::Parse(*key_range_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestDataParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  result->Set("databaseName", internal::ToValue(database_name_));
  result->Set("objectStoreName", internal::ToValue(object_store_name_));
  result->Set("indexName", internal::ToValue(index_name_));
  result->Set("skipCount", internal::ToValue(skip_count_));
  result->Set("pageSize", internal::ToValue(page_size_));
  if (key_range_.IsJust())
    result->Set("keyRange", internal::ToValue(*key_range_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RequestDataParams> RequestDataParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestDataParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestDataResult> RequestDataResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestDataResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestDataResult> result(new RequestDataResult());
  errors->Push();
  errors->SetName("RequestDataResult");
  const base::Value* object_store_data_entries_value;
  if (object->Get("objectStoreDataEntries", &object_store_data_entries_value)) {
    errors->SetName("objectStoreDataEntries");
    result->object_store_data_entries_ = internal::FromValue<std::vector<std::unique_ptr<headless::indexeddb::DataEntry>>>::Parse(*object_store_data_entries_value, errors);
  } else {
    errors->AddError("required property missing: objectStoreDataEntries");
  }
  const base::Value* has_more_value;
  if (object->Get("hasMore", &has_more_value)) {
    errors->SetName("hasMore");
    result->has_more_ = internal::FromValue<bool>::Parse(*has_more_value, errors);
  } else {
    errors->AddError("required property missing: hasMore");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestDataResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectStoreDataEntries", internal::ToValue(object_store_data_entries_));
  result->Set("hasMore", internal::ToValue(has_more_));
  return std::move(result);
}

std::unique_ptr<RequestDataResult> RequestDataResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestDataResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ClearObjectStoreParams> ClearObjectStoreParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ClearObjectStoreParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ClearObjectStoreParams> result(new ClearObjectStoreParams());
  errors->Push();
  errors->SetName("ClearObjectStoreParams");
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  const base::Value* database_name_value;
  if (object->Get("databaseName", &database_name_value)) {
    errors->SetName("databaseName");
    result->database_name_ = internal::FromValue<std::string>::Parse(*database_name_value, errors);
  } else {
    errors->AddError("required property missing: databaseName");
  }
  const base::Value* object_store_name_value;
  if (object->Get("objectStoreName", &object_store_name_value)) {
    errors->SetName("objectStoreName");
    result->object_store_name_ = internal::FromValue<std::string>::Parse(*object_store_name_value, errors);
  } else {
    errors->AddError("required property missing: objectStoreName");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ClearObjectStoreParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  result->Set("databaseName", internal::ToValue(database_name_));
  result->Set("objectStoreName", internal::ToValue(object_store_name_));
  return std::move(result);
}

std::unique_ptr<ClearObjectStoreParams> ClearObjectStoreParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ClearObjectStoreParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ClearObjectStoreResult> ClearObjectStoreResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ClearObjectStoreResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ClearObjectStoreResult> result(new ClearObjectStoreResult());
  errors->Push();
  errors->SetName("ClearObjectStoreResult");
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ClearObjectStoreResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  return std::move(result);
}

std::unique_ptr<ClearObjectStoreResult> ClearObjectStoreResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ClearObjectStoreResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace indexeddb

namespace cache_storage {

std::unique_ptr<DataEntry> DataEntry::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DataEntry");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DataEntry> result(new DataEntry());
  errors->Push();
  errors->SetName("DataEntry");
  const base::Value* request_value;
  if (object->Get("request", &request_value)) {
    errors->SetName("request");
    result->request_ = internal::FromValue<std::string>::Parse(*request_value, errors);
  } else {
    errors->AddError("required property missing: request");
  }
  const base::Value* response_value;
  if (object->Get("response", &response_value)) {
    errors->SetName("response");
    result->response_ = internal::FromValue<std::string>::Parse(*response_value, errors);
  } else {
    errors->AddError("required property missing: response");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DataEntry::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("request", internal::ToValue(request_));
  result->Set("response", internal::ToValue(response_));
  return std::move(result);
}

std::unique_ptr<DataEntry> DataEntry::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DataEntry> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Cache> Cache::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Cache");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Cache> result(new Cache());
  errors->Push();
  errors->SetName("Cache");
  const base::Value* cache_id_value;
  if (object->Get("cacheId", &cache_id_value)) {
    errors->SetName("cacheId");
    result->cache_id_ = internal::FromValue<std::string>::Parse(*cache_id_value, errors);
  } else {
    errors->AddError("required property missing: cacheId");
  }
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  const base::Value* cache_name_value;
  if (object->Get("cacheName", &cache_name_value)) {
    errors->SetName("cacheName");
    result->cache_name_ = internal::FromValue<std::string>::Parse(*cache_name_value, errors);
  } else {
    errors->AddError("required property missing: cacheName");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Cache::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cacheId", internal::ToValue(cache_id_));
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  result->Set("cacheName", internal::ToValue(cache_name_));
  return std::move(result);
}

std::unique_ptr<Cache> Cache::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Cache> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestCacheNamesParams> RequestCacheNamesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestCacheNamesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestCacheNamesParams> result(new RequestCacheNamesParams());
  errors->Push();
  errors->SetName("RequestCacheNamesParams");
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestCacheNamesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  return std::move(result);
}

std::unique_ptr<RequestCacheNamesParams> RequestCacheNamesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestCacheNamesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestCacheNamesResult> RequestCacheNamesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestCacheNamesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestCacheNamesResult> result(new RequestCacheNamesResult());
  errors->Push();
  errors->SetName("RequestCacheNamesResult");
  const base::Value* caches_value;
  if (object->Get("caches", &caches_value)) {
    errors->SetName("caches");
    result->caches_ = internal::FromValue<std::vector<std::unique_ptr<headless::cache_storage::Cache>>>::Parse(*caches_value, errors);
  } else {
    errors->AddError("required property missing: caches");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestCacheNamesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("caches", internal::ToValue(caches_));
  return std::move(result);
}

std::unique_ptr<RequestCacheNamesResult> RequestCacheNamesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestCacheNamesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestEntriesParams> RequestEntriesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestEntriesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestEntriesParams> result(new RequestEntriesParams());
  errors->Push();
  errors->SetName("RequestEntriesParams");
  const base::Value* cache_id_value;
  if (object->Get("cacheId", &cache_id_value)) {
    errors->SetName("cacheId");
    result->cache_id_ = internal::FromValue<std::string>::Parse(*cache_id_value, errors);
  } else {
    errors->AddError("required property missing: cacheId");
  }
  const base::Value* skip_count_value;
  if (object->Get("skipCount", &skip_count_value)) {
    errors->SetName("skipCount");
    result->skip_count_ = internal::FromValue<int>::Parse(*skip_count_value, errors);
  } else {
    errors->AddError("required property missing: skipCount");
  }
  const base::Value* page_size_value;
  if (object->Get("pageSize", &page_size_value)) {
    errors->SetName("pageSize");
    result->page_size_ = internal::FromValue<int>::Parse(*page_size_value, errors);
  } else {
    errors->AddError("required property missing: pageSize");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestEntriesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cacheId", internal::ToValue(cache_id_));
  result->Set("skipCount", internal::ToValue(skip_count_));
  result->Set("pageSize", internal::ToValue(page_size_));
  return std::move(result);
}

std::unique_ptr<RequestEntriesParams> RequestEntriesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestEntriesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestEntriesResult> RequestEntriesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestEntriesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestEntriesResult> result(new RequestEntriesResult());
  errors->Push();
  errors->SetName("RequestEntriesResult");
  const base::Value* cache_data_entries_value;
  if (object->Get("cacheDataEntries", &cache_data_entries_value)) {
    errors->SetName("cacheDataEntries");
    result->cache_data_entries_ = internal::FromValue<std::vector<std::unique_ptr<headless::cache_storage::DataEntry>>>::Parse(*cache_data_entries_value, errors);
  } else {
    errors->AddError("required property missing: cacheDataEntries");
  }
  const base::Value* has_more_value;
  if (object->Get("hasMore", &has_more_value)) {
    errors->SetName("hasMore");
    result->has_more_ = internal::FromValue<bool>::Parse(*has_more_value, errors);
  } else {
    errors->AddError("required property missing: hasMore");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestEntriesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cacheDataEntries", internal::ToValue(cache_data_entries_));
  result->Set("hasMore", internal::ToValue(has_more_));
  return std::move(result);
}

std::unique_ptr<RequestEntriesResult> RequestEntriesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestEntriesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DeleteCacheParams> DeleteCacheParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DeleteCacheParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DeleteCacheParams> result(new DeleteCacheParams());
  errors->Push();
  errors->SetName("DeleteCacheParams");
  const base::Value* cache_id_value;
  if (object->Get("cacheId", &cache_id_value)) {
    errors->SetName("cacheId");
    result->cache_id_ = internal::FromValue<std::string>::Parse(*cache_id_value, errors);
  } else {
    errors->AddError("required property missing: cacheId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DeleteCacheParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cacheId", internal::ToValue(cache_id_));
  return std::move(result);
}

std::unique_ptr<DeleteCacheParams> DeleteCacheParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DeleteCacheParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DeleteEntryParams> DeleteEntryParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DeleteEntryParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DeleteEntryParams> result(new DeleteEntryParams());
  errors->Push();
  errors->SetName("DeleteEntryParams");
  const base::Value* cache_id_value;
  if (object->Get("cacheId", &cache_id_value)) {
    errors->SetName("cacheId");
    result->cache_id_ = internal::FromValue<std::string>::Parse(*cache_id_value, errors);
  } else {
    errors->AddError("required property missing: cacheId");
  }
  const base::Value* request_value;
  if (object->Get("request", &request_value)) {
    errors->SetName("request");
    result->request_ = internal::FromValue<std::string>::Parse(*request_value, errors);
  } else {
    errors->AddError("required property missing: request");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DeleteEntryParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("cacheId", internal::ToValue(cache_id_));
  result->Set("request", internal::ToValue(request_));
  return std::move(result);
}

std::unique_ptr<DeleteEntryParams> DeleteEntryParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DeleteEntryParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace cache_storage

namespace dom_storage {

std::unique_ptr<StorageId> StorageId::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StorageId");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StorageId> result(new StorageId());
  errors->Push();
  errors->SetName("StorageId");
  const base::Value* security_origin_value;
  if (object->Get("securityOrigin", &security_origin_value)) {
    errors->SetName("securityOrigin");
    result->security_origin_ = internal::FromValue<std::string>::Parse(*security_origin_value, errors);
  } else {
    errors->AddError("required property missing: securityOrigin");
  }
  const base::Value* is_local_storage_value;
  if (object->Get("isLocalStorage", &is_local_storage_value)) {
    errors->SetName("isLocalStorage");
    result->is_local_storage_ = internal::FromValue<bool>::Parse(*is_local_storage_value, errors);
  } else {
    errors->AddError("required property missing: isLocalStorage");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StorageId::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("securityOrigin", internal::ToValue(security_origin_));
  result->Set("isLocalStorage", internal::ToValue(is_local_storage_));
  return std::move(result);
}

std::unique_ptr<StorageId> StorageId::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StorageId> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetDOMStorageItemsParams> GetDOMStorageItemsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetDOMStorageItemsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetDOMStorageItemsParams> result(new GetDOMStorageItemsParams());
  errors->Push();
  errors->SetName("GetDOMStorageItemsParams");
  const base::Value* storage_id_value;
  if (object->Get("storageId", &storage_id_value)) {
    errors->SetName("storageId");
    result->storage_id_ = internal::FromValue<headless::dom_storage::StorageId>::Parse(*storage_id_value, errors);
  } else {
    errors->AddError("required property missing: storageId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetDOMStorageItemsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("storageId", internal::ToValue(*storage_id_));
  return std::move(result);
}

std::unique_ptr<GetDOMStorageItemsParams> GetDOMStorageItemsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetDOMStorageItemsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetDOMStorageItemsResult> GetDOMStorageItemsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetDOMStorageItemsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetDOMStorageItemsResult> result(new GetDOMStorageItemsResult());
  errors->Push();
  errors->SetName("GetDOMStorageItemsResult");
  const base::Value* entries_value;
  if (object->Get("entries", &entries_value)) {
    errors->SetName("entries");
    result->entries_ = internal::FromValue<std::vector<std::vector<std::string>>>::Parse(*entries_value, errors);
  } else {
    errors->AddError("required property missing: entries");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetDOMStorageItemsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("entries", internal::ToValue(entries_));
  return std::move(result);
}

std::unique_ptr<GetDOMStorageItemsResult> GetDOMStorageItemsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetDOMStorageItemsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetDOMStorageItemParams> SetDOMStorageItemParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDOMStorageItemParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDOMStorageItemParams> result(new SetDOMStorageItemParams());
  errors->Push();
  errors->SetName("SetDOMStorageItemParams");
  const base::Value* storage_id_value;
  if (object->Get("storageId", &storage_id_value)) {
    errors->SetName("storageId");
    result->storage_id_ = internal::FromValue<headless::dom_storage::StorageId>::Parse(*storage_id_value, errors);
  } else {
    errors->AddError("required property missing: storageId");
  }
  const base::Value* key_value;
  if (object->Get("key", &key_value)) {
    errors->SetName("key");
    result->key_ = internal::FromValue<std::string>::Parse(*key_value, errors);
  } else {
    errors->AddError("required property missing: key");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDOMStorageItemParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("storageId", internal::ToValue(*storage_id_));
  result->Set("key", internal::ToValue(key_));
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<SetDOMStorageItemParams> SetDOMStorageItemParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDOMStorageItemParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveDOMStorageItemParams> RemoveDOMStorageItemParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveDOMStorageItemParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveDOMStorageItemParams> result(new RemoveDOMStorageItemParams());
  errors->Push();
  errors->SetName("RemoveDOMStorageItemParams");
  const base::Value* storage_id_value;
  if (object->Get("storageId", &storage_id_value)) {
    errors->SetName("storageId");
    result->storage_id_ = internal::FromValue<headless::dom_storage::StorageId>::Parse(*storage_id_value, errors);
  } else {
    errors->AddError("required property missing: storageId");
  }
  const base::Value* key_value;
  if (object->Get("key", &key_value)) {
    errors->SetName("key");
    result->key_ = internal::FromValue<std::string>::Parse(*key_value, errors);
  } else {
    errors->AddError("required property missing: key");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveDOMStorageItemParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("storageId", internal::ToValue(*storage_id_));
  result->Set("key", internal::ToValue(key_));
  return std::move(result);
}

std::unique_ptr<RemoveDOMStorageItemParams> RemoveDOMStorageItemParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveDOMStorageItemParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace dom_storage

namespace application_cache {

std::unique_ptr<ApplicationCacheResource> ApplicationCacheResource::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ApplicationCacheResource");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ApplicationCacheResource> result(new ApplicationCacheResource());
  errors->Push();
  errors->SetName("ApplicationCacheResource");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* size_value;
  if (object->Get("size", &size_value)) {
    errors->SetName("size");
    result->size_ = internal::FromValue<int>::Parse(*size_value, errors);
  } else {
    errors->AddError("required property missing: size");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<std::string>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ApplicationCacheResource::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  result->Set("size", internal::ToValue(size_));
  result->Set("type", internal::ToValue(type_));
  return std::move(result);
}

std::unique_ptr<ApplicationCacheResource> ApplicationCacheResource::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ApplicationCacheResource> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ApplicationCache> ApplicationCache::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ApplicationCache");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ApplicationCache> result(new ApplicationCache());
  errors->Push();
  errors->SetName("ApplicationCache");
  const base::Value* manifesturl_value;
  if (object->Get("manifestURL", &manifesturl_value)) {
    errors->SetName("manifestURL");
    result->manifesturl_ = internal::FromValue<std::string>::Parse(*manifesturl_value, errors);
  } else {
    errors->AddError("required property missing: manifestURL");
  }
  const base::Value* size_value;
  if (object->Get("size", &size_value)) {
    errors->SetName("size");
    result->size_ = internal::FromValue<double>::Parse(*size_value, errors);
  } else {
    errors->AddError("required property missing: size");
  }
  const base::Value* creation_time_value;
  if (object->Get("creationTime", &creation_time_value)) {
    errors->SetName("creationTime");
    result->creation_time_ = internal::FromValue<double>::Parse(*creation_time_value, errors);
  } else {
    errors->AddError("required property missing: creationTime");
  }
  const base::Value* update_time_value;
  if (object->Get("updateTime", &update_time_value)) {
    errors->SetName("updateTime");
    result->update_time_ = internal::FromValue<double>::Parse(*update_time_value, errors);
  } else {
    errors->AddError("required property missing: updateTime");
  }
  const base::Value* resources_value;
  if (object->Get("resources", &resources_value)) {
    errors->SetName("resources");
    result->resources_ = internal::FromValue<std::vector<std::unique_ptr<headless::application_cache::ApplicationCacheResource>>>::Parse(*resources_value, errors);
  } else {
    errors->AddError("required property missing: resources");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ApplicationCache::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("manifestURL", internal::ToValue(manifesturl_));
  result->Set("size", internal::ToValue(size_));
  result->Set("creationTime", internal::ToValue(creation_time_));
  result->Set("updateTime", internal::ToValue(update_time_));
  result->Set("resources", internal::ToValue(resources_));
  return std::move(result);
}

std::unique_ptr<ApplicationCache> ApplicationCache::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ApplicationCache> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<FrameWithManifest> FrameWithManifest::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("FrameWithManifest");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<FrameWithManifest> result(new FrameWithManifest());
  errors->Push();
  errors->SetName("FrameWithManifest");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  const base::Value* manifesturl_value;
  if (object->Get("manifestURL", &manifesturl_value)) {
    errors->SetName("manifestURL");
    result->manifesturl_ = internal::FromValue<std::string>::Parse(*manifesturl_value, errors);
  } else {
    errors->AddError("required property missing: manifestURL");
  }
  const base::Value* status_value;
  if (object->Get("status", &status_value)) {
    errors->SetName("status");
    result->status_ = internal::FromValue<int>::Parse(*status_value, errors);
  } else {
    errors->AddError("required property missing: status");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> FrameWithManifest::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  result->Set("manifestURL", internal::ToValue(manifesturl_));
  result->Set("status", internal::ToValue(status_));
  return std::move(result);
}

std::unique_ptr<FrameWithManifest> FrameWithManifest::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<FrameWithManifest> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetFramesWithManifestsResult> GetFramesWithManifestsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetFramesWithManifestsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetFramesWithManifestsResult> result(new GetFramesWithManifestsResult());
  errors->Push();
  errors->SetName("GetFramesWithManifestsResult");
  const base::Value* frame_ids_value;
  if (object->Get("frameIds", &frame_ids_value)) {
    errors->SetName("frameIds");
    result->frame_ids_ = internal::FromValue<std::vector<std::unique_ptr<headless::application_cache::FrameWithManifest>>>::Parse(*frame_ids_value, errors);
  } else {
    errors->AddError("required property missing: frameIds");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetFramesWithManifestsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameIds", internal::ToValue(frame_ids_));
  return std::move(result);
}

std::unique_ptr<GetFramesWithManifestsResult> GetFramesWithManifestsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetFramesWithManifestsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetManifestForFrameParams> GetManifestForFrameParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetManifestForFrameParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetManifestForFrameParams> result(new GetManifestForFrameParams());
  errors->Push();
  errors->SetName("GetManifestForFrameParams");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetManifestForFrameParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  return std::move(result);
}

std::unique_ptr<GetManifestForFrameParams> GetManifestForFrameParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetManifestForFrameParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetManifestForFrameResult> GetManifestForFrameResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetManifestForFrameResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetManifestForFrameResult> result(new GetManifestForFrameResult());
  errors->Push();
  errors->SetName("GetManifestForFrameResult");
  const base::Value* manifesturl_value;
  if (object->Get("manifestURL", &manifesturl_value)) {
    errors->SetName("manifestURL");
    result->manifesturl_ = internal::FromValue<std::string>::Parse(*manifesturl_value, errors);
  } else {
    errors->AddError("required property missing: manifestURL");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetManifestForFrameResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("manifestURL", internal::ToValue(manifesturl_));
  return std::move(result);
}

std::unique_ptr<GetManifestForFrameResult> GetManifestForFrameResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetManifestForFrameResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetApplicationCacheForFrameParams> GetApplicationCacheForFrameParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetApplicationCacheForFrameParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetApplicationCacheForFrameParams> result(new GetApplicationCacheForFrameParams());
  errors->Push();
  errors->SetName("GetApplicationCacheForFrameParams");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetApplicationCacheForFrameParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  return std::move(result);
}

std::unique_ptr<GetApplicationCacheForFrameParams> GetApplicationCacheForFrameParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetApplicationCacheForFrameParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetApplicationCacheForFrameResult> GetApplicationCacheForFrameResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetApplicationCacheForFrameResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetApplicationCacheForFrameResult> result(new GetApplicationCacheForFrameResult());
  errors->Push();
  errors->SetName("GetApplicationCacheForFrameResult");
  const base::Value* application_cache_value;
  if (object->Get("applicationCache", &application_cache_value)) {
    errors->SetName("applicationCache");
    result->application_cache_ = internal::FromValue<headless::application_cache::ApplicationCache>::Parse(*application_cache_value, errors);
  } else {
    errors->AddError("required property missing: applicationCache");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetApplicationCacheForFrameResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("applicationCache", internal::ToValue(*application_cache_));
  return std::move(result);
}

std::unique_ptr<GetApplicationCacheForFrameResult> GetApplicationCacheForFrameResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetApplicationCacheForFrameResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace application_cache

namespace dom {

std::unique_ptr<BackendNode> BackendNode::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("BackendNode");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<BackendNode> result(new BackendNode());
  errors->Push();
  errors->SetName("BackendNode");
  const base::Value* node_type_value;
  if (object->Get("nodeType", &node_type_value)) {
    errors->SetName("nodeType");
    result->node_type_ = internal::FromValue<int>::Parse(*node_type_value, errors);
  } else {
    errors->AddError("required property missing: nodeType");
  }
  const base::Value* node_name_value;
  if (object->Get("nodeName", &node_name_value)) {
    errors->SetName("nodeName");
    result->node_name_ = internal::FromValue<std::string>::Parse(*node_name_value, errors);
  } else {
    errors->AddError("required property missing: nodeName");
  }
  const base::Value* backend_node_id_value;
  if (object->Get("backendNodeId", &backend_node_id_value)) {
    errors->SetName("backendNodeId");
    result->backend_node_id_ = internal::FromValue<int>::Parse(*backend_node_id_value, errors);
  } else {
    errors->AddError("required property missing: backendNodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> BackendNode::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeType", internal::ToValue(node_type_));
  result->Set("nodeName", internal::ToValue(node_name_));
  result->Set("backendNodeId", internal::ToValue(backend_node_id_));
  return std::move(result);
}

std::unique_ptr<BackendNode> BackendNode::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<BackendNode> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Node> Node::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Node");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Node> result(new Node());
  errors->Push();
  errors->SetName("Node");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* node_type_value;
  if (object->Get("nodeType", &node_type_value)) {
    errors->SetName("nodeType");
    result->node_type_ = internal::FromValue<int>::Parse(*node_type_value, errors);
  } else {
    errors->AddError("required property missing: nodeType");
  }
  const base::Value* node_name_value;
  if (object->Get("nodeName", &node_name_value)) {
    errors->SetName("nodeName");
    result->node_name_ = internal::FromValue<std::string>::Parse(*node_name_value, errors);
  } else {
    errors->AddError("required property missing: nodeName");
  }
  const base::Value* local_name_value;
  if (object->Get("localName", &local_name_value)) {
    errors->SetName("localName");
    result->local_name_ = internal::FromValue<std::string>::Parse(*local_name_value, errors);
  } else {
    errors->AddError("required property missing: localName");
  }
  const base::Value* node_value_value;
  if (object->Get("nodeValue", &node_value_value)) {
    errors->SetName("nodeValue");
    result->node_value_ = internal::FromValue<std::string>::Parse(*node_value_value, errors);
  } else {
    errors->AddError("required property missing: nodeValue");
  }
  const base::Value* child_node_count_value;
  if (object->Get("childNodeCount", &child_node_count_value)) {
    errors->SetName("childNodeCount");
    result->child_node_count_ = Just(internal::FromValue<int>::Parse(*child_node_count_value, errors));
  }
  const base::Value* children_value;
  if (object->Get("children", &children_value)) {
    errors->SetName("children");
    result->children_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::dom::Node>>>::Parse(*children_value, errors));
  }
  const base::Value* attributes_value;
  if (object->Get("attributes", &attributes_value)) {
    errors->SetName("attributes");
    result->attributes_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*attributes_value, errors));
  }
  const base::Value* documenturl_value;
  if (object->Get("documentURL", &documenturl_value)) {
    errors->SetName("documentURL");
    result->documenturl_ = Just(internal::FromValue<std::string>::Parse(*documenturl_value, errors));
  }
  const base::Value* baseurl_value;
  if (object->Get("baseURL", &baseurl_value)) {
    errors->SetName("baseURL");
    result->baseurl_ = Just(internal::FromValue<std::string>::Parse(*baseurl_value, errors));
  }
  const base::Value* public_id_value;
  if (object->Get("publicId", &public_id_value)) {
    errors->SetName("publicId");
    result->public_id_ = Just(internal::FromValue<std::string>::Parse(*public_id_value, errors));
  }
  const base::Value* system_id_value;
  if (object->Get("systemId", &system_id_value)) {
    errors->SetName("systemId");
    result->system_id_ = Just(internal::FromValue<std::string>::Parse(*system_id_value, errors));
  }
  const base::Value* internal_subset_value;
  if (object->Get("internalSubset", &internal_subset_value)) {
    errors->SetName("internalSubset");
    result->internal_subset_ = Just(internal::FromValue<std::string>::Parse(*internal_subset_value, errors));
  }
  const base::Value* xml_version_value;
  if (object->Get("xmlVersion", &xml_version_value)) {
    errors->SetName("xmlVersion");
    result->xml_version_ = Just(internal::FromValue<std::string>::Parse(*xml_version_value, errors));
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = Just(internal::FromValue<std::string>::Parse(*name_value, errors));
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<std::string>::Parse(*value_value, errors));
  }
  const base::Value* pseudo_type_value;
  if (object->Get("pseudoType", &pseudo_type_value)) {
    errors->SetName("pseudoType");
    result->pseudo_type_ = Just(internal::FromValue<headless::dom::PseudoType>::Parse(*pseudo_type_value, errors));
  }
  const base::Value* shadow_root_type_value;
  if (object->Get("shadowRootType", &shadow_root_type_value)) {
    errors->SetName("shadowRootType");
    result->shadow_root_type_ = Just(internal::FromValue<headless::dom::ShadowRootType>::Parse(*shadow_root_type_value, errors));
  }
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = Just(internal::FromValue<std::string>::Parse(*frame_id_value, errors));
  }
  const base::Value* content_document_value;
  if (object->Get("contentDocument", &content_document_value)) {
    errors->SetName("contentDocument");
    result->content_document_ = Just(internal::FromValue<headless::dom::Node>::Parse(*content_document_value, errors));
  }
  const base::Value* shadow_roots_value;
  if (object->Get("shadowRoots", &shadow_roots_value)) {
    errors->SetName("shadowRoots");
    result->shadow_roots_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::dom::Node>>>::Parse(*shadow_roots_value, errors));
  }
  const base::Value* template_content_value;
  if (object->Get("templateContent", &template_content_value)) {
    errors->SetName("templateContent");
    result->template_content_ = Just(internal::FromValue<headless::dom::Node>::Parse(*template_content_value, errors));
  }
  const base::Value* pseudo_elements_value;
  if (object->Get("pseudoElements", &pseudo_elements_value)) {
    errors->SetName("pseudoElements");
    result->pseudo_elements_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::dom::Node>>>::Parse(*pseudo_elements_value, errors));
  }
  const base::Value* imported_document_value;
  if (object->Get("importedDocument", &imported_document_value)) {
    errors->SetName("importedDocument");
    result->imported_document_ = Just(internal::FromValue<headless::dom::Node>::Parse(*imported_document_value, errors));
  }
  const base::Value* distributed_nodes_value;
  if (object->Get("distributedNodes", &distributed_nodes_value)) {
    errors->SetName("distributedNodes");
    result->distributed_nodes_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::dom::BackendNode>>>::Parse(*distributed_nodes_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Node::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("nodeType", internal::ToValue(node_type_));
  result->Set("nodeName", internal::ToValue(node_name_));
  result->Set("localName", internal::ToValue(local_name_));
  result->Set("nodeValue", internal::ToValue(node_value_));
  if (child_node_count_.IsJust())
    result->Set("childNodeCount", internal::ToValue(child_node_count_.FromJust()));
  if (children_.IsJust())
    result->Set("children", internal::ToValue(children_.FromJust()));
  if (attributes_.IsJust())
    result->Set("attributes", internal::ToValue(attributes_.FromJust()));
  if (documenturl_.IsJust())
    result->Set("documentURL", internal::ToValue(documenturl_.FromJust()));
  if (baseurl_.IsJust())
    result->Set("baseURL", internal::ToValue(baseurl_.FromJust()));
  if (public_id_.IsJust())
    result->Set("publicId", internal::ToValue(public_id_.FromJust()));
  if (system_id_.IsJust())
    result->Set("systemId", internal::ToValue(system_id_.FromJust()));
  if (internal_subset_.IsJust())
    result->Set("internalSubset", internal::ToValue(internal_subset_.FromJust()));
  if (xml_version_.IsJust())
    result->Set("xmlVersion", internal::ToValue(xml_version_.FromJust()));
  if (name_.IsJust())
    result->Set("name", internal::ToValue(name_.FromJust()));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(value_.FromJust()));
  if (pseudo_type_.IsJust())
    result->Set("pseudoType", internal::ToValue(pseudo_type_.FromJust()));
  if (shadow_root_type_.IsJust())
    result->Set("shadowRootType", internal::ToValue(shadow_root_type_.FromJust()));
  if (frame_id_.IsJust())
    result->Set("frameId", internal::ToValue(frame_id_.FromJust()));
  if (content_document_.IsJust())
    result->Set("contentDocument", internal::ToValue(*content_document_.FromJust()));
  if (shadow_roots_.IsJust())
    result->Set("shadowRoots", internal::ToValue(shadow_roots_.FromJust()));
  if (template_content_.IsJust())
    result->Set("templateContent", internal::ToValue(*template_content_.FromJust()));
  if (pseudo_elements_.IsJust())
    result->Set("pseudoElements", internal::ToValue(pseudo_elements_.FromJust()));
  if (imported_document_.IsJust())
    result->Set("importedDocument", internal::ToValue(*imported_document_.FromJust()));
  if (distributed_nodes_.IsJust())
    result->Set("distributedNodes", internal::ToValue(distributed_nodes_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Node> Node::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Node> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RGBA> RGBA::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RGBA");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RGBA> result(new RGBA());
  errors->Push();
  errors->SetName("RGBA");
  const base::Value* r_value;
  if (object->Get("r", &r_value)) {
    errors->SetName("r");
    result->r_ = internal::FromValue<int>::Parse(*r_value, errors);
  } else {
    errors->AddError("required property missing: r");
  }
  const base::Value* g_value;
  if (object->Get("g", &g_value)) {
    errors->SetName("g");
    result->g_ = internal::FromValue<int>::Parse(*g_value, errors);
  } else {
    errors->AddError("required property missing: g");
  }
  const base::Value* b_value;
  if (object->Get("b", &b_value)) {
    errors->SetName("b");
    result->b_ = internal::FromValue<int>::Parse(*b_value, errors);
  } else {
    errors->AddError("required property missing: b");
  }
  const base::Value* a_value;
  if (object->Get("a", &a_value)) {
    errors->SetName("a");
    result->a_ = Just(internal::FromValue<double>::Parse(*a_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RGBA::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("r", internal::ToValue(r_));
  result->Set("g", internal::ToValue(g_));
  result->Set("b", internal::ToValue(b_));
  if (a_.IsJust())
    result->Set("a", internal::ToValue(a_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RGBA> RGBA::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RGBA> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<BoxModel> BoxModel::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("BoxModel");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<BoxModel> result(new BoxModel());
  errors->Push();
  errors->SetName("BoxModel");
  const base::Value* content_value;
  if (object->Get("content", &content_value)) {
    errors->SetName("content");
    result->content_ = internal::FromValue<std::vector<double>>::Parse(*content_value, errors);
  } else {
    errors->AddError("required property missing: content");
  }
  const base::Value* padding_value;
  if (object->Get("padding", &padding_value)) {
    errors->SetName("padding");
    result->padding_ = internal::FromValue<std::vector<double>>::Parse(*padding_value, errors);
  } else {
    errors->AddError("required property missing: padding");
  }
  const base::Value* border_value;
  if (object->Get("border", &border_value)) {
    errors->SetName("border");
    result->border_ = internal::FromValue<std::vector<double>>::Parse(*border_value, errors);
  } else {
    errors->AddError("required property missing: border");
  }
  const base::Value* margin_value;
  if (object->Get("margin", &margin_value)) {
    errors->SetName("margin");
    result->margin_ = internal::FromValue<std::vector<double>>::Parse(*margin_value, errors);
  } else {
    errors->AddError("required property missing: margin");
  }
  const base::Value* width_value;
  if (object->Get("width", &width_value)) {
    errors->SetName("width");
    result->width_ = internal::FromValue<int>::Parse(*width_value, errors);
  } else {
    errors->AddError("required property missing: width");
  }
  const base::Value* height_value;
  if (object->Get("height", &height_value)) {
    errors->SetName("height");
    result->height_ = internal::FromValue<int>::Parse(*height_value, errors);
  } else {
    errors->AddError("required property missing: height");
  }
  const base::Value* shape_outside_value;
  if (object->Get("shapeOutside", &shape_outside_value)) {
    errors->SetName("shapeOutside");
    result->shape_outside_ = Just(internal::FromValue<headless::dom::ShapeOutsideInfo>::Parse(*shape_outside_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> BoxModel::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("content", internal::ToValue(content_));
  result->Set("padding", internal::ToValue(padding_));
  result->Set("border", internal::ToValue(border_));
  result->Set("margin", internal::ToValue(margin_));
  result->Set("width", internal::ToValue(width_));
  result->Set("height", internal::ToValue(height_));
  if (shape_outside_.IsJust())
    result->Set("shapeOutside", internal::ToValue(*shape_outside_.FromJust()));
  return std::move(result);
}

std::unique_ptr<BoxModel> BoxModel::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<BoxModel> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ShapeOutsideInfo> ShapeOutsideInfo::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ShapeOutsideInfo");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ShapeOutsideInfo> result(new ShapeOutsideInfo());
  errors->Push();
  errors->SetName("ShapeOutsideInfo");
  const base::Value* bounds_value;
  if (object->Get("bounds", &bounds_value)) {
    errors->SetName("bounds");
    result->bounds_ = internal::FromValue<std::vector<double>>::Parse(*bounds_value, errors);
  } else {
    errors->AddError("required property missing: bounds");
  }
  const base::Value* shape_value;
  if (object->Get("shape", &shape_value)) {
    errors->SetName("shape");
    result->shape_ = internal::FromValue<std::vector<std::unique_ptr<base::Value>>>::Parse(*shape_value, errors);
  } else {
    errors->AddError("required property missing: shape");
  }
  const base::Value* margin_shape_value;
  if (object->Get("marginShape", &margin_shape_value)) {
    errors->SetName("marginShape");
    result->margin_shape_ = internal::FromValue<std::vector<std::unique_ptr<base::Value>>>::Parse(*margin_shape_value, errors);
  } else {
    errors->AddError("required property missing: marginShape");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ShapeOutsideInfo::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("bounds", internal::ToValue(bounds_));
  result->Set("shape", internal::ToValue(shape_));
  result->Set("marginShape", internal::ToValue(margin_shape_));
  return std::move(result);
}

std::unique_ptr<ShapeOutsideInfo> ShapeOutsideInfo::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ShapeOutsideInfo> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Rect> Rect::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Rect");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Rect> result(new Rect());
  errors->Push();
  errors->SetName("Rect");
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<double>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<double>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* width_value;
  if (object->Get("width", &width_value)) {
    errors->SetName("width");
    result->width_ = internal::FromValue<double>::Parse(*width_value, errors);
  } else {
    errors->AddError("required property missing: width");
  }
  const base::Value* height_value;
  if (object->Get("height", &height_value)) {
    errors->SetName("height");
    result->height_ = internal::FromValue<double>::Parse(*height_value, errors);
  } else {
    errors->AddError("required property missing: height");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Rect::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  result->Set("width", internal::ToValue(width_));
  result->Set("height", internal::ToValue(height_));
  return std::move(result);
}

std::unique_ptr<Rect> Rect::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Rect> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<HighlightConfig> HighlightConfig::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("HighlightConfig");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<HighlightConfig> result(new HighlightConfig());
  errors->Push();
  errors->SetName("HighlightConfig");
  const base::Value* show_info_value;
  if (object->Get("showInfo", &show_info_value)) {
    errors->SetName("showInfo");
    result->show_info_ = Just(internal::FromValue<bool>::Parse(*show_info_value, errors));
  }
  const base::Value* show_rulers_value;
  if (object->Get("showRulers", &show_rulers_value)) {
    errors->SetName("showRulers");
    result->show_rulers_ = Just(internal::FromValue<bool>::Parse(*show_rulers_value, errors));
  }
  const base::Value* show_extension_lines_value;
  if (object->Get("showExtensionLines", &show_extension_lines_value)) {
    errors->SetName("showExtensionLines");
    result->show_extension_lines_ = Just(internal::FromValue<bool>::Parse(*show_extension_lines_value, errors));
  }
  const base::Value* display_as_material_value;
  if (object->Get("displayAsMaterial", &display_as_material_value)) {
    errors->SetName("displayAsMaterial");
    result->display_as_material_ = Just(internal::FromValue<bool>::Parse(*display_as_material_value, errors));
  }
  const base::Value* content_color_value;
  if (object->Get("contentColor", &content_color_value)) {
    errors->SetName("contentColor");
    result->content_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*content_color_value, errors));
  }
  const base::Value* padding_color_value;
  if (object->Get("paddingColor", &padding_color_value)) {
    errors->SetName("paddingColor");
    result->padding_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*padding_color_value, errors));
  }
  const base::Value* border_color_value;
  if (object->Get("borderColor", &border_color_value)) {
    errors->SetName("borderColor");
    result->border_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*border_color_value, errors));
  }
  const base::Value* margin_color_value;
  if (object->Get("marginColor", &margin_color_value)) {
    errors->SetName("marginColor");
    result->margin_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*margin_color_value, errors));
  }
  const base::Value* event_target_color_value;
  if (object->Get("eventTargetColor", &event_target_color_value)) {
    errors->SetName("eventTargetColor");
    result->event_target_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*event_target_color_value, errors));
  }
  const base::Value* shape_color_value;
  if (object->Get("shapeColor", &shape_color_value)) {
    errors->SetName("shapeColor");
    result->shape_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*shape_color_value, errors));
  }
  const base::Value* shape_margin_color_value;
  if (object->Get("shapeMarginColor", &shape_margin_color_value)) {
    errors->SetName("shapeMarginColor");
    result->shape_margin_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*shape_margin_color_value, errors));
  }
  const base::Value* selector_list_value;
  if (object->Get("selectorList", &selector_list_value)) {
    errors->SetName("selectorList");
    result->selector_list_ = Just(internal::FromValue<std::string>::Parse(*selector_list_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> HighlightConfig::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (show_info_.IsJust())
    result->Set("showInfo", internal::ToValue(show_info_.FromJust()));
  if (show_rulers_.IsJust())
    result->Set("showRulers", internal::ToValue(show_rulers_.FromJust()));
  if (show_extension_lines_.IsJust())
    result->Set("showExtensionLines", internal::ToValue(show_extension_lines_.FromJust()));
  if (display_as_material_.IsJust())
    result->Set("displayAsMaterial", internal::ToValue(display_as_material_.FromJust()));
  if (content_color_.IsJust())
    result->Set("contentColor", internal::ToValue(*content_color_.FromJust()));
  if (padding_color_.IsJust())
    result->Set("paddingColor", internal::ToValue(*padding_color_.FromJust()));
  if (border_color_.IsJust())
    result->Set("borderColor", internal::ToValue(*border_color_.FromJust()));
  if (margin_color_.IsJust())
    result->Set("marginColor", internal::ToValue(*margin_color_.FromJust()));
  if (event_target_color_.IsJust())
    result->Set("eventTargetColor", internal::ToValue(*event_target_color_.FromJust()));
  if (shape_color_.IsJust())
    result->Set("shapeColor", internal::ToValue(*shape_color_.FromJust()));
  if (shape_margin_color_.IsJust())
    result->Set("shapeMarginColor", internal::ToValue(*shape_margin_color_.FromJust()));
  if (selector_list_.IsJust())
    result->Set("selectorList", internal::ToValue(selector_list_.FromJust()));
  return std::move(result);
}

std::unique_ptr<HighlightConfig> HighlightConfig::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<HighlightConfig> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetDocumentResult> GetDocumentResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetDocumentResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetDocumentResult> result(new GetDocumentResult());
  errors->Push();
  errors->SetName("GetDocumentResult");
  const base::Value* root_value;
  if (object->Get("root", &root_value)) {
    errors->SetName("root");
    result->root_ = internal::FromValue<headless::dom::Node>::Parse(*root_value, errors);
  } else {
    errors->AddError("required property missing: root");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetDocumentResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("root", internal::ToValue(*root_));
  return std::move(result);
}

std::unique_ptr<GetDocumentResult> GetDocumentResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetDocumentResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestChildNodesParams> RequestChildNodesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestChildNodesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestChildNodesParams> result(new RequestChildNodesParams());
  errors->Push();
  errors->SetName("RequestChildNodesParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* depth_value;
  if (object->Get("depth", &depth_value)) {
    errors->SetName("depth");
    result->depth_ = Just(internal::FromValue<int>::Parse(*depth_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestChildNodesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  if (depth_.IsJust())
    result->Set("depth", internal::ToValue(depth_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RequestChildNodesParams> RequestChildNodesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestChildNodesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<QuerySelectorParams> QuerySelectorParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("QuerySelectorParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<QuerySelectorParams> result(new QuerySelectorParams());
  errors->Push();
  errors->SetName("QuerySelectorParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* selector_value;
  if (object->Get("selector", &selector_value)) {
    errors->SetName("selector");
    result->selector_ = internal::FromValue<std::string>::Parse(*selector_value, errors);
  } else {
    errors->AddError("required property missing: selector");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> QuerySelectorParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("selector", internal::ToValue(selector_));
  return std::move(result);
}

std::unique_ptr<QuerySelectorParams> QuerySelectorParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<QuerySelectorParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<QuerySelectorResult> QuerySelectorResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("QuerySelectorResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<QuerySelectorResult> result(new QuerySelectorResult());
  errors->Push();
  errors->SetName("QuerySelectorResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> QuerySelectorResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<QuerySelectorResult> QuerySelectorResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<QuerySelectorResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<QuerySelectorAllParams> QuerySelectorAllParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("QuerySelectorAllParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<QuerySelectorAllParams> result(new QuerySelectorAllParams());
  errors->Push();
  errors->SetName("QuerySelectorAllParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* selector_value;
  if (object->Get("selector", &selector_value)) {
    errors->SetName("selector");
    result->selector_ = internal::FromValue<std::string>::Parse(*selector_value, errors);
  } else {
    errors->AddError("required property missing: selector");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> QuerySelectorAllParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("selector", internal::ToValue(selector_));
  return std::move(result);
}

std::unique_ptr<QuerySelectorAllParams> QuerySelectorAllParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<QuerySelectorAllParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<QuerySelectorAllResult> QuerySelectorAllResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("QuerySelectorAllResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<QuerySelectorAllResult> result(new QuerySelectorAllResult());
  errors->Push();
  errors->SetName("QuerySelectorAllResult");
  const base::Value* node_ids_value;
  if (object->Get("nodeIds", &node_ids_value)) {
    errors->SetName("nodeIds");
    result->node_ids_ = internal::FromValue<std::vector<int>>::Parse(*node_ids_value, errors);
  } else {
    errors->AddError("required property missing: nodeIds");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> QuerySelectorAllResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeIds", internal::ToValue(node_ids_));
  return std::move(result);
}

std::unique_ptr<QuerySelectorAllResult> QuerySelectorAllResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<QuerySelectorAllResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetNodeNameParams> SetNodeNameParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetNodeNameParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetNodeNameParams> result(new SetNodeNameParams());
  errors->Push();
  errors->SetName("SetNodeNameParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetNodeNameParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("name", internal::ToValue(name_));
  return std::move(result);
}

std::unique_ptr<SetNodeNameParams> SetNodeNameParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetNodeNameParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetNodeNameResult> SetNodeNameResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetNodeNameResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetNodeNameResult> result(new SetNodeNameResult());
  errors->Push();
  errors->SetName("SetNodeNameResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetNodeNameResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<SetNodeNameResult> SetNodeNameResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetNodeNameResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetNodeValueParams> SetNodeValueParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetNodeValueParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetNodeValueParams> result(new SetNodeValueParams());
  errors->Push();
  errors->SetName("SetNodeValueParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetNodeValueParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<SetNodeValueParams> SetNodeValueParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetNodeValueParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveNodeParams> RemoveNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveNodeParams> result(new RemoveNodeParams());
  errors->Push();
  errors->SetName("RemoveNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<RemoveNodeParams> RemoveNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetAttributeValueParams> SetAttributeValueParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetAttributeValueParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetAttributeValueParams> result(new SetAttributeValueParams());
  errors->Push();
  errors->SetName("SetAttributeValueParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetAttributeValueParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("name", internal::ToValue(name_));
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<SetAttributeValueParams> SetAttributeValueParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetAttributeValueParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetAttributesAsTextParams> SetAttributesAsTextParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetAttributesAsTextParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetAttributesAsTextParams> result(new SetAttributesAsTextParams());
  errors->Push();
  errors->SetName("SetAttributesAsTextParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = Just(internal::FromValue<std::string>::Parse(*name_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetAttributesAsTextParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("text", internal::ToValue(text_));
  if (name_.IsJust())
    result->Set("name", internal::ToValue(name_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetAttributesAsTextParams> SetAttributesAsTextParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetAttributesAsTextParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveAttributeParams> RemoveAttributeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveAttributeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveAttributeParams> result(new RemoveAttributeParams());
  errors->Push();
  errors->SetName("RemoveAttributeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveAttributeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("name", internal::ToValue(name_));
  return std::move(result);
}

std::unique_ptr<RemoveAttributeParams> RemoveAttributeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveAttributeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetOuterHTMLParams> GetOuterHTMLParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetOuterHTMLParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetOuterHTMLParams> result(new GetOuterHTMLParams());
  errors->Push();
  errors->SetName("GetOuterHTMLParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetOuterHTMLParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetOuterHTMLParams> GetOuterHTMLParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetOuterHTMLParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetOuterHTMLResult> GetOuterHTMLResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetOuterHTMLResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetOuterHTMLResult> result(new GetOuterHTMLResult());
  errors->Push();
  errors->SetName("GetOuterHTMLResult");
  const base::Value* outerhtml_value;
  if (object->Get("outerHTML", &outerhtml_value)) {
    errors->SetName("outerHTML");
    result->outerhtml_ = internal::FromValue<std::string>::Parse(*outerhtml_value, errors);
  } else {
    errors->AddError("required property missing: outerHTML");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetOuterHTMLResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("outerHTML", internal::ToValue(outerhtml_));
  return std::move(result);
}

std::unique_ptr<GetOuterHTMLResult> GetOuterHTMLResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetOuterHTMLResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetOuterHTMLParams> SetOuterHTMLParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetOuterHTMLParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetOuterHTMLParams> result(new SetOuterHTMLParams());
  errors->Push();
  errors->SetName("SetOuterHTMLParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* outerhtml_value;
  if (object->Get("outerHTML", &outerhtml_value)) {
    errors->SetName("outerHTML");
    result->outerhtml_ = internal::FromValue<std::string>::Parse(*outerhtml_value, errors);
  } else {
    errors->AddError("required property missing: outerHTML");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetOuterHTMLParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("outerHTML", internal::ToValue(outerhtml_));
  return std::move(result);
}

std::unique_ptr<SetOuterHTMLParams> SetOuterHTMLParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetOuterHTMLParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PerformSearchParams> PerformSearchParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PerformSearchParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PerformSearchParams> result(new PerformSearchParams());
  errors->Push();
  errors->SetName("PerformSearchParams");
  const base::Value* query_value;
  if (object->Get("query", &query_value)) {
    errors->SetName("query");
    result->query_ = internal::FromValue<std::string>::Parse(*query_value, errors);
  } else {
    errors->AddError("required property missing: query");
  }
  const base::Value* include_user_agent_shadowdom_value;
  if (object->Get("includeUserAgentShadowDOM", &include_user_agent_shadowdom_value)) {
    errors->SetName("includeUserAgentShadowDOM");
    result->include_user_agent_shadowdom_ = Just(internal::FromValue<bool>::Parse(*include_user_agent_shadowdom_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PerformSearchParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("query", internal::ToValue(query_));
  if (include_user_agent_shadowdom_.IsJust())
    result->Set("includeUserAgentShadowDOM", internal::ToValue(include_user_agent_shadowdom_.FromJust()));
  return std::move(result);
}

std::unique_ptr<PerformSearchParams> PerformSearchParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PerformSearchParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PerformSearchResult> PerformSearchResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PerformSearchResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PerformSearchResult> result(new PerformSearchResult());
  errors->Push();
  errors->SetName("PerformSearchResult");
  const base::Value* search_id_value;
  if (object->Get("searchId", &search_id_value)) {
    errors->SetName("searchId");
    result->search_id_ = internal::FromValue<std::string>::Parse(*search_id_value, errors);
  } else {
    errors->AddError("required property missing: searchId");
  }
  const base::Value* result_count_value;
  if (object->Get("resultCount", &result_count_value)) {
    errors->SetName("resultCount");
    result->result_count_ = internal::FromValue<int>::Parse(*result_count_value, errors);
  } else {
    errors->AddError("required property missing: resultCount");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PerformSearchResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("searchId", internal::ToValue(search_id_));
  result->Set("resultCount", internal::ToValue(result_count_));
  return std::move(result);
}

std::unique_ptr<PerformSearchResult> PerformSearchResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PerformSearchResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetSearchResultsParams> GetSearchResultsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetSearchResultsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetSearchResultsParams> result(new GetSearchResultsParams());
  errors->Push();
  errors->SetName("GetSearchResultsParams");
  const base::Value* search_id_value;
  if (object->Get("searchId", &search_id_value)) {
    errors->SetName("searchId");
    result->search_id_ = internal::FromValue<std::string>::Parse(*search_id_value, errors);
  } else {
    errors->AddError("required property missing: searchId");
  }
  const base::Value* from_index_value;
  if (object->Get("fromIndex", &from_index_value)) {
    errors->SetName("fromIndex");
    result->from_index_ = internal::FromValue<int>::Parse(*from_index_value, errors);
  } else {
    errors->AddError("required property missing: fromIndex");
  }
  const base::Value* to_index_value;
  if (object->Get("toIndex", &to_index_value)) {
    errors->SetName("toIndex");
    result->to_index_ = internal::FromValue<int>::Parse(*to_index_value, errors);
  } else {
    errors->AddError("required property missing: toIndex");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetSearchResultsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("searchId", internal::ToValue(search_id_));
  result->Set("fromIndex", internal::ToValue(from_index_));
  result->Set("toIndex", internal::ToValue(to_index_));
  return std::move(result);
}

std::unique_ptr<GetSearchResultsParams> GetSearchResultsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetSearchResultsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetSearchResultsResult> GetSearchResultsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetSearchResultsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetSearchResultsResult> result(new GetSearchResultsResult());
  errors->Push();
  errors->SetName("GetSearchResultsResult");
  const base::Value* node_ids_value;
  if (object->Get("nodeIds", &node_ids_value)) {
    errors->SetName("nodeIds");
    result->node_ids_ = internal::FromValue<std::vector<int>>::Parse(*node_ids_value, errors);
  } else {
    errors->AddError("required property missing: nodeIds");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetSearchResultsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeIds", internal::ToValue(node_ids_));
  return std::move(result);
}

std::unique_ptr<GetSearchResultsResult> GetSearchResultsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetSearchResultsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DiscardSearchResultsParams> DiscardSearchResultsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DiscardSearchResultsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DiscardSearchResultsParams> result(new DiscardSearchResultsParams());
  errors->Push();
  errors->SetName("DiscardSearchResultsParams");
  const base::Value* search_id_value;
  if (object->Get("searchId", &search_id_value)) {
    errors->SetName("searchId");
    result->search_id_ = internal::FromValue<std::string>::Parse(*search_id_value, errors);
  } else {
    errors->AddError("required property missing: searchId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DiscardSearchResultsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("searchId", internal::ToValue(search_id_));
  return std::move(result);
}

std::unique_ptr<DiscardSearchResultsParams> DiscardSearchResultsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DiscardSearchResultsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestNodeParams> RequestNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestNodeParams> result(new RequestNodeParams());
  errors->Push();
  errors->SetName("RequestNodeParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  return std::move(result);
}

std::unique_ptr<RequestNodeParams> RequestNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestNodeResult> RequestNodeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestNodeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestNodeResult> result(new RequestNodeResult());
  errors->Push();
  errors->SetName("RequestNodeResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestNodeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<RequestNodeResult> RequestNodeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestNodeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetInspectModeParams> SetInspectModeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetInspectModeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetInspectModeParams> result(new SetInspectModeParams());
  errors->Push();
  errors->SetName("SetInspectModeParams");
  const base::Value* mode_value;
  if (object->Get("mode", &mode_value)) {
    errors->SetName("mode");
    result->mode_ = internal::FromValue<headless::dom::InspectMode>::Parse(*mode_value, errors);
  } else {
    errors->AddError("required property missing: mode");
  }
  const base::Value* highlight_config_value;
  if (object->Get("highlightConfig", &highlight_config_value)) {
    errors->SetName("highlightConfig");
    result->highlight_config_ = Just(internal::FromValue<headless::dom::HighlightConfig>::Parse(*highlight_config_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetInspectModeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("mode", internal::ToValue(mode_));
  if (highlight_config_.IsJust())
    result->Set("highlightConfig", internal::ToValue(*highlight_config_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetInspectModeParams> SetInspectModeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetInspectModeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<HighlightRectParams> HighlightRectParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("HighlightRectParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<HighlightRectParams> result(new HighlightRectParams());
  errors->Push();
  errors->SetName("HighlightRectParams");
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* width_value;
  if (object->Get("width", &width_value)) {
    errors->SetName("width");
    result->width_ = internal::FromValue<int>::Parse(*width_value, errors);
  } else {
    errors->AddError("required property missing: width");
  }
  const base::Value* height_value;
  if (object->Get("height", &height_value)) {
    errors->SetName("height");
    result->height_ = internal::FromValue<int>::Parse(*height_value, errors);
  } else {
    errors->AddError("required property missing: height");
  }
  const base::Value* color_value;
  if (object->Get("color", &color_value)) {
    errors->SetName("color");
    result->color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*color_value, errors));
  }
  const base::Value* outline_color_value;
  if (object->Get("outlineColor", &outline_color_value)) {
    errors->SetName("outlineColor");
    result->outline_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*outline_color_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> HighlightRectParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  result->Set("width", internal::ToValue(width_));
  result->Set("height", internal::ToValue(height_));
  if (color_.IsJust())
    result->Set("color", internal::ToValue(*color_.FromJust()));
  if (outline_color_.IsJust())
    result->Set("outlineColor", internal::ToValue(*outline_color_.FromJust()));
  return std::move(result);
}

std::unique_ptr<HighlightRectParams> HighlightRectParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<HighlightRectParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<HighlightQuadParams> HighlightQuadParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("HighlightQuadParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<HighlightQuadParams> result(new HighlightQuadParams());
  errors->Push();
  errors->SetName("HighlightQuadParams");
  const base::Value* quad_value;
  if (object->Get("quad", &quad_value)) {
    errors->SetName("quad");
    result->quad_ = internal::FromValue<std::vector<double>>::Parse(*quad_value, errors);
  } else {
    errors->AddError("required property missing: quad");
  }
  const base::Value* color_value;
  if (object->Get("color", &color_value)) {
    errors->SetName("color");
    result->color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*color_value, errors));
  }
  const base::Value* outline_color_value;
  if (object->Get("outlineColor", &outline_color_value)) {
    errors->SetName("outlineColor");
    result->outline_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*outline_color_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> HighlightQuadParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("quad", internal::ToValue(quad_));
  if (color_.IsJust())
    result->Set("color", internal::ToValue(*color_.FromJust()));
  if (outline_color_.IsJust())
    result->Set("outlineColor", internal::ToValue(*outline_color_.FromJust()));
  return std::move(result);
}

std::unique_ptr<HighlightQuadParams> HighlightQuadParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<HighlightQuadParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<HighlightNodeParams> HighlightNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("HighlightNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<HighlightNodeParams> result(new HighlightNodeParams());
  errors->Push();
  errors->SetName("HighlightNodeParams");
  const base::Value* highlight_config_value;
  if (object->Get("highlightConfig", &highlight_config_value)) {
    errors->SetName("highlightConfig");
    result->highlight_config_ = internal::FromValue<headless::dom::HighlightConfig>::Parse(*highlight_config_value, errors);
  } else {
    errors->AddError("required property missing: highlightConfig");
  }
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = Just(internal::FromValue<int>::Parse(*node_id_value, errors));
  }
  const base::Value* backend_node_id_value;
  if (object->Get("backendNodeId", &backend_node_id_value)) {
    errors->SetName("backendNodeId");
    result->backend_node_id_ = Just(internal::FromValue<int>::Parse(*backend_node_id_value, errors));
  }
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = Just(internal::FromValue<std::string>::Parse(*object_id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> HighlightNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("highlightConfig", internal::ToValue(*highlight_config_));
  if (node_id_.IsJust())
    result->Set("nodeId", internal::ToValue(node_id_.FromJust()));
  if (backend_node_id_.IsJust())
    result->Set("backendNodeId", internal::ToValue(backend_node_id_.FromJust()));
  if (object_id_.IsJust())
    result->Set("objectId", internal::ToValue(object_id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<HighlightNodeParams> HighlightNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<HighlightNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<HighlightFrameParams> HighlightFrameParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("HighlightFrameParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<HighlightFrameParams> result(new HighlightFrameParams());
  errors->Push();
  errors->SetName("HighlightFrameParams");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  const base::Value* content_color_value;
  if (object->Get("contentColor", &content_color_value)) {
    errors->SetName("contentColor");
    result->content_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*content_color_value, errors));
  }
  const base::Value* content_outline_color_value;
  if (object->Get("contentOutlineColor", &content_outline_color_value)) {
    errors->SetName("contentOutlineColor");
    result->content_outline_color_ = Just(internal::FromValue<headless::dom::RGBA>::Parse(*content_outline_color_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> HighlightFrameParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  if (content_color_.IsJust())
    result->Set("contentColor", internal::ToValue(*content_color_.FromJust()));
  if (content_outline_color_.IsJust())
    result->Set("contentOutlineColor", internal::ToValue(*content_outline_color_.FromJust()));
  return std::move(result);
}

std::unique_ptr<HighlightFrameParams> HighlightFrameParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<HighlightFrameParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PushNodeByPathToFrontendParams> PushNodeByPathToFrontendParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PushNodeByPathToFrontendParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PushNodeByPathToFrontendParams> result(new PushNodeByPathToFrontendParams());
  errors->Push();
  errors->SetName("PushNodeByPathToFrontendParams");
  const base::Value* path_value;
  if (object->Get("path", &path_value)) {
    errors->SetName("path");
    result->path_ = internal::FromValue<std::string>::Parse(*path_value, errors);
  } else {
    errors->AddError("required property missing: path");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PushNodeByPathToFrontendParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("path", internal::ToValue(path_));
  return std::move(result);
}

std::unique_ptr<PushNodeByPathToFrontendParams> PushNodeByPathToFrontendParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PushNodeByPathToFrontendParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PushNodeByPathToFrontendResult> PushNodeByPathToFrontendResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PushNodeByPathToFrontendResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PushNodeByPathToFrontendResult> result(new PushNodeByPathToFrontendResult());
  errors->Push();
  errors->SetName("PushNodeByPathToFrontendResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PushNodeByPathToFrontendResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<PushNodeByPathToFrontendResult> PushNodeByPathToFrontendResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PushNodeByPathToFrontendResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PushNodesByBackendIdsToFrontendParams> PushNodesByBackendIdsToFrontendParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PushNodesByBackendIdsToFrontendParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PushNodesByBackendIdsToFrontendParams> result(new PushNodesByBackendIdsToFrontendParams());
  errors->Push();
  errors->SetName("PushNodesByBackendIdsToFrontendParams");
  const base::Value* backend_node_ids_value;
  if (object->Get("backendNodeIds", &backend_node_ids_value)) {
    errors->SetName("backendNodeIds");
    result->backend_node_ids_ = internal::FromValue<std::vector<int>>::Parse(*backend_node_ids_value, errors);
  } else {
    errors->AddError("required property missing: backendNodeIds");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PushNodesByBackendIdsToFrontendParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("backendNodeIds", internal::ToValue(backend_node_ids_));
  return std::move(result);
}

std::unique_ptr<PushNodesByBackendIdsToFrontendParams> PushNodesByBackendIdsToFrontendParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PushNodesByBackendIdsToFrontendParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PushNodesByBackendIdsToFrontendResult> PushNodesByBackendIdsToFrontendResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PushNodesByBackendIdsToFrontendResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PushNodesByBackendIdsToFrontendResult> result(new PushNodesByBackendIdsToFrontendResult());
  errors->Push();
  errors->SetName("PushNodesByBackendIdsToFrontendResult");
  const base::Value* node_ids_value;
  if (object->Get("nodeIds", &node_ids_value)) {
    errors->SetName("nodeIds");
    result->node_ids_ = internal::FromValue<std::vector<int>>::Parse(*node_ids_value, errors);
  } else {
    errors->AddError("required property missing: nodeIds");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PushNodesByBackendIdsToFrontendResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeIds", internal::ToValue(node_ids_));
  return std::move(result);
}

std::unique_ptr<PushNodesByBackendIdsToFrontendResult> PushNodesByBackendIdsToFrontendResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PushNodesByBackendIdsToFrontendResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetInspectedNodeParams> SetInspectedNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetInspectedNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetInspectedNodeParams> result(new SetInspectedNodeParams());
  errors->Push();
  errors->SetName("SetInspectedNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetInspectedNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<SetInspectedNodeParams> SetInspectedNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetInspectedNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ResolveNodeParams> ResolveNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ResolveNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ResolveNodeParams> result(new ResolveNodeParams());
  errors->Push();
  errors->SetName("ResolveNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* object_group_value;
  if (object->Get("objectGroup", &object_group_value)) {
    errors->SetName("objectGroup");
    result->object_group_ = Just(internal::FromValue<std::string>::Parse(*object_group_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ResolveNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  if (object_group_.IsJust())
    result->Set("objectGroup", internal::ToValue(object_group_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ResolveNodeParams> ResolveNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ResolveNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ResolveNodeResult> ResolveNodeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ResolveNodeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ResolveNodeResult> result(new ResolveNodeResult());
  errors->Push();
  errors->SetName("ResolveNodeResult");
  const base::Value* object_value;
  if (object->Get("object", &object_value)) {
    errors->SetName("object");
    result->object_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*object_value, errors);
  } else {
    errors->AddError("required property missing: object");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ResolveNodeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("object", internal::ToValue(*object_));
  return std::move(result);
}

std::unique_ptr<ResolveNodeResult> ResolveNodeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ResolveNodeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetAttributesParams> GetAttributesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetAttributesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetAttributesParams> result(new GetAttributesParams());
  errors->Push();
  errors->SetName("GetAttributesParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetAttributesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetAttributesParams> GetAttributesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetAttributesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetAttributesResult> GetAttributesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetAttributesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetAttributesResult> result(new GetAttributesResult());
  errors->Push();
  errors->SetName("GetAttributesResult");
  const base::Value* attributes_value;
  if (object->Get("attributes", &attributes_value)) {
    errors->SetName("attributes");
    result->attributes_ = internal::FromValue<std::vector<std::string>>::Parse(*attributes_value, errors);
  } else {
    errors->AddError("required property missing: attributes");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetAttributesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("attributes", internal::ToValue(attributes_));
  return std::move(result);
}

std::unique_ptr<GetAttributesResult> GetAttributesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetAttributesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CopyToParams> CopyToParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CopyToParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CopyToParams> result(new CopyToParams());
  errors->Push();
  errors->SetName("CopyToParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* target_node_id_value;
  if (object->Get("targetNodeId", &target_node_id_value)) {
    errors->SetName("targetNodeId");
    result->target_node_id_ = internal::FromValue<int>::Parse(*target_node_id_value, errors);
  } else {
    errors->AddError("required property missing: targetNodeId");
  }
  const base::Value* insert_before_node_id_value;
  if (object->Get("insertBeforeNodeId", &insert_before_node_id_value)) {
    errors->SetName("insertBeforeNodeId");
    result->insert_before_node_id_ = Just(internal::FromValue<int>::Parse(*insert_before_node_id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CopyToParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("targetNodeId", internal::ToValue(target_node_id_));
  if (insert_before_node_id_.IsJust())
    result->Set("insertBeforeNodeId", internal::ToValue(insert_before_node_id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CopyToParams> CopyToParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CopyToParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CopyToResult> CopyToResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CopyToResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CopyToResult> result(new CopyToResult());
  errors->Push();
  errors->SetName("CopyToResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CopyToResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<CopyToResult> CopyToResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CopyToResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MoveToParams> MoveToParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MoveToParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MoveToParams> result(new MoveToParams());
  errors->Push();
  errors->SetName("MoveToParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* target_node_id_value;
  if (object->Get("targetNodeId", &target_node_id_value)) {
    errors->SetName("targetNodeId");
    result->target_node_id_ = internal::FromValue<int>::Parse(*target_node_id_value, errors);
  } else {
    errors->AddError("required property missing: targetNodeId");
  }
  const base::Value* insert_before_node_id_value;
  if (object->Get("insertBeforeNodeId", &insert_before_node_id_value)) {
    errors->SetName("insertBeforeNodeId");
    result->insert_before_node_id_ = Just(internal::FromValue<int>::Parse(*insert_before_node_id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MoveToParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("targetNodeId", internal::ToValue(target_node_id_));
  if (insert_before_node_id_.IsJust())
    result->Set("insertBeforeNodeId", internal::ToValue(insert_before_node_id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<MoveToParams> MoveToParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MoveToParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MoveToResult> MoveToResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MoveToResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MoveToResult> result(new MoveToResult());
  errors->Push();
  errors->SetName("MoveToResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MoveToResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<MoveToResult> MoveToResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MoveToResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<FocusParams> FocusParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("FocusParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<FocusParams> result(new FocusParams());
  errors->Push();
  errors->SetName("FocusParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> FocusParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<FocusParams> FocusParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<FocusParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetFileInputFilesParams> SetFileInputFilesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetFileInputFilesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetFileInputFilesParams> result(new SetFileInputFilesParams());
  errors->Push();
  errors->SetName("SetFileInputFilesParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* files_value;
  if (object->Get("files", &files_value)) {
    errors->SetName("files");
    result->files_ = internal::FromValue<std::vector<std::string>>::Parse(*files_value, errors);
  } else {
    errors->AddError("required property missing: files");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetFileInputFilesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("files", internal::ToValue(files_));
  return std::move(result);
}

std::unique_ptr<SetFileInputFilesParams> SetFileInputFilesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetFileInputFilesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetBoxModelParams> GetBoxModelParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetBoxModelParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetBoxModelParams> result(new GetBoxModelParams());
  errors->Push();
  errors->SetName("GetBoxModelParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetBoxModelParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetBoxModelParams> GetBoxModelParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetBoxModelParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetBoxModelResult> GetBoxModelResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetBoxModelResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetBoxModelResult> result(new GetBoxModelResult());
  errors->Push();
  errors->SetName("GetBoxModelResult");
  const base::Value* model_value;
  if (object->Get("model", &model_value)) {
    errors->SetName("model");
    result->model_ = internal::FromValue<headless::dom::BoxModel>::Parse(*model_value, errors);
  } else {
    errors->AddError("required property missing: model");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetBoxModelResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("model", internal::ToValue(*model_));
  return std::move(result);
}

std::unique_ptr<GetBoxModelResult> GetBoxModelResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetBoxModelResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetNodeForLocationParams> GetNodeForLocationParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetNodeForLocationParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetNodeForLocationParams> result(new GetNodeForLocationParams());
  errors->Push();
  errors->SetName("GetNodeForLocationParams");
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetNodeForLocationParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  return std::move(result);
}

std::unique_ptr<GetNodeForLocationParams> GetNodeForLocationParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetNodeForLocationParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetNodeForLocationResult> GetNodeForLocationResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetNodeForLocationResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetNodeForLocationResult> result(new GetNodeForLocationResult());
  errors->Push();
  errors->SetName("GetNodeForLocationResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetNodeForLocationResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetNodeForLocationResult> GetNodeForLocationResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetNodeForLocationResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetRelayoutBoundaryParams> GetRelayoutBoundaryParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetRelayoutBoundaryParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetRelayoutBoundaryParams> result(new GetRelayoutBoundaryParams());
  errors->Push();
  errors->SetName("GetRelayoutBoundaryParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetRelayoutBoundaryParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetRelayoutBoundaryParams> GetRelayoutBoundaryParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetRelayoutBoundaryParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetRelayoutBoundaryResult> GetRelayoutBoundaryResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetRelayoutBoundaryResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetRelayoutBoundaryResult> result(new GetRelayoutBoundaryResult());
  errors->Push();
  errors->SetName("GetRelayoutBoundaryResult");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetRelayoutBoundaryResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetRelayoutBoundaryResult> GetRelayoutBoundaryResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetRelayoutBoundaryResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetHighlightObjectForTestParams> GetHighlightObjectForTestParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetHighlightObjectForTestParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetHighlightObjectForTestParams> result(new GetHighlightObjectForTestParams());
  errors->Push();
  errors->SetName("GetHighlightObjectForTestParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetHighlightObjectForTestParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetHighlightObjectForTestParams> GetHighlightObjectForTestParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetHighlightObjectForTestParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetHighlightObjectForTestResult> GetHighlightObjectForTestResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetHighlightObjectForTestResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetHighlightObjectForTestResult> result(new GetHighlightObjectForTestResult());
  errors->Push();
  errors->SetName("GetHighlightObjectForTestResult");
  const base::Value* highlight_value;
  if (object->Get("highlight", &highlight_value)) {
    errors->SetName("highlight");
    result->highlight_ = internal::FromValue<base::Value>::Parse(*highlight_value, errors);
  } else {
    errors->AddError("required property missing: highlight");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetHighlightObjectForTestResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("highlight", internal::ToValue(*highlight_));
  return std::move(result);
}

std::unique_ptr<GetHighlightObjectForTestResult> GetHighlightObjectForTestResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetHighlightObjectForTestResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace dom

namespace css {

std::unique_ptr<PseudoElementMatches> PseudoElementMatches::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PseudoElementMatches");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PseudoElementMatches> result(new PseudoElementMatches());
  errors->Push();
  errors->SetName("PseudoElementMatches");
  const base::Value* pseudo_type_value;
  if (object->Get("pseudoType", &pseudo_type_value)) {
    errors->SetName("pseudoType");
    result->pseudo_type_ = internal::FromValue<headless::dom::PseudoType>::Parse(*pseudo_type_value, errors);
  } else {
    errors->AddError("required property missing: pseudoType");
  }
  const base::Value* matches_value;
  if (object->Get("matches", &matches_value)) {
    errors->SetName("matches");
    result->matches_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::RuleMatch>>>::Parse(*matches_value, errors);
  } else {
    errors->AddError("required property missing: matches");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PseudoElementMatches::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("pseudoType", internal::ToValue(pseudo_type_));
  result->Set("matches", internal::ToValue(matches_));
  return std::move(result);
}

std::unique_ptr<PseudoElementMatches> PseudoElementMatches::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PseudoElementMatches> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<InheritedStyleEntry> InheritedStyleEntry::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("InheritedStyleEntry");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<InheritedStyleEntry> result(new InheritedStyleEntry());
  errors->Push();
  errors->SetName("InheritedStyleEntry");
  const base::Value* inline_style_value;
  if (object->Get("inlineStyle", &inline_style_value)) {
    errors->SetName("inlineStyle");
    result->inline_style_ = Just(internal::FromValue<headless::css::CSSStyle>::Parse(*inline_style_value, errors));
  }
  const base::Value* matchedcss_rules_value;
  if (object->Get("matchedCSSRules", &matchedcss_rules_value)) {
    errors->SetName("matchedCSSRules");
    result->matchedcss_rules_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::RuleMatch>>>::Parse(*matchedcss_rules_value, errors);
  } else {
    errors->AddError("required property missing: matchedCSSRules");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> InheritedStyleEntry::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (inline_style_.IsJust())
    result->Set("inlineStyle", internal::ToValue(*inline_style_.FromJust()));
  result->Set("matchedCSSRules", internal::ToValue(matchedcss_rules_));
  return std::move(result);
}

std::unique_ptr<InheritedStyleEntry> InheritedStyleEntry::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<InheritedStyleEntry> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RuleMatch> RuleMatch::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RuleMatch");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RuleMatch> result(new RuleMatch());
  errors->Push();
  errors->SetName("RuleMatch");
  const base::Value* rule_value;
  if (object->Get("rule", &rule_value)) {
    errors->SetName("rule");
    result->rule_ = internal::FromValue<headless::css::CSSRule>::Parse(*rule_value, errors);
  } else {
    errors->AddError("required property missing: rule");
  }
  const base::Value* matching_selectors_value;
  if (object->Get("matchingSelectors", &matching_selectors_value)) {
    errors->SetName("matchingSelectors");
    result->matching_selectors_ = internal::FromValue<std::vector<int>>::Parse(*matching_selectors_value, errors);
  } else {
    errors->AddError("required property missing: matchingSelectors");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RuleMatch::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("rule", internal::ToValue(*rule_));
  result->Set("matchingSelectors", internal::ToValue(matching_selectors_));
  return std::move(result);
}

std::unique_ptr<RuleMatch> RuleMatch::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RuleMatch> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Value> Value::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Value");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Value> result(new Value());
  errors->Push();
  errors->SetName("Value");
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = Just(internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Value::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("text", internal::ToValue(text_));
  if (range_.IsJust())
    result->Set("range", internal::ToValue(*range_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Value> Value::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Value> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SelectorList> SelectorList::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SelectorList");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SelectorList> result(new SelectorList());
  errors->Push();
  errors->SetName("SelectorList");
  const base::Value* selectors_value;
  if (object->Get("selectors", &selectors_value)) {
    errors->SetName("selectors");
    result->selectors_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::Value>>>::Parse(*selectors_value, errors);
  } else {
    errors->AddError("required property missing: selectors");
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SelectorList::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("selectors", internal::ToValue(selectors_));
  result->Set("text", internal::ToValue(text_));
  return std::move(result);
}

std::unique_ptr<SelectorList> SelectorList::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SelectorList> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSStyleSheetHeader> CSSStyleSheetHeader::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSStyleSheetHeader");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSStyleSheetHeader> result(new CSSStyleSheetHeader());
  errors->Push();
  errors->SetName("CSSStyleSheetHeader");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  const base::Value* sourceurl_value;
  if (object->Get("sourceURL", &sourceurl_value)) {
    errors->SetName("sourceURL");
    result->sourceurl_ = internal::FromValue<std::string>::Parse(*sourceurl_value, errors);
  } else {
    errors->AddError("required property missing: sourceURL");
  }
  const base::Value* source_mapurl_value;
  if (object->Get("sourceMapURL", &source_mapurl_value)) {
    errors->SetName("sourceMapURL");
    result->source_mapurl_ = Just(internal::FromValue<std::string>::Parse(*source_mapurl_value, errors));
  }
  const base::Value* origin_value;
  if (object->Get("origin", &origin_value)) {
    errors->SetName("origin");
    result->origin_ = internal::FromValue<headless::css::StyleSheetOrigin>::Parse(*origin_value, errors);
  } else {
    errors->AddError("required property missing: origin");
  }
  const base::Value* title_value;
  if (object->Get("title", &title_value)) {
    errors->SetName("title");
    result->title_ = internal::FromValue<std::string>::Parse(*title_value, errors);
  } else {
    errors->AddError("required property missing: title");
  }
  const base::Value* owner_node_value;
  if (object->Get("ownerNode", &owner_node_value)) {
    errors->SetName("ownerNode");
    result->owner_node_ = Just(internal::FromValue<int>::Parse(*owner_node_value, errors));
  }
  const base::Value* disabled_value;
  if (object->Get("disabled", &disabled_value)) {
    errors->SetName("disabled");
    result->disabled_ = internal::FromValue<bool>::Parse(*disabled_value, errors);
  } else {
    errors->AddError("required property missing: disabled");
  }
  const base::Value* has_sourceurl_value;
  if (object->Get("hasSourceURL", &has_sourceurl_value)) {
    errors->SetName("hasSourceURL");
    result->has_sourceurl_ = Just(internal::FromValue<bool>::Parse(*has_sourceurl_value, errors));
  }
  const base::Value* is_inline_value;
  if (object->Get("isInline", &is_inline_value)) {
    errors->SetName("isInline");
    result->is_inline_ = internal::FromValue<bool>::Parse(*is_inline_value, errors);
  } else {
    errors->AddError("required property missing: isInline");
  }
  const base::Value* start_line_value;
  if (object->Get("startLine", &start_line_value)) {
    errors->SetName("startLine");
    result->start_line_ = internal::FromValue<double>::Parse(*start_line_value, errors);
  } else {
    errors->AddError("required property missing: startLine");
  }
  const base::Value* start_column_value;
  if (object->Get("startColumn", &start_column_value)) {
    errors->SetName("startColumn");
    result->start_column_ = internal::FromValue<double>::Parse(*start_column_value, errors);
  } else {
    errors->AddError("required property missing: startColumn");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSStyleSheetHeader::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  result->Set("frameId", internal::ToValue(frame_id_));
  result->Set("sourceURL", internal::ToValue(sourceurl_));
  if (source_mapurl_.IsJust())
    result->Set("sourceMapURL", internal::ToValue(source_mapurl_.FromJust()));
  result->Set("origin", internal::ToValue(origin_));
  result->Set("title", internal::ToValue(title_));
  if (owner_node_.IsJust())
    result->Set("ownerNode", internal::ToValue(owner_node_.FromJust()));
  result->Set("disabled", internal::ToValue(disabled_));
  if (has_sourceurl_.IsJust())
    result->Set("hasSourceURL", internal::ToValue(has_sourceurl_.FromJust()));
  result->Set("isInline", internal::ToValue(is_inline_));
  result->Set("startLine", internal::ToValue(start_line_));
  result->Set("startColumn", internal::ToValue(start_column_));
  return std::move(result);
}

std::unique_ptr<CSSStyleSheetHeader> CSSStyleSheetHeader::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSStyleSheetHeader> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSRule> CSSRule::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSRule");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSRule> result(new CSSRule());
  errors->Push();
  errors->SetName("CSSRule");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = Just(internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors));
  }
  const base::Value* selector_list_value;
  if (object->Get("selectorList", &selector_list_value)) {
    errors->SetName("selectorList");
    result->selector_list_ = internal::FromValue<headless::css::SelectorList>::Parse(*selector_list_value, errors);
  } else {
    errors->AddError("required property missing: selectorList");
  }
  const base::Value* origin_value;
  if (object->Get("origin", &origin_value)) {
    errors->SetName("origin");
    result->origin_ = internal::FromValue<headless::css::StyleSheetOrigin>::Parse(*origin_value, errors);
  } else {
    errors->AddError("required property missing: origin");
  }
  const base::Value* style_value;
  if (object->Get("style", &style_value)) {
    errors->SetName("style");
    result->style_ = internal::FromValue<headless::css::CSSStyle>::Parse(*style_value, errors);
  } else {
    errors->AddError("required property missing: style");
  }
  const base::Value* media_value;
  if (object->Get("media", &media_value)) {
    errors->SetName("media");
    result->media_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::css::CSSMedia>>>::Parse(*media_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSRule::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (style_sheet_id_.IsJust())
    result->Set("styleSheetId", internal::ToValue(style_sheet_id_.FromJust()));
  result->Set("selectorList", internal::ToValue(*selector_list_));
  result->Set("origin", internal::ToValue(origin_));
  result->Set("style", internal::ToValue(*style_));
  if (media_.IsJust())
    result->Set("media", internal::ToValue(media_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CSSRule> CSSRule::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSRule> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SourceRange> SourceRange::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SourceRange");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SourceRange> result(new SourceRange());
  errors->Push();
  errors->SetName("SourceRange");
  const base::Value* start_line_value;
  if (object->Get("startLine", &start_line_value)) {
    errors->SetName("startLine");
    result->start_line_ = internal::FromValue<int>::Parse(*start_line_value, errors);
  } else {
    errors->AddError("required property missing: startLine");
  }
  const base::Value* start_column_value;
  if (object->Get("startColumn", &start_column_value)) {
    errors->SetName("startColumn");
    result->start_column_ = internal::FromValue<int>::Parse(*start_column_value, errors);
  } else {
    errors->AddError("required property missing: startColumn");
  }
  const base::Value* end_line_value;
  if (object->Get("endLine", &end_line_value)) {
    errors->SetName("endLine");
    result->end_line_ = internal::FromValue<int>::Parse(*end_line_value, errors);
  } else {
    errors->AddError("required property missing: endLine");
  }
  const base::Value* end_column_value;
  if (object->Get("endColumn", &end_column_value)) {
    errors->SetName("endColumn");
    result->end_column_ = internal::FromValue<int>::Parse(*end_column_value, errors);
  } else {
    errors->AddError("required property missing: endColumn");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SourceRange::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("startLine", internal::ToValue(start_line_));
  result->Set("startColumn", internal::ToValue(start_column_));
  result->Set("endLine", internal::ToValue(end_line_));
  result->Set("endColumn", internal::ToValue(end_column_));
  return std::move(result);
}

std::unique_ptr<SourceRange> SourceRange::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SourceRange> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ShorthandEntry> ShorthandEntry::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ShorthandEntry");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ShorthandEntry> result(new ShorthandEntry());
  errors->Push();
  errors->SetName("ShorthandEntry");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  const base::Value* important_value;
  if (object->Get("important", &important_value)) {
    errors->SetName("important");
    result->important_ = Just(internal::FromValue<bool>::Parse(*important_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ShorthandEntry::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("value", internal::ToValue(value_));
  if (important_.IsJust())
    result->Set("important", internal::ToValue(important_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ShorthandEntry> ShorthandEntry::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ShorthandEntry> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSComputedStyleProperty> CSSComputedStyleProperty::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSComputedStyleProperty");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSComputedStyleProperty> result(new CSSComputedStyleProperty());
  errors->Push();
  errors->SetName("CSSComputedStyleProperty");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSComputedStyleProperty::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<CSSComputedStyleProperty> CSSComputedStyleProperty::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSComputedStyleProperty> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSStyle> CSSStyle::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSStyle");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSStyle> result(new CSSStyle());
  errors->Push();
  errors->SetName("CSSStyle");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = Just(internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors));
  }
  const base::Value* css_properties_value;
  if (object->Get("cssProperties", &css_properties_value)) {
    errors->SetName("cssProperties");
    result->css_properties_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::CSSProperty>>>::Parse(*css_properties_value, errors);
  } else {
    errors->AddError("required property missing: cssProperties");
  }
  const base::Value* shorthand_entries_value;
  if (object->Get("shorthandEntries", &shorthand_entries_value)) {
    errors->SetName("shorthandEntries");
    result->shorthand_entries_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::ShorthandEntry>>>::Parse(*shorthand_entries_value, errors);
  } else {
    errors->AddError("required property missing: shorthandEntries");
  }
  const base::Value* css_text_value;
  if (object->Get("cssText", &css_text_value)) {
    errors->SetName("cssText");
    result->css_text_ = Just(internal::FromValue<std::string>::Parse(*css_text_value, errors));
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = Just(internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSStyle::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (style_sheet_id_.IsJust())
    result->Set("styleSheetId", internal::ToValue(style_sheet_id_.FromJust()));
  result->Set("cssProperties", internal::ToValue(css_properties_));
  result->Set("shorthandEntries", internal::ToValue(shorthand_entries_));
  if (css_text_.IsJust())
    result->Set("cssText", internal::ToValue(css_text_.FromJust()));
  if (range_.IsJust())
    result->Set("range", internal::ToValue(*range_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CSSStyle> CSSStyle::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSStyle> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSProperty> CSSProperty::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSProperty");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSProperty> result(new CSSProperty());
  errors->Push();
  errors->SetName("CSSProperty");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  const base::Value* important_value;
  if (object->Get("important", &important_value)) {
    errors->SetName("important");
    result->important_ = Just(internal::FromValue<bool>::Parse(*important_value, errors));
  }
  const base::Value* implicit_value;
  if (object->Get("implicit", &implicit_value)) {
    errors->SetName("implicit");
    result->implicit_ = Just(internal::FromValue<bool>::Parse(*implicit_value, errors));
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = Just(internal::FromValue<std::string>::Parse(*text_value, errors));
  }
  const base::Value* parsed_ok_value;
  if (object->Get("parsedOk", &parsed_ok_value)) {
    errors->SetName("parsedOk");
    result->parsed_ok_ = Just(internal::FromValue<bool>::Parse(*parsed_ok_value, errors));
  }
  const base::Value* disabled_value;
  if (object->Get("disabled", &disabled_value)) {
    errors->SetName("disabled");
    result->disabled_ = Just(internal::FromValue<bool>::Parse(*disabled_value, errors));
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = Just(internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSProperty::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("value", internal::ToValue(value_));
  if (important_.IsJust())
    result->Set("important", internal::ToValue(important_.FromJust()));
  if (implicit_.IsJust())
    result->Set("implicit", internal::ToValue(implicit_.FromJust()));
  if (text_.IsJust())
    result->Set("text", internal::ToValue(text_.FromJust()));
  if (parsed_ok_.IsJust())
    result->Set("parsedOk", internal::ToValue(parsed_ok_.FromJust()));
  if (disabled_.IsJust())
    result->Set("disabled", internal::ToValue(disabled_.FromJust()));
  if (range_.IsJust())
    result->Set("range", internal::ToValue(*range_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CSSProperty> CSSProperty::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSProperty> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSMedia> CSSMedia::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSMedia");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSMedia> result(new CSSMedia());
  errors->Push();
  errors->SetName("CSSMedia");
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  const base::Value* source_value;
  if (object->Get("source", &source_value)) {
    errors->SetName("source");
    result->source_ = internal::FromValue<headless::css::CSSMediaSource>::Parse(*source_value, errors);
  } else {
    errors->AddError("required property missing: source");
  }
  const base::Value* sourceurl_value;
  if (object->Get("sourceURL", &sourceurl_value)) {
    errors->SetName("sourceURL");
    result->sourceurl_ = Just(internal::FromValue<std::string>::Parse(*sourceurl_value, errors));
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = Just(internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors));
  }
  const base::Value* parent_style_sheet_id_value;
  if (object->Get("parentStyleSheetId", &parent_style_sheet_id_value)) {
    errors->SetName("parentStyleSheetId");
    result->parent_style_sheet_id_ = Just(internal::FromValue<std::string>::Parse(*parent_style_sheet_id_value, errors));
  }
  const base::Value* media_list_value;
  if (object->Get("mediaList", &media_list_value)) {
    errors->SetName("mediaList");
    result->media_list_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::css::MediaQuery>>>::Parse(*media_list_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSMedia::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("text", internal::ToValue(text_));
  result->Set("source", internal::ToValue(source_));
  if (sourceurl_.IsJust())
    result->Set("sourceURL", internal::ToValue(sourceurl_.FromJust()));
  if (range_.IsJust())
    result->Set("range", internal::ToValue(*range_.FromJust()));
  if (parent_style_sheet_id_.IsJust())
    result->Set("parentStyleSheetId", internal::ToValue(parent_style_sheet_id_.FromJust()));
  if (media_list_.IsJust())
    result->Set("mediaList", internal::ToValue(media_list_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CSSMedia> CSSMedia::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSMedia> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MediaQuery> MediaQuery::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MediaQuery");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MediaQuery> result(new MediaQuery());
  errors->Push();
  errors->SetName("MediaQuery");
  const base::Value* expressions_value;
  if (object->Get("expressions", &expressions_value)) {
    errors->SetName("expressions");
    result->expressions_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::MediaQueryExpression>>>::Parse(*expressions_value, errors);
  } else {
    errors->AddError("required property missing: expressions");
  }
  const base::Value* active_value;
  if (object->Get("active", &active_value)) {
    errors->SetName("active");
    result->active_ = internal::FromValue<bool>::Parse(*active_value, errors);
  } else {
    errors->AddError("required property missing: active");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MediaQuery::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("expressions", internal::ToValue(expressions_));
  result->Set("active", internal::ToValue(active_));
  return std::move(result);
}

std::unique_ptr<MediaQuery> MediaQuery::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MediaQuery> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MediaQueryExpression> MediaQueryExpression::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MediaQueryExpression");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MediaQueryExpression> result(new MediaQueryExpression());
  errors->Push();
  errors->SetName("MediaQueryExpression");
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<double>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  const base::Value* unit_value;
  if (object->Get("unit", &unit_value)) {
    errors->SetName("unit");
    result->unit_ = internal::FromValue<std::string>::Parse(*unit_value, errors);
  } else {
    errors->AddError("required property missing: unit");
  }
  const base::Value* feature_value;
  if (object->Get("feature", &feature_value)) {
    errors->SetName("feature");
    result->feature_ = internal::FromValue<std::string>::Parse(*feature_value, errors);
  } else {
    errors->AddError("required property missing: feature");
  }
  const base::Value* value_range_value;
  if (object->Get("valueRange", &value_range_value)) {
    errors->SetName("valueRange");
    result->value_range_ = Just(internal::FromValue<headless::css::SourceRange>::Parse(*value_range_value, errors));
  }
  const base::Value* computed_length_value;
  if (object->Get("computedLength", &computed_length_value)) {
    errors->SetName("computedLength");
    result->computed_length_ = Just(internal::FromValue<double>::Parse(*computed_length_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MediaQueryExpression::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("value", internal::ToValue(value_));
  result->Set("unit", internal::ToValue(unit_));
  result->Set("feature", internal::ToValue(feature_));
  if (value_range_.IsJust())
    result->Set("valueRange", internal::ToValue(*value_range_.FromJust()));
  if (computed_length_.IsJust())
    result->Set("computedLength", internal::ToValue(computed_length_.FromJust()));
  return std::move(result);
}

std::unique_ptr<MediaQueryExpression> MediaQueryExpression::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MediaQueryExpression> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PlatformFontUsage> PlatformFontUsage::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PlatformFontUsage");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PlatformFontUsage> result(new PlatformFontUsage());
  errors->Push();
  errors->SetName("PlatformFontUsage");
  const base::Value* family_name_value;
  if (object->Get("familyName", &family_name_value)) {
    errors->SetName("familyName");
    result->family_name_ = internal::FromValue<std::string>::Parse(*family_name_value, errors);
  } else {
    errors->AddError("required property missing: familyName");
  }
  const base::Value* is_custom_font_value;
  if (object->Get("isCustomFont", &is_custom_font_value)) {
    errors->SetName("isCustomFont");
    result->is_custom_font_ = internal::FromValue<bool>::Parse(*is_custom_font_value, errors);
  } else {
    errors->AddError("required property missing: isCustomFont");
  }
  const base::Value* glyph_count_value;
  if (object->Get("glyphCount", &glyph_count_value)) {
    errors->SetName("glyphCount");
    result->glyph_count_ = internal::FromValue<double>::Parse(*glyph_count_value, errors);
  } else {
    errors->AddError("required property missing: glyphCount");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PlatformFontUsage::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("familyName", internal::ToValue(family_name_));
  result->Set("isCustomFont", internal::ToValue(is_custom_font_));
  result->Set("glyphCount", internal::ToValue(glyph_count_));
  return std::move(result);
}

std::unique_ptr<PlatformFontUsage> PlatformFontUsage::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PlatformFontUsage> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSKeyframesRule> CSSKeyframesRule::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSKeyframesRule");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSKeyframesRule> result(new CSSKeyframesRule());
  errors->Push();
  errors->SetName("CSSKeyframesRule");
  const base::Value* animation_name_value;
  if (object->Get("animationName", &animation_name_value)) {
    errors->SetName("animationName");
    result->animation_name_ = internal::FromValue<headless::css::Value>::Parse(*animation_name_value, errors);
  } else {
    errors->AddError("required property missing: animationName");
  }
  const base::Value* keyframes_value;
  if (object->Get("keyframes", &keyframes_value)) {
    errors->SetName("keyframes");
    result->keyframes_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::CSSKeyframeRule>>>::Parse(*keyframes_value, errors);
  } else {
    errors->AddError("required property missing: keyframes");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSKeyframesRule::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("animationName", internal::ToValue(*animation_name_));
  result->Set("keyframes", internal::ToValue(keyframes_));
  return std::move(result);
}

std::unique_ptr<CSSKeyframesRule> CSSKeyframesRule::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSKeyframesRule> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CSSKeyframeRule> CSSKeyframeRule::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CSSKeyframeRule");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CSSKeyframeRule> result(new CSSKeyframeRule());
  errors->Push();
  errors->SetName("CSSKeyframeRule");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = Just(internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors));
  }
  const base::Value* origin_value;
  if (object->Get("origin", &origin_value)) {
    errors->SetName("origin");
    result->origin_ = internal::FromValue<headless::css::StyleSheetOrigin>::Parse(*origin_value, errors);
  } else {
    errors->AddError("required property missing: origin");
  }
  const base::Value* key_text_value;
  if (object->Get("keyText", &key_text_value)) {
    errors->SetName("keyText");
    result->key_text_ = internal::FromValue<headless::css::Value>::Parse(*key_text_value, errors);
  } else {
    errors->AddError("required property missing: keyText");
  }
  const base::Value* style_value;
  if (object->Get("style", &style_value)) {
    errors->SetName("style");
    result->style_ = internal::FromValue<headless::css::CSSStyle>::Parse(*style_value, errors);
  } else {
    errors->AddError("required property missing: style");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CSSKeyframeRule::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (style_sheet_id_.IsJust())
    result->Set("styleSheetId", internal::ToValue(style_sheet_id_.FromJust()));
  result->Set("origin", internal::ToValue(origin_));
  result->Set("keyText", internal::ToValue(*key_text_));
  result->Set("style", internal::ToValue(*style_));
  return std::move(result);
}

std::unique_ptr<CSSKeyframeRule> CSSKeyframeRule::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CSSKeyframeRule> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StyleDeclarationEdit> StyleDeclarationEdit::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StyleDeclarationEdit");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StyleDeclarationEdit> result(new StyleDeclarationEdit());
  errors->Push();
  errors->SetName("StyleDeclarationEdit");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors);
  } else {
    errors->AddError("required property missing: range");
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StyleDeclarationEdit::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  result->Set("range", internal::ToValue(*range_));
  result->Set("text", internal::ToValue(text_));
  return std::move(result);
}

std::unique_ptr<StyleDeclarationEdit> StyleDeclarationEdit::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StyleDeclarationEdit> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetMatchedStylesForNodeParams> GetMatchedStylesForNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetMatchedStylesForNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetMatchedStylesForNodeParams> result(new GetMatchedStylesForNodeParams());
  errors->Push();
  errors->SetName("GetMatchedStylesForNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetMatchedStylesForNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetMatchedStylesForNodeParams> GetMatchedStylesForNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetMatchedStylesForNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetMatchedStylesForNodeResult> GetMatchedStylesForNodeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetMatchedStylesForNodeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetMatchedStylesForNodeResult> result(new GetMatchedStylesForNodeResult());
  errors->Push();
  errors->SetName("GetMatchedStylesForNodeResult");
  const base::Value* inline_style_value;
  if (object->Get("inlineStyle", &inline_style_value)) {
    errors->SetName("inlineStyle");
    result->inline_style_ = Just(internal::FromValue<headless::css::CSSStyle>::Parse(*inline_style_value, errors));
  }
  const base::Value* attributes_style_value;
  if (object->Get("attributesStyle", &attributes_style_value)) {
    errors->SetName("attributesStyle");
    result->attributes_style_ = Just(internal::FromValue<headless::css::CSSStyle>::Parse(*attributes_style_value, errors));
  }
  const base::Value* matchedcss_rules_value;
  if (object->Get("matchedCSSRules", &matchedcss_rules_value)) {
    errors->SetName("matchedCSSRules");
    result->matchedcss_rules_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::css::RuleMatch>>>::Parse(*matchedcss_rules_value, errors));
  }
  const base::Value* pseudo_elements_value;
  if (object->Get("pseudoElements", &pseudo_elements_value)) {
    errors->SetName("pseudoElements");
    result->pseudo_elements_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::css::PseudoElementMatches>>>::Parse(*pseudo_elements_value, errors));
  }
  const base::Value* inherited_value;
  if (object->Get("inherited", &inherited_value)) {
    errors->SetName("inherited");
    result->inherited_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::css::InheritedStyleEntry>>>::Parse(*inherited_value, errors));
  }
  const base::Value* css_keyframes_rules_value;
  if (object->Get("cssKeyframesRules", &css_keyframes_rules_value)) {
    errors->SetName("cssKeyframesRules");
    result->css_keyframes_rules_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::css::CSSKeyframesRule>>>::Parse(*css_keyframes_rules_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetMatchedStylesForNodeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (inline_style_.IsJust())
    result->Set("inlineStyle", internal::ToValue(*inline_style_.FromJust()));
  if (attributes_style_.IsJust())
    result->Set("attributesStyle", internal::ToValue(*attributes_style_.FromJust()));
  if (matchedcss_rules_.IsJust())
    result->Set("matchedCSSRules", internal::ToValue(matchedcss_rules_.FromJust()));
  if (pseudo_elements_.IsJust())
    result->Set("pseudoElements", internal::ToValue(pseudo_elements_.FromJust()));
  if (inherited_.IsJust())
    result->Set("inherited", internal::ToValue(inherited_.FromJust()));
  if (css_keyframes_rules_.IsJust())
    result->Set("cssKeyframesRules", internal::ToValue(css_keyframes_rules_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetMatchedStylesForNodeResult> GetMatchedStylesForNodeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetMatchedStylesForNodeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetInlineStylesForNodeParams> GetInlineStylesForNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetInlineStylesForNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetInlineStylesForNodeParams> result(new GetInlineStylesForNodeParams());
  errors->Push();
  errors->SetName("GetInlineStylesForNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetInlineStylesForNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetInlineStylesForNodeParams> GetInlineStylesForNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetInlineStylesForNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetInlineStylesForNodeResult> GetInlineStylesForNodeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetInlineStylesForNodeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetInlineStylesForNodeResult> result(new GetInlineStylesForNodeResult());
  errors->Push();
  errors->SetName("GetInlineStylesForNodeResult");
  const base::Value* inline_style_value;
  if (object->Get("inlineStyle", &inline_style_value)) {
    errors->SetName("inlineStyle");
    result->inline_style_ = Just(internal::FromValue<headless::css::CSSStyle>::Parse(*inline_style_value, errors));
  }
  const base::Value* attributes_style_value;
  if (object->Get("attributesStyle", &attributes_style_value)) {
    errors->SetName("attributesStyle");
    result->attributes_style_ = Just(internal::FromValue<headless::css::CSSStyle>::Parse(*attributes_style_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetInlineStylesForNodeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (inline_style_.IsJust())
    result->Set("inlineStyle", internal::ToValue(*inline_style_.FromJust()));
  if (attributes_style_.IsJust())
    result->Set("attributesStyle", internal::ToValue(*attributes_style_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetInlineStylesForNodeResult> GetInlineStylesForNodeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetInlineStylesForNodeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetComputedStyleForNodeParams> GetComputedStyleForNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetComputedStyleForNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetComputedStyleForNodeParams> result(new GetComputedStyleForNodeParams());
  errors->Push();
  errors->SetName("GetComputedStyleForNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetComputedStyleForNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetComputedStyleForNodeParams> GetComputedStyleForNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetComputedStyleForNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetComputedStyleForNodeResult> GetComputedStyleForNodeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetComputedStyleForNodeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetComputedStyleForNodeResult> result(new GetComputedStyleForNodeResult());
  errors->Push();
  errors->SetName("GetComputedStyleForNodeResult");
  const base::Value* computed_style_value;
  if (object->Get("computedStyle", &computed_style_value)) {
    errors->SetName("computedStyle");
    result->computed_style_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::CSSComputedStyleProperty>>>::Parse(*computed_style_value, errors);
  } else {
    errors->AddError("required property missing: computedStyle");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetComputedStyleForNodeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("computedStyle", internal::ToValue(computed_style_));
  return std::move(result);
}

std::unique_ptr<GetComputedStyleForNodeResult> GetComputedStyleForNodeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetComputedStyleForNodeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetPlatformFontsForNodeParams> GetPlatformFontsForNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetPlatformFontsForNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetPlatformFontsForNodeParams> result(new GetPlatformFontsForNodeParams());
  errors->Push();
  errors->SetName("GetPlatformFontsForNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetPlatformFontsForNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetPlatformFontsForNodeParams> GetPlatformFontsForNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetPlatformFontsForNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetPlatformFontsForNodeResult> GetPlatformFontsForNodeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetPlatformFontsForNodeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetPlatformFontsForNodeResult> result(new GetPlatformFontsForNodeResult());
  errors->Push();
  errors->SetName("GetPlatformFontsForNodeResult");
  const base::Value* fonts_value;
  if (object->Get("fonts", &fonts_value)) {
    errors->SetName("fonts");
    result->fonts_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::PlatformFontUsage>>>::Parse(*fonts_value, errors);
  } else {
    errors->AddError("required property missing: fonts");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetPlatformFontsForNodeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("fonts", internal::ToValue(fonts_));
  return std::move(result);
}

std::unique_ptr<GetPlatformFontsForNodeResult> GetPlatformFontsForNodeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetPlatformFontsForNodeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetStyleSheetTextParams> GetStyleSheetTextParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetStyleSheetTextParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetStyleSheetTextParams> result(new GetStyleSheetTextParams());
  errors->Push();
  errors->SetName("GetStyleSheetTextParams");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetStyleSheetTextParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  return std::move(result);
}

std::unique_ptr<GetStyleSheetTextParams> GetStyleSheetTextParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetStyleSheetTextParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetStyleSheetTextResult> GetStyleSheetTextResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetStyleSheetTextResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetStyleSheetTextResult> result(new GetStyleSheetTextResult());
  errors->Push();
  errors->SetName("GetStyleSheetTextResult");
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetStyleSheetTextResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("text", internal::ToValue(text_));
  return std::move(result);
}

std::unique_ptr<GetStyleSheetTextResult> GetStyleSheetTextResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetStyleSheetTextResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetStyleSheetTextParams> SetStyleSheetTextParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetStyleSheetTextParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetStyleSheetTextParams> result(new SetStyleSheetTextParams());
  errors->Push();
  errors->SetName("SetStyleSheetTextParams");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetStyleSheetTextParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  result->Set("text", internal::ToValue(text_));
  return std::move(result);
}

std::unique_ptr<SetStyleSheetTextParams> SetStyleSheetTextParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetStyleSheetTextParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetStyleSheetTextResult> SetStyleSheetTextResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetStyleSheetTextResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetStyleSheetTextResult> result(new SetStyleSheetTextResult());
  errors->Push();
  errors->SetName("SetStyleSheetTextResult");
  const base::Value* source_mapurl_value;
  if (object->Get("sourceMapURL", &source_mapurl_value)) {
    errors->SetName("sourceMapURL");
    result->source_mapurl_ = Just(internal::FromValue<std::string>::Parse(*source_mapurl_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetStyleSheetTextResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (source_mapurl_.IsJust())
    result->Set("sourceMapURL", internal::ToValue(source_mapurl_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetStyleSheetTextResult> SetStyleSheetTextResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetStyleSheetTextResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetRuleSelectorParams> SetRuleSelectorParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetRuleSelectorParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetRuleSelectorParams> result(new SetRuleSelectorParams());
  errors->Push();
  errors->SetName("SetRuleSelectorParams");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors);
  } else {
    errors->AddError("required property missing: range");
  }
  const base::Value* selector_value;
  if (object->Get("selector", &selector_value)) {
    errors->SetName("selector");
    result->selector_ = internal::FromValue<std::string>::Parse(*selector_value, errors);
  } else {
    errors->AddError("required property missing: selector");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetRuleSelectorParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  result->Set("range", internal::ToValue(*range_));
  result->Set("selector", internal::ToValue(selector_));
  return std::move(result);
}

std::unique_ptr<SetRuleSelectorParams> SetRuleSelectorParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetRuleSelectorParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetRuleSelectorResult> SetRuleSelectorResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetRuleSelectorResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetRuleSelectorResult> result(new SetRuleSelectorResult());
  errors->Push();
  errors->SetName("SetRuleSelectorResult");
  const base::Value* selector_list_value;
  if (object->Get("selectorList", &selector_list_value)) {
    errors->SetName("selectorList");
    result->selector_list_ = internal::FromValue<headless::css::SelectorList>::Parse(*selector_list_value, errors);
  } else {
    errors->AddError("required property missing: selectorList");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetRuleSelectorResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("selectorList", internal::ToValue(*selector_list_));
  return std::move(result);
}

std::unique_ptr<SetRuleSelectorResult> SetRuleSelectorResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetRuleSelectorResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetKeyframeKeyParams> SetKeyframeKeyParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetKeyframeKeyParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetKeyframeKeyParams> result(new SetKeyframeKeyParams());
  errors->Push();
  errors->SetName("SetKeyframeKeyParams");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors);
  } else {
    errors->AddError("required property missing: range");
  }
  const base::Value* key_text_value;
  if (object->Get("keyText", &key_text_value)) {
    errors->SetName("keyText");
    result->key_text_ = internal::FromValue<std::string>::Parse(*key_text_value, errors);
  } else {
    errors->AddError("required property missing: keyText");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetKeyframeKeyParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  result->Set("range", internal::ToValue(*range_));
  result->Set("keyText", internal::ToValue(key_text_));
  return std::move(result);
}

std::unique_ptr<SetKeyframeKeyParams> SetKeyframeKeyParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetKeyframeKeyParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetKeyframeKeyResult> SetKeyframeKeyResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetKeyframeKeyResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetKeyframeKeyResult> result(new SetKeyframeKeyResult());
  errors->Push();
  errors->SetName("SetKeyframeKeyResult");
  const base::Value* key_text_value;
  if (object->Get("keyText", &key_text_value)) {
    errors->SetName("keyText");
    result->key_text_ = internal::FromValue<headless::css::Value>::Parse(*key_text_value, errors);
  } else {
    errors->AddError("required property missing: keyText");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetKeyframeKeyResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("keyText", internal::ToValue(*key_text_));
  return std::move(result);
}

std::unique_ptr<SetKeyframeKeyResult> SetKeyframeKeyResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetKeyframeKeyResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetStyleTextsParams> SetStyleTextsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetStyleTextsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetStyleTextsParams> result(new SetStyleTextsParams());
  errors->Push();
  errors->SetName("SetStyleTextsParams");
  const base::Value* edits_value;
  if (object->Get("edits", &edits_value)) {
    errors->SetName("edits");
    result->edits_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::StyleDeclarationEdit>>>::Parse(*edits_value, errors);
  } else {
    errors->AddError("required property missing: edits");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetStyleTextsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("edits", internal::ToValue(edits_));
  return std::move(result);
}

std::unique_ptr<SetStyleTextsParams> SetStyleTextsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetStyleTextsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetStyleTextsResult> SetStyleTextsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetStyleTextsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetStyleTextsResult> result(new SetStyleTextsResult());
  errors->Push();
  errors->SetName("SetStyleTextsResult");
  const base::Value* styles_value;
  if (object->Get("styles", &styles_value)) {
    errors->SetName("styles");
    result->styles_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::CSSStyle>>>::Parse(*styles_value, errors);
  } else {
    errors->AddError("required property missing: styles");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetStyleTextsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styles", internal::ToValue(styles_));
  return std::move(result);
}

std::unique_ptr<SetStyleTextsResult> SetStyleTextsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetStyleTextsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetMediaTextParams> SetMediaTextParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetMediaTextParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetMediaTextParams> result(new SetMediaTextParams());
  errors->Push();
  errors->SetName("SetMediaTextParams");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  const base::Value* range_value;
  if (object->Get("range", &range_value)) {
    errors->SetName("range");
    result->range_ = internal::FromValue<headless::css::SourceRange>::Parse(*range_value, errors);
  } else {
    errors->AddError("required property missing: range");
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = internal::FromValue<std::string>::Parse(*text_value, errors);
  } else {
    errors->AddError("required property missing: text");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetMediaTextParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  result->Set("range", internal::ToValue(*range_));
  result->Set("text", internal::ToValue(text_));
  return std::move(result);
}

std::unique_ptr<SetMediaTextParams> SetMediaTextParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetMediaTextParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetMediaTextResult> SetMediaTextResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetMediaTextResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetMediaTextResult> result(new SetMediaTextResult());
  errors->Push();
  errors->SetName("SetMediaTextResult");
  const base::Value* media_value;
  if (object->Get("media", &media_value)) {
    errors->SetName("media");
    result->media_ = internal::FromValue<headless::css::CSSMedia>::Parse(*media_value, errors);
  } else {
    errors->AddError("required property missing: media");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetMediaTextResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("media", internal::ToValue(*media_));
  return std::move(result);
}

std::unique_ptr<SetMediaTextResult> SetMediaTextResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetMediaTextResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CreateStyleSheetParams> CreateStyleSheetParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CreateStyleSheetParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CreateStyleSheetParams> result(new CreateStyleSheetParams());
  errors->Push();
  errors->SetName("CreateStyleSheetParams");
  const base::Value* frame_id_value;
  if (object->Get("frameId", &frame_id_value)) {
    errors->SetName("frameId");
    result->frame_id_ = internal::FromValue<std::string>::Parse(*frame_id_value, errors);
  } else {
    errors->AddError("required property missing: frameId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CreateStyleSheetParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("frameId", internal::ToValue(frame_id_));
  return std::move(result);
}

std::unique_ptr<CreateStyleSheetParams> CreateStyleSheetParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CreateStyleSheetParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CreateStyleSheetResult> CreateStyleSheetResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CreateStyleSheetResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CreateStyleSheetResult> result(new CreateStyleSheetResult());
  errors->Push();
  errors->SetName("CreateStyleSheetResult");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CreateStyleSheetResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  return std::move(result);
}

std::unique_ptr<CreateStyleSheetResult> CreateStyleSheetResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CreateStyleSheetResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AddRuleParams> AddRuleParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AddRuleParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AddRuleParams> result(new AddRuleParams());
  errors->Push();
  errors->SetName("AddRuleParams");
  const base::Value* style_sheet_id_value;
  if (object->Get("styleSheetId", &style_sheet_id_value)) {
    errors->SetName("styleSheetId");
    result->style_sheet_id_ = internal::FromValue<std::string>::Parse(*style_sheet_id_value, errors);
  } else {
    errors->AddError("required property missing: styleSheetId");
  }
  const base::Value* rule_text_value;
  if (object->Get("ruleText", &rule_text_value)) {
    errors->SetName("ruleText");
    result->rule_text_ = internal::FromValue<std::string>::Parse(*rule_text_value, errors);
  } else {
    errors->AddError("required property missing: ruleText");
  }
  const base::Value* location_value;
  if (object->Get("location", &location_value)) {
    errors->SetName("location");
    result->location_ = internal::FromValue<headless::css::SourceRange>::Parse(*location_value, errors);
  } else {
    errors->AddError("required property missing: location");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AddRuleParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("styleSheetId", internal::ToValue(style_sheet_id_));
  result->Set("ruleText", internal::ToValue(rule_text_));
  result->Set("location", internal::ToValue(*location_));
  return std::move(result);
}

std::unique_ptr<AddRuleParams> AddRuleParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AddRuleParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AddRuleResult> AddRuleResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AddRuleResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AddRuleResult> result(new AddRuleResult());
  errors->Push();
  errors->SetName("AddRuleResult");
  const base::Value* rule_value;
  if (object->Get("rule", &rule_value)) {
    errors->SetName("rule");
    result->rule_ = internal::FromValue<headless::css::CSSRule>::Parse(*rule_value, errors);
  } else {
    errors->AddError("required property missing: rule");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AddRuleResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("rule", internal::ToValue(*rule_));
  return std::move(result);
}

std::unique_ptr<AddRuleResult> AddRuleResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AddRuleResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ForcePseudoStateParams> ForcePseudoStateParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ForcePseudoStateParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ForcePseudoStateParams> result(new ForcePseudoStateParams());
  errors->Push();
  errors->SetName("ForcePseudoStateParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* forced_pseudo_classes_value;
  if (object->Get("forcedPseudoClasses", &forced_pseudo_classes_value)) {
    errors->SetName("forcedPseudoClasses");
    result->forced_pseudo_classes_ = internal::FromValue<std::vector<std::string>>::Parse(*forced_pseudo_classes_value, errors);
  } else {
    errors->AddError("required property missing: forcedPseudoClasses");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ForcePseudoStateParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("forcedPseudoClasses", internal::ToValue(forced_pseudo_classes_));
  return std::move(result);
}

std::unique_ptr<ForcePseudoStateParams> ForcePseudoStateParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ForcePseudoStateParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetMediaQueriesResult> GetMediaQueriesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetMediaQueriesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetMediaQueriesResult> result(new GetMediaQueriesResult());
  errors->Push();
  errors->SetName("GetMediaQueriesResult");
  const base::Value* medias_value;
  if (object->Get("medias", &medias_value)) {
    errors->SetName("medias");
    result->medias_ = internal::FromValue<std::vector<std::unique_ptr<headless::css::CSSMedia>>>::Parse(*medias_value, errors);
  } else {
    errors->AddError("required property missing: medias");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetMediaQueriesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("medias", internal::ToValue(medias_));
  return std::move(result);
}

std::unique_ptr<GetMediaQueriesResult> GetMediaQueriesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetMediaQueriesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetEffectivePropertyValueForNodeParams> SetEffectivePropertyValueForNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetEffectivePropertyValueForNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetEffectivePropertyValueForNodeParams> result(new SetEffectivePropertyValueForNodeParams());
  errors->Push();
  errors->SetName("SetEffectivePropertyValueForNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* property_name_value;
  if (object->Get("propertyName", &property_name_value)) {
    errors->SetName("propertyName");
    result->property_name_ = internal::FromValue<std::string>::Parse(*property_name_value, errors);
  } else {
    errors->AddError("required property missing: propertyName");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<std::string>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetEffectivePropertyValueForNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("propertyName", internal::ToValue(property_name_));
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<SetEffectivePropertyValueForNodeParams> SetEffectivePropertyValueForNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetEffectivePropertyValueForNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetBackgroundColorsParams> GetBackgroundColorsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetBackgroundColorsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetBackgroundColorsParams> result(new GetBackgroundColorsParams());
  errors->Push();
  errors->SetName("GetBackgroundColorsParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetBackgroundColorsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetBackgroundColorsParams> GetBackgroundColorsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetBackgroundColorsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetBackgroundColorsResult> GetBackgroundColorsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetBackgroundColorsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetBackgroundColorsResult> result(new GetBackgroundColorsResult());
  errors->Push();
  errors->SetName("GetBackgroundColorsResult");
  const base::Value* background_colors_value;
  if (object->Get("backgroundColors", &background_colors_value)) {
    errors->SetName("backgroundColors");
    result->background_colors_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*background_colors_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetBackgroundColorsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (background_colors_.IsJust())
    result->Set("backgroundColors", internal::ToValue(background_colors_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetBackgroundColorsResult> GetBackgroundColorsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetBackgroundColorsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace css

namespace io {

std::unique_ptr<ReadParams> ReadParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReadParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReadParams> result(new ReadParams());
  errors->Push();
  errors->SetName("ReadParams");
  const base::Value* handle_value;
  if (object->Get("handle", &handle_value)) {
    errors->SetName("handle");
    result->handle_ = internal::FromValue<std::string>::Parse(*handle_value, errors);
  } else {
    errors->AddError("required property missing: handle");
  }
  const base::Value* offset_value;
  if (object->Get("offset", &offset_value)) {
    errors->SetName("offset");
    result->offset_ = Just(internal::FromValue<int>::Parse(*offset_value, errors));
  }
  const base::Value* size_value;
  if (object->Get("size", &size_value)) {
    errors->SetName("size");
    result->size_ = Just(internal::FromValue<int>::Parse(*size_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReadParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("handle", internal::ToValue(handle_));
  if (offset_.IsJust())
    result->Set("offset", internal::ToValue(offset_.FromJust()));
  if (size_.IsJust())
    result->Set("size", internal::ToValue(size_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ReadParams> ReadParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReadParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReadResult> ReadResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReadResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReadResult> result(new ReadResult());
  errors->Push();
  errors->SetName("ReadResult");
  const base::Value* data_value;
  if (object->Get("data", &data_value)) {
    errors->SetName("data");
    result->data_ = internal::FromValue<std::string>::Parse(*data_value, errors);
  } else {
    errors->AddError("required property missing: data");
  }
  const base::Value* eof_value;
  if (object->Get("eof", &eof_value)) {
    errors->SetName("eof");
    result->eof_ = internal::FromValue<bool>::Parse(*eof_value, errors);
  } else {
    errors->AddError("required property missing: eof");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReadResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("data", internal::ToValue(data_));
  result->Set("eof", internal::ToValue(eof_));
  return std::move(result);
}

std::unique_ptr<ReadResult> ReadResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReadResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CloseParams> CloseParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CloseParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CloseParams> result(new CloseParams());
  errors->Push();
  errors->SetName("CloseParams");
  const base::Value* handle_value;
  if (object->Get("handle", &handle_value)) {
    errors->SetName("handle");
    result->handle_ = internal::FromValue<std::string>::Parse(*handle_value, errors);
  } else {
    errors->AddError("required property missing: handle");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CloseParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("handle", internal::ToValue(handle_));
  return std::move(result);
}

std::unique_ptr<CloseParams> CloseParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CloseParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace io

namespace debugger {

std::unique_ptr<Location> Location::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Location");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Location> result(new Location());
  errors->Push();
  errors->SetName("Location");
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<int>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* column_number_value;
  if (object->Get("columnNumber", &column_number_value)) {
    errors->SetName("columnNumber");
    result->column_number_ = Just(internal::FromValue<int>::Parse(*column_number_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Location::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("lineNumber", internal::ToValue(line_number_));
  if (column_number_.IsJust())
    result->Set("columnNumber", internal::ToValue(column_number_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Location> Location::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Location> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ScriptPosition> ScriptPosition::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ScriptPosition");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ScriptPosition> result(new ScriptPosition());
  errors->Push();
  errors->SetName("ScriptPosition");
  const base::Value* line_value;
  if (object->Get("line", &line_value)) {
    errors->SetName("line");
    result->line_ = internal::FromValue<int>::Parse(*line_value, errors);
  } else {
    errors->AddError("required property missing: line");
  }
  const base::Value* column_value;
  if (object->Get("column", &column_value)) {
    errors->SetName("column");
    result->column_ = internal::FromValue<int>::Parse(*column_value, errors);
  } else {
    errors->AddError("required property missing: column");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ScriptPosition::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("line", internal::ToValue(line_));
  result->Set("column", internal::ToValue(column_));
  return std::move(result);
}

std::unique_ptr<ScriptPosition> ScriptPosition::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ScriptPosition> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<FunctionDetails> FunctionDetails::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("FunctionDetails");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<FunctionDetails> result(new FunctionDetails());
  errors->Push();
  errors->SetName("FunctionDetails");
  const base::Value* location_value;
  if (object->Get("location", &location_value)) {
    errors->SetName("location");
    result->location_ = Just(internal::FromValue<headless::debugger::Location>::Parse(*location_value, errors));
  }
  const base::Value* function_name_value;
  if (object->Get("functionName", &function_name_value)) {
    errors->SetName("functionName");
    result->function_name_ = internal::FromValue<std::string>::Parse(*function_name_value, errors);
  } else {
    errors->AddError("required property missing: functionName");
  }
  const base::Value* is_generator_value;
  if (object->Get("isGenerator", &is_generator_value)) {
    errors->SetName("isGenerator");
    result->is_generator_ = internal::FromValue<bool>::Parse(*is_generator_value, errors);
  } else {
    errors->AddError("required property missing: isGenerator");
  }
  const base::Value* scope_chain_value;
  if (object->Get("scopeChain", &scope_chain_value)) {
    errors->SetName("scopeChain");
    result->scope_chain_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::debugger::Scope>>>::Parse(*scope_chain_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> FunctionDetails::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (location_.IsJust())
    result->Set("location", internal::ToValue(*location_.FromJust()));
  result->Set("functionName", internal::ToValue(function_name_));
  result->Set("isGenerator", internal::ToValue(is_generator_));
  if (scope_chain_.IsJust())
    result->Set("scopeChain", internal::ToValue(scope_chain_.FromJust()));
  return std::move(result);
}

std::unique_ptr<FunctionDetails> FunctionDetails::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<FunctionDetails> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GeneratorObjectDetails> GeneratorObjectDetails::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GeneratorObjectDetails");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GeneratorObjectDetails> result(new GeneratorObjectDetails());
  errors->Push();
  errors->SetName("GeneratorObjectDetails");
  const base::Value* function_value;
  if (object->Get("function", &function_value)) {
    errors->SetName("function");
    result->function_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*function_value, errors);
  } else {
    errors->AddError("required property missing: function");
  }
  const base::Value* function_name_value;
  if (object->Get("functionName", &function_name_value)) {
    errors->SetName("functionName");
    result->function_name_ = internal::FromValue<std::string>::Parse(*function_name_value, errors);
  } else {
    errors->AddError("required property missing: functionName");
  }
  const base::Value* status_value;
  if (object->Get("status", &status_value)) {
    errors->SetName("status");
    result->status_ = internal::FromValue<headless::debugger::GeneratorObjectDetailsStatus>::Parse(*status_value, errors);
  } else {
    errors->AddError("required property missing: status");
  }
  const base::Value* location_value;
  if (object->Get("location", &location_value)) {
    errors->SetName("location");
    result->location_ = Just(internal::FromValue<headless::debugger::Location>::Parse(*location_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GeneratorObjectDetails::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("function", internal::ToValue(*function_));
  result->Set("functionName", internal::ToValue(function_name_));
  result->Set("status", internal::ToValue(status_));
  if (location_.IsJust())
    result->Set("location", internal::ToValue(*location_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GeneratorObjectDetails> GeneratorObjectDetails::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GeneratorObjectDetails> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CollectionEntry> CollectionEntry::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CollectionEntry");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CollectionEntry> result(new CollectionEntry());
  errors->Push();
  errors->SetName("CollectionEntry");
  const base::Value* key_value;
  if (object->Get("key", &key_value)) {
    errors->SetName("key");
    result->key_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*key_value, errors));
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CollectionEntry::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (key_.IsJust())
    result->Set("key", internal::ToValue(*key_.FromJust()));
  result->Set("value", internal::ToValue(*value_));
  return std::move(result);
}

std::unique_ptr<CollectionEntry> CollectionEntry::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CollectionEntry> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CallFrame> CallFrame::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CallFrame");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CallFrame> result(new CallFrame());
  errors->Push();
  errors->SetName("CallFrame");
  const base::Value* call_frame_id_value;
  if (object->Get("callFrameId", &call_frame_id_value)) {
    errors->SetName("callFrameId");
    result->call_frame_id_ = internal::FromValue<std::string>::Parse(*call_frame_id_value, errors);
  } else {
    errors->AddError("required property missing: callFrameId");
  }
  const base::Value* function_name_value;
  if (object->Get("functionName", &function_name_value)) {
    errors->SetName("functionName");
    result->function_name_ = internal::FromValue<std::string>::Parse(*function_name_value, errors);
  } else {
    errors->AddError("required property missing: functionName");
  }
  const base::Value* function_location_value;
  if (object->Get("functionLocation", &function_location_value)) {
    errors->SetName("functionLocation");
    result->function_location_ = Just(internal::FromValue<headless::debugger::Location>::Parse(*function_location_value, errors));
  }
  const base::Value* location_value;
  if (object->Get("location", &location_value)) {
    errors->SetName("location");
    result->location_ = internal::FromValue<headless::debugger::Location>::Parse(*location_value, errors);
  } else {
    errors->AddError("required property missing: location");
  }
  const base::Value* scope_chain_value;
  if (object->Get("scopeChain", &scope_chain_value)) {
    errors->SetName("scopeChain");
    result->scope_chain_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::Scope>>>::Parse(*scope_chain_value, errors);
  } else {
    errors->AddError("required property missing: scopeChain");
  }
  const base::Value* this_value;
  if (object->Get("this", &this_value)) {
    errors->SetName("this");
    result->this_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*this_value, errors);
  } else {
    errors->AddError("required property missing: this");
  }
  const base::Value* return_value_value;
  if (object->Get("returnValue", &return_value_value)) {
    errors->SetName("returnValue");
    result->return_value_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*return_value_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CallFrame::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("callFrameId", internal::ToValue(call_frame_id_));
  result->Set("functionName", internal::ToValue(function_name_));
  if (function_location_.IsJust())
    result->Set("functionLocation", internal::ToValue(*function_location_.FromJust()));
  result->Set("location", internal::ToValue(*location_));
  result->Set("scopeChain", internal::ToValue(scope_chain_));
  result->Set("this", internal::ToValue(*this_));
  if (return_value_.IsJust())
    result->Set("returnValue", internal::ToValue(*return_value_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CallFrame> CallFrame::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CallFrame> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Scope> Scope::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Scope");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Scope> result(new Scope());
  errors->Push();
  errors->SetName("Scope");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::debugger::ScopeType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* object_value;
  if (object->Get("object", &object_value)) {
    errors->SetName("object");
    result->object_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*object_value, errors);
  } else {
    errors->AddError("required property missing: object");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = Just(internal::FromValue<std::string>::Parse(*name_value, errors));
  }
  const base::Value* start_location_value;
  if (object->Get("startLocation", &start_location_value)) {
    errors->SetName("startLocation");
    result->start_location_ = Just(internal::FromValue<headless::debugger::Location>::Parse(*start_location_value, errors));
  }
  const base::Value* end_location_value;
  if (object->Get("endLocation", &end_location_value)) {
    errors->SetName("endLocation");
    result->end_location_ = Just(internal::FromValue<headless::debugger::Location>::Parse(*end_location_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Scope::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  result->Set("object", internal::ToValue(*object_));
  if (name_.IsJust())
    result->Set("name", internal::ToValue(name_.FromJust()));
  if (start_location_.IsJust())
    result->Set("startLocation", internal::ToValue(*start_location_.FromJust()));
  if (end_location_.IsJust())
    result->Set("endLocation", internal::ToValue(*end_location_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Scope> Scope::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Scope> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetScriptSourceError> SetScriptSourceError::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetScriptSourceError");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetScriptSourceError> result(new SetScriptSourceError());
  errors->Push();
  errors->SetName("SetScriptSourceError");
  const base::Value* message_value;
  if (object->Get("message", &message_value)) {
    errors->SetName("message");
    result->message_ = internal::FromValue<std::string>::Parse(*message_value, errors);
  } else {
    errors->AddError("required property missing: message");
  }
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<int>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* column_number_value;
  if (object->Get("columnNumber", &column_number_value)) {
    errors->SetName("columnNumber");
    result->column_number_ = internal::FromValue<int>::Parse(*column_number_value, errors);
  } else {
    errors->AddError("required property missing: columnNumber");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetScriptSourceError::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("message", internal::ToValue(message_));
  result->Set("lineNumber", internal::ToValue(line_number_));
  result->Set("columnNumber", internal::ToValue(column_number_));
  return std::move(result);
}

std::unique_ptr<SetScriptSourceError> SetScriptSourceError::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetScriptSourceError> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SearchMatch> SearchMatch::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SearchMatch");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SearchMatch> result(new SearchMatch());
  errors->Push();
  errors->SetName("SearchMatch");
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<double>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* line_content_value;
  if (object->Get("lineContent", &line_content_value)) {
    errors->SetName("lineContent");
    result->line_content_ = internal::FromValue<std::string>::Parse(*line_content_value, errors);
  } else {
    errors->AddError("required property missing: lineContent");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SearchMatch::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("lineNumber", internal::ToValue(line_number_));
  result->Set("lineContent", internal::ToValue(line_content_));
  return std::move(result);
}

std::unique_ptr<SearchMatch> SearchMatch::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SearchMatch> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetBreakpointsActiveParams> SetBreakpointsActiveParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetBreakpointsActiveParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetBreakpointsActiveParams> result(new SetBreakpointsActiveParams());
  errors->Push();
  errors->SetName("SetBreakpointsActiveParams");
  const base::Value* active_value;
  if (object->Get("active", &active_value)) {
    errors->SetName("active");
    result->active_ = internal::FromValue<bool>::Parse(*active_value, errors);
  } else {
    errors->AddError("required property missing: active");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetBreakpointsActiveParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("active", internal::ToValue(active_));
  return std::move(result);
}

std::unique_ptr<SetBreakpointsActiveParams> SetBreakpointsActiveParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetBreakpointsActiveParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetSkipAllPausesParams> SetSkipAllPausesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetSkipAllPausesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetSkipAllPausesParams> result(new SetSkipAllPausesParams());
  errors->Push();
  errors->SetName("SetSkipAllPausesParams");
  const base::Value* skipped_value;
  if (object->Get("skipped", &skipped_value)) {
    errors->SetName("skipped");
    result->skipped_ = internal::FromValue<bool>::Parse(*skipped_value, errors);
  } else {
    errors->AddError("required property missing: skipped");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetSkipAllPausesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("skipped", internal::ToValue(skipped_));
  return std::move(result);
}

std::unique_ptr<SetSkipAllPausesParams> SetSkipAllPausesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetSkipAllPausesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetBreakpointByUrlParams> SetBreakpointByUrlParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetBreakpointByUrlParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetBreakpointByUrlParams> result(new SetBreakpointByUrlParams());
  errors->Push();
  errors->SetName("SetBreakpointByUrlParams");
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<int>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = Just(internal::FromValue<std::string>::Parse(*url_value, errors));
  }
  const base::Value* url_regex_value;
  if (object->Get("urlRegex", &url_regex_value)) {
    errors->SetName("urlRegex");
    result->url_regex_ = Just(internal::FromValue<std::string>::Parse(*url_regex_value, errors));
  }
  const base::Value* column_number_value;
  if (object->Get("columnNumber", &column_number_value)) {
    errors->SetName("columnNumber");
    result->column_number_ = Just(internal::FromValue<int>::Parse(*column_number_value, errors));
  }
  const base::Value* condition_value;
  if (object->Get("condition", &condition_value)) {
    errors->SetName("condition");
    result->condition_ = Just(internal::FromValue<std::string>::Parse(*condition_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetBreakpointByUrlParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("lineNumber", internal::ToValue(line_number_));
  if (url_.IsJust())
    result->Set("url", internal::ToValue(url_.FromJust()));
  if (url_regex_.IsJust())
    result->Set("urlRegex", internal::ToValue(url_regex_.FromJust()));
  if (column_number_.IsJust())
    result->Set("columnNumber", internal::ToValue(column_number_.FromJust()));
  if (condition_.IsJust())
    result->Set("condition", internal::ToValue(condition_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetBreakpointByUrlParams> SetBreakpointByUrlParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetBreakpointByUrlParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetBreakpointByUrlResult> SetBreakpointByUrlResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetBreakpointByUrlResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetBreakpointByUrlResult> result(new SetBreakpointByUrlResult());
  errors->Push();
  errors->SetName("SetBreakpointByUrlResult");
  const base::Value* breakpoint_id_value;
  if (object->Get("breakpointId", &breakpoint_id_value)) {
    errors->SetName("breakpointId");
    result->breakpoint_id_ = internal::FromValue<std::string>::Parse(*breakpoint_id_value, errors);
  } else {
    errors->AddError("required property missing: breakpointId");
  }
  const base::Value* locations_value;
  if (object->Get("locations", &locations_value)) {
    errors->SetName("locations");
    result->locations_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::Location>>>::Parse(*locations_value, errors);
  } else {
    errors->AddError("required property missing: locations");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetBreakpointByUrlResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("breakpointId", internal::ToValue(breakpoint_id_));
  result->Set("locations", internal::ToValue(locations_));
  return std::move(result);
}

std::unique_ptr<SetBreakpointByUrlResult> SetBreakpointByUrlResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetBreakpointByUrlResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetBreakpointParams> SetBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetBreakpointParams> result(new SetBreakpointParams());
  errors->Push();
  errors->SetName("SetBreakpointParams");
  const base::Value* location_value;
  if (object->Get("location", &location_value)) {
    errors->SetName("location");
    result->location_ = internal::FromValue<headless::debugger::Location>::Parse(*location_value, errors);
  } else {
    errors->AddError("required property missing: location");
  }
  const base::Value* condition_value;
  if (object->Get("condition", &condition_value)) {
    errors->SetName("condition");
    result->condition_ = Just(internal::FromValue<std::string>::Parse(*condition_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("location", internal::ToValue(*location_));
  if (condition_.IsJust())
    result->Set("condition", internal::ToValue(condition_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetBreakpointParams> SetBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetBreakpointResult> SetBreakpointResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetBreakpointResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetBreakpointResult> result(new SetBreakpointResult());
  errors->Push();
  errors->SetName("SetBreakpointResult");
  const base::Value* breakpoint_id_value;
  if (object->Get("breakpointId", &breakpoint_id_value)) {
    errors->SetName("breakpointId");
    result->breakpoint_id_ = internal::FromValue<std::string>::Parse(*breakpoint_id_value, errors);
  } else {
    errors->AddError("required property missing: breakpointId");
  }
  const base::Value* actual_location_value;
  if (object->Get("actualLocation", &actual_location_value)) {
    errors->SetName("actualLocation");
    result->actual_location_ = internal::FromValue<headless::debugger::Location>::Parse(*actual_location_value, errors);
  } else {
    errors->AddError("required property missing: actualLocation");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetBreakpointResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("breakpointId", internal::ToValue(breakpoint_id_));
  result->Set("actualLocation", internal::ToValue(*actual_location_));
  return std::move(result);
}

std::unique_ptr<SetBreakpointResult> SetBreakpointResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetBreakpointResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveBreakpointParams> RemoveBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveBreakpointParams> result(new RemoveBreakpointParams());
  errors->Push();
  errors->SetName("RemoveBreakpointParams");
  const base::Value* breakpoint_id_value;
  if (object->Get("breakpointId", &breakpoint_id_value)) {
    errors->SetName("breakpointId");
    result->breakpoint_id_ = internal::FromValue<std::string>::Parse(*breakpoint_id_value, errors);
  } else {
    errors->AddError("required property missing: breakpointId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("breakpointId", internal::ToValue(breakpoint_id_));
  return std::move(result);
}

std::unique_ptr<RemoveBreakpointParams> RemoveBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ContinueToLocationParams> ContinueToLocationParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ContinueToLocationParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ContinueToLocationParams> result(new ContinueToLocationParams());
  errors->Push();
  errors->SetName("ContinueToLocationParams");
  const base::Value* location_value;
  if (object->Get("location", &location_value)) {
    errors->SetName("location");
    result->location_ = internal::FromValue<headless::debugger::Location>::Parse(*location_value, errors);
  } else {
    errors->AddError("required property missing: location");
  }
  const base::Value* interstatement_location_value;
  if (object->Get("interstatementLocation", &interstatement_location_value)) {
    errors->SetName("interstatementLocation");
    result->interstatement_location_ = Just(internal::FromValue<bool>::Parse(*interstatement_location_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ContinueToLocationParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("location", internal::ToValue(*location_));
  if (interstatement_location_.IsJust())
    result->Set("interstatementLocation", internal::ToValue(interstatement_location_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ContinueToLocationParams> ContinueToLocationParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ContinueToLocationParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SearchInContentParams> SearchInContentParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SearchInContentParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SearchInContentParams> result(new SearchInContentParams());
  errors->Push();
  errors->SetName("SearchInContentParams");
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* query_value;
  if (object->Get("query", &query_value)) {
    errors->SetName("query");
    result->query_ = internal::FromValue<std::string>::Parse(*query_value, errors);
  } else {
    errors->AddError("required property missing: query");
  }
  const base::Value* case_sensitive_value;
  if (object->Get("caseSensitive", &case_sensitive_value)) {
    errors->SetName("caseSensitive");
    result->case_sensitive_ = Just(internal::FromValue<bool>::Parse(*case_sensitive_value, errors));
  }
  const base::Value* is_regex_value;
  if (object->Get("isRegex", &is_regex_value)) {
    errors->SetName("isRegex");
    result->is_regex_ = Just(internal::FromValue<bool>::Parse(*is_regex_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SearchInContentParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("query", internal::ToValue(query_));
  if (case_sensitive_.IsJust())
    result->Set("caseSensitive", internal::ToValue(case_sensitive_.FromJust()));
  if (is_regex_.IsJust())
    result->Set("isRegex", internal::ToValue(is_regex_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SearchInContentParams> SearchInContentParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SearchInContentParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SearchInContentResult> SearchInContentResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SearchInContentResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SearchInContentResult> result(new SearchInContentResult());
  errors->Push();
  errors->SetName("SearchInContentResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::SearchMatch>>>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SearchInContentResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<SearchInContentResult> SearchInContentResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SearchInContentResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CanSetScriptSourceResult> CanSetScriptSourceResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CanSetScriptSourceResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CanSetScriptSourceResult> result(new CanSetScriptSourceResult());
  errors->Push();
  errors->SetName("CanSetScriptSourceResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<bool>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CanSetScriptSourceResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(result_));
  return std::move(result);
}

std::unique_ptr<CanSetScriptSourceResult> CanSetScriptSourceResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CanSetScriptSourceResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetScriptSourceParams> SetScriptSourceParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetScriptSourceParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetScriptSourceParams> result(new SetScriptSourceParams());
  errors->Push();
  errors->SetName("SetScriptSourceParams");
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* script_source_value;
  if (object->Get("scriptSource", &script_source_value)) {
    errors->SetName("scriptSource");
    result->script_source_ = internal::FromValue<std::string>::Parse(*script_source_value, errors);
  } else {
    errors->AddError("required property missing: scriptSource");
  }
  const base::Value* preview_value;
  if (object->Get("preview", &preview_value)) {
    errors->SetName("preview");
    result->preview_ = Just(internal::FromValue<bool>::Parse(*preview_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetScriptSourceParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("scriptSource", internal::ToValue(script_source_));
  if (preview_.IsJust())
    result->Set("preview", internal::ToValue(preview_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetScriptSourceParams> SetScriptSourceParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetScriptSourceParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetScriptSourceResult> SetScriptSourceResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetScriptSourceResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetScriptSourceResult> result(new SetScriptSourceResult());
  errors->Push();
  errors->SetName("SetScriptSourceResult");
  const base::Value* call_frames_value;
  if (object->Get("callFrames", &call_frames_value)) {
    errors->SetName("callFrames");
    result->call_frames_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::debugger::CallFrame>>>::Parse(*call_frames_value, errors));
  }
  const base::Value* stack_changed_value;
  if (object->Get("stackChanged", &stack_changed_value)) {
    errors->SetName("stackChanged");
    result->stack_changed_ = Just(internal::FromValue<bool>::Parse(*stack_changed_value, errors));
  }
  const base::Value* async_stack_trace_value;
  if (object->Get("asyncStackTrace", &async_stack_trace_value)) {
    errors->SetName("asyncStackTrace");
    result->async_stack_trace_ = Just(internal::FromValue<headless::runtime::StackTrace>::Parse(*async_stack_trace_value, errors));
  }
  const base::Value* compile_error_value;
  if (object->Get("compileError", &compile_error_value)) {
    errors->SetName("compileError");
    result->compile_error_ = Just(internal::FromValue<headless::debugger::SetScriptSourceError>::Parse(*compile_error_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetScriptSourceResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (call_frames_.IsJust())
    result->Set("callFrames", internal::ToValue(call_frames_.FromJust()));
  if (stack_changed_.IsJust())
    result->Set("stackChanged", internal::ToValue(stack_changed_.FromJust()));
  if (async_stack_trace_.IsJust())
    result->Set("asyncStackTrace", internal::ToValue(*async_stack_trace_.FromJust()));
  if (compile_error_.IsJust())
    result->Set("compileError", internal::ToValue(*compile_error_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetScriptSourceResult> SetScriptSourceResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetScriptSourceResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RestartFrameParams> RestartFrameParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RestartFrameParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RestartFrameParams> result(new RestartFrameParams());
  errors->Push();
  errors->SetName("RestartFrameParams");
  const base::Value* call_frame_id_value;
  if (object->Get("callFrameId", &call_frame_id_value)) {
    errors->SetName("callFrameId");
    result->call_frame_id_ = internal::FromValue<std::string>::Parse(*call_frame_id_value, errors);
  } else {
    errors->AddError("required property missing: callFrameId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RestartFrameParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("callFrameId", internal::ToValue(call_frame_id_));
  return std::move(result);
}

std::unique_ptr<RestartFrameParams> RestartFrameParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RestartFrameParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RestartFrameResult> RestartFrameResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RestartFrameResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RestartFrameResult> result(new RestartFrameResult());
  errors->Push();
  errors->SetName("RestartFrameResult");
  const base::Value* call_frames_value;
  if (object->Get("callFrames", &call_frames_value)) {
    errors->SetName("callFrames");
    result->call_frames_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::CallFrame>>>::Parse(*call_frames_value, errors);
  } else {
    errors->AddError("required property missing: callFrames");
  }
  const base::Value* async_stack_trace_value;
  if (object->Get("asyncStackTrace", &async_stack_trace_value)) {
    errors->SetName("asyncStackTrace");
    result->async_stack_trace_ = Just(internal::FromValue<headless::runtime::StackTrace>::Parse(*async_stack_trace_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RestartFrameResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("callFrames", internal::ToValue(call_frames_));
  if (async_stack_trace_.IsJust())
    result->Set("asyncStackTrace", internal::ToValue(*async_stack_trace_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RestartFrameResult> RestartFrameResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RestartFrameResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetScriptSourceParams> GetScriptSourceParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetScriptSourceParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetScriptSourceParams> result(new GetScriptSourceParams());
  errors->Push();
  errors->SetName("GetScriptSourceParams");
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetScriptSourceParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptId", internal::ToValue(script_id_));
  return std::move(result);
}

std::unique_ptr<GetScriptSourceParams> GetScriptSourceParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetScriptSourceParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetScriptSourceResult> GetScriptSourceResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetScriptSourceResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetScriptSourceResult> result(new GetScriptSourceResult());
  errors->Push();
  errors->SetName("GetScriptSourceResult");
  const base::Value* script_source_value;
  if (object->Get("scriptSource", &script_source_value)) {
    errors->SetName("scriptSource");
    result->script_source_ = internal::FromValue<std::string>::Parse(*script_source_value, errors);
  } else {
    errors->AddError("required property missing: scriptSource");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetScriptSourceResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptSource", internal::ToValue(script_source_));
  return std::move(result);
}

std::unique_ptr<GetScriptSourceResult> GetScriptSourceResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetScriptSourceResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetFunctionDetailsParams> GetFunctionDetailsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetFunctionDetailsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetFunctionDetailsParams> result(new GetFunctionDetailsParams());
  errors->Push();
  errors->SetName("GetFunctionDetailsParams");
  const base::Value* function_id_value;
  if (object->Get("functionId", &function_id_value)) {
    errors->SetName("functionId");
    result->function_id_ = internal::FromValue<std::string>::Parse(*function_id_value, errors);
  } else {
    errors->AddError("required property missing: functionId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetFunctionDetailsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("functionId", internal::ToValue(function_id_));
  return std::move(result);
}

std::unique_ptr<GetFunctionDetailsParams> GetFunctionDetailsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetFunctionDetailsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetFunctionDetailsResult> GetFunctionDetailsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetFunctionDetailsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetFunctionDetailsResult> result(new GetFunctionDetailsResult());
  errors->Push();
  errors->SetName("GetFunctionDetailsResult");
  const base::Value* details_value;
  if (object->Get("details", &details_value)) {
    errors->SetName("details");
    result->details_ = internal::FromValue<headless::debugger::FunctionDetails>::Parse(*details_value, errors);
  } else {
    errors->AddError("required property missing: details");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetFunctionDetailsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("details", internal::ToValue(*details_));
  return std::move(result);
}

std::unique_ptr<GetFunctionDetailsResult> GetFunctionDetailsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetFunctionDetailsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetGeneratorObjectDetailsParams> GetGeneratorObjectDetailsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetGeneratorObjectDetailsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetGeneratorObjectDetailsParams> result(new GetGeneratorObjectDetailsParams());
  errors->Push();
  errors->SetName("GetGeneratorObjectDetailsParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetGeneratorObjectDetailsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  return std::move(result);
}

std::unique_ptr<GetGeneratorObjectDetailsParams> GetGeneratorObjectDetailsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetGeneratorObjectDetailsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetGeneratorObjectDetailsResult> GetGeneratorObjectDetailsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetGeneratorObjectDetailsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetGeneratorObjectDetailsResult> result(new GetGeneratorObjectDetailsResult());
  errors->Push();
  errors->SetName("GetGeneratorObjectDetailsResult");
  const base::Value* details_value;
  if (object->Get("details", &details_value)) {
    errors->SetName("details");
    result->details_ = internal::FromValue<headless::debugger::GeneratorObjectDetails>::Parse(*details_value, errors);
  } else {
    errors->AddError("required property missing: details");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetGeneratorObjectDetailsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("details", internal::ToValue(*details_));
  return std::move(result);
}

std::unique_ptr<GetGeneratorObjectDetailsResult> GetGeneratorObjectDetailsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetGeneratorObjectDetailsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCollectionEntriesParams> GetCollectionEntriesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCollectionEntriesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCollectionEntriesParams> result(new GetCollectionEntriesParams());
  errors->Push();
  errors->SetName("GetCollectionEntriesParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCollectionEntriesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  return std::move(result);
}

std::unique_ptr<GetCollectionEntriesParams> GetCollectionEntriesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCollectionEntriesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCollectionEntriesResult> GetCollectionEntriesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCollectionEntriesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCollectionEntriesResult> result(new GetCollectionEntriesResult());
  errors->Push();
  errors->SetName("GetCollectionEntriesResult");
  const base::Value* entries_value;
  if (object->Get("entries", &entries_value)) {
    errors->SetName("entries");
    result->entries_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::CollectionEntry>>>::Parse(*entries_value, errors);
  } else {
    errors->AddError("required property missing: entries");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCollectionEntriesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("entries", internal::ToValue(entries_));
  return std::move(result);
}

std::unique_ptr<GetCollectionEntriesResult> GetCollectionEntriesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCollectionEntriesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetPauseOnExceptionsParams> SetPauseOnExceptionsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetPauseOnExceptionsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetPauseOnExceptionsParams> result(new SetPauseOnExceptionsParams());
  errors->Push();
  errors->SetName("SetPauseOnExceptionsParams");
  const base::Value* state_value;
  if (object->Get("state", &state_value)) {
    errors->SetName("state");
    result->state_ = internal::FromValue<headless::debugger::SetPauseOnExceptionsState>::Parse(*state_value, errors);
  } else {
    errors->AddError("required property missing: state");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetPauseOnExceptionsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("state", internal::ToValue(state_));
  return std::move(result);
}

std::unique_ptr<SetPauseOnExceptionsParams> SetPauseOnExceptionsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetPauseOnExceptionsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EvaluateOnCallFrameParams> EvaluateOnCallFrameParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EvaluateOnCallFrameParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EvaluateOnCallFrameParams> result(new EvaluateOnCallFrameParams());
  errors->Push();
  errors->SetName("EvaluateOnCallFrameParams");
  const base::Value* call_frame_id_value;
  if (object->Get("callFrameId", &call_frame_id_value)) {
    errors->SetName("callFrameId");
    result->call_frame_id_ = internal::FromValue<std::string>::Parse(*call_frame_id_value, errors);
  } else {
    errors->AddError("required property missing: callFrameId");
  }
  const base::Value* expression_value;
  if (object->Get("expression", &expression_value)) {
    errors->SetName("expression");
    result->expression_ = internal::FromValue<std::string>::Parse(*expression_value, errors);
  } else {
    errors->AddError("required property missing: expression");
  }
  const base::Value* object_group_value;
  if (object->Get("objectGroup", &object_group_value)) {
    errors->SetName("objectGroup");
    result->object_group_ = Just(internal::FromValue<std::string>::Parse(*object_group_value, errors));
  }
  const base::Value* include_command_lineapi_value;
  if (object->Get("includeCommandLineAPI", &include_command_lineapi_value)) {
    errors->SetName("includeCommandLineAPI");
    result->include_command_lineapi_ = Just(internal::FromValue<bool>::Parse(*include_command_lineapi_value, errors));
  }
  const base::Value* do_not_pause_on_exceptions_and_mute_console_value;
  if (object->Get("doNotPauseOnExceptionsAndMuteConsole", &do_not_pause_on_exceptions_and_mute_console_value)) {
    errors->SetName("doNotPauseOnExceptionsAndMuteConsole");
    result->do_not_pause_on_exceptions_and_mute_console_ = Just(internal::FromValue<bool>::Parse(*do_not_pause_on_exceptions_and_mute_console_value, errors));
  }
  const base::Value* return_by_value_value;
  if (object->Get("returnByValue", &return_by_value_value)) {
    errors->SetName("returnByValue");
    result->return_by_value_ = Just(internal::FromValue<bool>::Parse(*return_by_value_value, errors));
  }
  const base::Value* generate_preview_value;
  if (object->Get("generatePreview", &generate_preview_value)) {
    errors->SetName("generatePreview");
    result->generate_preview_ = Just(internal::FromValue<bool>::Parse(*generate_preview_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EvaluateOnCallFrameParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("callFrameId", internal::ToValue(call_frame_id_));
  result->Set("expression", internal::ToValue(expression_));
  if (object_group_.IsJust())
    result->Set("objectGroup", internal::ToValue(object_group_.FromJust()));
  if (include_command_lineapi_.IsJust())
    result->Set("includeCommandLineAPI", internal::ToValue(include_command_lineapi_.FromJust()));
  if (do_not_pause_on_exceptions_and_mute_console_.IsJust())
    result->Set("doNotPauseOnExceptionsAndMuteConsole", internal::ToValue(do_not_pause_on_exceptions_and_mute_console_.FromJust()));
  if (return_by_value_.IsJust())
    result->Set("returnByValue", internal::ToValue(return_by_value_.FromJust()));
  if (generate_preview_.IsJust())
    result->Set("generatePreview", internal::ToValue(generate_preview_.FromJust()));
  return std::move(result);
}

std::unique_ptr<EvaluateOnCallFrameParams> EvaluateOnCallFrameParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EvaluateOnCallFrameParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EvaluateOnCallFrameResult> EvaluateOnCallFrameResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EvaluateOnCallFrameResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EvaluateOnCallFrameResult> result(new EvaluateOnCallFrameResult());
  errors->Push();
  errors->SetName("EvaluateOnCallFrameResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  const base::Value* was_thrown_value;
  if (object->Get("wasThrown", &was_thrown_value)) {
    errors->SetName("wasThrown");
    result->was_thrown_ = Just(internal::FromValue<bool>::Parse(*was_thrown_value, errors));
  }
  const base::Value* exception_details_value;
  if (object->Get("exceptionDetails", &exception_details_value)) {
    errors->SetName("exceptionDetails");
    result->exception_details_ = Just(internal::FromValue<headless::runtime::ExceptionDetails>::Parse(*exception_details_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EvaluateOnCallFrameResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(*result_));
  if (was_thrown_.IsJust())
    result->Set("wasThrown", internal::ToValue(was_thrown_.FromJust()));
  if (exception_details_.IsJust())
    result->Set("exceptionDetails", internal::ToValue(*exception_details_.FromJust()));
  return std::move(result);
}

std::unique_ptr<EvaluateOnCallFrameResult> EvaluateOnCallFrameResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EvaluateOnCallFrameResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetVariableValueParams> SetVariableValueParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetVariableValueParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetVariableValueParams> result(new SetVariableValueParams());
  errors->Push();
  errors->SetName("SetVariableValueParams");
  const base::Value* scope_number_value;
  if (object->Get("scopeNumber", &scope_number_value)) {
    errors->SetName("scopeNumber");
    result->scope_number_ = internal::FromValue<int>::Parse(*scope_number_value, errors);
  } else {
    errors->AddError("required property missing: scopeNumber");
  }
  const base::Value* variable_name_value;
  if (object->Get("variableName", &variable_name_value)) {
    errors->SetName("variableName");
    result->variable_name_ = internal::FromValue<std::string>::Parse(*variable_name_value, errors);
  } else {
    errors->AddError("required property missing: variableName");
  }
  const base::Value* new_value_value;
  if (object->Get("newValue", &new_value_value)) {
    errors->SetName("newValue");
    result->new_value_ = internal::FromValue<headless::runtime::CallArgument>::Parse(*new_value_value, errors);
  } else {
    errors->AddError("required property missing: newValue");
  }
  const base::Value* call_frame_id_value;
  if (object->Get("callFrameId", &call_frame_id_value)) {
    errors->SetName("callFrameId");
    result->call_frame_id_ = internal::FromValue<std::string>::Parse(*call_frame_id_value, errors);
  } else {
    errors->AddError("required property missing: callFrameId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetVariableValueParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scopeNumber", internal::ToValue(scope_number_));
  result->Set("variableName", internal::ToValue(variable_name_));
  result->Set("newValue", internal::ToValue(*new_value_));
  result->Set("callFrameId", internal::ToValue(call_frame_id_));
  return std::move(result);
}

std::unique_ptr<SetVariableValueParams> SetVariableValueParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetVariableValueParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetBacktraceResult> GetBacktraceResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetBacktraceResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetBacktraceResult> result(new GetBacktraceResult());
  errors->Push();
  errors->SetName("GetBacktraceResult");
  const base::Value* call_frames_value;
  if (object->Get("callFrames", &call_frames_value)) {
    errors->SetName("callFrames");
    result->call_frames_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::CallFrame>>>::Parse(*call_frames_value, errors);
  } else {
    errors->AddError("required property missing: callFrames");
  }
  const base::Value* async_stack_trace_value;
  if (object->Get("asyncStackTrace", &async_stack_trace_value)) {
    errors->SetName("asyncStackTrace");
    result->async_stack_trace_ = Just(internal::FromValue<headless::runtime::StackTrace>::Parse(*async_stack_trace_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetBacktraceResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("callFrames", internal::ToValue(call_frames_));
  if (async_stack_trace_.IsJust())
    result->Set("asyncStackTrace", internal::ToValue(*async_stack_trace_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetBacktraceResult> GetBacktraceResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetBacktraceResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetAsyncCallStackDepthParams> SetAsyncCallStackDepthParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetAsyncCallStackDepthParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetAsyncCallStackDepthParams> result(new SetAsyncCallStackDepthParams());
  errors->Push();
  errors->SetName("SetAsyncCallStackDepthParams");
  const base::Value* max_depth_value;
  if (object->Get("maxDepth", &max_depth_value)) {
    errors->SetName("maxDepth");
    result->max_depth_ = internal::FromValue<int>::Parse(*max_depth_value, errors);
  } else {
    errors->AddError("required property missing: maxDepth");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetAsyncCallStackDepthParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("maxDepth", internal::ToValue(max_depth_));
  return std::move(result);
}

std::unique_ptr<SetAsyncCallStackDepthParams> SetAsyncCallStackDepthParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetAsyncCallStackDepthParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetBlackboxedRangesParams> SetBlackboxedRangesParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetBlackboxedRangesParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetBlackboxedRangesParams> result(new SetBlackboxedRangesParams());
  errors->Push();
  errors->SetName("SetBlackboxedRangesParams");
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* positions_value;
  if (object->Get("positions", &positions_value)) {
    errors->SetName("positions");
    result->positions_ = internal::FromValue<std::vector<std::unique_ptr<headless::debugger::ScriptPosition>>>::Parse(*positions_value, errors);
  } else {
    errors->AddError("required property missing: positions");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetBlackboxedRangesParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("positions", internal::ToValue(positions_));
  return std::move(result);
}

std::unique_ptr<SetBlackboxedRangesParams> SetBlackboxedRangesParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetBlackboxedRangesParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace debugger

namespace dom_debugger {

std::unique_ptr<EventListener> EventListener::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EventListener");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EventListener> result(new EventListener());
  errors->Push();
  errors->SetName("EventListener");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<std::string>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* use_capture_value;
  if (object->Get("useCapture", &use_capture_value)) {
    errors->SetName("useCapture");
    result->use_capture_ = internal::FromValue<bool>::Parse(*use_capture_value, errors);
  } else {
    errors->AddError("required property missing: useCapture");
  }
  const base::Value* location_value;
  if (object->Get("location", &location_value)) {
    errors->SetName("location");
    result->location_ = internal::FromValue<headless::debugger::Location>::Parse(*location_value, errors);
  } else {
    errors->AddError("required property missing: location");
  }
  const base::Value* handler_value;
  if (object->Get("handler", &handler_value)) {
    errors->SetName("handler");
    result->handler_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*handler_value, errors));
  }
  const base::Value* original_handler_value;
  if (object->Get("originalHandler", &original_handler_value)) {
    errors->SetName("originalHandler");
    result->original_handler_ = Just(internal::FromValue<headless::runtime::RemoteObject>::Parse(*original_handler_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EventListener::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  result->Set("useCapture", internal::ToValue(use_capture_));
  result->Set("location", internal::ToValue(*location_));
  if (handler_.IsJust())
    result->Set("handler", internal::ToValue(*handler_.FromJust()));
  if (original_handler_.IsJust())
    result->Set("originalHandler", internal::ToValue(*original_handler_.FromJust()));
  return std::move(result);
}

std::unique_ptr<EventListener> EventListener::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EventListener> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetDOMBreakpointParams> SetDOMBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDOMBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDOMBreakpointParams> result(new SetDOMBreakpointParams());
  errors->Push();
  errors->SetName("SetDOMBreakpointParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::dom_debugger::DOMBreakpointType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDOMBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("type", internal::ToValue(type_));
  return std::move(result);
}

std::unique_ptr<SetDOMBreakpointParams> SetDOMBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDOMBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveDOMBreakpointParams> RemoveDOMBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveDOMBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveDOMBreakpointParams> result(new RemoveDOMBreakpointParams());
  errors->Push();
  errors->SetName("RemoveDOMBreakpointParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::dom_debugger::DOMBreakpointType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveDOMBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("type", internal::ToValue(type_));
  return std::move(result);
}

std::unique_ptr<RemoveDOMBreakpointParams> RemoveDOMBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveDOMBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetEventListenerBreakpointParams> SetEventListenerBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetEventListenerBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetEventListenerBreakpointParams> result(new SetEventListenerBreakpointParams());
  errors->Push();
  errors->SetName("SetEventListenerBreakpointParams");
  const base::Value* event_name_value;
  if (object->Get("eventName", &event_name_value)) {
    errors->SetName("eventName");
    result->event_name_ = internal::FromValue<std::string>::Parse(*event_name_value, errors);
  } else {
    errors->AddError("required property missing: eventName");
  }
  const base::Value* target_name_value;
  if (object->Get("targetName", &target_name_value)) {
    errors->SetName("targetName");
    result->target_name_ = Just(internal::FromValue<std::string>::Parse(*target_name_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetEventListenerBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("eventName", internal::ToValue(event_name_));
  if (target_name_.IsJust())
    result->Set("targetName", internal::ToValue(target_name_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SetEventListenerBreakpointParams> SetEventListenerBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetEventListenerBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveEventListenerBreakpointParams> RemoveEventListenerBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveEventListenerBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveEventListenerBreakpointParams> result(new RemoveEventListenerBreakpointParams());
  errors->Push();
  errors->SetName("RemoveEventListenerBreakpointParams");
  const base::Value* event_name_value;
  if (object->Get("eventName", &event_name_value)) {
    errors->SetName("eventName");
    result->event_name_ = internal::FromValue<std::string>::Parse(*event_name_value, errors);
  } else {
    errors->AddError("required property missing: eventName");
  }
  const base::Value* target_name_value;
  if (object->Get("targetName", &target_name_value)) {
    errors->SetName("targetName");
    result->target_name_ = Just(internal::FromValue<std::string>::Parse(*target_name_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveEventListenerBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("eventName", internal::ToValue(event_name_));
  if (target_name_.IsJust())
    result->Set("targetName", internal::ToValue(target_name_.FromJust()));
  return std::move(result);
}

std::unique_ptr<RemoveEventListenerBreakpointParams> RemoveEventListenerBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveEventListenerBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetInstrumentationBreakpointParams> SetInstrumentationBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetInstrumentationBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetInstrumentationBreakpointParams> result(new SetInstrumentationBreakpointParams());
  errors->Push();
  errors->SetName("SetInstrumentationBreakpointParams");
  const base::Value* event_name_value;
  if (object->Get("eventName", &event_name_value)) {
    errors->SetName("eventName");
    result->event_name_ = internal::FromValue<std::string>::Parse(*event_name_value, errors);
  } else {
    errors->AddError("required property missing: eventName");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetInstrumentationBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("eventName", internal::ToValue(event_name_));
  return std::move(result);
}

std::unique_ptr<SetInstrumentationBreakpointParams> SetInstrumentationBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetInstrumentationBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveInstrumentationBreakpointParams> RemoveInstrumentationBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveInstrumentationBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveInstrumentationBreakpointParams> result(new RemoveInstrumentationBreakpointParams());
  errors->Push();
  errors->SetName("RemoveInstrumentationBreakpointParams");
  const base::Value* event_name_value;
  if (object->Get("eventName", &event_name_value)) {
    errors->SetName("eventName");
    result->event_name_ = internal::FromValue<std::string>::Parse(*event_name_value, errors);
  } else {
    errors->AddError("required property missing: eventName");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveInstrumentationBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("eventName", internal::ToValue(event_name_));
  return std::move(result);
}

std::unique_ptr<RemoveInstrumentationBreakpointParams> RemoveInstrumentationBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveInstrumentationBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetXHRBreakpointParams> SetXHRBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetXHRBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetXHRBreakpointParams> result(new SetXHRBreakpointParams());
  errors->Push();
  errors->SetName("SetXHRBreakpointParams");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetXHRBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<SetXHRBreakpointParams> SetXHRBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetXHRBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RemoveXHRBreakpointParams> RemoveXHRBreakpointParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RemoveXHRBreakpointParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RemoveXHRBreakpointParams> result(new RemoveXHRBreakpointParams());
  errors->Push();
  errors->SetName("RemoveXHRBreakpointParams");
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RemoveXHRBreakpointParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<RemoveXHRBreakpointParams> RemoveXHRBreakpointParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RemoveXHRBreakpointParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetEventListenersParams> GetEventListenersParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetEventListenersParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetEventListenersParams> result(new GetEventListenersParams());
  errors->Push();
  errors->SetName("GetEventListenersParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetEventListenersParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  return std::move(result);
}

std::unique_ptr<GetEventListenersParams> GetEventListenersParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetEventListenersParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetEventListenersResult> GetEventListenersResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetEventListenersResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetEventListenersResult> result(new GetEventListenersResult());
  errors->Push();
  errors->SetName("GetEventListenersResult");
  const base::Value* listeners_value;
  if (object->Get("listeners", &listeners_value)) {
    errors->SetName("listeners");
    result->listeners_ = internal::FromValue<std::vector<std::unique_ptr<headless::dom_debugger::EventListener>>>::Parse(*listeners_value, errors);
  } else {
    errors->AddError("required property missing: listeners");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetEventListenersResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("listeners", internal::ToValue(listeners_));
  return std::move(result);
}

std::unique_ptr<GetEventListenersResult> GetEventListenersResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetEventListenersResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace dom_debugger

namespace profiler {

std::unique_ptr<CPUProfileNode> CPUProfileNode::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CPUProfileNode");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CPUProfileNode> result(new CPUProfileNode());
  errors->Push();
  errors->SetName("CPUProfileNode");
  const base::Value* function_name_value;
  if (object->Get("functionName", &function_name_value)) {
    errors->SetName("functionName");
    result->function_name_ = internal::FromValue<std::string>::Parse(*function_name_value, errors);
  } else {
    errors->AddError("required property missing: functionName");
  }
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<int>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* column_number_value;
  if (object->Get("columnNumber", &column_number_value)) {
    errors->SetName("columnNumber");
    result->column_number_ = internal::FromValue<int>::Parse(*column_number_value, errors);
  } else {
    errors->AddError("required property missing: columnNumber");
  }
  const base::Value* hit_count_value;
  if (object->Get("hitCount", &hit_count_value)) {
    errors->SetName("hitCount");
    result->hit_count_ = internal::FromValue<int>::Parse(*hit_count_value, errors);
  } else {
    errors->AddError("required property missing: hitCount");
  }
  const base::Value* calluid_value;
  if (object->Get("callUID", &calluid_value)) {
    errors->SetName("callUID");
    result->calluid_ = internal::FromValue<double>::Parse(*calluid_value, errors);
  } else {
    errors->AddError("required property missing: callUID");
  }
  const base::Value* children_value;
  if (object->Get("children", &children_value)) {
    errors->SetName("children");
    result->children_ = internal::FromValue<std::vector<std::unique_ptr<headless::profiler::CPUProfileNode>>>::Parse(*children_value, errors);
  } else {
    errors->AddError("required property missing: children");
  }
  const base::Value* deopt_reason_value;
  if (object->Get("deoptReason", &deopt_reason_value)) {
    errors->SetName("deoptReason");
    result->deopt_reason_ = internal::FromValue<std::string>::Parse(*deopt_reason_value, errors);
  } else {
    errors->AddError("required property missing: deoptReason");
  }
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<int>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  const base::Value* position_ticks_value;
  if (object->Get("positionTicks", &position_ticks_value)) {
    errors->SetName("positionTicks");
    result->position_ticks_ = internal::FromValue<std::vector<std::unique_ptr<headless::profiler::PositionTickInfo>>>::Parse(*position_ticks_value, errors);
  } else {
    errors->AddError("required property missing: positionTicks");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CPUProfileNode::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("functionName", internal::ToValue(function_name_));
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("url", internal::ToValue(url_));
  result->Set("lineNumber", internal::ToValue(line_number_));
  result->Set("columnNumber", internal::ToValue(column_number_));
  result->Set("hitCount", internal::ToValue(hit_count_));
  result->Set("callUID", internal::ToValue(calluid_));
  result->Set("children", internal::ToValue(children_));
  result->Set("deoptReason", internal::ToValue(deopt_reason_));
  result->Set("id", internal::ToValue(id_));
  result->Set("positionTicks", internal::ToValue(position_ticks_));
  return std::move(result);
}

std::unique_ptr<CPUProfileNode> CPUProfileNode::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CPUProfileNode> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CPUProfile> CPUProfile::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CPUProfile");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CPUProfile> result(new CPUProfile());
  errors->Push();
  errors->SetName("CPUProfile");
  const base::Value* head_value;
  if (object->Get("head", &head_value)) {
    errors->SetName("head");
    result->head_ = internal::FromValue<headless::profiler::CPUProfileNode>::Parse(*head_value, errors);
  } else {
    errors->AddError("required property missing: head");
  }
  const base::Value* start_time_value;
  if (object->Get("startTime", &start_time_value)) {
    errors->SetName("startTime");
    result->start_time_ = internal::FromValue<double>::Parse(*start_time_value, errors);
  } else {
    errors->AddError("required property missing: startTime");
  }
  const base::Value* end_time_value;
  if (object->Get("endTime", &end_time_value)) {
    errors->SetName("endTime");
    result->end_time_ = internal::FromValue<double>::Parse(*end_time_value, errors);
  } else {
    errors->AddError("required property missing: endTime");
  }
  const base::Value* samples_value;
  if (object->Get("samples", &samples_value)) {
    errors->SetName("samples");
    result->samples_ = Just(internal::FromValue<std::vector<int>>::Parse(*samples_value, errors));
  }
  const base::Value* timestamps_value;
  if (object->Get("timestamps", &timestamps_value)) {
    errors->SetName("timestamps");
    result->timestamps_ = Just(internal::FromValue<std::vector<double>>::Parse(*timestamps_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CPUProfile::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("head", internal::ToValue(*head_));
  result->Set("startTime", internal::ToValue(start_time_));
  result->Set("endTime", internal::ToValue(end_time_));
  if (samples_.IsJust())
    result->Set("samples", internal::ToValue(samples_.FromJust()));
  if (timestamps_.IsJust())
    result->Set("timestamps", internal::ToValue(timestamps_.FromJust()));
  return std::move(result);
}

std::unique_ptr<CPUProfile> CPUProfile::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CPUProfile> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PositionTickInfo> PositionTickInfo::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PositionTickInfo");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PositionTickInfo> result(new PositionTickInfo());
  errors->Push();
  errors->SetName("PositionTickInfo");
  const base::Value* line_value;
  if (object->Get("line", &line_value)) {
    errors->SetName("line");
    result->line_ = internal::FromValue<int>::Parse(*line_value, errors);
  } else {
    errors->AddError("required property missing: line");
  }
  const base::Value* ticks_value;
  if (object->Get("ticks", &ticks_value)) {
    errors->SetName("ticks");
    result->ticks_ = internal::FromValue<int>::Parse(*ticks_value, errors);
  } else {
    errors->AddError("required property missing: ticks");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PositionTickInfo::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("line", internal::ToValue(line_));
  result->Set("ticks", internal::ToValue(ticks_));
  return std::move(result);
}

std::unique_ptr<PositionTickInfo> PositionTickInfo::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PositionTickInfo> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetSamplingIntervalParams> SetSamplingIntervalParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetSamplingIntervalParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetSamplingIntervalParams> result(new SetSamplingIntervalParams());
  errors->Push();
  errors->SetName("SetSamplingIntervalParams");
  const base::Value* interval_value;
  if (object->Get("interval", &interval_value)) {
    errors->SetName("interval");
    result->interval_ = internal::FromValue<int>::Parse(*interval_value, errors);
  } else {
    errors->AddError("required property missing: interval");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetSamplingIntervalParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("interval", internal::ToValue(interval_));
  return std::move(result);
}

std::unique_ptr<SetSamplingIntervalParams> SetSamplingIntervalParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetSamplingIntervalParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StopResult> StopResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StopResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StopResult> result(new StopResult());
  errors->Push();
  errors->SetName("StopResult");
  const base::Value* profile_value;
  if (object->Get("profile", &profile_value)) {
    errors->SetName("profile");
    result->profile_ = internal::FromValue<headless::profiler::CPUProfile>::Parse(*profile_value, errors);
  } else {
    errors->AddError("required property missing: profile");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StopResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("profile", internal::ToValue(*profile_));
  return std::move(result);
}

std::unique_ptr<StopResult> StopResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StopResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace profiler

namespace heap_profiler {

std::unique_ptr<SamplingHeapProfileNode> SamplingHeapProfileNode::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SamplingHeapProfileNode");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SamplingHeapProfileNode> result(new SamplingHeapProfileNode());
  errors->Push();
  errors->SetName("SamplingHeapProfileNode");
  const base::Value* function_name_value;
  if (object->Get("functionName", &function_name_value)) {
    errors->SetName("functionName");
    result->function_name_ = internal::FromValue<std::string>::Parse(*function_name_value, errors);
  } else {
    errors->AddError("required property missing: functionName");
  }
  const base::Value* script_id_value;
  if (object->Get("scriptId", &script_id_value)) {
    errors->SetName("scriptId");
    result->script_id_ = internal::FromValue<std::string>::Parse(*script_id_value, errors);
  } else {
    errors->AddError("required property missing: scriptId");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<int>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* column_number_value;
  if (object->Get("columnNumber", &column_number_value)) {
    errors->SetName("columnNumber");
    result->column_number_ = internal::FromValue<int>::Parse(*column_number_value, errors);
  } else {
    errors->AddError("required property missing: columnNumber");
  }
  const base::Value* total_size_value;
  if (object->Get("totalSize", &total_size_value)) {
    errors->SetName("totalSize");
    result->total_size_ = internal::FromValue<double>::Parse(*total_size_value, errors);
  } else {
    errors->AddError("required property missing: totalSize");
  }
  const base::Value* children_value;
  if (object->Get("children", &children_value)) {
    errors->SetName("children");
    result->children_ = internal::FromValue<std::vector<std::unique_ptr<headless::heap_profiler::SamplingHeapProfileNode>>>::Parse(*children_value, errors);
  } else {
    errors->AddError("required property missing: children");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SamplingHeapProfileNode::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("functionName", internal::ToValue(function_name_));
  result->Set("scriptId", internal::ToValue(script_id_));
  result->Set("url", internal::ToValue(url_));
  result->Set("lineNumber", internal::ToValue(line_number_));
  result->Set("columnNumber", internal::ToValue(column_number_));
  result->Set("totalSize", internal::ToValue(total_size_));
  result->Set("children", internal::ToValue(children_));
  return std::move(result);
}

std::unique_ptr<SamplingHeapProfileNode> SamplingHeapProfileNode::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SamplingHeapProfileNode> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SamplingHeapProfile> SamplingHeapProfile::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SamplingHeapProfile");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SamplingHeapProfile> result(new SamplingHeapProfile());
  errors->Push();
  errors->SetName("SamplingHeapProfile");
  const base::Value* head_value;
  if (object->Get("head", &head_value)) {
    errors->SetName("head");
    result->head_ = internal::FromValue<headless::heap_profiler::SamplingHeapProfileNode>::Parse(*head_value, errors);
  } else {
    errors->AddError("required property missing: head");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SamplingHeapProfile::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("head", internal::ToValue(*head_));
  return std::move(result);
}

std::unique_ptr<SamplingHeapProfile> SamplingHeapProfile::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SamplingHeapProfile> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StartTrackingHeapObjectsParams> StartTrackingHeapObjectsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StartTrackingHeapObjectsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StartTrackingHeapObjectsParams> result(new StartTrackingHeapObjectsParams());
  errors->Push();
  errors->SetName("StartTrackingHeapObjectsParams");
  const base::Value* track_allocations_value;
  if (object->Get("trackAllocations", &track_allocations_value)) {
    errors->SetName("trackAllocations");
    result->track_allocations_ = Just(internal::FromValue<bool>::Parse(*track_allocations_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StartTrackingHeapObjectsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (track_allocations_.IsJust())
    result->Set("trackAllocations", internal::ToValue(track_allocations_.FromJust()));
  return std::move(result);
}

std::unique_ptr<StartTrackingHeapObjectsParams> StartTrackingHeapObjectsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StartTrackingHeapObjectsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StopTrackingHeapObjectsParams> StopTrackingHeapObjectsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StopTrackingHeapObjectsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StopTrackingHeapObjectsParams> result(new StopTrackingHeapObjectsParams());
  errors->Push();
  errors->SetName("StopTrackingHeapObjectsParams");
  const base::Value* report_progress_value;
  if (object->Get("reportProgress", &report_progress_value)) {
    errors->SetName("reportProgress");
    result->report_progress_ = Just(internal::FromValue<bool>::Parse(*report_progress_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StopTrackingHeapObjectsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (report_progress_.IsJust())
    result->Set("reportProgress", internal::ToValue(report_progress_.FromJust()));
  return std::move(result);
}

std::unique_ptr<StopTrackingHeapObjectsParams> StopTrackingHeapObjectsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StopTrackingHeapObjectsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<TakeHeapSnapshotParams> TakeHeapSnapshotParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("TakeHeapSnapshotParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<TakeHeapSnapshotParams> result(new TakeHeapSnapshotParams());
  errors->Push();
  errors->SetName("TakeHeapSnapshotParams");
  const base::Value* report_progress_value;
  if (object->Get("reportProgress", &report_progress_value)) {
    errors->SetName("reportProgress");
    result->report_progress_ = Just(internal::FromValue<bool>::Parse(*report_progress_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> TakeHeapSnapshotParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (report_progress_.IsJust())
    result->Set("reportProgress", internal::ToValue(report_progress_.FromJust()));
  return std::move(result);
}

std::unique_ptr<TakeHeapSnapshotParams> TakeHeapSnapshotParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<TakeHeapSnapshotParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetObjectByHeapObjectIdParams> GetObjectByHeapObjectIdParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetObjectByHeapObjectIdParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetObjectByHeapObjectIdParams> result(new GetObjectByHeapObjectIdParams());
  errors->Push();
  errors->SetName("GetObjectByHeapObjectIdParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  const base::Value* object_group_value;
  if (object->Get("objectGroup", &object_group_value)) {
    errors->SetName("objectGroup");
    result->object_group_ = Just(internal::FromValue<std::string>::Parse(*object_group_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetObjectByHeapObjectIdParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  if (object_group_.IsJust())
    result->Set("objectGroup", internal::ToValue(object_group_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetObjectByHeapObjectIdParams> GetObjectByHeapObjectIdParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetObjectByHeapObjectIdParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetObjectByHeapObjectIdResult> GetObjectByHeapObjectIdResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetObjectByHeapObjectIdResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetObjectByHeapObjectIdResult> result(new GetObjectByHeapObjectIdResult());
  errors->Push();
  errors->SetName("GetObjectByHeapObjectIdResult");
  const base::Value* result_value;
  if (object->Get("result", &result_value)) {
    errors->SetName("result");
    result->result_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*result_value, errors);
  } else {
    errors->AddError("required property missing: result");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetObjectByHeapObjectIdResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("result", internal::ToValue(*result_));
  return std::move(result);
}

std::unique_ptr<GetObjectByHeapObjectIdResult> GetObjectByHeapObjectIdResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetObjectByHeapObjectIdResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AddInspectedHeapObjectParams> AddInspectedHeapObjectParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AddInspectedHeapObjectParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AddInspectedHeapObjectParams> result(new AddInspectedHeapObjectParams());
  errors->Push();
  errors->SetName("AddInspectedHeapObjectParams");
  const base::Value* heap_object_id_value;
  if (object->Get("heapObjectId", &heap_object_id_value)) {
    errors->SetName("heapObjectId");
    result->heap_object_id_ = internal::FromValue<std::string>::Parse(*heap_object_id_value, errors);
  } else {
    errors->AddError("required property missing: heapObjectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AddInspectedHeapObjectParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("heapObjectId", internal::ToValue(heap_object_id_));
  return std::move(result);
}

std::unique_ptr<AddInspectedHeapObjectParams> AddInspectedHeapObjectParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AddInspectedHeapObjectParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetHeapObjectIdParams> GetHeapObjectIdParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetHeapObjectIdParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetHeapObjectIdParams> result(new GetHeapObjectIdParams());
  errors->Push();
  errors->SetName("GetHeapObjectIdParams");
  const base::Value* object_id_value;
  if (object->Get("objectId", &object_id_value)) {
    errors->SetName("objectId");
    result->object_id_ = internal::FromValue<std::string>::Parse(*object_id_value, errors);
  } else {
    errors->AddError("required property missing: objectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetHeapObjectIdParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("objectId", internal::ToValue(object_id_));
  return std::move(result);
}

std::unique_ptr<GetHeapObjectIdParams> GetHeapObjectIdParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetHeapObjectIdParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetHeapObjectIdResult> GetHeapObjectIdResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetHeapObjectIdResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetHeapObjectIdResult> result(new GetHeapObjectIdResult());
  errors->Push();
  errors->SetName("GetHeapObjectIdResult");
  const base::Value* heap_snapshot_object_id_value;
  if (object->Get("heapSnapshotObjectId", &heap_snapshot_object_id_value)) {
    errors->SetName("heapSnapshotObjectId");
    result->heap_snapshot_object_id_ = internal::FromValue<std::string>::Parse(*heap_snapshot_object_id_value, errors);
  } else {
    errors->AddError("required property missing: heapSnapshotObjectId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetHeapObjectIdResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("heapSnapshotObjectId", internal::ToValue(heap_snapshot_object_id_));
  return std::move(result);
}

std::unique_ptr<GetHeapObjectIdResult> GetHeapObjectIdResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetHeapObjectIdResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StopSamplingResult> StopSamplingResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StopSamplingResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StopSamplingResult> result(new StopSamplingResult());
  errors->Push();
  errors->SetName("StopSamplingResult");
  const base::Value* profile_value;
  if (object->Get("profile", &profile_value)) {
    errors->SetName("profile");
    result->profile_ = internal::FromValue<headless::heap_profiler::SamplingHeapProfile>::Parse(*profile_value, errors);
  } else {
    errors->AddError("required property missing: profile");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StopSamplingResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("profile", internal::ToValue(*profile_));
  return std::move(result);
}

std::unique_ptr<StopSamplingResult> StopSamplingResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StopSamplingResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace heap_profiler

namespace worker {

std::unique_ptr<SendMessageToWorkerParams> SendMessageToWorkerParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SendMessageToWorkerParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SendMessageToWorkerParams> result(new SendMessageToWorkerParams());
  errors->Push();
  errors->SetName("SendMessageToWorkerParams");
  const base::Value* worker_id_value;
  if (object->Get("workerId", &worker_id_value)) {
    errors->SetName("workerId");
    result->worker_id_ = internal::FromValue<std::string>::Parse(*worker_id_value, errors);
  } else {
    errors->AddError("required property missing: workerId");
  }
  const base::Value* message_value;
  if (object->Get("message", &message_value)) {
    errors->SetName("message");
    result->message_ = internal::FromValue<std::string>::Parse(*message_value, errors);
  } else {
    errors->AddError("required property missing: message");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SendMessageToWorkerParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("workerId", internal::ToValue(worker_id_));
  result->Set("message", internal::ToValue(message_));
  return std::move(result);
}

std::unique_ptr<SendMessageToWorkerParams> SendMessageToWorkerParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SendMessageToWorkerParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetWaitForDebuggerOnStartParams> SetWaitForDebuggerOnStartParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetWaitForDebuggerOnStartParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetWaitForDebuggerOnStartParams> result(new SetWaitForDebuggerOnStartParams());
  errors->Push();
  errors->SetName("SetWaitForDebuggerOnStartParams");
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<bool>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetWaitForDebuggerOnStartParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("value", internal::ToValue(value_));
  return std::move(result);
}

std::unique_ptr<SetWaitForDebuggerOnStartParams> SetWaitForDebuggerOnStartParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetWaitForDebuggerOnStartParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace worker

namespace service_worker {

std::unique_ptr<ServiceWorkerRegistration> ServiceWorkerRegistration::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ServiceWorkerRegistration");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ServiceWorkerRegistration> result(new ServiceWorkerRegistration());
  errors->Push();
  errors->SetName("ServiceWorkerRegistration");
  const base::Value* registration_id_value;
  if (object->Get("registrationId", &registration_id_value)) {
    errors->SetName("registrationId");
    result->registration_id_ = internal::FromValue<std::string>::Parse(*registration_id_value, errors);
  } else {
    errors->AddError("required property missing: registrationId");
  }
  const base::Value* scopeurl_value;
  if (object->Get("scopeURL", &scopeurl_value)) {
    errors->SetName("scopeURL");
    result->scopeurl_ = internal::FromValue<std::string>::Parse(*scopeurl_value, errors);
  } else {
    errors->AddError("required property missing: scopeURL");
  }
  const base::Value* is_deleted_value;
  if (object->Get("isDeleted", &is_deleted_value)) {
    errors->SetName("isDeleted");
    result->is_deleted_ = internal::FromValue<bool>::Parse(*is_deleted_value, errors);
  } else {
    errors->AddError("required property missing: isDeleted");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ServiceWorkerRegistration::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("registrationId", internal::ToValue(registration_id_));
  result->Set("scopeURL", internal::ToValue(scopeurl_));
  result->Set("isDeleted", internal::ToValue(is_deleted_));
  return std::move(result);
}

std::unique_ptr<ServiceWorkerRegistration> ServiceWorkerRegistration::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ServiceWorkerRegistration> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ServiceWorkerVersion> ServiceWorkerVersion::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ServiceWorkerVersion");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ServiceWorkerVersion> result(new ServiceWorkerVersion());
  errors->Push();
  errors->SetName("ServiceWorkerVersion");
  const base::Value* version_id_value;
  if (object->Get("versionId", &version_id_value)) {
    errors->SetName("versionId");
    result->version_id_ = internal::FromValue<std::string>::Parse(*version_id_value, errors);
  } else {
    errors->AddError("required property missing: versionId");
  }
  const base::Value* registration_id_value;
  if (object->Get("registrationId", &registration_id_value)) {
    errors->SetName("registrationId");
    result->registration_id_ = internal::FromValue<std::string>::Parse(*registration_id_value, errors);
  } else {
    errors->AddError("required property missing: registrationId");
  }
  const base::Value* scripturl_value;
  if (object->Get("scriptURL", &scripturl_value)) {
    errors->SetName("scriptURL");
    result->scripturl_ = internal::FromValue<std::string>::Parse(*scripturl_value, errors);
  } else {
    errors->AddError("required property missing: scriptURL");
  }
  const base::Value* running_status_value;
  if (object->Get("runningStatus", &running_status_value)) {
    errors->SetName("runningStatus");
    result->running_status_ = internal::FromValue<headless::service_worker::ServiceWorkerVersionRunningStatus>::Parse(*running_status_value, errors);
  } else {
    errors->AddError("required property missing: runningStatus");
  }
  const base::Value* status_value;
  if (object->Get("status", &status_value)) {
    errors->SetName("status");
    result->status_ = internal::FromValue<headless::service_worker::ServiceWorkerVersionStatus>::Parse(*status_value, errors);
  } else {
    errors->AddError("required property missing: status");
  }
  const base::Value* script_last_modified_value;
  if (object->Get("scriptLastModified", &script_last_modified_value)) {
    errors->SetName("scriptLastModified");
    result->script_last_modified_ = Just(internal::FromValue<double>::Parse(*script_last_modified_value, errors));
  }
  const base::Value* script_response_time_value;
  if (object->Get("scriptResponseTime", &script_response_time_value)) {
    errors->SetName("scriptResponseTime");
    result->script_response_time_ = Just(internal::FromValue<double>::Parse(*script_response_time_value, errors));
  }
  const base::Value* controlled_clients_value;
  if (object->Get("controlledClients", &controlled_clients_value)) {
    errors->SetName("controlledClients");
    result->controlled_clients_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*controlled_clients_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ServiceWorkerVersion::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("versionId", internal::ToValue(version_id_));
  result->Set("registrationId", internal::ToValue(registration_id_));
  result->Set("scriptURL", internal::ToValue(scripturl_));
  result->Set("runningStatus", internal::ToValue(running_status_));
  result->Set("status", internal::ToValue(status_));
  if (script_last_modified_.IsJust())
    result->Set("scriptLastModified", internal::ToValue(script_last_modified_.FromJust()));
  if (script_response_time_.IsJust())
    result->Set("scriptResponseTime", internal::ToValue(script_response_time_.FromJust()));
  if (controlled_clients_.IsJust())
    result->Set("controlledClients", internal::ToValue(controlled_clients_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ServiceWorkerVersion> ServiceWorkerVersion::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ServiceWorkerVersion> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ServiceWorkerErrorMessage> ServiceWorkerErrorMessage::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ServiceWorkerErrorMessage");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ServiceWorkerErrorMessage> result(new ServiceWorkerErrorMessage());
  errors->Push();
  errors->SetName("ServiceWorkerErrorMessage");
  const base::Value* error_message_value;
  if (object->Get("errorMessage", &error_message_value)) {
    errors->SetName("errorMessage");
    result->error_message_ = internal::FromValue<std::string>::Parse(*error_message_value, errors);
  } else {
    errors->AddError("required property missing: errorMessage");
  }
  const base::Value* registration_id_value;
  if (object->Get("registrationId", &registration_id_value)) {
    errors->SetName("registrationId");
    result->registration_id_ = internal::FromValue<std::string>::Parse(*registration_id_value, errors);
  } else {
    errors->AddError("required property missing: registrationId");
  }
  const base::Value* version_id_value;
  if (object->Get("versionId", &version_id_value)) {
    errors->SetName("versionId");
    result->version_id_ = internal::FromValue<std::string>::Parse(*version_id_value, errors);
  } else {
    errors->AddError("required property missing: versionId");
  }
  const base::Value* sourceurl_value;
  if (object->Get("sourceURL", &sourceurl_value)) {
    errors->SetName("sourceURL");
    result->sourceurl_ = internal::FromValue<std::string>::Parse(*sourceurl_value, errors);
  } else {
    errors->AddError("required property missing: sourceURL");
  }
  const base::Value* line_number_value;
  if (object->Get("lineNumber", &line_number_value)) {
    errors->SetName("lineNumber");
    result->line_number_ = internal::FromValue<int>::Parse(*line_number_value, errors);
  } else {
    errors->AddError("required property missing: lineNumber");
  }
  const base::Value* column_number_value;
  if (object->Get("columnNumber", &column_number_value)) {
    errors->SetName("columnNumber");
    result->column_number_ = internal::FromValue<int>::Parse(*column_number_value, errors);
  } else {
    errors->AddError("required property missing: columnNumber");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ServiceWorkerErrorMessage::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("errorMessage", internal::ToValue(error_message_));
  result->Set("registrationId", internal::ToValue(registration_id_));
  result->Set("versionId", internal::ToValue(version_id_));
  result->Set("sourceURL", internal::ToValue(sourceurl_));
  result->Set("lineNumber", internal::ToValue(line_number_));
  result->Set("columnNumber", internal::ToValue(column_number_));
  return std::move(result);
}

std::unique_ptr<ServiceWorkerErrorMessage> ServiceWorkerErrorMessage::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ServiceWorkerErrorMessage> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<TargetInfo> TargetInfo::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("TargetInfo");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<TargetInfo> result(new TargetInfo());
  errors->Push();
  errors->SetName("TargetInfo");
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<std::string>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<std::string>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* title_value;
  if (object->Get("title", &title_value)) {
    errors->SetName("title");
    result->title_ = internal::FromValue<std::string>::Parse(*title_value, errors);
  } else {
    errors->AddError("required property missing: title");
  }
  const base::Value* url_value;
  if (object->Get("url", &url_value)) {
    errors->SetName("url");
    result->url_ = internal::FromValue<std::string>::Parse(*url_value, errors);
  } else {
    errors->AddError("required property missing: url");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> TargetInfo::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("id", internal::ToValue(id_));
  result->Set("type", internal::ToValue(type_));
  result->Set("title", internal::ToValue(title_));
  result->Set("url", internal::ToValue(url_));
  return std::move(result);
}

std::unique_ptr<TargetInfo> TargetInfo::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<TargetInfo> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SendMessageParams> SendMessageParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SendMessageParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SendMessageParams> result(new SendMessageParams());
  errors->Push();
  errors->SetName("SendMessageParams");
  const base::Value* worker_id_value;
  if (object->Get("workerId", &worker_id_value)) {
    errors->SetName("workerId");
    result->worker_id_ = internal::FromValue<std::string>::Parse(*worker_id_value, errors);
  } else {
    errors->AddError("required property missing: workerId");
  }
  const base::Value* message_value;
  if (object->Get("message", &message_value)) {
    errors->SetName("message");
    result->message_ = internal::FromValue<std::string>::Parse(*message_value, errors);
  } else {
    errors->AddError("required property missing: message");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SendMessageParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("workerId", internal::ToValue(worker_id_));
  result->Set("message", internal::ToValue(message_));
  return std::move(result);
}

std::unique_ptr<SendMessageParams> SendMessageParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SendMessageParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StopParams> StopParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StopParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StopParams> result(new StopParams());
  errors->Push();
  errors->SetName("StopParams");
  const base::Value* worker_id_value;
  if (object->Get("workerId", &worker_id_value)) {
    errors->SetName("workerId");
    result->worker_id_ = internal::FromValue<std::string>::Parse(*worker_id_value, errors);
  } else {
    errors->AddError("required property missing: workerId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StopParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("workerId", internal::ToValue(worker_id_));
  return std::move(result);
}

std::unique_ptr<StopParams> StopParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StopParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<UnregisterParams> UnregisterParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("UnregisterParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<UnregisterParams> result(new UnregisterParams());
  errors->Push();
  errors->SetName("UnregisterParams");
  const base::Value* scopeurl_value;
  if (object->Get("scopeURL", &scopeurl_value)) {
    errors->SetName("scopeURL");
    result->scopeurl_ = internal::FromValue<std::string>::Parse(*scopeurl_value, errors);
  } else {
    errors->AddError("required property missing: scopeURL");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> UnregisterParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scopeURL", internal::ToValue(scopeurl_));
  return std::move(result);
}

std::unique_ptr<UnregisterParams> UnregisterParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<UnregisterParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<UpdateRegistrationParams> UpdateRegistrationParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("UpdateRegistrationParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<UpdateRegistrationParams> result(new UpdateRegistrationParams());
  errors->Push();
  errors->SetName("UpdateRegistrationParams");
  const base::Value* scopeurl_value;
  if (object->Get("scopeURL", &scopeurl_value)) {
    errors->SetName("scopeURL");
    result->scopeurl_ = internal::FromValue<std::string>::Parse(*scopeurl_value, errors);
  } else {
    errors->AddError("required property missing: scopeURL");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> UpdateRegistrationParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scopeURL", internal::ToValue(scopeurl_));
  return std::move(result);
}

std::unique_ptr<UpdateRegistrationParams> UpdateRegistrationParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<UpdateRegistrationParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StartWorkerParams> StartWorkerParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StartWorkerParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StartWorkerParams> result(new StartWorkerParams());
  errors->Push();
  errors->SetName("StartWorkerParams");
  const base::Value* scopeurl_value;
  if (object->Get("scopeURL", &scopeurl_value)) {
    errors->SetName("scopeURL");
    result->scopeurl_ = internal::FromValue<std::string>::Parse(*scopeurl_value, errors);
  } else {
    errors->AddError("required property missing: scopeURL");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StartWorkerParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("scopeURL", internal::ToValue(scopeurl_));
  return std::move(result);
}

std::unique_ptr<StartWorkerParams> StartWorkerParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StartWorkerParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StopWorkerParams> StopWorkerParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StopWorkerParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StopWorkerParams> result(new StopWorkerParams());
  errors->Push();
  errors->SetName("StopWorkerParams");
  const base::Value* version_id_value;
  if (object->Get("versionId", &version_id_value)) {
    errors->SetName("versionId");
    result->version_id_ = internal::FromValue<std::string>::Parse(*version_id_value, errors);
  } else {
    errors->AddError("required property missing: versionId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StopWorkerParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("versionId", internal::ToValue(version_id_));
  return std::move(result);
}

std::unique_ptr<StopWorkerParams> StopWorkerParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StopWorkerParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<InspectWorkerParams> InspectWorkerParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("InspectWorkerParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<InspectWorkerParams> result(new InspectWorkerParams());
  errors->Push();
  errors->SetName("InspectWorkerParams");
  const base::Value* version_id_value;
  if (object->Get("versionId", &version_id_value)) {
    errors->SetName("versionId");
    result->version_id_ = internal::FromValue<std::string>::Parse(*version_id_value, errors);
  } else {
    errors->AddError("required property missing: versionId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> InspectWorkerParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("versionId", internal::ToValue(version_id_));
  return std::move(result);
}

std::unique_ptr<InspectWorkerParams> InspectWorkerParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<InspectWorkerParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetForceUpdateOnPageLoadParams> SetForceUpdateOnPageLoadParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetForceUpdateOnPageLoadParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetForceUpdateOnPageLoadParams> result(new SetForceUpdateOnPageLoadParams());
  errors->Push();
  errors->SetName("SetForceUpdateOnPageLoadParams");
  const base::Value* force_update_on_page_load_value;
  if (object->Get("forceUpdateOnPageLoad", &force_update_on_page_load_value)) {
    errors->SetName("forceUpdateOnPageLoad");
    result->force_update_on_page_load_ = internal::FromValue<bool>::Parse(*force_update_on_page_load_value, errors);
  } else {
    errors->AddError("required property missing: forceUpdateOnPageLoad");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetForceUpdateOnPageLoadParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("forceUpdateOnPageLoad", internal::ToValue(force_update_on_page_load_));
  return std::move(result);
}

std::unique_ptr<SetForceUpdateOnPageLoadParams> SetForceUpdateOnPageLoadParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetForceUpdateOnPageLoadParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DeliverPushMessageParams> DeliverPushMessageParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DeliverPushMessageParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DeliverPushMessageParams> result(new DeliverPushMessageParams());
  errors->Push();
  errors->SetName("DeliverPushMessageParams");
  const base::Value* origin_value;
  if (object->Get("origin", &origin_value)) {
    errors->SetName("origin");
    result->origin_ = internal::FromValue<std::string>::Parse(*origin_value, errors);
  } else {
    errors->AddError("required property missing: origin");
  }
  const base::Value* registration_id_value;
  if (object->Get("registrationId", &registration_id_value)) {
    errors->SetName("registrationId");
    result->registration_id_ = internal::FromValue<std::string>::Parse(*registration_id_value, errors);
  } else {
    errors->AddError("required property missing: registrationId");
  }
  const base::Value* data_value;
  if (object->Get("data", &data_value)) {
    errors->SetName("data");
    result->data_ = internal::FromValue<std::string>::Parse(*data_value, errors);
  } else {
    errors->AddError("required property missing: data");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DeliverPushMessageParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("origin", internal::ToValue(origin_));
  result->Set("registrationId", internal::ToValue(registration_id_));
  result->Set("data", internal::ToValue(data_));
  return std::move(result);
}

std::unique_ptr<DeliverPushMessageParams> DeliverPushMessageParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DeliverPushMessageParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetTargetInfoParams> GetTargetInfoParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetTargetInfoParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetTargetInfoParams> result(new GetTargetInfoParams());
  errors->Push();
  errors->SetName("GetTargetInfoParams");
  const base::Value* target_id_value;
  if (object->Get("targetId", &target_id_value)) {
    errors->SetName("targetId");
    result->target_id_ = internal::FromValue<std::string>::Parse(*target_id_value, errors);
  } else {
    errors->AddError("required property missing: targetId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetTargetInfoParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("targetId", internal::ToValue(target_id_));
  return std::move(result);
}

std::unique_ptr<GetTargetInfoParams> GetTargetInfoParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetTargetInfoParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetTargetInfoResult> GetTargetInfoResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetTargetInfoResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetTargetInfoResult> result(new GetTargetInfoResult());
  errors->Push();
  errors->SetName("GetTargetInfoResult");
  const base::Value* target_info_value;
  if (object->Get("targetInfo", &target_info_value)) {
    errors->SetName("targetInfo");
    result->target_info_ = internal::FromValue<headless::service_worker::TargetInfo>::Parse(*target_info_value, errors);
  } else {
    errors->AddError("required property missing: targetInfo");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetTargetInfoResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("targetInfo", internal::ToValue(*target_info_));
  return std::move(result);
}

std::unique_ptr<GetTargetInfoResult> GetTargetInfoResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetTargetInfoResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ActivateTargetParams> ActivateTargetParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ActivateTargetParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ActivateTargetParams> result(new ActivateTargetParams());
  errors->Push();
  errors->SetName("ActivateTargetParams");
  const base::Value* target_id_value;
  if (object->Get("targetId", &target_id_value)) {
    errors->SetName("targetId");
    result->target_id_ = internal::FromValue<std::string>::Parse(*target_id_value, errors);
  } else {
    errors->AddError("required property missing: targetId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ActivateTargetParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("targetId", internal::ToValue(target_id_));
  return std::move(result);
}

std::unique_ptr<ActivateTargetParams> ActivateTargetParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ActivateTargetParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace service_worker

namespace input {

std::unique_ptr<TouchPoint> TouchPoint::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("TouchPoint");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<TouchPoint> result(new TouchPoint());
  errors->Push();
  errors->SetName("TouchPoint");
  const base::Value* state_value;
  if (object->Get("state", &state_value)) {
    errors->SetName("state");
    result->state_ = internal::FromValue<headless::input::TouchPointState>::Parse(*state_value, errors);
  } else {
    errors->AddError("required property missing: state");
  }
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* radiusx_value;
  if (object->Get("radiusX", &radiusx_value)) {
    errors->SetName("radiusX");
    result->radiusx_ = Just(internal::FromValue<int>::Parse(*radiusx_value, errors));
  }
  const base::Value* radiusy_value;
  if (object->Get("radiusY", &radiusy_value)) {
    errors->SetName("radiusY");
    result->radiusy_ = Just(internal::FromValue<int>::Parse(*radiusy_value, errors));
  }
  const base::Value* rotation_angle_value;
  if (object->Get("rotationAngle", &rotation_angle_value)) {
    errors->SetName("rotationAngle");
    result->rotation_angle_ = Just(internal::FromValue<double>::Parse(*rotation_angle_value, errors));
  }
  const base::Value* force_value;
  if (object->Get("force", &force_value)) {
    errors->SetName("force");
    result->force_ = Just(internal::FromValue<double>::Parse(*force_value, errors));
  }
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = Just(internal::FromValue<double>::Parse(*id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> TouchPoint::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("state", internal::ToValue(state_));
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  if (radiusx_.IsJust())
    result->Set("radiusX", internal::ToValue(radiusx_.FromJust()));
  if (radiusy_.IsJust())
    result->Set("radiusY", internal::ToValue(radiusy_.FromJust()));
  if (rotation_angle_.IsJust())
    result->Set("rotationAngle", internal::ToValue(rotation_angle_.FromJust()));
  if (force_.IsJust())
    result->Set("force", internal::ToValue(force_.FromJust()));
  if (id_.IsJust())
    result->Set("id", internal::ToValue(id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<TouchPoint> TouchPoint::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<TouchPoint> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DispatchKeyEventParams> DispatchKeyEventParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DispatchKeyEventParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DispatchKeyEventParams> result(new DispatchKeyEventParams());
  errors->Push();
  errors->SetName("DispatchKeyEventParams");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::input::DispatchKeyEventType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* modifiers_value;
  if (object->Get("modifiers", &modifiers_value)) {
    errors->SetName("modifiers");
    result->modifiers_ = Just(internal::FromValue<int>::Parse(*modifiers_value, errors));
  }
  const base::Value* timestamp_value;
  if (object->Get("timestamp", &timestamp_value)) {
    errors->SetName("timestamp");
    result->timestamp_ = Just(internal::FromValue<double>::Parse(*timestamp_value, errors));
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = Just(internal::FromValue<std::string>::Parse(*text_value, errors));
  }
  const base::Value* unmodified_text_value;
  if (object->Get("unmodifiedText", &unmodified_text_value)) {
    errors->SetName("unmodifiedText");
    result->unmodified_text_ = Just(internal::FromValue<std::string>::Parse(*unmodified_text_value, errors));
  }
  const base::Value* key_identifier_value;
  if (object->Get("keyIdentifier", &key_identifier_value)) {
    errors->SetName("keyIdentifier");
    result->key_identifier_ = Just(internal::FromValue<std::string>::Parse(*key_identifier_value, errors));
  }
  const base::Value* code_value;
  if (object->Get("code", &code_value)) {
    errors->SetName("code");
    result->code_ = Just(internal::FromValue<std::string>::Parse(*code_value, errors));
  }
  const base::Value* key_value;
  if (object->Get("key", &key_value)) {
    errors->SetName("key");
    result->key_ = Just(internal::FromValue<std::string>::Parse(*key_value, errors));
  }
  const base::Value* windows_virtual_key_code_value;
  if (object->Get("windowsVirtualKeyCode", &windows_virtual_key_code_value)) {
    errors->SetName("windowsVirtualKeyCode");
    result->windows_virtual_key_code_ = Just(internal::FromValue<int>::Parse(*windows_virtual_key_code_value, errors));
  }
  const base::Value* native_virtual_key_code_value;
  if (object->Get("nativeVirtualKeyCode", &native_virtual_key_code_value)) {
    errors->SetName("nativeVirtualKeyCode");
    result->native_virtual_key_code_ = Just(internal::FromValue<int>::Parse(*native_virtual_key_code_value, errors));
  }
  const base::Value* auto_repeat_value;
  if (object->Get("autoRepeat", &auto_repeat_value)) {
    errors->SetName("autoRepeat");
    result->auto_repeat_ = Just(internal::FromValue<bool>::Parse(*auto_repeat_value, errors));
  }
  const base::Value* is_keypad_value;
  if (object->Get("isKeypad", &is_keypad_value)) {
    errors->SetName("isKeypad");
    result->is_keypad_ = Just(internal::FromValue<bool>::Parse(*is_keypad_value, errors));
  }
  const base::Value* is_system_key_value;
  if (object->Get("isSystemKey", &is_system_key_value)) {
    errors->SetName("isSystemKey");
    result->is_system_key_ = Just(internal::FromValue<bool>::Parse(*is_system_key_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DispatchKeyEventParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (modifiers_.IsJust())
    result->Set("modifiers", internal::ToValue(modifiers_.FromJust()));
  if (timestamp_.IsJust())
    result->Set("timestamp", internal::ToValue(timestamp_.FromJust()));
  if (text_.IsJust())
    result->Set("text", internal::ToValue(text_.FromJust()));
  if (unmodified_text_.IsJust())
    result->Set("unmodifiedText", internal::ToValue(unmodified_text_.FromJust()));
  if (key_identifier_.IsJust())
    result->Set("keyIdentifier", internal::ToValue(key_identifier_.FromJust()));
  if (code_.IsJust())
    result->Set("code", internal::ToValue(code_.FromJust()));
  if (key_.IsJust())
    result->Set("key", internal::ToValue(key_.FromJust()));
  if (windows_virtual_key_code_.IsJust())
    result->Set("windowsVirtualKeyCode", internal::ToValue(windows_virtual_key_code_.FromJust()));
  if (native_virtual_key_code_.IsJust())
    result->Set("nativeVirtualKeyCode", internal::ToValue(native_virtual_key_code_.FromJust()));
  if (auto_repeat_.IsJust())
    result->Set("autoRepeat", internal::ToValue(auto_repeat_.FromJust()));
  if (is_keypad_.IsJust())
    result->Set("isKeypad", internal::ToValue(is_keypad_.FromJust()));
  if (is_system_key_.IsJust())
    result->Set("isSystemKey", internal::ToValue(is_system_key_.FromJust()));
  return std::move(result);
}

std::unique_ptr<DispatchKeyEventParams> DispatchKeyEventParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DispatchKeyEventParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DispatchMouseEventParams> DispatchMouseEventParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DispatchMouseEventParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DispatchMouseEventParams> result(new DispatchMouseEventParams());
  errors->Push();
  errors->SetName("DispatchMouseEventParams");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::input::DispatchMouseEventType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* modifiers_value;
  if (object->Get("modifiers", &modifiers_value)) {
    errors->SetName("modifiers");
    result->modifiers_ = Just(internal::FromValue<int>::Parse(*modifiers_value, errors));
  }
  const base::Value* timestamp_value;
  if (object->Get("timestamp", &timestamp_value)) {
    errors->SetName("timestamp");
    result->timestamp_ = Just(internal::FromValue<double>::Parse(*timestamp_value, errors));
  }
  const base::Value* button_value;
  if (object->Get("button", &button_value)) {
    errors->SetName("button");
    result->button_ = Just(internal::FromValue<headless::input::DispatchMouseEventButton>::Parse(*button_value, errors));
  }
  const base::Value* click_count_value;
  if (object->Get("clickCount", &click_count_value)) {
    errors->SetName("clickCount");
    result->click_count_ = Just(internal::FromValue<int>::Parse(*click_count_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DispatchMouseEventParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  if (modifiers_.IsJust())
    result->Set("modifiers", internal::ToValue(modifiers_.FromJust()));
  if (timestamp_.IsJust())
    result->Set("timestamp", internal::ToValue(timestamp_.FromJust()));
  if (button_.IsJust())
    result->Set("button", internal::ToValue(button_.FromJust()));
  if (click_count_.IsJust())
    result->Set("clickCount", internal::ToValue(click_count_.FromJust()));
  return std::move(result);
}

std::unique_ptr<DispatchMouseEventParams> DispatchMouseEventParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DispatchMouseEventParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<DispatchTouchEventParams> DispatchTouchEventParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("DispatchTouchEventParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<DispatchTouchEventParams> result(new DispatchTouchEventParams());
  errors->Push();
  errors->SetName("DispatchTouchEventParams");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::input::DispatchTouchEventType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* touch_points_value;
  if (object->Get("touchPoints", &touch_points_value)) {
    errors->SetName("touchPoints");
    result->touch_points_ = internal::FromValue<std::vector<std::unique_ptr<headless::input::TouchPoint>>>::Parse(*touch_points_value, errors);
  } else {
    errors->AddError("required property missing: touchPoints");
  }
  const base::Value* modifiers_value;
  if (object->Get("modifiers", &modifiers_value)) {
    errors->SetName("modifiers");
    result->modifiers_ = Just(internal::FromValue<int>::Parse(*modifiers_value, errors));
  }
  const base::Value* timestamp_value;
  if (object->Get("timestamp", &timestamp_value)) {
    errors->SetName("timestamp");
    result->timestamp_ = Just(internal::FromValue<double>::Parse(*timestamp_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> DispatchTouchEventParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  result->Set("touchPoints", internal::ToValue(touch_points_));
  if (modifiers_.IsJust())
    result->Set("modifiers", internal::ToValue(modifiers_.FromJust()));
  if (timestamp_.IsJust())
    result->Set("timestamp", internal::ToValue(timestamp_.FromJust()));
  return std::move(result);
}

std::unique_ptr<DispatchTouchEventParams> DispatchTouchEventParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<DispatchTouchEventParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<EmulateTouchFromMouseEventParams> EmulateTouchFromMouseEventParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("EmulateTouchFromMouseEventParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<EmulateTouchFromMouseEventParams> result(new EmulateTouchFromMouseEventParams());
  errors->Push();
  errors->SetName("EmulateTouchFromMouseEventParams");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::input::EmulateTouchFromMouseEventType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* timestamp_value;
  if (object->Get("timestamp", &timestamp_value)) {
    errors->SetName("timestamp");
    result->timestamp_ = internal::FromValue<double>::Parse(*timestamp_value, errors);
  } else {
    errors->AddError("required property missing: timestamp");
  }
  const base::Value* button_value;
  if (object->Get("button", &button_value)) {
    errors->SetName("button");
    result->button_ = internal::FromValue<headless::input::EmulateTouchFromMouseEventButton>::Parse(*button_value, errors);
  } else {
    errors->AddError("required property missing: button");
  }
  const base::Value* deltax_value;
  if (object->Get("deltaX", &deltax_value)) {
    errors->SetName("deltaX");
    result->deltax_ = Just(internal::FromValue<double>::Parse(*deltax_value, errors));
  }
  const base::Value* deltay_value;
  if (object->Get("deltaY", &deltay_value)) {
    errors->SetName("deltaY");
    result->deltay_ = Just(internal::FromValue<double>::Parse(*deltay_value, errors));
  }
  const base::Value* modifiers_value;
  if (object->Get("modifiers", &modifiers_value)) {
    errors->SetName("modifiers");
    result->modifiers_ = Just(internal::FromValue<int>::Parse(*modifiers_value, errors));
  }
  const base::Value* click_count_value;
  if (object->Get("clickCount", &click_count_value)) {
    errors->SetName("clickCount");
    result->click_count_ = Just(internal::FromValue<int>::Parse(*click_count_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> EmulateTouchFromMouseEventParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  result->Set("timestamp", internal::ToValue(timestamp_));
  result->Set("button", internal::ToValue(button_));
  if (deltax_.IsJust())
    result->Set("deltaX", internal::ToValue(deltax_.FromJust()));
  if (deltay_.IsJust())
    result->Set("deltaY", internal::ToValue(deltay_.FromJust()));
  if (modifiers_.IsJust())
    result->Set("modifiers", internal::ToValue(modifiers_.FromJust()));
  if (click_count_.IsJust())
    result->Set("clickCount", internal::ToValue(click_count_.FromJust()));
  return std::move(result);
}

std::unique_ptr<EmulateTouchFromMouseEventParams> EmulateTouchFromMouseEventParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<EmulateTouchFromMouseEventParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SynthesizePinchGestureParams> SynthesizePinchGestureParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SynthesizePinchGestureParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SynthesizePinchGestureParams> result(new SynthesizePinchGestureParams());
  errors->Push();
  errors->SetName("SynthesizePinchGestureParams");
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* scale_factor_value;
  if (object->Get("scaleFactor", &scale_factor_value)) {
    errors->SetName("scaleFactor");
    result->scale_factor_ = internal::FromValue<double>::Parse(*scale_factor_value, errors);
  } else {
    errors->AddError("required property missing: scaleFactor");
  }
  const base::Value* relative_speed_value;
  if (object->Get("relativeSpeed", &relative_speed_value)) {
    errors->SetName("relativeSpeed");
    result->relative_speed_ = Just(internal::FromValue<int>::Parse(*relative_speed_value, errors));
  }
  const base::Value* gesture_source_type_value;
  if (object->Get("gestureSourceType", &gesture_source_type_value)) {
    errors->SetName("gestureSourceType");
    result->gesture_source_type_ = Just(internal::FromValue<headless::input::GestureSourceType>::Parse(*gesture_source_type_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SynthesizePinchGestureParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  result->Set("scaleFactor", internal::ToValue(scale_factor_));
  if (relative_speed_.IsJust())
    result->Set("relativeSpeed", internal::ToValue(relative_speed_.FromJust()));
  if (gesture_source_type_.IsJust())
    result->Set("gestureSourceType", internal::ToValue(gesture_source_type_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SynthesizePinchGestureParams> SynthesizePinchGestureParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SynthesizePinchGestureParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SynthesizeScrollGestureParams> SynthesizeScrollGestureParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SynthesizeScrollGestureParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SynthesizeScrollGestureParams> result(new SynthesizeScrollGestureParams());
  errors->Push();
  errors->SetName("SynthesizeScrollGestureParams");
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* x_distance_value;
  if (object->Get("xDistance", &x_distance_value)) {
    errors->SetName("xDistance");
    result->x_distance_ = Just(internal::FromValue<int>::Parse(*x_distance_value, errors));
  }
  const base::Value* y_distance_value;
  if (object->Get("yDistance", &y_distance_value)) {
    errors->SetName("yDistance");
    result->y_distance_ = Just(internal::FromValue<int>::Parse(*y_distance_value, errors));
  }
  const base::Value* x_overscroll_value;
  if (object->Get("xOverscroll", &x_overscroll_value)) {
    errors->SetName("xOverscroll");
    result->x_overscroll_ = Just(internal::FromValue<int>::Parse(*x_overscroll_value, errors));
  }
  const base::Value* y_overscroll_value;
  if (object->Get("yOverscroll", &y_overscroll_value)) {
    errors->SetName("yOverscroll");
    result->y_overscroll_ = Just(internal::FromValue<int>::Parse(*y_overscroll_value, errors));
  }
  const base::Value* prevent_fling_value;
  if (object->Get("preventFling", &prevent_fling_value)) {
    errors->SetName("preventFling");
    result->prevent_fling_ = Just(internal::FromValue<bool>::Parse(*prevent_fling_value, errors));
  }
  const base::Value* speed_value;
  if (object->Get("speed", &speed_value)) {
    errors->SetName("speed");
    result->speed_ = Just(internal::FromValue<int>::Parse(*speed_value, errors));
  }
  const base::Value* gesture_source_type_value;
  if (object->Get("gestureSourceType", &gesture_source_type_value)) {
    errors->SetName("gestureSourceType");
    result->gesture_source_type_ = Just(internal::FromValue<headless::input::GestureSourceType>::Parse(*gesture_source_type_value, errors));
  }
  const base::Value* repeat_count_value;
  if (object->Get("repeatCount", &repeat_count_value)) {
    errors->SetName("repeatCount");
    result->repeat_count_ = Just(internal::FromValue<int>::Parse(*repeat_count_value, errors));
  }
  const base::Value* repeat_delay_ms_value;
  if (object->Get("repeatDelayMs", &repeat_delay_ms_value)) {
    errors->SetName("repeatDelayMs");
    result->repeat_delay_ms_ = Just(internal::FromValue<int>::Parse(*repeat_delay_ms_value, errors));
  }
  const base::Value* interaction_marker_name_value;
  if (object->Get("interactionMarkerName", &interaction_marker_name_value)) {
    errors->SetName("interactionMarkerName");
    result->interaction_marker_name_ = Just(internal::FromValue<std::string>::Parse(*interaction_marker_name_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SynthesizeScrollGestureParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  if (x_distance_.IsJust())
    result->Set("xDistance", internal::ToValue(x_distance_.FromJust()));
  if (y_distance_.IsJust())
    result->Set("yDistance", internal::ToValue(y_distance_.FromJust()));
  if (x_overscroll_.IsJust())
    result->Set("xOverscroll", internal::ToValue(x_overscroll_.FromJust()));
  if (y_overscroll_.IsJust())
    result->Set("yOverscroll", internal::ToValue(y_overscroll_.FromJust()));
  if (prevent_fling_.IsJust())
    result->Set("preventFling", internal::ToValue(prevent_fling_.FromJust()));
  if (speed_.IsJust())
    result->Set("speed", internal::ToValue(speed_.FromJust()));
  if (gesture_source_type_.IsJust())
    result->Set("gestureSourceType", internal::ToValue(gesture_source_type_.FromJust()));
  if (repeat_count_.IsJust())
    result->Set("repeatCount", internal::ToValue(repeat_count_.FromJust()));
  if (repeat_delay_ms_.IsJust())
    result->Set("repeatDelayMs", internal::ToValue(repeat_delay_ms_.FromJust()));
  if (interaction_marker_name_.IsJust())
    result->Set("interactionMarkerName", internal::ToValue(interaction_marker_name_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SynthesizeScrollGestureParams> SynthesizeScrollGestureParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SynthesizeScrollGestureParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SynthesizeTapGestureParams> SynthesizeTapGestureParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SynthesizeTapGestureParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SynthesizeTapGestureParams> result(new SynthesizeTapGestureParams());
  errors->Push();
  errors->SetName("SynthesizeTapGestureParams");
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<int>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<int>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* duration_value;
  if (object->Get("duration", &duration_value)) {
    errors->SetName("duration");
    result->duration_ = Just(internal::FromValue<int>::Parse(*duration_value, errors));
  }
  const base::Value* tap_count_value;
  if (object->Get("tapCount", &tap_count_value)) {
    errors->SetName("tapCount");
    result->tap_count_ = Just(internal::FromValue<int>::Parse(*tap_count_value, errors));
  }
  const base::Value* gesture_source_type_value;
  if (object->Get("gestureSourceType", &gesture_source_type_value)) {
    errors->SetName("gestureSourceType");
    result->gesture_source_type_ = Just(internal::FromValue<headless::input::GestureSourceType>::Parse(*gesture_source_type_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SynthesizeTapGestureParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  if (duration_.IsJust())
    result->Set("duration", internal::ToValue(duration_.FromJust()));
  if (tap_count_.IsJust())
    result->Set("tapCount", internal::ToValue(tap_count_.FromJust()));
  if (gesture_source_type_.IsJust())
    result->Set("gestureSourceType", internal::ToValue(gesture_source_type_.FromJust()));
  return std::move(result);
}

std::unique_ptr<SynthesizeTapGestureParams> SynthesizeTapGestureParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SynthesizeTapGestureParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace input

namespace layer_tree {

std::unique_ptr<ScrollRect> ScrollRect::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ScrollRect");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ScrollRect> result(new ScrollRect());
  errors->Push();
  errors->SetName("ScrollRect");
  const base::Value* rect_value;
  if (object->Get("rect", &rect_value)) {
    errors->SetName("rect");
    result->rect_ = internal::FromValue<headless::dom::Rect>::Parse(*rect_value, errors);
  } else {
    errors->AddError("required property missing: rect");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::layer_tree::ScrollRectType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ScrollRect::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("rect", internal::ToValue(*rect_));
  result->Set("type", internal::ToValue(type_));
  return std::move(result);
}

std::unique_ptr<ScrollRect> ScrollRect::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ScrollRect> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<PictureTile> PictureTile::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("PictureTile");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<PictureTile> result(new PictureTile());
  errors->Push();
  errors->SetName("PictureTile");
  const base::Value* x_value;
  if (object->Get("x", &x_value)) {
    errors->SetName("x");
    result->x_ = internal::FromValue<double>::Parse(*x_value, errors);
  } else {
    errors->AddError("required property missing: x");
  }
  const base::Value* y_value;
  if (object->Get("y", &y_value)) {
    errors->SetName("y");
    result->y_ = internal::FromValue<double>::Parse(*y_value, errors);
  } else {
    errors->AddError("required property missing: y");
  }
  const base::Value* picture_value;
  if (object->Get("picture", &picture_value)) {
    errors->SetName("picture");
    result->picture_ = internal::FromValue<std::string>::Parse(*picture_value, errors);
  } else {
    errors->AddError("required property missing: picture");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> PictureTile::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("x", internal::ToValue(x_));
  result->Set("y", internal::ToValue(y_));
  result->Set("picture", internal::ToValue(picture_));
  return std::move(result);
}

std::unique_ptr<PictureTile> PictureTile::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<PictureTile> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<Layer> Layer::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Layer");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Layer> result(new Layer());
  errors->Push();
  errors->SetName("Layer");
  const base::Value* layer_id_value;
  if (object->Get("layerId", &layer_id_value)) {
    errors->SetName("layerId");
    result->layer_id_ = internal::FromValue<std::string>::Parse(*layer_id_value, errors);
  } else {
    errors->AddError("required property missing: layerId");
  }
  const base::Value* parent_layer_id_value;
  if (object->Get("parentLayerId", &parent_layer_id_value)) {
    errors->SetName("parentLayerId");
    result->parent_layer_id_ = Just(internal::FromValue<std::string>::Parse(*parent_layer_id_value, errors));
  }
  const base::Value* backend_node_id_value;
  if (object->Get("backendNodeId", &backend_node_id_value)) {
    errors->SetName("backendNodeId");
    result->backend_node_id_ = Just(internal::FromValue<int>::Parse(*backend_node_id_value, errors));
  }
  const base::Value* offsetx_value;
  if (object->Get("offsetX", &offsetx_value)) {
    errors->SetName("offsetX");
    result->offsetx_ = internal::FromValue<double>::Parse(*offsetx_value, errors);
  } else {
    errors->AddError("required property missing: offsetX");
  }
  const base::Value* offsety_value;
  if (object->Get("offsetY", &offsety_value)) {
    errors->SetName("offsetY");
    result->offsety_ = internal::FromValue<double>::Parse(*offsety_value, errors);
  } else {
    errors->AddError("required property missing: offsetY");
  }
  const base::Value* width_value;
  if (object->Get("width", &width_value)) {
    errors->SetName("width");
    result->width_ = internal::FromValue<double>::Parse(*width_value, errors);
  } else {
    errors->AddError("required property missing: width");
  }
  const base::Value* height_value;
  if (object->Get("height", &height_value)) {
    errors->SetName("height");
    result->height_ = internal::FromValue<double>::Parse(*height_value, errors);
  } else {
    errors->AddError("required property missing: height");
  }
  const base::Value* transform_value;
  if (object->Get("transform", &transform_value)) {
    errors->SetName("transform");
    result->transform_ = Just(internal::FromValue<std::vector<double>>::Parse(*transform_value, errors));
  }
  const base::Value* anchorx_value;
  if (object->Get("anchorX", &anchorx_value)) {
    errors->SetName("anchorX");
    result->anchorx_ = Just(internal::FromValue<double>::Parse(*anchorx_value, errors));
  }
  const base::Value* anchory_value;
  if (object->Get("anchorY", &anchory_value)) {
    errors->SetName("anchorY");
    result->anchory_ = Just(internal::FromValue<double>::Parse(*anchory_value, errors));
  }
  const base::Value* anchorz_value;
  if (object->Get("anchorZ", &anchorz_value)) {
    errors->SetName("anchorZ");
    result->anchorz_ = Just(internal::FromValue<double>::Parse(*anchorz_value, errors));
  }
  const base::Value* paint_count_value;
  if (object->Get("paintCount", &paint_count_value)) {
    errors->SetName("paintCount");
    result->paint_count_ = internal::FromValue<int>::Parse(*paint_count_value, errors);
  } else {
    errors->AddError("required property missing: paintCount");
  }
  const base::Value* draws_content_value;
  if (object->Get("drawsContent", &draws_content_value)) {
    errors->SetName("drawsContent");
    result->draws_content_ = internal::FromValue<bool>::Parse(*draws_content_value, errors);
  } else {
    errors->AddError("required property missing: drawsContent");
  }
  const base::Value* invisible_value;
  if (object->Get("invisible", &invisible_value)) {
    errors->SetName("invisible");
    result->invisible_ = Just(internal::FromValue<bool>::Parse(*invisible_value, errors));
  }
  const base::Value* scroll_rects_value;
  if (object->Get("scrollRects", &scroll_rects_value)) {
    errors->SetName("scrollRects");
    result->scroll_rects_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::layer_tree::ScrollRect>>>::Parse(*scroll_rects_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Layer::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("layerId", internal::ToValue(layer_id_));
  if (parent_layer_id_.IsJust())
    result->Set("parentLayerId", internal::ToValue(parent_layer_id_.FromJust()));
  if (backend_node_id_.IsJust())
    result->Set("backendNodeId", internal::ToValue(backend_node_id_.FromJust()));
  result->Set("offsetX", internal::ToValue(offsetx_));
  result->Set("offsetY", internal::ToValue(offsety_));
  result->Set("width", internal::ToValue(width_));
  result->Set("height", internal::ToValue(height_));
  if (transform_.IsJust())
    result->Set("transform", internal::ToValue(transform_.FromJust()));
  if (anchorx_.IsJust())
    result->Set("anchorX", internal::ToValue(anchorx_.FromJust()));
  if (anchory_.IsJust())
    result->Set("anchorY", internal::ToValue(anchory_.FromJust()));
  if (anchorz_.IsJust())
    result->Set("anchorZ", internal::ToValue(anchorz_.FromJust()));
  result->Set("paintCount", internal::ToValue(paint_count_));
  result->Set("drawsContent", internal::ToValue(draws_content_));
  if (invisible_.IsJust())
    result->Set("invisible", internal::ToValue(invisible_.FromJust()));
  if (scroll_rects_.IsJust())
    result->Set("scrollRects", internal::ToValue(scroll_rects_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Layer> Layer::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Layer> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CompositingReasonsParams> CompositingReasonsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CompositingReasonsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CompositingReasonsParams> result(new CompositingReasonsParams());
  errors->Push();
  errors->SetName("CompositingReasonsParams");
  const base::Value* layer_id_value;
  if (object->Get("layerId", &layer_id_value)) {
    errors->SetName("layerId");
    result->layer_id_ = internal::FromValue<std::string>::Parse(*layer_id_value, errors);
  } else {
    errors->AddError("required property missing: layerId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CompositingReasonsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("layerId", internal::ToValue(layer_id_));
  return std::move(result);
}

std::unique_ptr<CompositingReasonsParams> CompositingReasonsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CompositingReasonsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<CompositingReasonsResult> CompositingReasonsResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("CompositingReasonsResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<CompositingReasonsResult> result(new CompositingReasonsResult());
  errors->Push();
  errors->SetName("CompositingReasonsResult");
  const base::Value* compositing_reasons_value;
  if (object->Get("compositingReasons", &compositing_reasons_value)) {
    errors->SetName("compositingReasons");
    result->compositing_reasons_ = internal::FromValue<std::vector<std::string>>::Parse(*compositing_reasons_value, errors);
  } else {
    errors->AddError("required property missing: compositingReasons");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> CompositingReasonsResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("compositingReasons", internal::ToValue(compositing_reasons_));
  return std::move(result);
}

std::unique_ptr<CompositingReasonsResult> CompositingReasonsResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<CompositingReasonsResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MakeSnapshotParams> MakeSnapshotParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MakeSnapshotParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MakeSnapshotParams> result(new MakeSnapshotParams());
  errors->Push();
  errors->SetName("MakeSnapshotParams");
  const base::Value* layer_id_value;
  if (object->Get("layerId", &layer_id_value)) {
    errors->SetName("layerId");
    result->layer_id_ = internal::FromValue<std::string>::Parse(*layer_id_value, errors);
  } else {
    errors->AddError("required property missing: layerId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MakeSnapshotParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("layerId", internal::ToValue(layer_id_));
  return std::move(result);
}

std::unique_ptr<MakeSnapshotParams> MakeSnapshotParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MakeSnapshotParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MakeSnapshotResult> MakeSnapshotResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MakeSnapshotResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MakeSnapshotResult> result(new MakeSnapshotResult());
  errors->Push();
  errors->SetName("MakeSnapshotResult");
  const base::Value* snapshot_id_value;
  if (object->Get("snapshotId", &snapshot_id_value)) {
    errors->SetName("snapshotId");
    result->snapshot_id_ = internal::FromValue<std::string>::Parse(*snapshot_id_value, errors);
  } else {
    errors->AddError("required property missing: snapshotId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MakeSnapshotResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("snapshotId", internal::ToValue(snapshot_id_));
  return std::move(result);
}

std::unique_ptr<MakeSnapshotResult> MakeSnapshotResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MakeSnapshotResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<LoadSnapshotParams> LoadSnapshotParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("LoadSnapshotParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<LoadSnapshotParams> result(new LoadSnapshotParams());
  errors->Push();
  errors->SetName("LoadSnapshotParams");
  const base::Value* tiles_value;
  if (object->Get("tiles", &tiles_value)) {
    errors->SetName("tiles");
    result->tiles_ = internal::FromValue<std::vector<std::unique_ptr<headless::layer_tree::PictureTile>>>::Parse(*tiles_value, errors);
  } else {
    errors->AddError("required property missing: tiles");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> LoadSnapshotParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("tiles", internal::ToValue(tiles_));
  return std::move(result);
}

std::unique_ptr<LoadSnapshotParams> LoadSnapshotParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<LoadSnapshotParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<LoadSnapshotResult> LoadSnapshotResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("LoadSnapshotResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<LoadSnapshotResult> result(new LoadSnapshotResult());
  errors->Push();
  errors->SetName("LoadSnapshotResult");
  const base::Value* snapshot_id_value;
  if (object->Get("snapshotId", &snapshot_id_value)) {
    errors->SetName("snapshotId");
    result->snapshot_id_ = internal::FromValue<std::string>::Parse(*snapshot_id_value, errors);
  } else {
    errors->AddError("required property missing: snapshotId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> LoadSnapshotResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("snapshotId", internal::ToValue(snapshot_id_));
  return std::move(result);
}

std::unique_ptr<LoadSnapshotResult> LoadSnapshotResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<LoadSnapshotResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReleaseSnapshotParams> ReleaseSnapshotParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReleaseSnapshotParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReleaseSnapshotParams> result(new ReleaseSnapshotParams());
  errors->Push();
  errors->SetName("ReleaseSnapshotParams");
  const base::Value* snapshot_id_value;
  if (object->Get("snapshotId", &snapshot_id_value)) {
    errors->SetName("snapshotId");
    result->snapshot_id_ = internal::FromValue<std::string>::Parse(*snapshot_id_value, errors);
  } else {
    errors->AddError("required property missing: snapshotId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReleaseSnapshotParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("snapshotId", internal::ToValue(snapshot_id_));
  return std::move(result);
}

std::unique_ptr<ReleaseSnapshotParams> ReleaseSnapshotParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReleaseSnapshotParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ProfileSnapshotParams> ProfileSnapshotParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ProfileSnapshotParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ProfileSnapshotParams> result(new ProfileSnapshotParams());
  errors->Push();
  errors->SetName("ProfileSnapshotParams");
  const base::Value* snapshot_id_value;
  if (object->Get("snapshotId", &snapshot_id_value)) {
    errors->SetName("snapshotId");
    result->snapshot_id_ = internal::FromValue<std::string>::Parse(*snapshot_id_value, errors);
  } else {
    errors->AddError("required property missing: snapshotId");
  }
  const base::Value* min_repeat_count_value;
  if (object->Get("minRepeatCount", &min_repeat_count_value)) {
    errors->SetName("minRepeatCount");
    result->min_repeat_count_ = Just(internal::FromValue<int>::Parse(*min_repeat_count_value, errors));
  }
  const base::Value* min_duration_value;
  if (object->Get("minDuration", &min_duration_value)) {
    errors->SetName("minDuration");
    result->min_duration_ = Just(internal::FromValue<double>::Parse(*min_duration_value, errors));
  }
  const base::Value* clip_rect_value;
  if (object->Get("clipRect", &clip_rect_value)) {
    errors->SetName("clipRect");
    result->clip_rect_ = Just(internal::FromValue<headless::dom::Rect>::Parse(*clip_rect_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ProfileSnapshotParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("snapshotId", internal::ToValue(snapshot_id_));
  if (min_repeat_count_.IsJust())
    result->Set("minRepeatCount", internal::ToValue(min_repeat_count_.FromJust()));
  if (min_duration_.IsJust())
    result->Set("minDuration", internal::ToValue(min_duration_.FromJust()));
  if (clip_rect_.IsJust())
    result->Set("clipRect", internal::ToValue(*clip_rect_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ProfileSnapshotParams> ProfileSnapshotParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ProfileSnapshotParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ProfileSnapshotResult> ProfileSnapshotResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ProfileSnapshotResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ProfileSnapshotResult> result(new ProfileSnapshotResult());
  errors->Push();
  errors->SetName("ProfileSnapshotResult");
  const base::Value* timings_value;
  if (object->Get("timings", &timings_value)) {
    errors->SetName("timings");
    result->timings_ = internal::FromValue<std::vector<std::vector<double>>>::Parse(*timings_value, errors);
  } else {
    errors->AddError("required property missing: timings");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ProfileSnapshotResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("timings", internal::ToValue(timings_));
  return std::move(result);
}

std::unique_ptr<ProfileSnapshotResult> ProfileSnapshotResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ProfileSnapshotResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReplaySnapshotParams> ReplaySnapshotParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReplaySnapshotParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReplaySnapshotParams> result(new ReplaySnapshotParams());
  errors->Push();
  errors->SetName("ReplaySnapshotParams");
  const base::Value* snapshot_id_value;
  if (object->Get("snapshotId", &snapshot_id_value)) {
    errors->SetName("snapshotId");
    result->snapshot_id_ = internal::FromValue<std::string>::Parse(*snapshot_id_value, errors);
  } else {
    errors->AddError("required property missing: snapshotId");
  }
  const base::Value* from_step_value;
  if (object->Get("fromStep", &from_step_value)) {
    errors->SetName("fromStep");
    result->from_step_ = Just(internal::FromValue<int>::Parse(*from_step_value, errors));
  }
  const base::Value* to_step_value;
  if (object->Get("toStep", &to_step_value)) {
    errors->SetName("toStep");
    result->to_step_ = Just(internal::FromValue<int>::Parse(*to_step_value, errors));
  }
  const base::Value* scale_value;
  if (object->Get("scale", &scale_value)) {
    errors->SetName("scale");
    result->scale_ = Just(internal::FromValue<double>::Parse(*scale_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReplaySnapshotParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("snapshotId", internal::ToValue(snapshot_id_));
  if (from_step_.IsJust())
    result->Set("fromStep", internal::ToValue(from_step_.FromJust()));
  if (to_step_.IsJust())
    result->Set("toStep", internal::ToValue(to_step_.FromJust()));
  if (scale_.IsJust())
    result->Set("scale", internal::ToValue(scale_.FromJust()));
  return std::move(result);
}

std::unique_ptr<ReplaySnapshotParams> ReplaySnapshotParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReplaySnapshotParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReplaySnapshotResult> ReplaySnapshotResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReplaySnapshotResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReplaySnapshotResult> result(new ReplaySnapshotResult());
  errors->Push();
  errors->SetName("ReplaySnapshotResult");
  const base::Value* dataurl_value;
  if (object->Get("dataURL", &dataurl_value)) {
    errors->SetName("dataURL");
    result->dataurl_ = internal::FromValue<std::string>::Parse(*dataurl_value, errors);
  } else {
    errors->AddError("required property missing: dataURL");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReplaySnapshotResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("dataURL", internal::ToValue(dataurl_));
  return std::move(result);
}

std::unique_ptr<ReplaySnapshotResult> ReplaySnapshotResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReplaySnapshotResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SnapshotCommandLogParams> SnapshotCommandLogParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SnapshotCommandLogParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SnapshotCommandLogParams> result(new SnapshotCommandLogParams());
  errors->Push();
  errors->SetName("SnapshotCommandLogParams");
  const base::Value* snapshot_id_value;
  if (object->Get("snapshotId", &snapshot_id_value)) {
    errors->SetName("snapshotId");
    result->snapshot_id_ = internal::FromValue<std::string>::Parse(*snapshot_id_value, errors);
  } else {
    errors->AddError("required property missing: snapshotId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SnapshotCommandLogParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("snapshotId", internal::ToValue(snapshot_id_));
  return std::move(result);
}

std::unique_ptr<SnapshotCommandLogParams> SnapshotCommandLogParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SnapshotCommandLogParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SnapshotCommandLogResult> SnapshotCommandLogResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SnapshotCommandLogResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SnapshotCommandLogResult> result(new SnapshotCommandLogResult());
  errors->Push();
  errors->SetName("SnapshotCommandLogResult");
  const base::Value* command_log_value;
  if (object->Get("commandLog", &command_log_value)) {
    errors->SetName("commandLog");
    result->command_log_ = internal::FromValue<std::vector<std::unique_ptr<base::Value>>>::Parse(*command_log_value, errors);
  } else {
    errors->AddError("required property missing: commandLog");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SnapshotCommandLogResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("commandLog", internal::ToValue(command_log_));
  return std::move(result);
}

std::unique_ptr<SnapshotCommandLogResult> SnapshotCommandLogResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SnapshotCommandLogResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace layer_tree

namespace device_orientation {

std::unique_ptr<SetDeviceOrientationOverrideParams> SetDeviceOrientationOverrideParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetDeviceOrientationOverrideParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetDeviceOrientationOverrideParams> result(new SetDeviceOrientationOverrideParams());
  errors->Push();
  errors->SetName("SetDeviceOrientationOverrideParams");
  const base::Value* alpha_value;
  if (object->Get("alpha", &alpha_value)) {
    errors->SetName("alpha");
    result->alpha_ = internal::FromValue<double>::Parse(*alpha_value, errors);
  } else {
    errors->AddError("required property missing: alpha");
  }
  const base::Value* beta_value;
  if (object->Get("beta", &beta_value)) {
    errors->SetName("beta");
    result->beta_ = internal::FromValue<double>::Parse(*beta_value, errors);
  } else {
    errors->AddError("required property missing: beta");
  }
  const base::Value* gamma_value;
  if (object->Get("gamma", &gamma_value)) {
    errors->SetName("gamma");
    result->gamma_ = internal::FromValue<double>::Parse(*gamma_value, errors);
  } else {
    errors->AddError("required property missing: gamma");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetDeviceOrientationOverrideParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("alpha", internal::ToValue(alpha_));
  result->Set("beta", internal::ToValue(beta_));
  result->Set("gamma", internal::ToValue(gamma_));
  return std::move(result);
}

std::unique_ptr<SetDeviceOrientationOverrideParams> SetDeviceOrientationOverrideParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetDeviceOrientationOverrideParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace device_orientation

namespace tracing {

std::unique_ptr<MemoryDumpTrigger> MemoryDumpTrigger::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MemoryDumpTrigger");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MemoryDumpTrigger> result(new MemoryDumpTrigger());
  errors->Push();
  errors->SetName("MemoryDumpTrigger");
  const base::Value* mode_value;
  if (object->Get("mode", &mode_value)) {
    errors->SetName("mode");
    result->mode_ = internal::FromValue<headless::tracing::MemoryDumpTriggerMode>::Parse(*mode_value, errors);
  } else {
    errors->AddError("required property missing: mode");
  }
  const base::Value* periodic_interval_ms_value;
  if (object->Get("periodicIntervalMs", &periodic_interval_ms_value)) {
    errors->SetName("periodicIntervalMs");
    result->periodic_interval_ms_ = internal::FromValue<int>::Parse(*periodic_interval_ms_value, errors);
  } else {
    errors->AddError("required property missing: periodicIntervalMs");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MemoryDumpTrigger::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("mode", internal::ToValue(mode_));
  result->Set("periodicIntervalMs", internal::ToValue(periodic_interval_ms_));
  return std::move(result);
}

std::unique_ptr<MemoryDumpTrigger> MemoryDumpTrigger::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MemoryDumpTrigger> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<MemoryDumpConfig> MemoryDumpConfig::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("MemoryDumpConfig");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<MemoryDumpConfig> result(new MemoryDumpConfig());
  errors->Push();
  errors->SetName("MemoryDumpConfig");
  const base::Value* triggers_value;
  if (object->Get("triggers", &triggers_value)) {
    errors->SetName("triggers");
    result->triggers_ = internal::FromValue<std::vector<std::unique_ptr<headless::tracing::MemoryDumpTrigger>>>::Parse(*triggers_value, errors);
  } else {
    errors->AddError("required property missing: triggers");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> MemoryDumpConfig::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("triggers", internal::ToValue(triggers_));
  return std::move(result);
}

std::unique_ptr<MemoryDumpConfig> MemoryDumpConfig::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<MemoryDumpConfig> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<TraceConfig> TraceConfig::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("TraceConfig");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<TraceConfig> result(new TraceConfig());
  errors->Push();
  errors->SetName("TraceConfig");
  const base::Value* record_mode_value;
  if (object->Get("recordMode", &record_mode_value)) {
    errors->SetName("recordMode");
    result->record_mode_ = Just(internal::FromValue<headless::tracing::TraceConfigRecordMode>::Parse(*record_mode_value, errors));
  }
  const base::Value* enable_sampling_value;
  if (object->Get("enableSampling", &enable_sampling_value)) {
    errors->SetName("enableSampling");
    result->enable_sampling_ = Just(internal::FromValue<bool>::Parse(*enable_sampling_value, errors));
  }
  const base::Value* enable_systrace_value;
  if (object->Get("enableSystrace", &enable_systrace_value)) {
    errors->SetName("enableSystrace");
    result->enable_systrace_ = Just(internal::FromValue<bool>::Parse(*enable_systrace_value, errors));
  }
  const base::Value* enable_argument_filter_value;
  if (object->Get("enableArgumentFilter", &enable_argument_filter_value)) {
    errors->SetName("enableArgumentFilter");
    result->enable_argument_filter_ = Just(internal::FromValue<bool>::Parse(*enable_argument_filter_value, errors));
  }
  const base::Value* included_categories_value;
  if (object->Get("includedCategories", &included_categories_value)) {
    errors->SetName("includedCategories");
    result->included_categories_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*included_categories_value, errors));
  }
  const base::Value* excluded_categories_value;
  if (object->Get("excludedCategories", &excluded_categories_value)) {
    errors->SetName("excludedCategories");
    result->excluded_categories_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*excluded_categories_value, errors));
  }
  const base::Value* synthetic_delays_value;
  if (object->Get("syntheticDelays", &synthetic_delays_value)) {
    errors->SetName("syntheticDelays");
    result->synthetic_delays_ = Just(internal::FromValue<std::vector<std::string>>::Parse(*synthetic_delays_value, errors));
  }
  const base::Value* memory_dump_config_value;
  if (object->Get("memoryDumpConfig", &memory_dump_config_value)) {
    errors->SetName("memoryDumpConfig");
    result->memory_dump_config_ = Just(internal::FromValue<headless::tracing::MemoryDumpConfig>::Parse(*memory_dump_config_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> TraceConfig::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (record_mode_.IsJust())
    result->Set("recordMode", internal::ToValue(record_mode_.FromJust()));
  if (enable_sampling_.IsJust())
    result->Set("enableSampling", internal::ToValue(enable_sampling_.FromJust()));
  if (enable_systrace_.IsJust())
    result->Set("enableSystrace", internal::ToValue(enable_systrace_.FromJust()));
  if (enable_argument_filter_.IsJust())
    result->Set("enableArgumentFilter", internal::ToValue(enable_argument_filter_.FromJust()));
  if (included_categories_.IsJust())
    result->Set("includedCategories", internal::ToValue(included_categories_.FromJust()));
  if (excluded_categories_.IsJust())
    result->Set("excludedCategories", internal::ToValue(excluded_categories_.FromJust()));
  if (synthetic_delays_.IsJust())
    result->Set("syntheticDelays", internal::ToValue(synthetic_delays_.FromJust()));
  if (memory_dump_config_.IsJust())
    result->Set("memoryDumpConfig", internal::ToValue(*memory_dump_config_.FromJust()));
  return std::move(result);
}

std::unique_ptr<TraceConfig> TraceConfig::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<TraceConfig> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<StartParams> StartParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("StartParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<StartParams> result(new StartParams());
  errors->Push();
  errors->SetName("StartParams");
  const base::Value* categories_value;
  if (object->Get("categories", &categories_value)) {
    errors->SetName("categories");
    result->categories_ = Just(internal::FromValue<std::string>::Parse(*categories_value, errors));
  }
  const base::Value* options_value;
  if (object->Get("options", &options_value)) {
    errors->SetName("options");
    result->options_ = Just(internal::FromValue<std::string>::Parse(*options_value, errors));
  }
  const base::Value* buffer_usage_reporting_interval_value;
  if (object->Get("bufferUsageReportingInterval", &buffer_usage_reporting_interval_value)) {
    errors->SetName("bufferUsageReportingInterval");
    result->buffer_usage_reporting_interval_ = Just(internal::FromValue<double>::Parse(*buffer_usage_reporting_interval_value, errors));
  }
  const base::Value* transfer_mode_value;
  if (object->Get("transferMode", &transfer_mode_value)) {
    errors->SetName("transferMode");
    result->transfer_mode_ = Just(internal::FromValue<headless::tracing::StartTransferMode>::Parse(*transfer_mode_value, errors));
  }
  const base::Value* trace_config_value;
  if (object->Get("traceConfig", &trace_config_value)) {
    errors->SetName("traceConfig");
    result->trace_config_ = Just(internal::FromValue<headless::tracing::TraceConfig>::Parse(*trace_config_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> StartParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (categories_.IsJust())
    result->Set("categories", internal::ToValue(categories_.FromJust()));
  if (options_.IsJust())
    result->Set("options", internal::ToValue(options_.FromJust()));
  if (buffer_usage_reporting_interval_.IsJust())
    result->Set("bufferUsageReportingInterval", internal::ToValue(buffer_usage_reporting_interval_.FromJust()));
  if (transfer_mode_.IsJust())
    result->Set("transferMode", internal::ToValue(transfer_mode_.FromJust()));
  if (trace_config_.IsJust())
    result->Set("traceConfig", internal::ToValue(*trace_config_.FromJust()));
  return std::move(result);
}

std::unique_ptr<StartParams> StartParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<StartParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCategoriesResult> GetCategoriesResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCategoriesResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCategoriesResult> result(new GetCategoriesResult());
  errors->Push();
  errors->SetName("GetCategoriesResult");
  const base::Value* categories_value;
  if (object->Get("categories", &categories_value)) {
    errors->SetName("categories");
    result->categories_ = internal::FromValue<std::vector<std::string>>::Parse(*categories_value, errors);
  } else {
    errors->AddError("required property missing: categories");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCategoriesResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("categories", internal::ToValue(categories_));
  return std::move(result);
}

std::unique_ptr<GetCategoriesResult> GetCategoriesResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCategoriesResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RequestMemoryDumpResult> RequestMemoryDumpResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RequestMemoryDumpResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RequestMemoryDumpResult> result(new RequestMemoryDumpResult());
  errors->Push();
  errors->SetName("RequestMemoryDumpResult");
  const base::Value* dump_guid_value;
  if (object->Get("dumpGuid", &dump_guid_value)) {
    errors->SetName("dumpGuid");
    result->dump_guid_ = internal::FromValue<std::string>::Parse(*dump_guid_value, errors);
  } else {
    errors->AddError("required property missing: dumpGuid");
  }
  const base::Value* success_value;
  if (object->Get("success", &success_value)) {
    errors->SetName("success");
    result->success_ = internal::FromValue<bool>::Parse(*success_value, errors);
  } else {
    errors->AddError("required property missing: success");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RequestMemoryDumpResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("dumpGuid", internal::ToValue(dump_guid_));
  result->Set("success", internal::ToValue(success_));
  return std::move(result);
}

std::unique_ptr<RequestMemoryDumpResult> RequestMemoryDumpResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RequestMemoryDumpResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<RecordClockSyncMarkerParams> RecordClockSyncMarkerParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("RecordClockSyncMarkerParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<RecordClockSyncMarkerParams> result(new RecordClockSyncMarkerParams());
  errors->Push();
  errors->SetName("RecordClockSyncMarkerParams");
  const base::Value* sync_id_value;
  if (object->Get("syncId", &sync_id_value)) {
    errors->SetName("syncId");
    result->sync_id_ = internal::FromValue<std::string>::Parse(*sync_id_value, errors);
  } else {
    errors->AddError("required property missing: syncId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> RecordClockSyncMarkerParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("syncId", internal::ToValue(sync_id_));
  return std::move(result);
}

std::unique_ptr<RecordClockSyncMarkerParams> RecordClockSyncMarkerParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<RecordClockSyncMarkerParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace tracing

namespace animation {

std::unique_ptr<Animation> Animation::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("Animation");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<Animation> result(new Animation());
  errors->Push();
  errors->SetName("Animation");
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<std::string>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* paused_state_value;
  if (object->Get("pausedState", &paused_state_value)) {
    errors->SetName("pausedState");
    result->paused_state_ = internal::FromValue<bool>::Parse(*paused_state_value, errors);
  } else {
    errors->AddError("required property missing: pausedState");
  }
  const base::Value* play_state_value;
  if (object->Get("playState", &play_state_value)) {
    errors->SetName("playState");
    result->play_state_ = internal::FromValue<std::string>::Parse(*play_state_value, errors);
  } else {
    errors->AddError("required property missing: playState");
  }
  const base::Value* playback_rate_value;
  if (object->Get("playbackRate", &playback_rate_value)) {
    errors->SetName("playbackRate");
    result->playback_rate_ = internal::FromValue<double>::Parse(*playback_rate_value, errors);
  } else {
    errors->AddError("required property missing: playbackRate");
  }
  const base::Value* start_time_value;
  if (object->Get("startTime", &start_time_value)) {
    errors->SetName("startTime");
    result->start_time_ = internal::FromValue<double>::Parse(*start_time_value, errors);
  } else {
    errors->AddError("required property missing: startTime");
  }
  const base::Value* current_time_value;
  if (object->Get("currentTime", &current_time_value)) {
    errors->SetName("currentTime");
    result->current_time_ = internal::FromValue<double>::Parse(*current_time_value, errors);
  } else {
    errors->AddError("required property missing: currentTime");
  }
  const base::Value* source_value;
  if (object->Get("source", &source_value)) {
    errors->SetName("source");
    result->source_ = internal::FromValue<headless::animation::AnimationEffect>::Parse(*source_value, errors);
  } else {
    errors->AddError("required property missing: source");
  }
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::animation::AnimationType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* css_id_value;
  if (object->Get("cssId", &css_id_value)) {
    errors->SetName("cssId");
    result->css_id_ = Just(internal::FromValue<std::string>::Parse(*css_id_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> Animation::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("id", internal::ToValue(id_));
  result->Set("name", internal::ToValue(name_));
  result->Set("pausedState", internal::ToValue(paused_state_));
  result->Set("playState", internal::ToValue(play_state_));
  result->Set("playbackRate", internal::ToValue(playback_rate_));
  result->Set("startTime", internal::ToValue(start_time_));
  result->Set("currentTime", internal::ToValue(current_time_));
  result->Set("source", internal::ToValue(*source_));
  result->Set("type", internal::ToValue(type_));
  if (css_id_.IsJust())
    result->Set("cssId", internal::ToValue(css_id_.FromJust()));
  return std::move(result);
}

std::unique_ptr<Animation> Animation::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<Animation> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AnimationEffect> AnimationEffect::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AnimationEffect");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AnimationEffect> result(new AnimationEffect());
  errors->Push();
  errors->SetName("AnimationEffect");
  const base::Value* delay_value;
  if (object->Get("delay", &delay_value)) {
    errors->SetName("delay");
    result->delay_ = internal::FromValue<double>::Parse(*delay_value, errors);
  } else {
    errors->AddError("required property missing: delay");
  }
  const base::Value* end_delay_value;
  if (object->Get("endDelay", &end_delay_value)) {
    errors->SetName("endDelay");
    result->end_delay_ = internal::FromValue<double>::Parse(*end_delay_value, errors);
  } else {
    errors->AddError("required property missing: endDelay");
  }
  const base::Value* playback_rate_value;
  if (object->Get("playbackRate", &playback_rate_value)) {
    errors->SetName("playbackRate");
    result->playback_rate_ = internal::FromValue<double>::Parse(*playback_rate_value, errors);
  } else {
    errors->AddError("required property missing: playbackRate");
  }
  const base::Value* iteration_start_value;
  if (object->Get("iterationStart", &iteration_start_value)) {
    errors->SetName("iterationStart");
    result->iteration_start_ = internal::FromValue<double>::Parse(*iteration_start_value, errors);
  } else {
    errors->AddError("required property missing: iterationStart");
  }
  const base::Value* iterations_value;
  if (object->Get("iterations", &iterations_value)) {
    errors->SetName("iterations");
    result->iterations_ = internal::FromValue<double>::Parse(*iterations_value, errors);
  } else {
    errors->AddError("required property missing: iterations");
  }
  const base::Value* duration_value;
  if (object->Get("duration", &duration_value)) {
    errors->SetName("duration");
    result->duration_ = internal::FromValue<double>::Parse(*duration_value, errors);
  } else {
    errors->AddError("required property missing: duration");
  }
  const base::Value* direction_value;
  if (object->Get("direction", &direction_value)) {
    errors->SetName("direction");
    result->direction_ = internal::FromValue<std::string>::Parse(*direction_value, errors);
  } else {
    errors->AddError("required property missing: direction");
  }
  const base::Value* fill_value;
  if (object->Get("fill", &fill_value)) {
    errors->SetName("fill");
    result->fill_ = internal::FromValue<std::string>::Parse(*fill_value, errors);
  } else {
    errors->AddError("required property missing: fill");
  }
  const base::Value* backend_node_id_value;
  if (object->Get("backendNodeId", &backend_node_id_value)) {
    errors->SetName("backendNodeId");
    result->backend_node_id_ = internal::FromValue<int>::Parse(*backend_node_id_value, errors);
  } else {
    errors->AddError("required property missing: backendNodeId");
  }
  const base::Value* keyframes_rule_value;
  if (object->Get("keyframesRule", &keyframes_rule_value)) {
    errors->SetName("keyframesRule");
    result->keyframes_rule_ = Just(internal::FromValue<headless::animation::KeyframesRule>::Parse(*keyframes_rule_value, errors));
  }
  const base::Value* easing_value;
  if (object->Get("easing", &easing_value)) {
    errors->SetName("easing");
    result->easing_ = internal::FromValue<std::string>::Parse(*easing_value, errors);
  } else {
    errors->AddError("required property missing: easing");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AnimationEffect::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("delay", internal::ToValue(delay_));
  result->Set("endDelay", internal::ToValue(end_delay_));
  result->Set("playbackRate", internal::ToValue(playback_rate_));
  result->Set("iterationStart", internal::ToValue(iteration_start_));
  result->Set("iterations", internal::ToValue(iterations_));
  result->Set("duration", internal::ToValue(duration_));
  result->Set("direction", internal::ToValue(direction_));
  result->Set("fill", internal::ToValue(fill_));
  result->Set("backendNodeId", internal::ToValue(backend_node_id_));
  if (keyframes_rule_.IsJust())
    result->Set("keyframesRule", internal::ToValue(*keyframes_rule_.FromJust()));
  result->Set("easing", internal::ToValue(easing_));
  return std::move(result);
}

std::unique_ptr<AnimationEffect> AnimationEffect::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AnimationEffect> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<KeyframesRule> KeyframesRule::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("KeyframesRule");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<KeyframesRule> result(new KeyframesRule());
  errors->Push();
  errors->SetName("KeyframesRule");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = Just(internal::FromValue<std::string>::Parse(*name_value, errors));
  }
  const base::Value* keyframes_value;
  if (object->Get("keyframes", &keyframes_value)) {
    errors->SetName("keyframes");
    result->keyframes_ = internal::FromValue<std::vector<std::unique_ptr<headless::animation::KeyframeStyle>>>::Parse(*keyframes_value, errors);
  } else {
    errors->AddError("required property missing: keyframes");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> KeyframesRule::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (name_.IsJust())
    result->Set("name", internal::ToValue(name_.FromJust()));
  result->Set("keyframes", internal::ToValue(keyframes_));
  return std::move(result);
}

std::unique_ptr<KeyframesRule> KeyframesRule::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<KeyframesRule> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<KeyframeStyle> KeyframeStyle::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("KeyframeStyle");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<KeyframeStyle> result(new KeyframeStyle());
  errors->Push();
  errors->SetName("KeyframeStyle");
  const base::Value* offset_value;
  if (object->Get("offset", &offset_value)) {
    errors->SetName("offset");
    result->offset_ = internal::FromValue<std::string>::Parse(*offset_value, errors);
  } else {
    errors->AddError("required property missing: offset");
  }
  const base::Value* easing_value;
  if (object->Get("easing", &easing_value)) {
    errors->SetName("easing");
    result->easing_ = internal::FromValue<std::string>::Parse(*easing_value, errors);
  } else {
    errors->AddError("required property missing: easing");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> KeyframeStyle::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("offset", internal::ToValue(offset_));
  result->Set("easing", internal::ToValue(easing_));
  return std::move(result);
}

std::unique_ptr<KeyframeStyle> KeyframeStyle::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<KeyframeStyle> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetPlaybackRateResult> GetPlaybackRateResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetPlaybackRateResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetPlaybackRateResult> result(new GetPlaybackRateResult());
  errors->Push();
  errors->SetName("GetPlaybackRateResult");
  const base::Value* playback_rate_value;
  if (object->Get("playbackRate", &playback_rate_value)) {
    errors->SetName("playbackRate");
    result->playback_rate_ = internal::FromValue<double>::Parse(*playback_rate_value, errors);
  } else {
    errors->AddError("required property missing: playbackRate");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetPlaybackRateResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("playbackRate", internal::ToValue(playback_rate_));
  return std::move(result);
}

std::unique_ptr<GetPlaybackRateResult> GetPlaybackRateResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetPlaybackRateResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetPlaybackRateParams> SetPlaybackRateParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetPlaybackRateParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetPlaybackRateParams> result(new SetPlaybackRateParams());
  errors->Push();
  errors->SetName("SetPlaybackRateParams");
  const base::Value* playback_rate_value;
  if (object->Get("playbackRate", &playback_rate_value)) {
    errors->SetName("playbackRate");
    result->playback_rate_ = internal::FromValue<double>::Parse(*playback_rate_value, errors);
  } else {
    errors->AddError("required property missing: playbackRate");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetPlaybackRateParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("playbackRate", internal::ToValue(playback_rate_));
  return std::move(result);
}

std::unique_ptr<SetPlaybackRateParams> SetPlaybackRateParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetPlaybackRateParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCurrentTimeParams> GetCurrentTimeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCurrentTimeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCurrentTimeParams> result(new GetCurrentTimeParams());
  errors->Push();
  errors->SetName("GetCurrentTimeParams");
  const base::Value* id_value;
  if (object->Get("id", &id_value)) {
    errors->SetName("id");
    result->id_ = internal::FromValue<std::string>::Parse(*id_value, errors);
  } else {
    errors->AddError("required property missing: id");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCurrentTimeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("id", internal::ToValue(id_));
  return std::move(result);
}

std::unique_ptr<GetCurrentTimeParams> GetCurrentTimeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCurrentTimeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetCurrentTimeResult> GetCurrentTimeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetCurrentTimeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetCurrentTimeResult> result(new GetCurrentTimeResult());
  errors->Push();
  errors->SetName("GetCurrentTimeResult");
  const base::Value* current_time_value;
  if (object->Get("currentTime", &current_time_value)) {
    errors->SetName("currentTime");
    result->current_time_ = internal::FromValue<double>::Parse(*current_time_value, errors);
  } else {
    errors->AddError("required property missing: currentTime");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetCurrentTimeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("currentTime", internal::ToValue(current_time_));
  return std::move(result);
}

std::unique_ptr<GetCurrentTimeResult> GetCurrentTimeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetCurrentTimeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetPausedParams> SetPausedParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetPausedParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetPausedParams> result(new SetPausedParams());
  errors->Push();
  errors->SetName("SetPausedParams");
  const base::Value* animations_value;
  if (object->Get("animations", &animations_value)) {
    errors->SetName("animations");
    result->animations_ = internal::FromValue<std::vector<std::string>>::Parse(*animations_value, errors);
  } else {
    errors->AddError("required property missing: animations");
  }
  const base::Value* paused_value;
  if (object->Get("paused", &paused_value)) {
    errors->SetName("paused");
    result->paused_ = internal::FromValue<bool>::Parse(*paused_value, errors);
  } else {
    errors->AddError("required property missing: paused");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetPausedParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("animations", internal::ToValue(animations_));
  result->Set("paused", internal::ToValue(paused_));
  return std::move(result);
}

std::unique_ptr<SetPausedParams> SetPausedParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetPausedParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SetTimingParams> SetTimingParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SetTimingParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SetTimingParams> result(new SetTimingParams());
  errors->Push();
  errors->SetName("SetTimingParams");
  const base::Value* animation_id_value;
  if (object->Get("animationId", &animation_id_value)) {
    errors->SetName("animationId");
    result->animation_id_ = internal::FromValue<std::string>::Parse(*animation_id_value, errors);
  } else {
    errors->AddError("required property missing: animationId");
  }
  const base::Value* duration_value;
  if (object->Get("duration", &duration_value)) {
    errors->SetName("duration");
    result->duration_ = internal::FromValue<double>::Parse(*duration_value, errors);
  } else {
    errors->AddError("required property missing: duration");
  }
  const base::Value* delay_value;
  if (object->Get("delay", &delay_value)) {
    errors->SetName("delay");
    result->delay_ = internal::FromValue<double>::Parse(*delay_value, errors);
  } else {
    errors->AddError("required property missing: delay");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SetTimingParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("animationId", internal::ToValue(animation_id_));
  result->Set("duration", internal::ToValue(duration_));
  result->Set("delay", internal::ToValue(delay_));
  return std::move(result);
}

std::unique_ptr<SetTimingParams> SetTimingParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SetTimingParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<SeekAnimationsParams> SeekAnimationsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("SeekAnimationsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<SeekAnimationsParams> result(new SeekAnimationsParams());
  errors->Push();
  errors->SetName("SeekAnimationsParams");
  const base::Value* animations_value;
  if (object->Get("animations", &animations_value)) {
    errors->SetName("animations");
    result->animations_ = internal::FromValue<std::vector<std::string>>::Parse(*animations_value, errors);
  } else {
    errors->AddError("required property missing: animations");
  }
  const base::Value* current_time_value;
  if (object->Get("currentTime", &current_time_value)) {
    errors->SetName("currentTime");
    result->current_time_ = internal::FromValue<double>::Parse(*current_time_value, errors);
  } else {
    errors->AddError("required property missing: currentTime");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> SeekAnimationsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("animations", internal::ToValue(animations_));
  result->Set("currentTime", internal::ToValue(current_time_));
  return std::move(result);
}

std::unique_ptr<SeekAnimationsParams> SeekAnimationsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<SeekAnimationsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ReleaseAnimationsParams> ReleaseAnimationsParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ReleaseAnimationsParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ReleaseAnimationsParams> result(new ReleaseAnimationsParams());
  errors->Push();
  errors->SetName("ReleaseAnimationsParams");
  const base::Value* animations_value;
  if (object->Get("animations", &animations_value)) {
    errors->SetName("animations");
    result->animations_ = internal::FromValue<std::vector<std::string>>::Parse(*animations_value, errors);
  } else {
    errors->AddError("required property missing: animations");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ReleaseAnimationsParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("animations", internal::ToValue(animations_));
  return std::move(result);
}

std::unique_ptr<ReleaseAnimationsParams> ReleaseAnimationsParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ReleaseAnimationsParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ResolveAnimationParams> ResolveAnimationParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ResolveAnimationParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ResolveAnimationParams> result(new ResolveAnimationParams());
  errors->Push();
  errors->SetName("ResolveAnimationParams");
  const base::Value* animation_id_value;
  if (object->Get("animationId", &animation_id_value)) {
    errors->SetName("animationId");
    result->animation_id_ = internal::FromValue<std::string>::Parse(*animation_id_value, errors);
  } else {
    errors->AddError("required property missing: animationId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ResolveAnimationParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("animationId", internal::ToValue(animation_id_));
  return std::move(result);
}

std::unique_ptr<ResolveAnimationParams> ResolveAnimationParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ResolveAnimationParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<ResolveAnimationResult> ResolveAnimationResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("ResolveAnimationResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<ResolveAnimationResult> result(new ResolveAnimationResult());
  errors->Push();
  errors->SetName("ResolveAnimationResult");
  const base::Value* remote_object_value;
  if (object->Get("remoteObject", &remote_object_value)) {
    errors->SetName("remoteObject");
    result->remote_object_ = internal::FromValue<headless::runtime::RemoteObject>::Parse(*remote_object_value, errors);
  } else {
    errors->AddError("required property missing: remoteObject");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> ResolveAnimationResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("remoteObject", internal::ToValue(*remote_object_));
  return std::move(result);
}

std::unique_ptr<ResolveAnimationResult> ResolveAnimationResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<ResolveAnimationResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace animation

namespace accessibility {

std::unique_ptr<AXValueSource> AXValueSource::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AXValueSource");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AXValueSource> result(new AXValueSource());
  errors->Push();
  errors->SetName("AXValueSource");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::accessibility::AXValueSourceType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<headless::accessibility::AXValue>::Parse(*value_value, errors));
  }
  const base::Value* attribute_value;
  if (object->Get("attribute", &attribute_value)) {
    errors->SetName("attribute");
    result->attribute_ = Just(internal::FromValue<std::string>::Parse(*attribute_value, errors));
  }
  const base::Value* attribute_value_value;
  if (object->Get("attributeValue", &attribute_value_value)) {
    errors->SetName("attributeValue");
    result->attribute_value_ = Just(internal::FromValue<headless::accessibility::AXValue>::Parse(*attribute_value_value, errors));
  }
  const base::Value* superseded_value;
  if (object->Get("superseded", &superseded_value)) {
    errors->SetName("superseded");
    result->superseded_ = Just(internal::FromValue<bool>::Parse(*superseded_value, errors));
  }
  const base::Value* native_source_value;
  if (object->Get("nativeSource", &native_source_value)) {
    errors->SetName("nativeSource");
    result->native_source_ = Just(internal::FromValue<headless::accessibility::AXValueNativeSourceType>::Parse(*native_source_value, errors));
  }
  const base::Value* native_source_value_value;
  if (object->Get("nativeSourceValue", &native_source_value_value)) {
    errors->SetName("nativeSourceValue");
    result->native_source_value_ = Just(internal::FromValue<headless::accessibility::AXValue>::Parse(*native_source_value_value, errors));
  }
  const base::Value* invalid_value;
  if (object->Get("invalid", &invalid_value)) {
    errors->SetName("invalid");
    result->invalid_ = Just(internal::FromValue<bool>::Parse(*invalid_value, errors));
  }
  const base::Value* invalid_reason_value;
  if (object->Get("invalidReason", &invalid_reason_value)) {
    errors->SetName("invalidReason");
    result->invalid_reason_ = Just(internal::FromValue<std::string>::Parse(*invalid_reason_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AXValueSource::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(*value_.FromJust()));
  if (attribute_.IsJust())
    result->Set("attribute", internal::ToValue(attribute_.FromJust()));
  if (attribute_value_.IsJust())
    result->Set("attributeValue", internal::ToValue(*attribute_value_.FromJust()));
  if (superseded_.IsJust())
    result->Set("superseded", internal::ToValue(superseded_.FromJust()));
  if (native_source_.IsJust())
    result->Set("nativeSource", internal::ToValue(native_source_.FromJust()));
  if (native_source_value_.IsJust())
    result->Set("nativeSourceValue", internal::ToValue(*native_source_value_.FromJust()));
  if (invalid_.IsJust())
    result->Set("invalid", internal::ToValue(invalid_.FromJust()));
  if (invalid_reason_.IsJust())
    result->Set("invalidReason", internal::ToValue(invalid_reason_.FromJust()));
  return std::move(result);
}

std::unique_ptr<AXValueSource> AXValueSource::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AXValueSource> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AXRelatedNode> AXRelatedNode::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AXRelatedNode");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AXRelatedNode> result(new AXRelatedNode());
  errors->Push();
  errors->SetName("AXRelatedNode");
  const base::Value* backend_node_id_value;
  if (object->Get("backendNodeId", &backend_node_id_value)) {
    errors->SetName("backendNodeId");
    result->backend_node_id_ = internal::FromValue<int>::Parse(*backend_node_id_value, errors);
  } else {
    errors->AddError("required property missing: backendNodeId");
  }
  const base::Value* idref_value;
  if (object->Get("idref", &idref_value)) {
    errors->SetName("idref");
    result->idref_ = Just(internal::FromValue<std::string>::Parse(*idref_value, errors));
  }
  const base::Value* text_value;
  if (object->Get("text", &text_value)) {
    errors->SetName("text");
    result->text_ = Just(internal::FromValue<std::string>::Parse(*text_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AXRelatedNode::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("backendNodeId", internal::ToValue(backend_node_id_));
  if (idref_.IsJust())
    result->Set("idref", internal::ToValue(idref_.FromJust()));
  if (text_.IsJust())
    result->Set("text", internal::ToValue(text_.FromJust()));
  return std::move(result);
}

std::unique_ptr<AXRelatedNode> AXRelatedNode::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AXRelatedNode> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AXProperty> AXProperty::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AXProperty");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AXProperty> result(new AXProperty());
  errors->Push();
  errors->SetName("AXProperty");
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = internal::FromValue<std::string>::Parse(*name_value, errors);
  } else {
    errors->AddError("required property missing: name");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = internal::FromValue<headless::accessibility::AXValue>::Parse(*value_value, errors);
  } else {
    errors->AddError("required property missing: value");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AXProperty::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("name", internal::ToValue(name_));
  result->Set("value", internal::ToValue(*value_));
  return std::move(result);
}

std::unique_ptr<AXProperty> AXProperty::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AXProperty> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AXValue> AXValue::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AXValue");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AXValue> result(new AXValue());
  errors->Push();
  errors->SetName("AXValue");
  const base::Value* type_value;
  if (object->Get("type", &type_value)) {
    errors->SetName("type");
    result->type_ = internal::FromValue<headless::accessibility::AXValueType>::Parse(*type_value, errors);
  } else {
    errors->AddError("required property missing: type");
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<base::Value>::Parse(*value_value, errors));
  }
  const base::Value* related_nodes_value;
  if (object->Get("relatedNodes", &related_nodes_value)) {
    errors->SetName("relatedNodes");
    result->related_nodes_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::accessibility::AXRelatedNode>>>::Parse(*related_nodes_value, errors));
  }
  const base::Value* sources_value;
  if (object->Get("sources", &sources_value)) {
    errors->SetName("sources");
    result->sources_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::accessibility::AXValueSource>>>::Parse(*sources_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AXValue::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("type", internal::ToValue(type_));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(*value_.FromJust()));
  if (related_nodes_.IsJust())
    result->Set("relatedNodes", internal::ToValue(related_nodes_.FromJust()));
  if (sources_.IsJust())
    result->Set("sources", internal::ToValue(sources_.FromJust()));
  return std::move(result);
}

std::unique_ptr<AXValue> AXValue::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AXValue> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<AXNode> AXNode::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("AXNode");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<AXNode> result(new AXNode());
  errors->Push();
  errors->SetName("AXNode");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<std::string>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  const base::Value* ignored_value;
  if (object->Get("ignored", &ignored_value)) {
    errors->SetName("ignored");
    result->ignored_ = internal::FromValue<bool>::Parse(*ignored_value, errors);
  } else {
    errors->AddError("required property missing: ignored");
  }
  const base::Value* ignored_reasons_value;
  if (object->Get("ignoredReasons", &ignored_reasons_value)) {
    errors->SetName("ignoredReasons");
    result->ignored_reasons_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::accessibility::AXProperty>>>::Parse(*ignored_reasons_value, errors));
  }
  const base::Value* role_value;
  if (object->Get("role", &role_value)) {
    errors->SetName("role");
    result->role_ = Just(internal::FromValue<headless::accessibility::AXValue>::Parse(*role_value, errors));
  }
  const base::Value* name_value;
  if (object->Get("name", &name_value)) {
    errors->SetName("name");
    result->name_ = Just(internal::FromValue<headless::accessibility::AXValue>::Parse(*name_value, errors));
  }
  const base::Value* description_value;
  if (object->Get("description", &description_value)) {
    errors->SetName("description");
    result->description_ = Just(internal::FromValue<headless::accessibility::AXValue>::Parse(*description_value, errors));
  }
  const base::Value* value_value;
  if (object->Get("value", &value_value)) {
    errors->SetName("value");
    result->value_ = Just(internal::FromValue<headless::accessibility::AXValue>::Parse(*value_value, errors));
  }
  const base::Value* properties_value;
  if (object->Get("properties", &properties_value)) {
    errors->SetName("properties");
    result->properties_ = Just(internal::FromValue<std::vector<std::unique_ptr<headless::accessibility::AXProperty>>>::Parse(*properties_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> AXNode::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  result->Set("ignored", internal::ToValue(ignored_));
  if (ignored_reasons_.IsJust())
    result->Set("ignoredReasons", internal::ToValue(ignored_reasons_.FromJust()));
  if (role_.IsJust())
    result->Set("role", internal::ToValue(*role_.FromJust()));
  if (name_.IsJust())
    result->Set("name", internal::ToValue(*name_.FromJust()));
  if (description_.IsJust())
    result->Set("description", internal::ToValue(*description_.FromJust()));
  if (value_.IsJust())
    result->Set("value", internal::ToValue(*value_.FromJust()));
  if (properties_.IsJust())
    result->Set("properties", internal::ToValue(properties_.FromJust()));
  return std::move(result);
}

std::unique_ptr<AXNode> AXNode::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<AXNode> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetAXNodeParams> GetAXNodeParams::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetAXNodeParams");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetAXNodeParams> result(new GetAXNodeParams());
  errors->Push();
  errors->SetName("GetAXNodeParams");
  const base::Value* node_id_value;
  if (object->Get("nodeId", &node_id_value)) {
    errors->SetName("nodeId");
    result->node_id_ = internal::FromValue<int>::Parse(*node_id_value, errors);
  } else {
    errors->AddError("required property missing: nodeId");
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetAXNodeParams::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  result->Set("nodeId", internal::ToValue(node_id_));
  return std::move(result);
}

std::unique_ptr<GetAXNodeParams> GetAXNodeParams::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetAXNodeParams> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}


std::unique_ptr<GetAXNodeResult> GetAXNodeResult::Parse(const base::Value& value, ErrorReporter* errors) {
  errors->Push();
  errors->SetName("GetAXNodeResult");
  const base::DictionaryValue* object;
  if (!value.GetAsDictionary(&object)) {
    errors->AddError("object expected");
    errors->Pop();
    return nullptr;
  }

  std::unique_ptr<GetAXNodeResult> result(new GetAXNodeResult());
  errors->Push();
  errors->SetName("GetAXNodeResult");
  const base::Value* accessibility_node_value;
  if (object->Get("accessibilityNode", &accessibility_node_value)) {
    errors->SetName("accessibilityNode");
    result->accessibility_node_ = Just(internal::FromValue<headless::accessibility::AXNode>::Parse(*accessibility_node_value, errors));
  }
  errors->Pop();
  errors->Pop();
  if (errors->HasErrors())
    return nullptr;
  return result;
}

std::unique_ptr<base::Value> GetAXNodeResult::Serialize() const {
  std::unique_ptr<base::DictionaryValue> result(new base::DictionaryValue());
  if (accessibility_node_.IsJust())
    result->Set("accessibilityNode", internal::ToValue(*accessibility_node_.FromJust()));
  return std::move(result);
}

std::unique_ptr<GetAXNodeResult> GetAXNodeResult::Clone() const {
  ErrorReporter errors;
  std::unique_ptr<GetAXNodeResult> result = Parse(*Serialize(), &errors);
  DCHECK(!errors.HasErrors());
  return result;
}

}  // namespace accessibility

} // namespace headless
