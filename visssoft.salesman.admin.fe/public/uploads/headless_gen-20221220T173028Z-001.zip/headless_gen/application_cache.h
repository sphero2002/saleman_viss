// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_APPLICATION_CACHE_H_
#define HEADLESS_PUBLIC_DOMAINS_APPLICATION_CACHE_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace application_cache {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Returns array of frame identifiers with manifest urls for each frame containing a document associated with some application cache.
  void GetFramesWithManifests(base::Callback<void(std::unique_ptr<GetFramesWithManifestsResult>)> callback = base::Callback<void(std::unique_ptr<GetFramesWithManifestsResult>)>());
  // Enables application cache domain notifications.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Returns manifest URL for document in the given frame.
  void GetManifestForFrame(std::unique_ptr<GetManifestForFrameParams> params, base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)> callback = base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)>());
  void GetManifestForFrame(std::string frameId, base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)> callback = base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)>());
  // Returns relevant application cache data for the document in given frame.
  void GetApplicationCacheForFrame(std::unique_ptr<GetApplicationCacheForFrameParams> params, base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)> callback = base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)>());
  void GetApplicationCacheForFrame(std::string frameId, base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)> callback = base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)>());
 private:
  static void HandleGetFramesWithManifestsResponse(base::Callback<void(std::unique_ptr<GetFramesWithManifestsResult>)> callback, const base::Value& response);
  static void HandleGetManifestForFrameResponse(base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)> callback, const base::Value& response);
  static void HandleGetApplicationCacheForFrameResponse(base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace application_cache
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_APPLICATION_CACHE_H_
