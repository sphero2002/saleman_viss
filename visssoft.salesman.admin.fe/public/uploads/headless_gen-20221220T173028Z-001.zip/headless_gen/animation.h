// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_ANIMATION_H_
#define HEADLESS_PUBLIC_DOMAINS_ANIMATION_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace animation {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables animation domain notifications.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables animation domain notifications.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Gets the playback rate of the document timeline.
  void GetPlaybackRate(base::Callback<void(std::unique_ptr<GetPlaybackRateResult>)> callback = base::Callback<void(std::unique_ptr<GetPlaybackRateResult>)>());
  // Sets the playback rate of the document timeline.
  void SetPlaybackRate(std::unique_ptr<SetPlaybackRateParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetPlaybackRate(double playbackRate, base::Callback<void()> callback = base::Callback<void()>());
  // Returns the current time of the an animation.
  void GetCurrentTime(std::unique_ptr<GetCurrentTimeParams> params, base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)> callback = base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)>());
  void GetCurrentTime(std::string id, base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)> callback = base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)>());
  // Sets the paused state of a set of animations.
  void SetPaused(std::unique_ptr<SetPausedParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetPaused(std::vector<std::string> animations, bool paused, base::Callback<void()> callback = base::Callback<void()>());
  // Sets the timing of an animation node.
  void SetTiming(std::unique_ptr<SetTimingParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetTiming(std::string animationId, double duration, double delay, base::Callback<void()> callback = base::Callback<void()>());
  // Seek a set of animations to a particular time within each animation.
  void SeekAnimations(std::unique_ptr<SeekAnimationsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SeekAnimations(std::vector<std::string> animations, double currentTime, base::Callback<void()> callback = base::Callback<void()>());
  // Releases a set of animations to no longer be manipulated.
  void ReleaseAnimations(std::unique_ptr<ReleaseAnimationsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ReleaseAnimations(std::vector<std::string> animations, base::Callback<void()> callback = base::Callback<void()>());
  // Gets the remote object of the Animation.
  void ResolveAnimation(std::unique_ptr<ResolveAnimationParams> params, base::Callback<void(std::unique_ptr<ResolveAnimationResult>)> callback = base::Callback<void(std::unique_ptr<ResolveAnimationResult>)>());
  void ResolveAnimation(std::string animationId, base::Callback<void(std::unique_ptr<ResolveAnimationResult>)> callback = base::Callback<void(std::unique_ptr<ResolveAnimationResult>)>());
 private:
  static void HandleGetPlaybackRateResponse(base::Callback<void(std::unique_ptr<GetPlaybackRateResult>)> callback, const base::Value& response);
  static void HandleGetCurrentTimeResponse(base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)> callback, const base::Value& response);
  static void HandleResolveAnimationResponse(base::Callback<void(std::unique_ptr<ResolveAnimationResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace animation
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_ANIMATION_H_
