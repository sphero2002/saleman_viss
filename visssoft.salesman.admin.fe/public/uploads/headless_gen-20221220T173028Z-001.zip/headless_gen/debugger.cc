// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/debugger.h"

#include "base/bind.h"

namespace headless {

namespace debugger {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.disable", std::move(callback));
}

void Domain::SetBreakpointsActive(std::unique_ptr<SetBreakpointsActiveParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.setBreakpointsActive", params->Serialize(), std::move(callback));
}

void Domain::SetSkipAllPauses(std::unique_ptr<SetSkipAllPausesParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.setSkipAllPauses", params->Serialize(), std::move(callback));
}

void Domain::SetBreakpointByUrl(std::unique_ptr<SetBreakpointByUrlParams> params, base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)> callback) {
  dispatcher_->SendMessage("Debugger.setBreakpointByUrl", params->Serialize(), base::Bind(&Domain::HandleSetBreakpointByUrlResponse, callback));
}

void Domain::SetBreakpoint(std::unique_ptr<SetBreakpointParams> params, base::Callback<void(std::unique_ptr<SetBreakpointResult>)> callback) {
  dispatcher_->SendMessage("Debugger.setBreakpoint", params->Serialize(), base::Bind(&Domain::HandleSetBreakpointResponse, callback));
}

void Domain::RemoveBreakpoint(std::unique_ptr<RemoveBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.removeBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::ContinueToLocation(std::unique_ptr<ContinueToLocationParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.continueToLocation", params->Serialize(), std::move(callback));
}

void Domain::StepOver(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.stepOver", std::move(callback));
}

void Domain::StepInto(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.stepInto", std::move(callback));
}

void Domain::StepOut(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.stepOut", std::move(callback));
}

void Domain::Pause(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.pause", std::move(callback));
}

void Domain::Resume(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.resume", std::move(callback));
}

void Domain::SearchInContent(std::unique_ptr<SearchInContentParams> params, base::Callback<void(std::unique_ptr<SearchInContentResult>)> callback) {
  dispatcher_->SendMessage("Debugger.searchInContent", params->Serialize(), base::Bind(&Domain::HandleSearchInContentResponse, callback));
}

void Domain::CanSetScriptSource(base::Callback<void(std::unique_ptr<CanSetScriptSourceResult>)> callback) {
  dispatcher_->SendMessage("Debugger.canSetScriptSource", base::Bind(&Domain::HandleCanSetScriptSourceResponse, callback));
}

void Domain::SetScriptSource(std::unique_ptr<SetScriptSourceParams> params, base::Callback<void(std::unique_ptr<SetScriptSourceResult>)> callback) {
  dispatcher_->SendMessage("Debugger.setScriptSource", params->Serialize(), base::Bind(&Domain::HandleSetScriptSourceResponse, callback));
}

void Domain::RestartFrame(std::unique_ptr<RestartFrameParams> params, base::Callback<void(std::unique_ptr<RestartFrameResult>)> callback) {
  dispatcher_->SendMessage("Debugger.restartFrame", params->Serialize(), base::Bind(&Domain::HandleRestartFrameResponse, callback));
}

void Domain::GetScriptSource(std::unique_ptr<GetScriptSourceParams> params, base::Callback<void(std::unique_ptr<GetScriptSourceResult>)> callback) {
  dispatcher_->SendMessage("Debugger.getScriptSource", params->Serialize(), base::Bind(&Domain::HandleGetScriptSourceResponse, callback));
}

void Domain::GetFunctionDetails(std::unique_ptr<GetFunctionDetailsParams> params, base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)> callback) {
  dispatcher_->SendMessage("Debugger.getFunctionDetails", params->Serialize(), base::Bind(&Domain::HandleGetFunctionDetailsResponse, callback));
}

void Domain::GetGeneratorObjectDetails(std::unique_ptr<GetGeneratorObjectDetailsParams> params, base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)> callback) {
  dispatcher_->SendMessage("Debugger.getGeneratorObjectDetails", params->Serialize(), base::Bind(&Domain::HandleGetGeneratorObjectDetailsResponse, callback));
}

void Domain::GetCollectionEntries(std::unique_ptr<GetCollectionEntriesParams> params, base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)> callback) {
  dispatcher_->SendMessage("Debugger.getCollectionEntries", params->Serialize(), base::Bind(&Domain::HandleGetCollectionEntriesResponse, callback));
}

void Domain::SetPauseOnExceptions(std::unique_ptr<SetPauseOnExceptionsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.setPauseOnExceptions", params->Serialize(), std::move(callback));
}

void Domain::EvaluateOnCallFrame(std::unique_ptr<EvaluateOnCallFrameParams> params, base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)> callback) {
  dispatcher_->SendMessage("Debugger.evaluateOnCallFrame", params->Serialize(), base::Bind(&Domain::HandleEvaluateOnCallFrameResponse, callback));
}

void Domain::SetVariableValue(std::unique_ptr<SetVariableValueParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.setVariableValue", params->Serialize(), std::move(callback));
}

void Domain::GetBacktrace(base::Callback<void(std::unique_ptr<GetBacktraceResult>)> callback) {
  dispatcher_->SendMessage("Debugger.getBacktrace", base::Bind(&Domain::HandleGetBacktraceResponse, callback));
}

void Domain::SetAsyncCallStackDepth(std::unique_ptr<SetAsyncCallStackDepthParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.setAsyncCallStackDepth", params->Serialize(), std::move(callback));
}

void Domain::SetBlackboxedRanges(std::unique_ptr<SetBlackboxedRangesParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Debugger.setBlackboxedRanges", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleSetBreakpointByUrlResponse(base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetBreakpointByUrlResult> result = SetBreakpointByUrlResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetBreakpointResponse(base::Callback<void(std::unique_ptr<SetBreakpointResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetBreakpointResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetBreakpointResult> result = SetBreakpointResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSearchInContentResponse(base::Callback<void(std::unique_ptr<SearchInContentResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SearchInContentResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SearchInContentResult> result = SearchInContentResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCanSetScriptSourceResponse(base::Callback<void(std::unique_ptr<CanSetScriptSourceResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CanSetScriptSourceResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CanSetScriptSourceResult> result = CanSetScriptSourceResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetScriptSourceResponse(base::Callback<void(std::unique_ptr<SetScriptSourceResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetScriptSourceResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetScriptSourceResult> result = SetScriptSourceResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleRestartFrameResponse(base::Callback<void(std::unique_ptr<RestartFrameResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RestartFrameResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RestartFrameResult> result = RestartFrameResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetScriptSourceResponse(base::Callback<void(std::unique_ptr<GetScriptSourceResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetScriptSourceResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetScriptSourceResult> result = GetScriptSourceResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetFunctionDetailsResponse(base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetFunctionDetailsResult> result = GetFunctionDetailsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetGeneratorObjectDetailsResponse(base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetGeneratorObjectDetailsResult> result = GetGeneratorObjectDetailsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetCollectionEntriesResponse(base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetCollectionEntriesResult> result = GetCollectionEntriesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleEvaluateOnCallFrameResponse(base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<EvaluateOnCallFrameResult> result = EvaluateOnCallFrameResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetBacktraceResponse(base::Callback<void(std::unique_ptr<GetBacktraceResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetBacktraceResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetBacktraceResult> result = GetBacktraceResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace debugger

} // namespace headless
