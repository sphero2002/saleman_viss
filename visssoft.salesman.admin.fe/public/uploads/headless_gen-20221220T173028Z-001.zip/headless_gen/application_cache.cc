// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/application_cache.h"

#include "base/bind.h"

namespace headless {

namespace application_cache {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::GetFramesWithManifests(base::Callback<void(std::unique_ptr<GetFramesWithManifestsResult>)> callback) {
  dispatcher_->SendMessage("ApplicationCache.getFramesWithManifests", base::Bind(&Domain::HandleGetFramesWithManifestsResponse, callback));
}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("ApplicationCache.enable", std::move(callback));
}

void Domain::GetManifestForFrame(std::unique_ptr<GetManifestForFrameParams> params, base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)> callback) {
  dispatcher_->SendMessage("ApplicationCache.getManifestForFrame", params->Serialize(), base::Bind(&Domain::HandleGetManifestForFrameResponse, callback));
}

void Domain::GetApplicationCacheForFrame(std::unique_ptr<GetApplicationCacheForFrameParams> params, base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)> callback) {
  dispatcher_->SendMessage("ApplicationCache.getApplicationCacheForFrame", params->Serialize(), base::Bind(&Domain::HandleGetApplicationCacheForFrameResponse, callback));
}


// static
void Domain::HandleGetFramesWithManifestsResponse(base::Callback<void(std::unique_ptr<GetFramesWithManifestsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetFramesWithManifestsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetFramesWithManifestsResult> result = GetFramesWithManifestsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetManifestForFrameResponse(base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetManifestForFrameResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetManifestForFrameResult> result = GetManifestForFrameResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetApplicationCacheForFrameResponse(base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetApplicationCacheForFrameResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetApplicationCacheForFrameResult> result = GetApplicationCacheForFrameResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace application_cache

} // namespace headless
