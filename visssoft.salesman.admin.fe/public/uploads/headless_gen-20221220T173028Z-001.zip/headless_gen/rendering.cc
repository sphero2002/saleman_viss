// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/rendering.h"

#include "base/bind.h"

namespace headless {

namespace rendering {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::SetShowPaintRects(std::unique_ptr<SetShowPaintRectsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Rendering.setShowPaintRects", params->Serialize(), std::move(callback));
}

void Domain::SetShowDebugBorders(std::unique_ptr<SetShowDebugBordersParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Rendering.setShowDebugBorders", params->Serialize(), std::move(callback));
}

void Domain::SetShowFPSCounter(std::unique_ptr<SetShowFPSCounterParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Rendering.setShowFPSCounter", params->Serialize(), std::move(callback));
}

void Domain::SetShowScrollBottleneckRects(std::unique_ptr<SetShowScrollBottleneckRectsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Rendering.setShowScrollBottleneckRects", params->Serialize(), std::move(callback));
}

void Domain::SetShowViewportSizeOnResize(std::unique_ptr<SetShowViewportSizeOnResizeParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Rendering.setShowViewportSizeOnResize", params->Serialize(), std::move(callback));
}


}  // namespace rendering

} // namespace headless
