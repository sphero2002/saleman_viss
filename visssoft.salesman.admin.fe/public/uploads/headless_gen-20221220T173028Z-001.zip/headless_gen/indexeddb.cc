// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/indexeddb.h"

#include "base/bind.h"

namespace headless {

namespace indexeddb {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("IndexedDB.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("IndexedDB.disable", std::move(callback));
}

void Domain::RequestDatabaseNames(std::unique_ptr<RequestDatabaseNamesParams> params, base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)> callback) {
  dispatcher_->SendMessage("IndexedDB.requestDatabaseNames", params->Serialize(), base::Bind(&Domain::HandleRequestDatabaseNamesResponse, callback));
}

void Domain::RequestDatabase(std::unique_ptr<RequestDatabaseParams> params, base::Callback<void(std::unique_ptr<RequestDatabaseResult>)> callback) {
  dispatcher_->SendMessage("IndexedDB.requestDatabase", params->Serialize(), base::Bind(&Domain::HandleRequestDatabaseResponse, callback));
}

void Domain::RequestData(std::unique_ptr<RequestDataParams> params, base::Callback<void(std::unique_ptr<RequestDataResult>)> callback) {
  dispatcher_->SendMessage("IndexedDB.requestData", params->Serialize(), base::Bind(&Domain::HandleRequestDataResponse, callback));
}

void Domain::ClearObjectStore(std::unique_ptr<ClearObjectStoreParams> params, base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)> callback) {
  dispatcher_->SendMessage("IndexedDB.clearObjectStore", params->Serialize(), base::Bind(&Domain::HandleClearObjectStoreResponse, callback));
}


// static
void Domain::HandleRequestDatabaseNamesResponse(base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RequestDatabaseNamesResult> result = RequestDatabaseNamesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleRequestDatabaseResponse(base::Callback<void(std::unique_ptr<RequestDatabaseResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RequestDatabaseResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RequestDatabaseResult> result = RequestDatabaseResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleRequestDataResponse(base::Callback<void(std::unique_ptr<RequestDataResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RequestDataResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RequestDataResult> result = RequestDataResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleClearObjectStoreResponse(base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<ClearObjectStoreResult> result = ClearObjectStoreResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace indexeddb

} // namespace headless
