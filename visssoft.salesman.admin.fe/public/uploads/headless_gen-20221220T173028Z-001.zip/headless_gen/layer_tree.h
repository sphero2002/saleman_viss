// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_LAYER_TREE_H_
#define HEADLESS_PUBLIC_DOMAINS_LAYER_TREE_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace layer_tree {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables compositing tree inspection.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables compositing tree inspection.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Provides the reasons why the given layer was composited.
  void CompositingReasons(std::unique_ptr<CompositingReasonsParams> params, base::Callback<void(std::unique_ptr<CompositingReasonsResult>)> callback = base::Callback<void(std::unique_ptr<CompositingReasonsResult>)>());
  void CompositingReasons(std::string layerId, base::Callback<void(std::unique_ptr<CompositingReasonsResult>)> callback = base::Callback<void(std::unique_ptr<CompositingReasonsResult>)>());
  // Returns the layer snapshot identifier.
  void MakeSnapshot(std::unique_ptr<MakeSnapshotParams> params, base::Callback<void(std::unique_ptr<MakeSnapshotResult>)> callback = base::Callback<void(std::unique_ptr<MakeSnapshotResult>)>());
  void MakeSnapshot(std::string layerId, base::Callback<void(std::unique_ptr<MakeSnapshotResult>)> callback = base::Callback<void(std::unique_ptr<MakeSnapshotResult>)>());
  // Returns the snapshot identifier.
  void LoadSnapshot(std::unique_ptr<LoadSnapshotParams> params, base::Callback<void(std::unique_ptr<LoadSnapshotResult>)> callback = base::Callback<void(std::unique_ptr<LoadSnapshotResult>)>());
  void LoadSnapshot(std::vector<std::unique_ptr<headless::layer_tree::PictureTile>> tiles, base::Callback<void(std::unique_ptr<LoadSnapshotResult>)> callback = base::Callback<void(std::unique_ptr<LoadSnapshotResult>)>());
  // Releases layer snapshot captured by the back-end.
  void ReleaseSnapshot(std::unique_ptr<ReleaseSnapshotParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ReleaseSnapshot(std::string snapshotId, base::Callback<void()> callback = base::Callback<void()>());
  void ProfileSnapshot(std::unique_ptr<ProfileSnapshotParams> params, base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)> callback = base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)>());
  void ProfileSnapshot(std::string snapshotId, base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)> callback = base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)>());
  // Replays the layer snapshot and returns the resulting bitmap.
  void ReplaySnapshot(std::unique_ptr<ReplaySnapshotParams> params, base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)> callback = base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)>());
  void ReplaySnapshot(std::string snapshotId, base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)> callback = base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)>());
  // Replays the layer snapshot and returns canvas log.
  void SnapshotCommandLog(std::unique_ptr<SnapshotCommandLogParams> params, base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)> callback = base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)>());
  void SnapshotCommandLog(std::string snapshotId, base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)> callback = base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)>());
 private:
  static void HandleCompositingReasonsResponse(base::Callback<void(std::unique_ptr<CompositingReasonsResult>)> callback, const base::Value& response);
  static void HandleMakeSnapshotResponse(base::Callback<void(std::unique_ptr<MakeSnapshotResult>)> callback, const base::Value& response);
  static void HandleLoadSnapshotResponse(base::Callback<void(std::unique_ptr<LoadSnapshotResult>)> callback, const base::Value& response);
  static void HandleProfileSnapshotResponse(base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)> callback, const base::Value& response);
  static void HandleReplaySnapshotResponse(base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)> callback, const base::Value& response);
  static void HandleSnapshotCommandLogResponse(base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace layer_tree
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_LAYER_TREE_H_
