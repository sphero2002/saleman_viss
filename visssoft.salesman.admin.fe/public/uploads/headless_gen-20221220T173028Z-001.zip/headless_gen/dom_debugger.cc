// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/dom_debugger.h"

#include "base/bind.h"

namespace headless {

namespace dom_debugger {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::SetDOMBreakpoint(std::unique_ptr<SetDOMBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.setDOMBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::RemoveDOMBreakpoint(std::unique_ptr<RemoveDOMBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.removeDOMBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::SetEventListenerBreakpoint(std::unique_ptr<SetEventListenerBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.setEventListenerBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::RemoveEventListenerBreakpoint(std::unique_ptr<RemoveEventListenerBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.removeEventListenerBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::SetInstrumentationBreakpoint(std::unique_ptr<SetInstrumentationBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.setInstrumentationBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::RemoveInstrumentationBreakpoint(std::unique_ptr<RemoveInstrumentationBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.removeInstrumentationBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::SetXHRBreakpoint(std::unique_ptr<SetXHRBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.setXHRBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::RemoveXHRBreakpoint(std::unique_ptr<RemoveXHRBreakpointParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMDebugger.removeXHRBreakpoint", params->Serialize(), std::move(callback));
}

void Domain::GetEventListeners(std::unique_ptr<GetEventListenersParams> params, base::Callback<void(std::unique_ptr<GetEventListenersResult>)> callback) {
  dispatcher_->SendMessage("DOMDebugger.getEventListeners", params->Serialize(), base::Bind(&Domain::HandleGetEventListenersResponse, callback));
}


// static
void Domain::HandleGetEventListenersResponse(base::Callback<void(std::unique_ptr<GetEventListenersResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetEventListenersResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetEventListenersResult> result = GetEventListenersResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace dom_debugger

} // namespace headless
