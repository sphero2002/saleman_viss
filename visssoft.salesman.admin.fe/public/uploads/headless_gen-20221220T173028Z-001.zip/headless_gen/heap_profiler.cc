// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/heap_profiler.h"

#include "base/bind.h"

namespace headless {

namespace heap_profiler {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.disable", std::move(callback));
}

void Domain::StartTrackingHeapObjects(std::unique_ptr<StartTrackingHeapObjectsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.startTrackingHeapObjects", params->Serialize(), std::move(callback));
}

void Domain::StopTrackingHeapObjects(std::unique_ptr<StopTrackingHeapObjectsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.stopTrackingHeapObjects", params->Serialize(), std::move(callback));
}

void Domain::TakeHeapSnapshot(std::unique_ptr<TakeHeapSnapshotParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.takeHeapSnapshot", params->Serialize(), std::move(callback));
}

void Domain::CollectGarbage(base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.collectGarbage", std::move(callback));
}

void Domain::GetObjectByHeapObjectId(std::unique_ptr<GetObjectByHeapObjectIdParams> params, base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)> callback) {
  dispatcher_->SendMessage("HeapProfiler.getObjectByHeapObjectId", params->Serialize(), base::Bind(&Domain::HandleGetObjectByHeapObjectIdResponse, callback));
}

void Domain::AddInspectedHeapObject(std::unique_ptr<AddInspectedHeapObjectParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.addInspectedHeapObject", params->Serialize(), std::move(callback));
}

void Domain::GetHeapObjectId(std::unique_ptr<GetHeapObjectIdParams> params, base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)> callback) {
  dispatcher_->SendMessage("HeapProfiler.getHeapObjectId", params->Serialize(), base::Bind(&Domain::HandleGetHeapObjectIdResponse, callback));
}

void Domain::StartSampling(base::Callback<void()> callback) {
  dispatcher_->SendMessage("HeapProfiler.startSampling", std::move(callback));
}

void Domain::StopSampling(base::Callback<void(std::unique_ptr<StopSamplingResult>)> callback) {
  dispatcher_->SendMessage("HeapProfiler.stopSampling", base::Bind(&Domain::HandleStopSamplingResponse, callback));
}


// static
void Domain::HandleGetObjectByHeapObjectIdResponse(base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetObjectByHeapObjectIdResult> result = GetObjectByHeapObjectIdResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetHeapObjectIdResponse(base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetHeapObjectIdResult> result = GetHeapObjectIdResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleStopSamplingResponse(base::Callback<void(std::unique_ptr<StopSamplingResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<StopSamplingResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<StopSamplingResult> result = StopSamplingResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace heap_profiler

} // namespace headless
