// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_DOM_H_
#define HEADLESS_PUBLIC_DOMAINS_DOM_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace dom {

// This domain exposes DOM read/write operations. Each DOM Node is represented with its mirror object that has an <code>id</code>. This <code>id</code> can be used to get additional information on the Node, resolve it into the JavaScript object wrapper, etc. It is important that client receives DOM events only for the nodes that are known to the client. Backend keeps track of the nodes that were sent to the client and never sends the same node twice. It is client's responsibility to collect information about the nodes that were sent to the client.<p>Note that <code>iframe</code> owner elements will return corresponding document elements as their child nodes.</p>
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables DOM agent for the given page.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables DOM agent for the given page.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Returns the root DOM node to the caller.
  void GetDocument(base::Callback<void(std::unique_ptr<GetDocumentResult>)> callback = base::Callback<void(std::unique_ptr<GetDocumentResult>)>());
  // Requests that children of the node with given id are returned to the caller in form of <code>setChildNodes</code> events where not only immediate children are retrieved, but all children down to the specified depth.
  void RequestChildNodes(std::unique_ptr<RequestChildNodesParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RequestChildNodes(int nodeId, base::Callback<void()> callback = base::Callback<void()>());
  // Executes <code>querySelector</code> on a given node.
  void QuerySelector(std::unique_ptr<QuerySelectorParams> params, base::Callback<void(std::unique_ptr<QuerySelectorResult>)> callback = base::Callback<void(std::unique_ptr<QuerySelectorResult>)>());
  void QuerySelector(int nodeId, std::string selector, base::Callback<void(std::unique_ptr<QuerySelectorResult>)> callback = base::Callback<void(std::unique_ptr<QuerySelectorResult>)>());
  // Executes <code>querySelectorAll</code> on a given node.
  void QuerySelectorAll(std::unique_ptr<QuerySelectorAllParams> params, base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)> callback = base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)>());
  void QuerySelectorAll(int nodeId, std::string selector, base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)> callback = base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)>());
  // Sets node name for a node with given id.
  void SetNodeName(std::unique_ptr<SetNodeNameParams> params, base::Callback<void(std::unique_ptr<SetNodeNameResult>)> callback = base::Callback<void(std::unique_ptr<SetNodeNameResult>)>());
  void SetNodeName(int nodeId, std::string name, base::Callback<void(std::unique_ptr<SetNodeNameResult>)> callback = base::Callback<void(std::unique_ptr<SetNodeNameResult>)>());
  // Sets node value for a node with given id.
  void SetNodeValue(std::unique_ptr<SetNodeValueParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetNodeValue(int nodeId, std::string value, base::Callback<void()> callback = base::Callback<void()>());
  // Removes node with given id.
  void RemoveNode(std::unique_ptr<RemoveNodeParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveNode(int nodeId, base::Callback<void()> callback = base::Callback<void()>());
  // Sets attribute for an element with given id.
  void SetAttributeValue(std::unique_ptr<SetAttributeValueParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetAttributeValue(int nodeId, std::string name, std::string value, base::Callback<void()> callback = base::Callback<void()>());
  // Sets attributes on element with given id. This method is useful when user edits some existing attribute value and types in several attribute name/value pairs.
  void SetAttributesAsText(std::unique_ptr<SetAttributesAsTextParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetAttributesAsText(int nodeId, std::string text, base::Callback<void()> callback = base::Callback<void()>());
  // Removes attribute with given name from an element with given id.
  void RemoveAttribute(std::unique_ptr<RemoveAttributeParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveAttribute(int nodeId, std::string name, base::Callback<void()> callback = base::Callback<void()>());
  // Returns node's HTML markup.
  void GetOuterHTML(std::unique_ptr<GetOuterHTMLParams> params, base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)> callback = base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)>());
  void GetOuterHTML(int nodeId, base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)> callback = base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)>());
  // Sets node HTML markup, returns new node id.
  void SetOuterHTML(std::unique_ptr<SetOuterHTMLParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetOuterHTML(int nodeId, std::string outerHTML, base::Callback<void()> callback = base::Callback<void()>());
  // Searches for a given string in the DOM tree. Use <code>getSearchResults</code> to access search results or <code>cancelSearch</code> to end this search session.
  void PerformSearch(std::unique_ptr<PerformSearchParams> params, base::Callback<void(std::unique_ptr<PerformSearchResult>)> callback = base::Callback<void(std::unique_ptr<PerformSearchResult>)>());
  void PerformSearch(std::string query, base::Callback<void(std::unique_ptr<PerformSearchResult>)> callback = base::Callback<void(std::unique_ptr<PerformSearchResult>)>());
  // Returns search results from given <code>fromIndex</code> to given <code>toIndex</code> from the sarch with the given identifier.
  void GetSearchResults(std::unique_ptr<GetSearchResultsParams> params, base::Callback<void(std::unique_ptr<GetSearchResultsResult>)> callback = base::Callback<void(std::unique_ptr<GetSearchResultsResult>)>());
  void GetSearchResults(std::string searchId, int fromIndex, int toIndex, base::Callback<void(std::unique_ptr<GetSearchResultsResult>)> callback = base::Callback<void(std::unique_ptr<GetSearchResultsResult>)>());
  // Discards search results from the session with the given id. <code>getSearchResults</code> should no longer be called for that search.
  void DiscardSearchResults(std::unique_ptr<DiscardSearchResultsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DiscardSearchResults(std::string searchId, base::Callback<void()> callback = base::Callback<void()>());
  // Requests that the node is sent to the caller given the JavaScript node object reference. All nodes that form the path from the node to the root are also sent to the client as a series of <code>setChildNodes</code> notifications.
  void RequestNode(std::unique_ptr<RequestNodeParams> params, base::Callback<void(std::unique_ptr<RequestNodeResult>)> callback = base::Callback<void(std::unique_ptr<RequestNodeResult>)>());
  void RequestNode(std::string objectId, base::Callback<void(std::unique_ptr<RequestNodeResult>)> callback = base::Callback<void(std::unique_ptr<RequestNodeResult>)>());
  // Enters the 'inspect' mode. In this mode, elements that user is hovering over are highlighted. Backend then generates 'inspectNodeRequested' event upon element selection.
  void SetInspectMode(std::unique_ptr<SetInspectModeParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetInspectMode(headless::dom::InspectMode mode, base::Callback<void()> callback = base::Callback<void()>());
  // Highlights given rectangle. Coordinates are absolute with respect to the main frame viewport.
  void HighlightRect(std::unique_ptr<HighlightRectParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void HighlightRect(int x, int y, int width, int height, base::Callback<void()> callback = base::Callback<void()>());
  // Highlights given quad. Coordinates are absolute with respect to the main frame viewport.
  void HighlightQuad(std::unique_ptr<HighlightQuadParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void HighlightQuad(std::vector<double> quad, base::Callback<void()> callback = base::Callback<void()>());
  // Highlights DOM node with given id or with the given JavaScript object wrapper. Either nodeId or objectId must be specified.
  void HighlightNode(std::unique_ptr<HighlightNodeParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void HighlightNode(std::unique_ptr<headless::dom::HighlightConfig> highlightConfig, base::Callback<void()> callback = base::Callback<void()>());
  // Hides DOM node highlight.
  void HideHighlight(base::Callback<void()> callback = base::Callback<void()>());
  // Highlights owner element of the frame with given id.
  void HighlightFrame(std::unique_ptr<HighlightFrameParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void HighlightFrame(std::string frameId, base::Callback<void()> callback = base::Callback<void()>());
  // Requests that the node is sent to the caller given its path. // FIXME, use XPath
  void PushNodeByPathToFrontend(std::unique_ptr<PushNodeByPathToFrontendParams> params, base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)> callback = base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)>());
  void PushNodeByPathToFrontend(std::string path, base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)> callback = base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)>());
  // Requests that a batch of nodes is sent to the caller given their backend node ids.
  void PushNodesByBackendIdsToFrontend(std::unique_ptr<PushNodesByBackendIdsToFrontendParams> params, base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)> callback = base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)>());
  void PushNodesByBackendIdsToFrontend(std::vector<int> backendNodeIds, base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)> callback = base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)>());
  // Enables console to refer to the node with given id via $x (see Command Line API for more details $x functions).
  void SetInspectedNode(std::unique_ptr<SetInspectedNodeParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetInspectedNode(int nodeId, base::Callback<void()> callback = base::Callback<void()>());
  // Resolves JavaScript node object for given node id.
  void ResolveNode(std::unique_ptr<ResolveNodeParams> params, base::Callback<void(std::unique_ptr<ResolveNodeResult>)> callback = base::Callback<void(std::unique_ptr<ResolveNodeResult>)>());
  void ResolveNode(int nodeId, base::Callback<void(std::unique_ptr<ResolveNodeResult>)> callback = base::Callback<void(std::unique_ptr<ResolveNodeResult>)>());
  // Returns attributes for the specified node.
  void GetAttributes(std::unique_ptr<GetAttributesParams> params, base::Callback<void(std::unique_ptr<GetAttributesResult>)> callback = base::Callback<void(std::unique_ptr<GetAttributesResult>)>());
  void GetAttributes(int nodeId, base::Callback<void(std::unique_ptr<GetAttributesResult>)> callback = base::Callback<void(std::unique_ptr<GetAttributesResult>)>());
  // Creates a deep copy of the specified node and places it into the target container before the given anchor.
  void CopyTo(std::unique_ptr<CopyToParams> params, base::Callback<void(std::unique_ptr<CopyToResult>)> callback = base::Callback<void(std::unique_ptr<CopyToResult>)>());
  void CopyTo(int nodeId, int targetNodeId, base::Callback<void(std::unique_ptr<CopyToResult>)> callback = base::Callback<void(std::unique_ptr<CopyToResult>)>());
  // Moves node into the new container, places it before the given anchor.
  void MoveTo(std::unique_ptr<MoveToParams> params, base::Callback<void(std::unique_ptr<MoveToResult>)> callback = base::Callback<void(std::unique_ptr<MoveToResult>)>());
  void MoveTo(int nodeId, int targetNodeId, base::Callback<void(std::unique_ptr<MoveToResult>)> callback = base::Callback<void(std::unique_ptr<MoveToResult>)>());
  // Undoes the last performed action.
  void Undo(base::Callback<void()> callback = base::Callback<void()>());
  // Re-does the last undone action.
  void Redo(base::Callback<void()> callback = base::Callback<void()>());
  // Marks last undoable state.
  void MarkUndoableState(base::Callback<void()> callback = base::Callback<void()>());
  // Focuses the given element.
  void Focus(std::unique_ptr<FocusParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void Focus(int nodeId, base::Callback<void()> callback = base::Callback<void()>());
  // Sets files for the given file input element.
  void SetFileInputFiles(std::unique_ptr<SetFileInputFilesParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetFileInputFiles(int nodeId, std::vector<std::string> files, base::Callback<void()> callback = base::Callback<void()>());
  // Returns boxes for the currently selected nodes.
  void GetBoxModel(std::unique_ptr<GetBoxModelParams> params, base::Callback<void(std::unique_ptr<GetBoxModelResult>)> callback = base::Callback<void(std::unique_ptr<GetBoxModelResult>)>());
  void GetBoxModel(int nodeId, base::Callback<void(std::unique_ptr<GetBoxModelResult>)> callback = base::Callback<void(std::unique_ptr<GetBoxModelResult>)>());
  // Returns node id at given location.
  void GetNodeForLocation(std::unique_ptr<GetNodeForLocationParams> params, base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)> callback = base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)>());
  void GetNodeForLocation(int x, int y, base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)> callback = base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)>());
  // Returns the id of the nearest ancestor that is a relayout boundary.
  void GetRelayoutBoundary(std::unique_ptr<GetRelayoutBoundaryParams> params, base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)> callback = base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)>());
  void GetRelayoutBoundary(int nodeId, base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)> callback = base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)>());
  // For testing.
  void GetHighlightObjectForTest(std::unique_ptr<GetHighlightObjectForTestParams> params, base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)> callback = base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)>());
  void GetHighlightObjectForTest(int nodeId, base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)> callback = base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)>());
 private:
  static void HandleGetDocumentResponse(base::Callback<void(std::unique_ptr<GetDocumentResult>)> callback, const base::Value& response);
  static void HandleQuerySelectorResponse(base::Callback<void(std::unique_ptr<QuerySelectorResult>)> callback, const base::Value& response);
  static void HandleQuerySelectorAllResponse(base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)> callback, const base::Value& response);
  static void HandleSetNodeNameResponse(base::Callback<void(std::unique_ptr<SetNodeNameResult>)> callback, const base::Value& response);
  static void HandleGetOuterHTMLResponse(base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)> callback, const base::Value& response);
  static void HandlePerformSearchResponse(base::Callback<void(std::unique_ptr<PerformSearchResult>)> callback, const base::Value& response);
  static void HandleGetSearchResultsResponse(base::Callback<void(std::unique_ptr<GetSearchResultsResult>)> callback, const base::Value& response);
  static void HandleRequestNodeResponse(base::Callback<void(std::unique_ptr<RequestNodeResult>)> callback, const base::Value& response);
  static void HandlePushNodeByPathToFrontendResponse(base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)> callback, const base::Value& response);
  static void HandlePushNodesByBackendIdsToFrontendResponse(base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)> callback, const base::Value& response);
  static void HandleResolveNodeResponse(base::Callback<void(std::unique_ptr<ResolveNodeResult>)> callback, const base::Value& response);
  static void HandleGetAttributesResponse(base::Callback<void(std::unique_ptr<GetAttributesResult>)> callback, const base::Value& response);
  static void HandleCopyToResponse(base::Callback<void(std::unique_ptr<CopyToResult>)> callback, const base::Value& response);
  static void HandleMoveToResponse(base::Callback<void(std::unique_ptr<MoveToResult>)> callback, const base::Value& response);
  static void HandleGetBoxModelResponse(base::Callback<void(std::unique_ptr<GetBoxModelResult>)> callback, const base::Value& response);
  static void HandleGetNodeForLocationResponse(base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)> callback, const base::Value& response);
  static void HandleGetRelayoutBoundaryResponse(base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)> callback, const base::Value& response);
  static void HandleGetHighlightObjectForTestResponse(base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace dom
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_DOM_H_
