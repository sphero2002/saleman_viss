// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/animation.h"

#include "base/bind.h"

namespace headless {

namespace animation {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Animation.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Animation.disable", std::move(callback));
}

void Domain::GetPlaybackRate(base::Callback<void(std::unique_ptr<GetPlaybackRateResult>)> callback) {
  dispatcher_->SendMessage("Animation.getPlaybackRate", base::Bind(&Domain::HandleGetPlaybackRateResponse, callback));
}

void Domain::SetPlaybackRate(std::unique_ptr<SetPlaybackRateParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Animation.setPlaybackRate", params->Serialize(), std::move(callback));
}

void Domain::GetCurrentTime(std::unique_ptr<GetCurrentTimeParams> params, base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)> callback) {
  dispatcher_->SendMessage("Animation.getCurrentTime", params->Serialize(), base::Bind(&Domain::HandleGetCurrentTimeResponse, callback));
}

void Domain::SetPaused(std::unique_ptr<SetPausedParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Animation.setPaused", params->Serialize(), std::move(callback));
}

void Domain::SetTiming(std::unique_ptr<SetTimingParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Animation.setTiming", params->Serialize(), std::move(callback));
}

void Domain::SeekAnimations(std::unique_ptr<SeekAnimationsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Animation.seekAnimations", params->Serialize(), std::move(callback));
}

void Domain::ReleaseAnimations(std::unique_ptr<ReleaseAnimationsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Animation.releaseAnimations", params->Serialize(), std::move(callback));
}

void Domain::ResolveAnimation(std::unique_ptr<ResolveAnimationParams> params, base::Callback<void(std::unique_ptr<ResolveAnimationResult>)> callback) {
  dispatcher_->SendMessage("Animation.resolveAnimation", params->Serialize(), base::Bind(&Domain::HandleResolveAnimationResponse, callback));
}


// static
void Domain::HandleGetPlaybackRateResponse(base::Callback<void(std::unique_ptr<GetPlaybackRateResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetPlaybackRateResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetPlaybackRateResult> result = GetPlaybackRateResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetCurrentTimeResponse(base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetCurrentTimeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetCurrentTimeResult> result = GetCurrentTimeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleResolveAnimationResponse(base::Callback<void(std::unique_ptr<ResolveAnimationResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<ResolveAnimationResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<ResolveAnimationResult> result = ResolveAnimationResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace animation

} // namespace headless
