// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_NETWORK_H_
#define HEADLESS_PUBLIC_DOMAINS_NETWORK_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace network {

// Network domain allows tracking network activities of the page. It exposes information about http, file, data and other requests and responses, their headers, bodies, timing, etc.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables network tracking, network events will now be delivered to the client.
  void Enable(std::unique_ptr<EnableParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables network tracking, prevents network events from being sent to the client.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Allows overriding user agent with the given string.
  void SetUserAgentOverride(std::unique_ptr<SetUserAgentOverrideParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetUserAgentOverride(std::string userAgent, base::Callback<void()> callback = base::Callback<void()>());
  // Specifies whether to always send extra HTTP headers with the requests from this page.
  void SetExtraHTTPHeaders(std::unique_ptr<SetExtraHTTPHeadersParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetExtraHTTPHeaders(std::unique_ptr<base::DictionaryValue> headers, base::Callback<void()> callback = base::Callback<void()>());
  // Returns content served for the given request.
  void GetResponseBody(std::unique_ptr<GetResponseBodyParams> params, base::Callback<void(std::unique_ptr<GetResponseBodyResult>)> callback = base::Callback<void(std::unique_ptr<GetResponseBodyResult>)>());
  void GetResponseBody(std::string requestId, base::Callback<void(std::unique_ptr<GetResponseBodyResult>)> callback = base::Callback<void(std::unique_ptr<GetResponseBodyResult>)>());
  // Blocks specific URL from loading.
  void AddBlockedURL(std::unique_ptr<AddBlockedURLParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void AddBlockedURL(std::string url, base::Callback<void()> callback = base::Callback<void()>());
  // Cancels blocking of a specific URL from loading.
  void RemoveBlockedURL(std::unique_ptr<RemoveBlockedURLParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveBlockedURL(std::string url, base::Callback<void()> callback = base::Callback<void()>());
  // This method sends a new XMLHttpRequest which is identical to the original one. The following parameters should be identical: method, url, async, request body, extra headers, withCredentials attribute, user, password.
  void ReplayXHR(std::unique_ptr<ReplayXHRParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ReplayXHR(std::string requestId, base::Callback<void()> callback = base::Callback<void()>());
  // Toggles monitoring of XMLHttpRequest. If <code>true</code>, console will receive messages upon each XHR issued.
  void SetMonitoringXHREnabled(std::unique_ptr<SetMonitoringXHREnabledParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetMonitoringXHREnabled(bool enabled, base::Callback<void()> callback = base::Callback<void()>());
  // Tells whether clearing browser cache is supported.
  void CanClearBrowserCache(base::Callback<void(std::unique_ptr<CanClearBrowserCacheResult>)> callback = base::Callback<void(std::unique_ptr<CanClearBrowserCacheResult>)>());
  // Clears browser cache.
  void ClearBrowserCache(base::Callback<void()> callback = base::Callback<void()>());
  // Tells whether clearing browser cookies is supported.
  void CanClearBrowserCookies(base::Callback<void(std::unique_ptr<CanClearBrowserCookiesResult>)> callback = base::Callback<void(std::unique_ptr<CanClearBrowserCookiesResult>)>());
  // Clears browser cookies.
  void ClearBrowserCookies(base::Callback<void()> callback = base::Callback<void()>());
  // Returns all browser cookies. Depending on the backend support, will return detailed cookie information in the <code>cookies</code> field.
  void GetCookies(base::Callback<void(std::unique_ptr<GetCookiesResult>)> callback = base::Callback<void(std::unique_ptr<GetCookiesResult>)>());
  // Deletes browser cookie with given name, domain and path.
  void DeleteCookie(std::unique_ptr<DeleteCookieParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DeleteCookie(std::string cookieName, std::string url, base::Callback<void()> callback = base::Callback<void()>());
  // Tells whether emulation of network conditions is supported.
  void CanEmulateNetworkConditions(base::Callback<void(std::unique_ptr<CanEmulateNetworkConditionsResult>)> callback = base::Callback<void(std::unique_ptr<CanEmulateNetworkConditionsResult>)>());
  // Activates emulation of network conditions.
  void EmulateNetworkConditions(std::unique_ptr<EmulateNetworkConditionsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void EmulateNetworkConditions(bool offline, double latency, double downloadThroughput, double uploadThroughput, base::Callback<void()> callback = base::Callback<void()>());
  // Toggles ignoring cache for each request. If <code>true</code>, cache will not be used.
  void SetCacheDisabled(std::unique_ptr<SetCacheDisabledParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetCacheDisabled(bool cacheDisabled, base::Callback<void()> callback = base::Callback<void()>());
  // For testing.
  void SetDataSizeLimitsForTest(std::unique_ptr<SetDataSizeLimitsForTestParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetDataSizeLimitsForTest(int maxTotalSize, int maxResourceSize, base::Callback<void()> callback = base::Callback<void()>());
  // Returns details for the given certificate.
  void GetCertificateDetails(std::unique_ptr<GetCertificateDetailsParams> params, base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)> callback = base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)>());
  void GetCertificateDetails(int certificateId, base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)> callback = base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)>());
  // Displays native dialog with the certificate details.
  void ShowCertificateViewer(std::unique_ptr<ShowCertificateViewerParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ShowCertificateViewer(int certificateId, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleGetResponseBodyResponse(base::Callback<void(std::unique_ptr<GetResponseBodyResult>)> callback, const base::Value& response);
  static void HandleCanClearBrowserCacheResponse(base::Callback<void(std::unique_ptr<CanClearBrowserCacheResult>)> callback, const base::Value& response);
  static void HandleCanClearBrowserCookiesResponse(base::Callback<void(std::unique_ptr<CanClearBrowserCookiesResult>)> callback, const base::Value& response);
  static void HandleGetCookiesResponse(base::Callback<void(std::unique_ptr<GetCookiesResult>)> callback, const base::Value& response);
  static void HandleCanEmulateNetworkConditionsResponse(base::Callback<void(std::unique_ptr<CanEmulateNetworkConditionsResult>)> callback, const base::Value& response);
  static void HandleGetCertificateDetailsResponse(base::Callback<void(std::unique_ptr<GetCertificateDetailsResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace network
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_NETWORK_H_
