// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/profiler.h"

#include "base/bind.h"

namespace headless {

namespace profiler {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Profiler.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Profiler.disable", std::move(callback));
}

void Domain::SetSamplingInterval(std::unique_ptr<SetSamplingIntervalParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Profiler.setSamplingInterval", params->Serialize(), std::move(callback));
}

void Domain::Start(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Profiler.start", std::move(callback));
}

void Domain::Stop(base::Callback<void(std::unique_ptr<StopResult>)> callback) {
  dispatcher_->SendMessage("Profiler.stop", base::Bind(&Domain::HandleStopResponse, callback));
}


// static
void Domain::HandleStopResponse(base::Callback<void(std::unique_ptr<StopResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<StopResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<StopResult> result = StopResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace profiler

} // namespace headless
