// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_INSPECTOR_H_
#define HEADLESS_PUBLIC_DOMAINS_INSPECTOR_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace inspector {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables inspector domain notifications.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables inspector domain notifications.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
 private:

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace inspector
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_INSPECTOR_H_
