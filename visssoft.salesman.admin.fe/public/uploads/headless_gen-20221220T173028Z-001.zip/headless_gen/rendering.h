// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_RENDERING_H_
#define HEADLESS_PUBLIC_DOMAINS_RENDERING_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace rendering {

// This domain allows to control rendering of the page.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Requests that backend shows paint rectangles
  void SetShowPaintRects(std::unique_ptr<SetShowPaintRectsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetShowPaintRects(bool result, base::Callback<void()> callback = base::Callback<void()>());
  // Requests that backend shows debug borders on layers
  void SetShowDebugBorders(std::unique_ptr<SetShowDebugBordersParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetShowDebugBorders(bool show, base::Callback<void()> callback = base::Callback<void()>());
  // Requests that backend shows the FPS counter
  void SetShowFPSCounter(std::unique_ptr<SetShowFPSCounterParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetShowFPSCounter(bool show, base::Callback<void()> callback = base::Callback<void()>());
  // Requests that backend shows scroll bottleneck rects
  void SetShowScrollBottleneckRects(std::unique_ptr<SetShowScrollBottleneckRectsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetShowScrollBottleneckRects(bool show, base::Callback<void()> callback = base::Callback<void()>());
  // Paints viewport size upon main frame resize.
  void SetShowViewportSizeOnResize(std::unique_ptr<SetShowViewportSizeOnResizeParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetShowViewportSizeOnResize(bool show, base::Callback<void()> callback = base::Callback<void()>());
 private:

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace rendering
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_RENDERING_H_
