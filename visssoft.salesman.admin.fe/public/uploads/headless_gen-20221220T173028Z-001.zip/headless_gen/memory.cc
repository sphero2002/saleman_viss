// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/memory.h"

#include "base/bind.h"

namespace headless {

namespace memory {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::GetDOMCounters(base::Callback<void(std::unique_ptr<GetDOMCountersResult>)> callback) {
  dispatcher_->SendMessage("Memory.getDOMCounters", base::Bind(&Domain::HandleGetDOMCountersResponse, callback));
}

void Domain::SetPressureNotificationsSuppressed(std::unique_ptr<SetPressureNotificationsSuppressedParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Memory.setPressureNotificationsSuppressed", params->Serialize(), std::move(callback));
}

void Domain::SimulatePressureNotification(std::unique_ptr<SimulatePressureNotificationParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Memory.simulatePressureNotification", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleGetDOMCountersResponse(base::Callback<void(std::unique_ptr<GetDOMCountersResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetDOMCountersResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetDOMCountersResult> result = GetDOMCountersResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace memory

} // namespace headless
