// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_RUNTIME_H_
#define HEADLESS_PUBLIC_DOMAINS_RUNTIME_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace runtime {

// Runtime domain exposes JavaScript runtime by means of remote evaluation and mirror objects. Evaluation results are returned as mirror object that expose object type, string representation and unique identifier that can be used for further object reference. Original objects are maintained in memory unless they are either explicitly released or are released along with the other objects in their object group.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Evaluates expression on global object.
  void Evaluate(std::unique_ptr<EvaluateParams> params, base::Callback<void(std::unique_ptr<EvaluateResult>)> callback = base::Callback<void(std::unique_ptr<EvaluateResult>)>());
  void Evaluate(std::string expression, base::Callback<void(std::unique_ptr<EvaluateResult>)> callback = base::Callback<void(std::unique_ptr<EvaluateResult>)>());
  // Calls function with given declaration on the given object. Object group of the result is inherited from the target object.
  void CallFunctionOn(std::unique_ptr<CallFunctionOnParams> params, base::Callback<void(std::unique_ptr<CallFunctionOnResult>)> callback = base::Callback<void(std::unique_ptr<CallFunctionOnResult>)>());
  void CallFunctionOn(std::string objectId, std::string functionDeclaration, base::Callback<void(std::unique_ptr<CallFunctionOnResult>)> callback = base::Callback<void(std::unique_ptr<CallFunctionOnResult>)>());
  // Returns properties of a given object. Object group of the result is inherited from the target object.
  void GetProperties(std::unique_ptr<GetPropertiesParams> params, base::Callback<void(std::unique_ptr<GetPropertiesResult>)> callback = base::Callback<void(std::unique_ptr<GetPropertiesResult>)>());
  void GetProperties(std::string objectId, base::Callback<void(std::unique_ptr<GetPropertiesResult>)> callback = base::Callback<void(std::unique_ptr<GetPropertiesResult>)>());
  // Releases remote object with given id.
  void ReleaseObject(std::unique_ptr<ReleaseObjectParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ReleaseObject(std::string objectId, base::Callback<void()> callback = base::Callback<void()>());
  // Releases all remote objects that belong to a given group.
  void ReleaseObjectGroup(std::unique_ptr<ReleaseObjectGroupParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ReleaseObjectGroup(std::string objectGroup, base::Callback<void()> callback = base::Callback<void()>());
  // Tells inspected instance(worker or page) that it can run in case it was started paused.
  void Run(base::Callback<void()> callback = base::Callback<void()>());
  // Enables reporting of execution contexts creation by means of <code>executionContextCreated</code> event. When the reporting gets enabled the event will be sent immediately for each existing execution context.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables reporting of execution contexts creation.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  void SetCustomObjectFormatterEnabled(std::unique_ptr<SetCustomObjectFormatterEnabledParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetCustomObjectFormatterEnabled(bool enabled, base::Callback<void()> callback = base::Callback<void()>());
  // Compiles expression.
  void CompileScript(std::unique_ptr<CompileScriptParams> params, base::Callback<void(std::unique_ptr<CompileScriptResult>)> callback = base::Callback<void(std::unique_ptr<CompileScriptResult>)>());
  void CompileScript(std::string expression, std::string sourceURL, bool persistScript, int executionContextId, base::Callback<void(std::unique_ptr<CompileScriptResult>)> callback = base::Callback<void(std::unique_ptr<CompileScriptResult>)>());
  // Runs script with given id in a given context.
  void RunScript(std::unique_ptr<RunScriptParams> params, base::Callback<void(std::unique_ptr<RunScriptResult>)> callback = base::Callback<void(std::unique_ptr<RunScriptResult>)>());
  void RunScript(std::string scriptId, int executionContextId, base::Callback<void(std::unique_ptr<RunScriptResult>)> callback = base::Callback<void(std::unique_ptr<RunScriptResult>)>());
 private:
  static void HandleEvaluateResponse(base::Callback<void(std::unique_ptr<EvaluateResult>)> callback, const base::Value& response);
  static void HandleCallFunctionOnResponse(base::Callback<void(std::unique_ptr<CallFunctionOnResult>)> callback, const base::Value& response);
  static void HandleGetPropertiesResponse(base::Callback<void(std::unique_ptr<GetPropertiesResult>)> callback, const base::Value& response);
  static void HandleCompileScriptResponse(base::Callback<void(std::unique_ptr<CompileScriptResult>)> callback, const base::Value& response);
  static void HandleRunScriptResponse(base::Callback<void(std::unique_ptr<RunScriptResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace runtime
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_RUNTIME_H_
