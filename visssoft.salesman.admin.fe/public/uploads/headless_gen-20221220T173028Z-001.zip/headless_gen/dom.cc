// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/dom.h"

#include "base/bind.h"

namespace headless {

namespace dom {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.disable", std::move(callback));
}

void Domain::GetDocument(base::Callback<void(std::unique_ptr<GetDocumentResult>)> callback) {
  dispatcher_->SendMessage("DOM.getDocument", base::Bind(&Domain::HandleGetDocumentResponse, callback));
}

void Domain::RequestChildNodes(std::unique_ptr<RequestChildNodesParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.requestChildNodes", params->Serialize(), std::move(callback));
}

void Domain::QuerySelector(std::unique_ptr<QuerySelectorParams> params, base::Callback<void(std::unique_ptr<QuerySelectorResult>)> callback) {
  dispatcher_->SendMessage("DOM.querySelector", params->Serialize(), base::Bind(&Domain::HandleQuerySelectorResponse, callback));
}

void Domain::QuerySelectorAll(std::unique_ptr<QuerySelectorAllParams> params, base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)> callback) {
  dispatcher_->SendMessage("DOM.querySelectorAll", params->Serialize(), base::Bind(&Domain::HandleQuerySelectorAllResponse, callback));
}

void Domain::SetNodeName(std::unique_ptr<SetNodeNameParams> params, base::Callback<void(std::unique_ptr<SetNodeNameResult>)> callback) {
  dispatcher_->SendMessage("DOM.setNodeName", params->Serialize(), base::Bind(&Domain::HandleSetNodeNameResponse, callback));
}

void Domain::SetNodeValue(std::unique_ptr<SetNodeValueParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.setNodeValue", params->Serialize(), std::move(callback));
}

void Domain::RemoveNode(std::unique_ptr<RemoveNodeParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.removeNode", params->Serialize(), std::move(callback));
}

void Domain::SetAttributeValue(std::unique_ptr<SetAttributeValueParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.setAttributeValue", params->Serialize(), std::move(callback));
}

void Domain::SetAttributesAsText(std::unique_ptr<SetAttributesAsTextParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.setAttributesAsText", params->Serialize(), std::move(callback));
}

void Domain::RemoveAttribute(std::unique_ptr<RemoveAttributeParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.removeAttribute", params->Serialize(), std::move(callback));
}

void Domain::GetOuterHTML(std::unique_ptr<GetOuterHTMLParams> params, base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)> callback) {
  dispatcher_->SendMessage("DOM.getOuterHTML", params->Serialize(), base::Bind(&Domain::HandleGetOuterHTMLResponse, callback));
}

void Domain::SetOuterHTML(std::unique_ptr<SetOuterHTMLParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.setOuterHTML", params->Serialize(), std::move(callback));
}

void Domain::PerformSearch(std::unique_ptr<PerformSearchParams> params, base::Callback<void(std::unique_ptr<PerformSearchResult>)> callback) {
  dispatcher_->SendMessage("DOM.performSearch", params->Serialize(), base::Bind(&Domain::HandlePerformSearchResponse, callback));
}

void Domain::GetSearchResults(std::unique_ptr<GetSearchResultsParams> params, base::Callback<void(std::unique_ptr<GetSearchResultsResult>)> callback) {
  dispatcher_->SendMessage("DOM.getSearchResults", params->Serialize(), base::Bind(&Domain::HandleGetSearchResultsResponse, callback));
}

void Domain::DiscardSearchResults(std::unique_ptr<DiscardSearchResultsParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.discardSearchResults", params->Serialize(), std::move(callback));
}

void Domain::RequestNode(std::unique_ptr<RequestNodeParams> params, base::Callback<void(std::unique_ptr<RequestNodeResult>)> callback) {
  dispatcher_->SendMessage("DOM.requestNode", params->Serialize(), base::Bind(&Domain::HandleRequestNodeResponse, callback));
}

void Domain::SetInspectMode(std::unique_ptr<SetInspectModeParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.setInspectMode", params->Serialize(), std::move(callback));
}

void Domain::HighlightRect(std::unique_ptr<HighlightRectParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.highlightRect", params->Serialize(), std::move(callback));
}

void Domain::HighlightQuad(std::unique_ptr<HighlightQuadParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.highlightQuad", params->Serialize(), std::move(callback));
}

void Domain::HighlightNode(std::unique_ptr<HighlightNodeParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.highlightNode", params->Serialize(), std::move(callback));
}

void Domain::HideHighlight(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.hideHighlight", std::move(callback));
}

void Domain::HighlightFrame(std::unique_ptr<HighlightFrameParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.highlightFrame", params->Serialize(), std::move(callback));
}

void Domain::PushNodeByPathToFrontend(std::unique_ptr<PushNodeByPathToFrontendParams> params, base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)> callback) {
  dispatcher_->SendMessage("DOM.pushNodeByPathToFrontend", params->Serialize(), base::Bind(&Domain::HandlePushNodeByPathToFrontendResponse, callback));
}

void Domain::PushNodesByBackendIdsToFrontend(std::unique_ptr<PushNodesByBackendIdsToFrontendParams> params, base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)> callback) {
  dispatcher_->SendMessage("DOM.pushNodesByBackendIdsToFrontend", params->Serialize(), base::Bind(&Domain::HandlePushNodesByBackendIdsToFrontendResponse, callback));
}

void Domain::SetInspectedNode(std::unique_ptr<SetInspectedNodeParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.setInspectedNode", params->Serialize(), std::move(callback));
}

void Domain::ResolveNode(std::unique_ptr<ResolveNodeParams> params, base::Callback<void(std::unique_ptr<ResolveNodeResult>)> callback) {
  dispatcher_->SendMessage("DOM.resolveNode", params->Serialize(), base::Bind(&Domain::HandleResolveNodeResponse, callback));
}

void Domain::GetAttributes(std::unique_ptr<GetAttributesParams> params, base::Callback<void(std::unique_ptr<GetAttributesResult>)> callback) {
  dispatcher_->SendMessage("DOM.getAttributes", params->Serialize(), base::Bind(&Domain::HandleGetAttributesResponse, callback));
}

void Domain::CopyTo(std::unique_ptr<CopyToParams> params, base::Callback<void(std::unique_ptr<CopyToResult>)> callback) {
  dispatcher_->SendMessage("DOM.copyTo", params->Serialize(), base::Bind(&Domain::HandleCopyToResponse, callback));
}

void Domain::MoveTo(std::unique_ptr<MoveToParams> params, base::Callback<void(std::unique_ptr<MoveToResult>)> callback) {
  dispatcher_->SendMessage("DOM.moveTo", params->Serialize(), base::Bind(&Domain::HandleMoveToResponse, callback));
}

void Domain::Undo(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.undo", std::move(callback));
}

void Domain::Redo(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.redo", std::move(callback));
}

void Domain::MarkUndoableState(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.markUndoableState", std::move(callback));
}

void Domain::Focus(std::unique_ptr<FocusParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.focus", params->Serialize(), std::move(callback));
}

void Domain::SetFileInputFiles(std::unique_ptr<SetFileInputFilesParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOM.setFileInputFiles", params->Serialize(), std::move(callback));
}

void Domain::GetBoxModel(std::unique_ptr<GetBoxModelParams> params, base::Callback<void(std::unique_ptr<GetBoxModelResult>)> callback) {
  dispatcher_->SendMessage("DOM.getBoxModel", params->Serialize(), base::Bind(&Domain::HandleGetBoxModelResponse, callback));
}

void Domain::GetNodeForLocation(std::unique_ptr<GetNodeForLocationParams> params, base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)> callback) {
  dispatcher_->SendMessage("DOM.getNodeForLocation", params->Serialize(), base::Bind(&Domain::HandleGetNodeForLocationResponse, callback));
}

void Domain::GetRelayoutBoundary(std::unique_ptr<GetRelayoutBoundaryParams> params, base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)> callback) {
  dispatcher_->SendMessage("DOM.getRelayoutBoundary", params->Serialize(), base::Bind(&Domain::HandleGetRelayoutBoundaryResponse, callback));
}

void Domain::GetHighlightObjectForTest(std::unique_ptr<GetHighlightObjectForTestParams> params, base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)> callback) {
  dispatcher_->SendMessage("DOM.getHighlightObjectForTest", params->Serialize(), base::Bind(&Domain::HandleGetHighlightObjectForTestResponse, callback));
}


// static
void Domain::HandleGetDocumentResponse(base::Callback<void(std::unique_ptr<GetDocumentResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetDocumentResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetDocumentResult> result = GetDocumentResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleQuerySelectorResponse(base::Callback<void(std::unique_ptr<QuerySelectorResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<QuerySelectorResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<QuerySelectorResult> result = QuerySelectorResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleQuerySelectorAllResponse(base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<QuerySelectorAllResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<QuerySelectorAllResult> result = QuerySelectorAllResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSetNodeNameResponse(base::Callback<void(std::unique_ptr<SetNodeNameResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SetNodeNameResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SetNodeNameResult> result = SetNodeNameResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetOuterHTMLResponse(base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetOuterHTMLResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetOuterHTMLResult> result = GetOuterHTMLResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandlePerformSearchResponse(base::Callback<void(std::unique_ptr<PerformSearchResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<PerformSearchResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<PerformSearchResult> result = PerformSearchResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetSearchResultsResponse(base::Callback<void(std::unique_ptr<GetSearchResultsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetSearchResultsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetSearchResultsResult> result = GetSearchResultsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleRequestNodeResponse(base::Callback<void(std::unique_ptr<RequestNodeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RequestNodeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RequestNodeResult> result = RequestNodeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandlePushNodeByPathToFrontendResponse(base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<PushNodeByPathToFrontendResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<PushNodeByPathToFrontendResult> result = PushNodeByPathToFrontendResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandlePushNodesByBackendIdsToFrontendResponse(base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<PushNodesByBackendIdsToFrontendResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<PushNodesByBackendIdsToFrontendResult> result = PushNodesByBackendIdsToFrontendResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleResolveNodeResponse(base::Callback<void(std::unique_ptr<ResolveNodeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<ResolveNodeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<ResolveNodeResult> result = ResolveNodeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetAttributesResponse(base::Callback<void(std::unique_ptr<GetAttributesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetAttributesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetAttributesResult> result = GetAttributesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCopyToResponse(base::Callback<void(std::unique_ptr<CopyToResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CopyToResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CopyToResult> result = CopyToResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleMoveToResponse(base::Callback<void(std::unique_ptr<MoveToResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<MoveToResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<MoveToResult> result = MoveToResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetBoxModelResponse(base::Callback<void(std::unique_ptr<GetBoxModelResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetBoxModelResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetBoxModelResult> result = GetBoxModelResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetNodeForLocationResponse(base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetNodeForLocationResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetNodeForLocationResult> result = GetNodeForLocationResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetRelayoutBoundaryResponse(base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetRelayoutBoundaryResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetRelayoutBoundaryResult> result = GetRelayoutBoundaryResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetHighlightObjectForTestResponse(base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetHighlightObjectForTestResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetHighlightObjectForTestResult> result = GetHighlightObjectForTestResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace dom

} // namespace headless
