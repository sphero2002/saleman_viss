// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/dom_storage.h"

#include "base/bind.h"

namespace headless {

namespace dom_storage {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMStorage.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMStorage.disable", std::move(callback));
}

void Domain::GetDOMStorageItems(std::unique_ptr<GetDOMStorageItemsParams> params, base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)> callback) {
  dispatcher_->SendMessage("DOMStorage.getDOMStorageItems", params->Serialize(), base::Bind(&Domain::HandleGetDOMStorageItemsResponse, callback));
}

void Domain::SetDOMStorageItem(std::unique_ptr<SetDOMStorageItemParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMStorage.setDOMStorageItem", params->Serialize(), std::move(callback));
}

void Domain::RemoveDOMStorageItem(std::unique_ptr<RemoveDOMStorageItemParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DOMStorage.removeDOMStorageItem", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleGetDOMStorageItemsResponse(base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetDOMStorageItemsResult> result = GetDOMStorageItemsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace dom_storage

} // namespace headless
