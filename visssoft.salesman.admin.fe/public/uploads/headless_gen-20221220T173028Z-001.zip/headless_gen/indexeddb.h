// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_INDEXEDDB_H_
#define HEADLESS_PUBLIC_DOMAINS_INDEXEDDB_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace indexeddb {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables events from backend.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables events from backend.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Requests database names for given security origin.
  void RequestDatabaseNames(std::unique_ptr<RequestDatabaseNamesParams> params, base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)> callback = base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)>());
  void RequestDatabaseNames(std::string securityOrigin, base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)> callback = base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)>());
  // Requests database with given name in given frame.
  void RequestDatabase(std::unique_ptr<RequestDatabaseParams> params, base::Callback<void(std::unique_ptr<RequestDatabaseResult>)> callback = base::Callback<void(std::unique_ptr<RequestDatabaseResult>)>());
  void RequestDatabase(std::string securityOrigin, std::string databaseName, base::Callback<void(std::unique_ptr<RequestDatabaseResult>)> callback = base::Callback<void(std::unique_ptr<RequestDatabaseResult>)>());
  // Requests data from object store or index.
  void RequestData(std::unique_ptr<RequestDataParams> params, base::Callback<void(std::unique_ptr<RequestDataResult>)> callback = base::Callback<void(std::unique_ptr<RequestDataResult>)>());
  void RequestData(std::string securityOrigin, std::string databaseName, std::string objectStoreName, std::string indexName, int skipCount, int pageSize, base::Callback<void(std::unique_ptr<RequestDataResult>)> callback = base::Callback<void(std::unique_ptr<RequestDataResult>)>());
  // Clears all entries from an object store.
  void ClearObjectStore(std::unique_ptr<ClearObjectStoreParams> params, base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)> callback = base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)>());
  void ClearObjectStore(std::string securityOrigin, std::string databaseName, std::string objectStoreName, base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)> callback = base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)>());
 private:
  static void HandleRequestDatabaseNamesResponse(base::Callback<void(std::unique_ptr<RequestDatabaseNamesResult>)> callback, const base::Value& response);
  static void HandleRequestDatabaseResponse(base::Callback<void(std::unique_ptr<RequestDatabaseResult>)> callback, const base::Value& response);
  static void HandleRequestDataResponse(base::Callback<void(std::unique_ptr<RequestDataResult>)> callback, const base::Value& response);
  static void HandleClearObjectStoreResponse(base::Callback<void(std::unique_ptr<ClearObjectStoreResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace indexeddb
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_INDEXEDDB_H_
