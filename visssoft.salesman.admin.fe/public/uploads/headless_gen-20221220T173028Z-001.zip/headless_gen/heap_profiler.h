// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_HEAP_PROFILER_H_
#define HEADLESS_PUBLIC_DOMAINS_HEAP_PROFILER_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace heap_profiler {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  void StartTrackingHeapObjects(std::unique_ptr<StartTrackingHeapObjectsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void StartTrackingHeapObjects(base::Callback<void()> callback = base::Callback<void()>());
  void StopTrackingHeapObjects(std::unique_ptr<StopTrackingHeapObjectsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void StopTrackingHeapObjects(base::Callback<void()> callback = base::Callback<void()>());
  void TakeHeapSnapshot(std::unique_ptr<TakeHeapSnapshotParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void TakeHeapSnapshot(base::Callback<void()> callback = base::Callback<void()>());
  void CollectGarbage(base::Callback<void()> callback = base::Callback<void()>());
  void GetObjectByHeapObjectId(std::unique_ptr<GetObjectByHeapObjectIdParams> params, base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)> callback = base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)>());
  void GetObjectByHeapObjectId(std::string objectId, base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)> callback = base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)>());
  // Enables console to refer to the node with given id via $x (see Command Line API for more details $x functions).
  void AddInspectedHeapObject(std::unique_ptr<AddInspectedHeapObjectParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void AddInspectedHeapObject(std::string heapObjectId, base::Callback<void()> callback = base::Callback<void()>());
  void GetHeapObjectId(std::unique_ptr<GetHeapObjectIdParams> params, base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)> callback = base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)>());
  void GetHeapObjectId(std::string objectId, base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)> callback = base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)>());
  void StartSampling(base::Callback<void()> callback = base::Callback<void()>());
  void StopSampling(base::Callback<void(std::unique_ptr<StopSamplingResult>)> callback = base::Callback<void(std::unique_ptr<StopSamplingResult>)>());
 private:
  static void HandleGetObjectByHeapObjectIdResponse(base::Callback<void(std::unique_ptr<GetObjectByHeapObjectIdResult>)> callback, const base::Value& response);
  static void HandleGetHeapObjectIdResponse(base::Callback<void(std::unique_ptr<GetHeapObjectIdResult>)> callback, const base::Value& response);
  static void HandleStopSamplingResponse(base::Callback<void(std::unique_ptr<StopSamplingResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace heap_profiler
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_HEAP_PROFILER_H_
