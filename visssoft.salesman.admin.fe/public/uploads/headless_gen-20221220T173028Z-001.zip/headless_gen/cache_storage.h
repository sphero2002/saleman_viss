// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_CACHE_STORAGE_H_
#define HEADLESS_PUBLIC_DOMAINS_CACHE_STORAGE_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace cache_storage {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Requests cache names.
  void RequestCacheNames(std::unique_ptr<RequestCacheNamesParams> params, base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)> callback = base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)>());
  void RequestCacheNames(std::string securityOrigin, base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)> callback = base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)>());
  // Requests data from cache.
  void RequestEntries(std::unique_ptr<RequestEntriesParams> params, base::Callback<void(std::unique_ptr<RequestEntriesResult>)> callback = base::Callback<void(std::unique_ptr<RequestEntriesResult>)>());
  void RequestEntries(std::string cacheId, int skipCount, int pageSize, base::Callback<void(std::unique_ptr<RequestEntriesResult>)> callback = base::Callback<void(std::unique_ptr<RequestEntriesResult>)>());
  // Deletes a cache.
  void DeleteCache(std::unique_ptr<DeleteCacheParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DeleteCache(std::string cacheId, base::Callback<void()> callback = base::Callback<void()>());
  // Deletes a cache entry.
  void DeleteEntry(std::unique_ptr<DeleteEntryParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DeleteEntry(std::string cacheId, std::string request, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleRequestCacheNamesResponse(base::Callback<void(std::unique_ptr<RequestCacheNamesResult>)> callback, const base::Value& response);
  static void HandleRequestEntriesResponse(base::Callback<void(std::unique_ptr<RequestEntriesResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace cache_storage
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_CACHE_STORAGE_H_
