// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_DATABASE_H_
#define HEADLESS_PUBLIC_DOMAINS_DATABASE_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace database {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables database tracking, database events will now be delivered to the client.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables database tracking, prevents database events from being sent to the client.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  void GetDatabaseTableNames(std::unique_ptr<GetDatabaseTableNamesParams> params, base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)> callback = base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)>());
  void GetDatabaseTableNames(std::string databaseId, base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)> callback = base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)>());
  void ExecuteSQL(std::unique_ptr<ExecuteSQLParams> params, base::Callback<void(std::unique_ptr<ExecuteSQLResult>)> callback = base::Callback<void(std::unique_ptr<ExecuteSQLResult>)>());
  void ExecuteSQL(std::string databaseId, std::string query, base::Callback<void(std::unique_ptr<ExecuteSQLResult>)> callback = base::Callback<void(std::unique_ptr<ExecuteSQLResult>)>());
 private:
  static void HandleGetDatabaseTableNamesResponse(base::Callback<void(std::unique_ptr<GetDatabaseTableNamesResult>)> callback, const base::Value& response);
  static void HandleExecuteSQLResponse(base::Callback<void(std::unique_ptr<ExecuteSQLResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace database
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_DATABASE_H_
