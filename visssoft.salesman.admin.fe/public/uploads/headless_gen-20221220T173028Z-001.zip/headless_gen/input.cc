// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/input.h"

#include "base/bind.h"

namespace headless {

namespace input {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::DispatchKeyEvent(std::unique_ptr<DispatchKeyEventParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Input.dispatchKeyEvent", params->Serialize(), std::move(callback));
}

void Domain::DispatchMouseEvent(std::unique_ptr<DispatchMouseEventParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Input.dispatchMouseEvent", params->Serialize(), std::move(callback));
}

void Domain::DispatchTouchEvent(std::unique_ptr<DispatchTouchEventParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Input.dispatchTouchEvent", params->Serialize(), std::move(callback));
}

void Domain::EmulateTouchFromMouseEvent(std::unique_ptr<EmulateTouchFromMouseEventParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Input.emulateTouchFromMouseEvent", params->Serialize(), std::move(callback));
}

void Domain::SynthesizePinchGesture(std::unique_ptr<SynthesizePinchGestureParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Input.synthesizePinchGesture", params->Serialize(), std::move(callback));
}

void Domain::SynthesizeScrollGesture(std::unique_ptr<SynthesizeScrollGestureParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Input.synthesizeScrollGesture", params->Serialize(), std::move(callback));
}

void Domain::SynthesizeTapGesture(std::unique_ptr<SynthesizeTapGestureParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Input.synthesizeTapGesture", params->Serialize(), std::move(callback));
}


}  // namespace input

} // namespace headless
