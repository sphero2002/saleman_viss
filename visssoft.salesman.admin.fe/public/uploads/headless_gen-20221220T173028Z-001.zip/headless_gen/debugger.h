// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_DEBUGGER_H_
#define HEADLESS_PUBLIC_DOMAINS_DEBUGGER_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace debugger {

// Debugger domain exposes JavaScript debugging capabilities. It allows setting and removing breakpoints, stepping through execution, exploring stack traces, etc.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables debugger for the given page. Clients should not assume that the debugging has been enabled until the result for this command is received.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables debugger for given page.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Activates / deactivates all breakpoints on the page.
  void SetBreakpointsActive(std::unique_ptr<SetBreakpointsActiveParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetBreakpointsActive(bool active, base::Callback<void()> callback = base::Callback<void()>());
  // Makes page not interrupt on any pauses (breakpoint, exception, dom exception etc).
  void SetSkipAllPauses(std::unique_ptr<SetSkipAllPausesParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetSkipAllPauses(bool skipped, base::Callback<void()> callback = base::Callback<void()>());
  // Sets JavaScript breakpoint at given location specified either by URL or URL regex. Once this command is issued, all existing parsed scripts will have breakpoints resolved and returned in <code>locations</code> property. Further matching script parsing will result in subsequent <code>breakpointResolved</code> events issued. This logical breakpoint will survive page reloads.
  void SetBreakpointByUrl(std::unique_ptr<SetBreakpointByUrlParams> params, base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)> callback = base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)>());
  void SetBreakpointByUrl(int lineNumber, base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)> callback = base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)>());
  // Sets JavaScript breakpoint at a given location.
  void SetBreakpoint(std::unique_ptr<SetBreakpointParams> params, base::Callback<void(std::unique_ptr<SetBreakpointResult>)> callback = base::Callback<void(std::unique_ptr<SetBreakpointResult>)>());
  void SetBreakpoint(std::unique_ptr<headless::debugger::Location> location, base::Callback<void(std::unique_ptr<SetBreakpointResult>)> callback = base::Callback<void(std::unique_ptr<SetBreakpointResult>)>());
  // Removes JavaScript breakpoint.
  void RemoveBreakpoint(std::unique_ptr<RemoveBreakpointParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveBreakpoint(std::string breakpointId, base::Callback<void()> callback = base::Callback<void()>());
  // Continues execution until specific location is reached.
  void ContinueToLocation(std::unique_ptr<ContinueToLocationParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void ContinueToLocation(std::unique_ptr<headless::debugger::Location> location, base::Callback<void()> callback = base::Callback<void()>());
  // Steps over the statement.
  void StepOver(base::Callback<void()> callback = base::Callback<void()>());
  // Steps into the function call.
  void StepInto(base::Callback<void()> callback = base::Callback<void()>());
  // Steps out of the function call.
  void StepOut(base::Callback<void()> callback = base::Callback<void()>());
  // Stops on the next JavaScript statement.
  void Pause(base::Callback<void()> callback = base::Callback<void()>());
  // Resumes JavaScript execution.
  void Resume(base::Callback<void()> callback = base::Callback<void()>());
  // Searches for given string in script content.
  void SearchInContent(std::unique_ptr<SearchInContentParams> params, base::Callback<void(std::unique_ptr<SearchInContentResult>)> callback = base::Callback<void(std::unique_ptr<SearchInContentResult>)>());
  void SearchInContent(std::string scriptId, std::string query, base::Callback<void(std::unique_ptr<SearchInContentResult>)> callback = base::Callback<void(std::unique_ptr<SearchInContentResult>)>());
  // Always returns true.
  void CanSetScriptSource(base::Callback<void(std::unique_ptr<CanSetScriptSourceResult>)> callback = base::Callback<void(std::unique_ptr<CanSetScriptSourceResult>)>());
  // Edits JavaScript source live.
  void SetScriptSource(std::unique_ptr<SetScriptSourceParams> params, base::Callback<void(std::unique_ptr<SetScriptSourceResult>)> callback = base::Callback<void(std::unique_ptr<SetScriptSourceResult>)>());
  void SetScriptSource(std::string scriptId, std::string scriptSource, base::Callback<void(std::unique_ptr<SetScriptSourceResult>)> callback = base::Callback<void(std::unique_ptr<SetScriptSourceResult>)>());
  // Restarts particular call frame from the beginning.
  void RestartFrame(std::unique_ptr<RestartFrameParams> params, base::Callback<void(std::unique_ptr<RestartFrameResult>)> callback = base::Callback<void(std::unique_ptr<RestartFrameResult>)>());
  void RestartFrame(std::string callFrameId, base::Callback<void(std::unique_ptr<RestartFrameResult>)> callback = base::Callback<void(std::unique_ptr<RestartFrameResult>)>());
  // Returns source for the script with given id.
  void GetScriptSource(std::unique_ptr<GetScriptSourceParams> params, base::Callback<void(std::unique_ptr<GetScriptSourceResult>)> callback = base::Callback<void(std::unique_ptr<GetScriptSourceResult>)>());
  void GetScriptSource(std::string scriptId, base::Callback<void(std::unique_ptr<GetScriptSourceResult>)> callback = base::Callback<void(std::unique_ptr<GetScriptSourceResult>)>());
  // Returns detailed information on given function.
  void GetFunctionDetails(std::unique_ptr<GetFunctionDetailsParams> params, base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)> callback = base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)>());
  void GetFunctionDetails(std::string functionId, base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)> callback = base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)>());
  // Returns detailed information on given generator object.
  void GetGeneratorObjectDetails(std::unique_ptr<GetGeneratorObjectDetailsParams> params, base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)> callback = base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)>());
  void GetGeneratorObjectDetails(std::string objectId, base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)> callback = base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)>());
  // Returns entries of given collection.
  void GetCollectionEntries(std::unique_ptr<GetCollectionEntriesParams> params, base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)> callback = base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)>());
  void GetCollectionEntries(std::string objectId, base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)> callback = base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)>());
  // Defines pause on exceptions state. Can be set to stop on all exceptions, uncaught exceptions or no exceptions. Initial pause on exceptions state is <code>none</code>.
  void SetPauseOnExceptions(std::unique_ptr<SetPauseOnExceptionsParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetPauseOnExceptions(headless::debugger::SetPauseOnExceptionsState state, base::Callback<void()> callback = base::Callback<void()>());
  // Evaluates expression on a given call frame.
  void EvaluateOnCallFrame(std::unique_ptr<EvaluateOnCallFrameParams> params, base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)> callback = base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)>());
  void EvaluateOnCallFrame(std::string callFrameId, std::string expression, base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)> callback = base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)>());
  // Changes value of variable in a callframe. Object-based scopes are not supported and must be mutated manually.
  void SetVariableValue(std::unique_ptr<SetVariableValueParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetVariableValue(int scopeNumber, std::string variableName, std::unique_ptr<headless::runtime::CallArgument> newValue, std::string callFrameId, base::Callback<void()> callback = base::Callback<void()>());
  // Returns call stack including variables changed since VM was paused. VM must be paused.
  void GetBacktrace(base::Callback<void(std::unique_ptr<GetBacktraceResult>)> callback = base::Callback<void(std::unique_ptr<GetBacktraceResult>)>());
  // Enables or disables async call stacks tracking.
  void SetAsyncCallStackDepth(std::unique_ptr<SetAsyncCallStackDepthParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetAsyncCallStackDepth(int maxDepth, base::Callback<void()> callback = base::Callback<void()>());
  // Makes backend skip steps in the script in blackboxed ranges. VM will try leave blacklisted scripts by performing 'step in' several times, finally resorting to 'step out' if unsuccessful. Positions array contains positions where blackbox state is changed. First interval isn't blackboxed. Array should be sorted.
  void SetBlackboxedRanges(std::unique_ptr<SetBlackboxedRangesParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetBlackboxedRanges(std::string scriptId, std::vector<std::unique_ptr<headless::debugger::ScriptPosition>> positions, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleSetBreakpointByUrlResponse(base::Callback<void(std::unique_ptr<SetBreakpointByUrlResult>)> callback, const base::Value& response);
  static void HandleSetBreakpointResponse(base::Callback<void(std::unique_ptr<SetBreakpointResult>)> callback, const base::Value& response);
  static void HandleSearchInContentResponse(base::Callback<void(std::unique_ptr<SearchInContentResult>)> callback, const base::Value& response);
  static void HandleCanSetScriptSourceResponse(base::Callback<void(std::unique_ptr<CanSetScriptSourceResult>)> callback, const base::Value& response);
  static void HandleSetScriptSourceResponse(base::Callback<void(std::unique_ptr<SetScriptSourceResult>)> callback, const base::Value& response);
  static void HandleRestartFrameResponse(base::Callback<void(std::unique_ptr<RestartFrameResult>)> callback, const base::Value& response);
  static void HandleGetScriptSourceResponse(base::Callback<void(std::unique_ptr<GetScriptSourceResult>)> callback, const base::Value& response);
  static void HandleGetFunctionDetailsResponse(base::Callback<void(std::unique_ptr<GetFunctionDetailsResult>)> callback, const base::Value& response);
  static void HandleGetGeneratorObjectDetailsResponse(base::Callback<void(std::unique_ptr<GetGeneratorObjectDetailsResult>)> callback, const base::Value& response);
  static void HandleGetCollectionEntriesResponse(base::Callback<void(std::unique_ptr<GetCollectionEntriesResult>)> callback, const base::Value& response);
  static void HandleEvaluateOnCallFrameResponse(base::Callback<void(std::unique_ptr<EvaluateOnCallFrameResult>)> callback, const base::Value& response);
  static void HandleGetBacktraceResponse(base::Callback<void(std::unique_ptr<GetBacktraceResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace debugger
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_DEBUGGER_H_
