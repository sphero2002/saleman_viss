// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/emulation.h"

#include "base/bind.h"

namespace headless {

namespace emulation {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::SetDeviceMetricsOverride(std::unique_ptr<SetDeviceMetricsOverrideParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.setDeviceMetricsOverride", params->Serialize(), std::move(callback));
}

void Domain::ClearDeviceMetricsOverride(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.clearDeviceMetricsOverride", std::move(callback));
}

void Domain::ResetPageScaleFactor(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.resetPageScaleFactor", std::move(callback));
}

void Domain::SetPageScaleFactor(std::unique_ptr<SetPageScaleFactorParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.setPageScaleFactor", params->Serialize(), std::move(callback));
}

void Domain::SetScriptExecutionDisabled(std::unique_ptr<SetScriptExecutionDisabledParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.setScriptExecutionDisabled", params->Serialize(), std::move(callback));
}

void Domain::SetGeolocationOverride(std::unique_ptr<SetGeolocationOverrideParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.setGeolocationOverride", params->Serialize(), std::move(callback));
}

void Domain::ClearGeolocationOverride(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.clearGeolocationOverride", std::move(callback));
}

void Domain::SetTouchEmulationEnabled(std::unique_ptr<SetTouchEmulationEnabledParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.setTouchEmulationEnabled", params->Serialize(), std::move(callback));
}

void Domain::SetEmulatedMedia(std::unique_ptr<SetEmulatedMediaParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.setEmulatedMedia", params->Serialize(), std::move(callback));
}

void Domain::SetCPUThrottlingRate(std::unique_ptr<SetCPUThrottlingRateParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Emulation.setCPUThrottlingRate", params->Serialize(), std::move(callback));
}

void Domain::CanEmulate(base::Callback<void(std::unique_ptr<CanEmulateResult>)> callback) {
  dispatcher_->SendMessage("Emulation.canEmulate", base::Bind(&Domain::HandleCanEmulateResponse, callback));
}


// static
void Domain::HandleCanEmulateResponse(base::Callback<void(std::unique_ptr<CanEmulateResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CanEmulateResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CanEmulateResult> result = CanEmulateResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace emulation

} // namespace headless
