// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/layer_tree.h"

#include "base/bind.h"

namespace headless {

namespace layer_tree {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("LayerTree.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("LayerTree.disable", std::move(callback));
}

void Domain::CompositingReasons(std::unique_ptr<CompositingReasonsParams> params, base::Callback<void(std::unique_ptr<CompositingReasonsResult>)> callback) {
  dispatcher_->SendMessage("LayerTree.compositingReasons", params->Serialize(), base::Bind(&Domain::HandleCompositingReasonsResponse, callback));
}

void Domain::MakeSnapshot(std::unique_ptr<MakeSnapshotParams> params, base::Callback<void(std::unique_ptr<MakeSnapshotResult>)> callback) {
  dispatcher_->SendMessage("LayerTree.makeSnapshot", params->Serialize(), base::Bind(&Domain::HandleMakeSnapshotResponse, callback));
}

void Domain::LoadSnapshot(std::unique_ptr<LoadSnapshotParams> params, base::Callback<void(std::unique_ptr<LoadSnapshotResult>)> callback) {
  dispatcher_->SendMessage("LayerTree.loadSnapshot", params->Serialize(), base::Bind(&Domain::HandleLoadSnapshotResponse, callback));
}

void Domain::ReleaseSnapshot(std::unique_ptr<ReleaseSnapshotParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("LayerTree.releaseSnapshot", params->Serialize(), std::move(callback));
}

void Domain::ProfileSnapshot(std::unique_ptr<ProfileSnapshotParams> params, base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)> callback) {
  dispatcher_->SendMessage("LayerTree.profileSnapshot", params->Serialize(), base::Bind(&Domain::HandleProfileSnapshotResponse, callback));
}

void Domain::ReplaySnapshot(std::unique_ptr<ReplaySnapshotParams> params, base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)> callback) {
  dispatcher_->SendMessage("LayerTree.replaySnapshot", params->Serialize(), base::Bind(&Domain::HandleReplaySnapshotResponse, callback));
}

void Domain::SnapshotCommandLog(std::unique_ptr<SnapshotCommandLogParams> params, base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)> callback) {
  dispatcher_->SendMessage("LayerTree.snapshotCommandLog", params->Serialize(), base::Bind(&Domain::HandleSnapshotCommandLogResponse, callback));
}


// static
void Domain::HandleCompositingReasonsResponse(base::Callback<void(std::unique_ptr<CompositingReasonsResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CompositingReasonsResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CompositingReasonsResult> result = CompositingReasonsResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleMakeSnapshotResponse(base::Callback<void(std::unique_ptr<MakeSnapshotResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<MakeSnapshotResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<MakeSnapshotResult> result = MakeSnapshotResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleLoadSnapshotResponse(base::Callback<void(std::unique_ptr<LoadSnapshotResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<LoadSnapshotResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<LoadSnapshotResult> result = LoadSnapshotResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleProfileSnapshotResponse(base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<ProfileSnapshotResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<ProfileSnapshotResult> result = ProfileSnapshotResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleReplaySnapshotResponse(base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<ReplaySnapshotResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<ReplaySnapshotResult> result = ReplaySnapshotResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSnapshotCommandLogResponse(base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SnapshotCommandLogResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SnapshotCommandLogResult> result = SnapshotCommandLogResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace layer_tree

} // namespace headless
