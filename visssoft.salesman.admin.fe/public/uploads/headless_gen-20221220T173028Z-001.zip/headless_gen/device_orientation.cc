// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/device_orientation.h"

#include "base/bind.h"

namespace headless {

namespace device_orientation {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::SetDeviceOrientationOverride(std::unique_ptr<SetDeviceOrientationOverrideParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("DeviceOrientation.setDeviceOrientationOverride", params->Serialize(), std::move(callback));
}

void Domain::ClearDeviceOrientationOverride(base::Callback<void()> callback) {
  dispatcher_->SendMessage("DeviceOrientation.clearDeviceOrientationOverride", std::move(callback));
}


}  // namespace device_orientation

} // namespace headless
