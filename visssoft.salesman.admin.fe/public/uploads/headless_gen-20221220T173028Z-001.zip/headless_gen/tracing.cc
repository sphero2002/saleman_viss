// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/tracing.h"

#include "base/bind.h"

namespace headless {

namespace tracing {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Start(std::unique_ptr<StartParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Tracing.start", params->Serialize(), std::move(callback));
}

void Domain::End(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Tracing.end", std::move(callback));
}

void Domain::GetCategories(base::Callback<void(std::unique_ptr<GetCategoriesResult>)> callback) {
  dispatcher_->SendMessage("Tracing.getCategories", base::Bind(&Domain::HandleGetCategoriesResponse, callback));
}

void Domain::RequestMemoryDump(base::Callback<void(std::unique_ptr<RequestMemoryDumpResult>)> callback) {
  dispatcher_->SendMessage("Tracing.requestMemoryDump", base::Bind(&Domain::HandleRequestMemoryDumpResponse, callback));
}

void Domain::RecordClockSyncMarker(std::unique_ptr<RecordClockSyncMarkerParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Tracing.recordClockSyncMarker", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleGetCategoriesResponse(base::Callback<void(std::unique_ptr<GetCategoriesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetCategoriesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetCategoriesResult> result = GetCategoriesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleRequestMemoryDumpResponse(base::Callback<void(std::unique_ptr<RequestMemoryDumpResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<RequestMemoryDumpResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<RequestMemoryDumpResult> result = RequestMemoryDumpResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace tracing

} // namespace headless
