// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_TYPE_CONVERSIONS_H_
#define HEADLESS_PUBLIC_DOMAINS_TYPE_CONVERSIONS_H_

#include "headless/public/domains/types.h"
#include "headless/public/internal/value_conversions.h"

namespace headless {
namespace internal {

template <>
struct FromValue<memory::PressureLevel> {
  static memory::PressureLevel Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return memory::PressureLevel::MODERATE;
    }
    if (string_value == "moderate")
      return memory::PressureLevel::MODERATE;
    if (string_value == "critical")
      return memory::PressureLevel::CRITICAL;
    errors->AddError("invalid enum value");
    return memory::PressureLevel::MODERATE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const memory::PressureLevel& value, T*) {
  switch (value) {
    case memory::PressureLevel::MODERATE:
      return base::WrapUnique(new base::StringValue("moderate"));
    case memory::PressureLevel::CRITICAL:
      return base::WrapUnique(new base::StringValue("critical"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<memory::GetDOMCountersResult> {
  static std::unique_ptr<memory::GetDOMCountersResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return memory::GetDOMCountersResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const memory::GetDOMCountersResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<memory::SetPressureNotificationsSuppressedParams> {
  static std::unique_ptr<memory::SetPressureNotificationsSuppressedParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return memory::SetPressureNotificationsSuppressedParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const memory::SetPressureNotificationsSuppressedParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<memory::SimulatePressureNotificationParams> {
  static std::unique_ptr<memory::SimulatePressureNotificationParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return memory::SimulatePressureNotificationParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const memory::SimulatePressureNotificationParams& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<page::ResourceType> {
  static page::ResourceType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return page::ResourceType::DOCUMENT;
    }
    if (string_value == "Document")
      return page::ResourceType::DOCUMENT;
    if (string_value == "Stylesheet")
      return page::ResourceType::STYLESHEET;
    if (string_value == "Image")
      return page::ResourceType::IMAGE;
    if (string_value == "Media")
      return page::ResourceType::MEDIA;
    if (string_value == "Font")
      return page::ResourceType::FONT;
    if (string_value == "Script")
      return page::ResourceType::SCRIPT;
    if (string_value == "TextTrack")
      return page::ResourceType::TEXT_TRACK;
    if (string_value == "XHR")
      return page::ResourceType::XHR;
    if (string_value == "Fetch")
      return page::ResourceType::FETCH;
    if (string_value == "EventSource")
      return page::ResourceType::EVENT_SOURCE;
    if (string_value == "WebSocket")
      return page::ResourceType::WEB_SOCKET;
    if (string_value == "Manifest")
      return page::ResourceType::MANIFEST;
    if (string_value == "Other")
      return page::ResourceType::OTHER;
    errors->AddError("invalid enum value");
    return page::ResourceType::DOCUMENT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::ResourceType& value, T*) {
  switch (value) {
    case page::ResourceType::DOCUMENT:
      return base::WrapUnique(new base::StringValue("Document"));
    case page::ResourceType::STYLESHEET:
      return base::WrapUnique(new base::StringValue("Stylesheet"));
    case page::ResourceType::IMAGE:
      return base::WrapUnique(new base::StringValue("Image"));
    case page::ResourceType::MEDIA:
      return base::WrapUnique(new base::StringValue("Media"));
    case page::ResourceType::FONT:
      return base::WrapUnique(new base::StringValue("Font"));
    case page::ResourceType::SCRIPT:
      return base::WrapUnique(new base::StringValue("Script"));
    case page::ResourceType::TEXT_TRACK:
      return base::WrapUnique(new base::StringValue("TextTrack"));
    case page::ResourceType::XHR:
      return base::WrapUnique(new base::StringValue("XHR"));
    case page::ResourceType::FETCH:
      return base::WrapUnique(new base::StringValue("Fetch"));
    case page::ResourceType::EVENT_SOURCE:
      return base::WrapUnique(new base::StringValue("EventSource"));
    case page::ResourceType::WEB_SOCKET:
      return base::WrapUnique(new base::StringValue("WebSocket"));
    case page::ResourceType::MANIFEST:
      return base::WrapUnique(new base::StringValue("Manifest"));
    case page::ResourceType::OTHER:
      return base::WrapUnique(new base::StringValue("Other"));
  };
  NOTREACHED();
  return nullptr;
}


template <>
struct FromValue<page::Frame> {
  static std::unique_ptr<page::Frame> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::Frame::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::Frame& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::FrameResource> {
  static std::unique_ptr<page::FrameResource> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::FrameResource::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::FrameResource& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::FrameResourceTree> {
  static std::unique_ptr<page::FrameResourceTree> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::FrameResourceTree::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::FrameResourceTree& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<page::NavigationEntry> {
  static std::unique_ptr<page::NavigationEntry> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::NavigationEntry::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::NavigationEntry& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::ScreencastFrameMetadata> {
  static std::unique_ptr<page::ScreencastFrameMetadata> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::ScreencastFrameMetadata::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::ScreencastFrameMetadata& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<page::DialogType> {
  static page::DialogType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return page::DialogType::ALERT;
    }
    if (string_value == "alert")
      return page::DialogType::ALERT;
    if (string_value == "confirm")
      return page::DialogType::CONFIRM;
    if (string_value == "prompt")
      return page::DialogType::PROMPT;
    if (string_value == "beforeunload")
      return page::DialogType::BEFOREUNLOAD;
    errors->AddError("invalid enum value");
    return page::DialogType::ALERT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::DialogType& value, T*) {
  switch (value) {
    case page::DialogType::ALERT:
      return base::WrapUnique(new base::StringValue("alert"));
    case page::DialogType::CONFIRM:
      return base::WrapUnique(new base::StringValue("confirm"));
    case page::DialogType::PROMPT:
      return base::WrapUnique(new base::StringValue("prompt"));
    case page::DialogType::BEFOREUNLOAD:
      return base::WrapUnique(new base::StringValue("beforeunload"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<page::AddScriptToEvaluateOnLoadParams> {
  static std::unique_ptr<page::AddScriptToEvaluateOnLoadParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::AddScriptToEvaluateOnLoadParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::AddScriptToEvaluateOnLoadParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::AddScriptToEvaluateOnLoadResult> {
  static std::unique_ptr<page::AddScriptToEvaluateOnLoadResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::AddScriptToEvaluateOnLoadResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::AddScriptToEvaluateOnLoadResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::RemoveScriptToEvaluateOnLoadParams> {
  static std::unique_ptr<page::RemoveScriptToEvaluateOnLoadParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::RemoveScriptToEvaluateOnLoadParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::RemoveScriptToEvaluateOnLoadParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SetAutoAttachToCreatedPagesParams> {
  static std::unique_ptr<page::SetAutoAttachToCreatedPagesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetAutoAttachToCreatedPagesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetAutoAttachToCreatedPagesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::ReloadParams> {
  static std::unique_ptr<page::ReloadParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::ReloadParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::ReloadParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::NavigateParams> {
  static std::unique_ptr<page::NavigateParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::NavigateParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::NavigateParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::NavigateResult> {
  static std::unique_ptr<page::NavigateResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::NavigateResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::NavigateResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::GetNavigationHistoryResult> {
  static std::unique_ptr<page::GetNavigationHistoryResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::GetNavigationHistoryResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::GetNavigationHistoryResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::NavigateToHistoryEntryParams> {
  static std::unique_ptr<page::NavigateToHistoryEntryParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::NavigateToHistoryEntryParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::NavigateToHistoryEntryParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::GetCookiesResult> {
  static std::unique_ptr<page::GetCookiesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::GetCookiesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::GetCookiesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::DeleteCookieParams> {
  static std::unique_ptr<page::DeleteCookieParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::DeleteCookieParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::DeleteCookieParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::GetResourceTreeResult> {
  static std::unique_ptr<page::GetResourceTreeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::GetResourceTreeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::GetResourceTreeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::GetResourceContentParams> {
  static std::unique_ptr<page::GetResourceContentParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::GetResourceContentParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::GetResourceContentParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::GetResourceContentResult> {
  static std::unique_ptr<page::GetResourceContentResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::GetResourceContentResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::GetResourceContentResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SearchInResourceParams> {
  static std::unique_ptr<page::SearchInResourceParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SearchInResourceParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SearchInResourceParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SearchInResourceResult> {
  static std::unique_ptr<page::SearchInResourceResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SearchInResourceResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SearchInResourceResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SetDocumentContentParams> {
  static std::unique_ptr<page::SetDocumentContentParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetDocumentContentParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetDocumentContentParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SetDeviceMetricsOverrideParams> {
  static std::unique_ptr<page::SetDeviceMetricsOverrideParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetDeviceMetricsOverrideParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetDeviceMetricsOverrideParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SetGeolocationOverrideParams> {
  static std::unique_ptr<page::SetGeolocationOverrideParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetGeolocationOverrideParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetGeolocationOverrideParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SetDeviceOrientationOverrideParams> {
  static std::unique_ptr<page::SetDeviceOrientationOverrideParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetDeviceOrientationOverrideParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetDeviceOrientationOverrideParams& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<page::SetTouchEmulationEnabledConfiguration> {
  static page::SetTouchEmulationEnabledConfiguration Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return page::SetTouchEmulationEnabledConfiguration::MOBILE;
    }
    if (string_value == "mobile")
      return page::SetTouchEmulationEnabledConfiguration::MOBILE;
    if (string_value == "desktop")
      return page::SetTouchEmulationEnabledConfiguration::DESKTOP;
    errors->AddError("invalid enum value");
    return page::SetTouchEmulationEnabledConfiguration::MOBILE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetTouchEmulationEnabledConfiguration& value, T*) {
  switch (value) {
    case page::SetTouchEmulationEnabledConfiguration::MOBILE:
      return base::WrapUnique(new base::StringValue("mobile"));
    case page::SetTouchEmulationEnabledConfiguration::DESKTOP:
      return base::WrapUnique(new base::StringValue("desktop"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<page::SetTouchEmulationEnabledParams> {
  static std::unique_ptr<page::SetTouchEmulationEnabledParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetTouchEmulationEnabledParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetTouchEmulationEnabledParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::CaptureScreenshotResult> {
  static std::unique_ptr<page::CaptureScreenshotResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::CaptureScreenshotResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::CaptureScreenshotResult& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<page::StartScreencastFormat> {
  static page::StartScreencastFormat Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return page::StartScreencastFormat::JPEG;
    }
    if (string_value == "jpeg")
      return page::StartScreencastFormat::JPEG;
    if (string_value == "png")
      return page::StartScreencastFormat::PNG;
    errors->AddError("invalid enum value");
    return page::StartScreencastFormat::JPEG;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::StartScreencastFormat& value, T*) {
  switch (value) {
    case page::StartScreencastFormat::JPEG:
      return base::WrapUnique(new base::StringValue("jpeg"));
    case page::StartScreencastFormat::PNG:
      return base::WrapUnique(new base::StringValue("png"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<page::StartScreencastParams> {
  static std::unique_ptr<page::StartScreencastParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::StartScreencastParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::StartScreencastParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::ScreencastFrameAckParams> {
  static std::unique_ptr<page::ScreencastFrameAckParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::ScreencastFrameAckParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::ScreencastFrameAckParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::HandleJavaScriptDialogParams> {
  static std::unique_ptr<page::HandleJavaScriptDialogParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::HandleJavaScriptDialogParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::HandleJavaScriptDialogParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SetColorPickerEnabledParams> {
  static std::unique_ptr<page::SetColorPickerEnabledParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetColorPickerEnabledParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetColorPickerEnabledParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<page::SetOverlayMessageParams> {
  static std::unique_ptr<page::SetOverlayMessageParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return page::SetOverlayMessageParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const page::SetOverlayMessageParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<rendering::SetShowPaintRectsParams> {
  static std::unique_ptr<rendering::SetShowPaintRectsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return rendering::SetShowPaintRectsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const rendering::SetShowPaintRectsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<rendering::SetShowDebugBordersParams> {
  static std::unique_ptr<rendering::SetShowDebugBordersParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return rendering::SetShowDebugBordersParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const rendering::SetShowDebugBordersParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<rendering::SetShowFPSCounterParams> {
  static std::unique_ptr<rendering::SetShowFPSCounterParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return rendering::SetShowFPSCounterParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const rendering::SetShowFPSCounterParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<rendering::SetShowScrollBottleneckRectsParams> {
  static std::unique_ptr<rendering::SetShowScrollBottleneckRectsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return rendering::SetShowScrollBottleneckRectsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const rendering::SetShowScrollBottleneckRectsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<rendering::SetShowViewportSizeOnResizeParams> {
  static std::unique_ptr<rendering::SetShowViewportSizeOnResizeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return rendering::SetShowViewportSizeOnResizeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const rendering::SetShowViewportSizeOnResizeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<emulation::ScreenOrientation> {
  static std::unique_ptr<emulation::ScreenOrientation> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::ScreenOrientation::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::ScreenOrientation& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<emulation::ScreenOrientationType> {
  static emulation::ScreenOrientationType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return emulation::ScreenOrientationType::PORTRAIT_PRIMARY;
    }
    if (string_value == "portraitPrimary")
      return emulation::ScreenOrientationType::PORTRAIT_PRIMARY;
    if (string_value == "portraitSecondary")
      return emulation::ScreenOrientationType::PORTRAIT_SECONDARY;
    if (string_value == "landscapePrimary")
      return emulation::ScreenOrientationType::LANDSCAPE_PRIMARY;
    if (string_value == "landscapeSecondary")
      return emulation::ScreenOrientationType::LANDSCAPE_SECONDARY;
    errors->AddError("invalid enum value");
    return emulation::ScreenOrientationType::PORTRAIT_PRIMARY;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::ScreenOrientationType& value, T*) {
  switch (value) {
    case emulation::ScreenOrientationType::PORTRAIT_PRIMARY:
      return base::WrapUnique(new base::StringValue("portraitPrimary"));
    case emulation::ScreenOrientationType::PORTRAIT_SECONDARY:
      return base::WrapUnique(new base::StringValue("portraitSecondary"));
    case emulation::ScreenOrientationType::LANDSCAPE_PRIMARY:
      return base::WrapUnique(new base::StringValue("landscapePrimary"));
    case emulation::ScreenOrientationType::LANDSCAPE_SECONDARY:
      return base::WrapUnique(new base::StringValue("landscapeSecondary"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<emulation::SetDeviceMetricsOverrideParams> {
  static std::unique_ptr<emulation::SetDeviceMetricsOverrideParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::SetDeviceMetricsOverrideParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetDeviceMetricsOverrideParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<emulation::SetPageScaleFactorParams> {
  static std::unique_ptr<emulation::SetPageScaleFactorParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::SetPageScaleFactorParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetPageScaleFactorParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<emulation::SetScriptExecutionDisabledParams> {
  static std::unique_ptr<emulation::SetScriptExecutionDisabledParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::SetScriptExecutionDisabledParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetScriptExecutionDisabledParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<emulation::SetGeolocationOverrideParams> {
  static std::unique_ptr<emulation::SetGeolocationOverrideParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::SetGeolocationOverrideParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetGeolocationOverrideParams& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<emulation::SetTouchEmulationEnabledConfiguration> {
  static emulation::SetTouchEmulationEnabledConfiguration Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return emulation::SetTouchEmulationEnabledConfiguration::MOBILE;
    }
    if (string_value == "mobile")
      return emulation::SetTouchEmulationEnabledConfiguration::MOBILE;
    if (string_value == "desktop")
      return emulation::SetTouchEmulationEnabledConfiguration::DESKTOP;
    errors->AddError("invalid enum value");
    return emulation::SetTouchEmulationEnabledConfiguration::MOBILE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetTouchEmulationEnabledConfiguration& value, T*) {
  switch (value) {
    case emulation::SetTouchEmulationEnabledConfiguration::MOBILE:
      return base::WrapUnique(new base::StringValue("mobile"));
    case emulation::SetTouchEmulationEnabledConfiguration::DESKTOP:
      return base::WrapUnique(new base::StringValue("desktop"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<emulation::SetTouchEmulationEnabledParams> {
  static std::unique_ptr<emulation::SetTouchEmulationEnabledParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::SetTouchEmulationEnabledParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetTouchEmulationEnabledParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<emulation::SetEmulatedMediaParams> {
  static std::unique_ptr<emulation::SetEmulatedMediaParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::SetEmulatedMediaParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetEmulatedMediaParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<emulation::SetCPUThrottlingRateParams> {
  static std::unique_ptr<emulation::SetCPUThrottlingRateParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::SetCPUThrottlingRateParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::SetCPUThrottlingRateParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<emulation::CanEmulateResult> {
  static std::unique_ptr<emulation::CanEmulateResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return emulation::CanEmulateResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const emulation::CanEmulateResult& value, T*) {
  return value.Serialize();
}




template <>
struct FromValue<runtime::RemoteObject> {
  static std::unique_ptr<runtime::RemoteObject> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::RemoteObject::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::RemoteObject& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::CustomPreview> {
  static std::unique_ptr<runtime::CustomPreview> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::CustomPreview::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CustomPreview& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::ObjectPreview> {
  static std::unique_ptr<runtime::ObjectPreview> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::ObjectPreview::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::ObjectPreview& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::PropertyPreview> {
  static std::unique_ptr<runtime::PropertyPreview> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::PropertyPreview::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::PropertyPreview& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::EntryPreview> {
  static std::unique_ptr<runtime::EntryPreview> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::EntryPreview::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::EntryPreview& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::PropertyDescriptor> {
  static std::unique_ptr<runtime::PropertyDescriptor> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::PropertyDescriptor::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::PropertyDescriptor& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::InternalPropertyDescriptor> {
  static std::unique_ptr<runtime::InternalPropertyDescriptor> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::InternalPropertyDescriptor::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::InternalPropertyDescriptor& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::CallArgument> {
  static std::unique_ptr<runtime::CallArgument> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::CallArgument::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CallArgument& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<runtime::ExecutionContextDescription> {
  static std::unique_ptr<runtime::ExecutionContextDescription> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::ExecutionContextDescription::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::ExecutionContextDescription& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::ExceptionDetails> {
  static std::unique_ptr<runtime::ExceptionDetails> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::ExceptionDetails::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::ExceptionDetails& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::CallFrame> {
  static std::unique_ptr<runtime::CallFrame> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::CallFrame::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CallFrame& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::StackTrace> {
  static std::unique_ptr<runtime::StackTrace> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::StackTrace::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::StackTrace& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<runtime::RemoteObjectType> {
  static runtime::RemoteObjectType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return runtime::RemoteObjectType::OBJECT;
    }
    if (string_value == "object")
      return runtime::RemoteObjectType::OBJECT;
    if (string_value == "function")
      return runtime::RemoteObjectType::FUNCTION;
    if (string_value == "undefined")
      return runtime::RemoteObjectType::UNDEFINED;
    if (string_value == "string")
      return runtime::RemoteObjectType::STRING;
    if (string_value == "number")
      return runtime::RemoteObjectType::NUMBER;
    if (string_value == "boolean")
      return runtime::RemoteObjectType::BOOLEAN;
    if (string_value == "symbol")
      return runtime::RemoteObjectType::SYMBOL;
    errors->AddError("invalid enum value");
    return runtime::RemoteObjectType::OBJECT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::RemoteObjectType& value, T*) {
  switch (value) {
    case runtime::RemoteObjectType::OBJECT:
      return base::WrapUnique(new base::StringValue("object"));
    case runtime::RemoteObjectType::FUNCTION:
      return base::WrapUnique(new base::StringValue("function"));
    case runtime::RemoteObjectType::UNDEFINED:
      return base::WrapUnique(new base::StringValue("undefined"));
    case runtime::RemoteObjectType::STRING:
      return base::WrapUnique(new base::StringValue("string"));
    case runtime::RemoteObjectType::NUMBER:
      return base::WrapUnique(new base::StringValue("number"));
    case runtime::RemoteObjectType::BOOLEAN:
      return base::WrapUnique(new base::StringValue("boolean"));
    case runtime::RemoteObjectType::SYMBOL:
      return base::WrapUnique(new base::StringValue("symbol"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<runtime::RemoteObjectSubtype> {
  static runtime::RemoteObjectSubtype Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return runtime::RemoteObjectSubtype::ARRAY;
    }
    if (string_value == "array")
      return runtime::RemoteObjectSubtype::ARRAY;
    if (string_value == "null")
      return runtime::RemoteObjectSubtype::NONE;
    if (string_value == "node")
      return runtime::RemoteObjectSubtype::NODE;
    if (string_value == "regexp")
      return runtime::RemoteObjectSubtype::REGEXP;
    if (string_value == "date")
      return runtime::RemoteObjectSubtype::DATE;
    if (string_value == "map")
      return runtime::RemoteObjectSubtype::MAP;
    if (string_value == "set")
      return runtime::RemoteObjectSubtype::SET;
    if (string_value == "iterator")
      return runtime::RemoteObjectSubtype::ITERATOR;
    if (string_value == "generator")
      return runtime::RemoteObjectSubtype::GENERATOR;
    if (string_value == "error")
      return runtime::RemoteObjectSubtype::ERROR;
    errors->AddError("invalid enum value");
    return runtime::RemoteObjectSubtype::ARRAY;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::RemoteObjectSubtype& value, T*) {
  switch (value) {
    case runtime::RemoteObjectSubtype::ARRAY:
      return base::WrapUnique(new base::StringValue("array"));
    case runtime::RemoteObjectSubtype::NONE:
      return base::WrapUnique(new base::StringValue("null"));
    case runtime::RemoteObjectSubtype::NODE:
      return base::WrapUnique(new base::StringValue("node"));
    case runtime::RemoteObjectSubtype::REGEXP:
      return base::WrapUnique(new base::StringValue("regexp"));
    case runtime::RemoteObjectSubtype::DATE:
      return base::WrapUnique(new base::StringValue("date"));
    case runtime::RemoteObjectSubtype::MAP:
      return base::WrapUnique(new base::StringValue("map"));
    case runtime::RemoteObjectSubtype::SET:
      return base::WrapUnique(new base::StringValue("set"));
    case runtime::RemoteObjectSubtype::ITERATOR:
      return base::WrapUnique(new base::StringValue("iterator"));
    case runtime::RemoteObjectSubtype::GENERATOR:
      return base::WrapUnique(new base::StringValue("generator"));
    case runtime::RemoteObjectSubtype::ERROR:
      return base::WrapUnique(new base::StringValue("error"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<runtime::ObjectPreviewType> {
  static runtime::ObjectPreviewType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return runtime::ObjectPreviewType::OBJECT;
    }
    if (string_value == "object")
      return runtime::ObjectPreviewType::OBJECT;
    if (string_value == "function")
      return runtime::ObjectPreviewType::FUNCTION;
    if (string_value == "undefined")
      return runtime::ObjectPreviewType::UNDEFINED;
    if (string_value == "string")
      return runtime::ObjectPreviewType::STRING;
    if (string_value == "number")
      return runtime::ObjectPreviewType::NUMBER;
    if (string_value == "boolean")
      return runtime::ObjectPreviewType::BOOLEAN;
    if (string_value == "symbol")
      return runtime::ObjectPreviewType::SYMBOL;
    errors->AddError("invalid enum value");
    return runtime::ObjectPreviewType::OBJECT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::ObjectPreviewType& value, T*) {
  switch (value) {
    case runtime::ObjectPreviewType::OBJECT:
      return base::WrapUnique(new base::StringValue("object"));
    case runtime::ObjectPreviewType::FUNCTION:
      return base::WrapUnique(new base::StringValue("function"));
    case runtime::ObjectPreviewType::UNDEFINED:
      return base::WrapUnique(new base::StringValue("undefined"));
    case runtime::ObjectPreviewType::STRING:
      return base::WrapUnique(new base::StringValue("string"));
    case runtime::ObjectPreviewType::NUMBER:
      return base::WrapUnique(new base::StringValue("number"));
    case runtime::ObjectPreviewType::BOOLEAN:
      return base::WrapUnique(new base::StringValue("boolean"));
    case runtime::ObjectPreviewType::SYMBOL:
      return base::WrapUnique(new base::StringValue("symbol"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<runtime::ObjectPreviewSubtype> {
  static runtime::ObjectPreviewSubtype Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return runtime::ObjectPreviewSubtype::ARRAY;
    }
    if (string_value == "array")
      return runtime::ObjectPreviewSubtype::ARRAY;
    if (string_value == "null")
      return runtime::ObjectPreviewSubtype::NONE;
    if (string_value == "node")
      return runtime::ObjectPreviewSubtype::NODE;
    if (string_value == "regexp")
      return runtime::ObjectPreviewSubtype::REGEXP;
    if (string_value == "date")
      return runtime::ObjectPreviewSubtype::DATE;
    if (string_value == "map")
      return runtime::ObjectPreviewSubtype::MAP;
    if (string_value == "set")
      return runtime::ObjectPreviewSubtype::SET;
    if (string_value == "iterator")
      return runtime::ObjectPreviewSubtype::ITERATOR;
    if (string_value == "generator")
      return runtime::ObjectPreviewSubtype::GENERATOR;
    if (string_value == "error")
      return runtime::ObjectPreviewSubtype::ERROR;
    errors->AddError("invalid enum value");
    return runtime::ObjectPreviewSubtype::ARRAY;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::ObjectPreviewSubtype& value, T*) {
  switch (value) {
    case runtime::ObjectPreviewSubtype::ARRAY:
      return base::WrapUnique(new base::StringValue("array"));
    case runtime::ObjectPreviewSubtype::NONE:
      return base::WrapUnique(new base::StringValue("null"));
    case runtime::ObjectPreviewSubtype::NODE:
      return base::WrapUnique(new base::StringValue("node"));
    case runtime::ObjectPreviewSubtype::REGEXP:
      return base::WrapUnique(new base::StringValue("regexp"));
    case runtime::ObjectPreviewSubtype::DATE:
      return base::WrapUnique(new base::StringValue("date"));
    case runtime::ObjectPreviewSubtype::MAP:
      return base::WrapUnique(new base::StringValue("map"));
    case runtime::ObjectPreviewSubtype::SET:
      return base::WrapUnique(new base::StringValue("set"));
    case runtime::ObjectPreviewSubtype::ITERATOR:
      return base::WrapUnique(new base::StringValue("iterator"));
    case runtime::ObjectPreviewSubtype::GENERATOR:
      return base::WrapUnique(new base::StringValue("generator"));
    case runtime::ObjectPreviewSubtype::ERROR:
      return base::WrapUnique(new base::StringValue("error"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<runtime::PropertyPreviewType> {
  static runtime::PropertyPreviewType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return runtime::PropertyPreviewType::OBJECT;
    }
    if (string_value == "object")
      return runtime::PropertyPreviewType::OBJECT;
    if (string_value == "function")
      return runtime::PropertyPreviewType::FUNCTION;
    if (string_value == "undefined")
      return runtime::PropertyPreviewType::UNDEFINED;
    if (string_value == "string")
      return runtime::PropertyPreviewType::STRING;
    if (string_value == "number")
      return runtime::PropertyPreviewType::NUMBER;
    if (string_value == "boolean")
      return runtime::PropertyPreviewType::BOOLEAN;
    if (string_value == "symbol")
      return runtime::PropertyPreviewType::SYMBOL;
    if (string_value == "accessor")
      return runtime::PropertyPreviewType::ACCESSOR;
    errors->AddError("invalid enum value");
    return runtime::PropertyPreviewType::OBJECT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::PropertyPreviewType& value, T*) {
  switch (value) {
    case runtime::PropertyPreviewType::OBJECT:
      return base::WrapUnique(new base::StringValue("object"));
    case runtime::PropertyPreviewType::FUNCTION:
      return base::WrapUnique(new base::StringValue("function"));
    case runtime::PropertyPreviewType::UNDEFINED:
      return base::WrapUnique(new base::StringValue("undefined"));
    case runtime::PropertyPreviewType::STRING:
      return base::WrapUnique(new base::StringValue("string"));
    case runtime::PropertyPreviewType::NUMBER:
      return base::WrapUnique(new base::StringValue("number"));
    case runtime::PropertyPreviewType::BOOLEAN:
      return base::WrapUnique(new base::StringValue("boolean"));
    case runtime::PropertyPreviewType::SYMBOL:
      return base::WrapUnique(new base::StringValue("symbol"));
    case runtime::PropertyPreviewType::ACCESSOR:
      return base::WrapUnique(new base::StringValue("accessor"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<runtime::PropertyPreviewSubtype> {
  static runtime::PropertyPreviewSubtype Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return runtime::PropertyPreviewSubtype::ARRAY;
    }
    if (string_value == "array")
      return runtime::PropertyPreviewSubtype::ARRAY;
    if (string_value == "null")
      return runtime::PropertyPreviewSubtype::NONE;
    if (string_value == "node")
      return runtime::PropertyPreviewSubtype::NODE;
    if (string_value == "regexp")
      return runtime::PropertyPreviewSubtype::REGEXP;
    if (string_value == "date")
      return runtime::PropertyPreviewSubtype::DATE;
    if (string_value == "map")
      return runtime::PropertyPreviewSubtype::MAP;
    if (string_value == "set")
      return runtime::PropertyPreviewSubtype::SET;
    if (string_value == "iterator")
      return runtime::PropertyPreviewSubtype::ITERATOR;
    if (string_value == "generator")
      return runtime::PropertyPreviewSubtype::GENERATOR;
    if (string_value == "error")
      return runtime::PropertyPreviewSubtype::ERROR;
    errors->AddError("invalid enum value");
    return runtime::PropertyPreviewSubtype::ARRAY;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::PropertyPreviewSubtype& value, T*) {
  switch (value) {
    case runtime::PropertyPreviewSubtype::ARRAY:
      return base::WrapUnique(new base::StringValue("array"));
    case runtime::PropertyPreviewSubtype::NONE:
      return base::WrapUnique(new base::StringValue("null"));
    case runtime::PropertyPreviewSubtype::NODE:
      return base::WrapUnique(new base::StringValue("node"));
    case runtime::PropertyPreviewSubtype::REGEXP:
      return base::WrapUnique(new base::StringValue("regexp"));
    case runtime::PropertyPreviewSubtype::DATE:
      return base::WrapUnique(new base::StringValue("date"));
    case runtime::PropertyPreviewSubtype::MAP:
      return base::WrapUnique(new base::StringValue("map"));
    case runtime::PropertyPreviewSubtype::SET:
      return base::WrapUnique(new base::StringValue("set"));
    case runtime::PropertyPreviewSubtype::ITERATOR:
      return base::WrapUnique(new base::StringValue("iterator"));
    case runtime::PropertyPreviewSubtype::GENERATOR:
      return base::WrapUnique(new base::StringValue("generator"));
    case runtime::PropertyPreviewSubtype::ERROR:
      return base::WrapUnique(new base::StringValue("error"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<runtime::CallArgumentType> {
  static runtime::CallArgumentType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return runtime::CallArgumentType::OBJECT;
    }
    if (string_value == "object")
      return runtime::CallArgumentType::OBJECT;
    if (string_value == "function")
      return runtime::CallArgumentType::FUNCTION;
    if (string_value == "undefined")
      return runtime::CallArgumentType::UNDEFINED;
    if (string_value == "string")
      return runtime::CallArgumentType::STRING;
    if (string_value == "number")
      return runtime::CallArgumentType::NUMBER;
    if (string_value == "boolean")
      return runtime::CallArgumentType::BOOLEAN;
    if (string_value == "symbol")
      return runtime::CallArgumentType::SYMBOL;
    errors->AddError("invalid enum value");
    return runtime::CallArgumentType::OBJECT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CallArgumentType& value, T*) {
  switch (value) {
    case runtime::CallArgumentType::OBJECT:
      return base::WrapUnique(new base::StringValue("object"));
    case runtime::CallArgumentType::FUNCTION:
      return base::WrapUnique(new base::StringValue("function"));
    case runtime::CallArgumentType::UNDEFINED:
      return base::WrapUnique(new base::StringValue("undefined"));
    case runtime::CallArgumentType::STRING:
      return base::WrapUnique(new base::StringValue("string"));
    case runtime::CallArgumentType::NUMBER:
      return base::WrapUnique(new base::StringValue("number"));
    case runtime::CallArgumentType::BOOLEAN:
      return base::WrapUnique(new base::StringValue("boolean"));
    case runtime::CallArgumentType::SYMBOL:
      return base::WrapUnique(new base::StringValue("symbol"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<runtime::EvaluateParams> {
  static std::unique_ptr<runtime::EvaluateParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::EvaluateParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::EvaluateParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::EvaluateResult> {
  static std::unique_ptr<runtime::EvaluateResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::EvaluateResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::EvaluateResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::CallFunctionOnParams> {
  static std::unique_ptr<runtime::CallFunctionOnParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::CallFunctionOnParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CallFunctionOnParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::CallFunctionOnResult> {
  static std::unique_ptr<runtime::CallFunctionOnResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::CallFunctionOnResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CallFunctionOnResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::GetPropertiesParams> {
  static std::unique_ptr<runtime::GetPropertiesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::GetPropertiesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::GetPropertiesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::GetPropertiesResult> {
  static std::unique_ptr<runtime::GetPropertiesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::GetPropertiesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::GetPropertiesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::ReleaseObjectParams> {
  static std::unique_ptr<runtime::ReleaseObjectParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::ReleaseObjectParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::ReleaseObjectParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::ReleaseObjectGroupParams> {
  static std::unique_ptr<runtime::ReleaseObjectGroupParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::ReleaseObjectGroupParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::ReleaseObjectGroupParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::SetCustomObjectFormatterEnabledParams> {
  static std::unique_ptr<runtime::SetCustomObjectFormatterEnabledParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::SetCustomObjectFormatterEnabledParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::SetCustomObjectFormatterEnabledParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::CompileScriptParams> {
  static std::unique_ptr<runtime::CompileScriptParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::CompileScriptParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CompileScriptParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::CompileScriptResult> {
  static std::unique_ptr<runtime::CompileScriptResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::CompileScriptResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::CompileScriptResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::RunScriptParams> {
  static std::unique_ptr<runtime::RunScriptParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::RunScriptParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::RunScriptParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<runtime::RunScriptResult> {
  static std::unique_ptr<runtime::RunScriptResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return runtime::RunScriptResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const runtime::RunScriptResult& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<console::ConsoleMessage> {
  static std::unique_ptr<console::ConsoleMessage> Parse(const base::Value& value, ErrorReporter* errors) {
    return console::ConsoleMessage::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const console::ConsoleMessage& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<console::ConsoleMessageSource> {
  static console::ConsoleMessageSource Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return console::ConsoleMessageSource::XML;
    }
    if (string_value == "xml")
      return console::ConsoleMessageSource::XML;
    if (string_value == "javascript")
      return console::ConsoleMessageSource::JAVASCRIPT;
    if (string_value == "network")
      return console::ConsoleMessageSource::NETWORK;
    if (string_value == "console-api")
      return console::ConsoleMessageSource::CONSOLE_API;
    if (string_value == "storage")
      return console::ConsoleMessageSource::STORAGE;
    if (string_value == "appcache")
      return console::ConsoleMessageSource::APPCACHE;
    if (string_value == "rendering")
      return console::ConsoleMessageSource::RENDERING;
    if (string_value == "security")
      return console::ConsoleMessageSource::SECURITY;
    if (string_value == "other")
      return console::ConsoleMessageSource::OTHER;
    if (string_value == "deprecation")
      return console::ConsoleMessageSource::DEPRECATION;
    errors->AddError("invalid enum value");
    return console::ConsoleMessageSource::XML;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const console::ConsoleMessageSource& value, T*) {
  switch (value) {
    case console::ConsoleMessageSource::XML:
      return base::WrapUnique(new base::StringValue("xml"));
    case console::ConsoleMessageSource::JAVASCRIPT:
      return base::WrapUnique(new base::StringValue("javascript"));
    case console::ConsoleMessageSource::NETWORK:
      return base::WrapUnique(new base::StringValue("network"));
    case console::ConsoleMessageSource::CONSOLE_API:
      return base::WrapUnique(new base::StringValue("console-api"));
    case console::ConsoleMessageSource::STORAGE:
      return base::WrapUnique(new base::StringValue("storage"));
    case console::ConsoleMessageSource::APPCACHE:
      return base::WrapUnique(new base::StringValue("appcache"));
    case console::ConsoleMessageSource::RENDERING:
      return base::WrapUnique(new base::StringValue("rendering"));
    case console::ConsoleMessageSource::SECURITY:
      return base::WrapUnique(new base::StringValue("security"));
    case console::ConsoleMessageSource::OTHER:
      return base::WrapUnique(new base::StringValue("other"));
    case console::ConsoleMessageSource::DEPRECATION:
      return base::WrapUnique(new base::StringValue("deprecation"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<console::ConsoleMessageLevel> {
  static console::ConsoleMessageLevel Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return console::ConsoleMessageLevel::LOG;
    }
    if (string_value == "log")
      return console::ConsoleMessageLevel::LOG;
    if (string_value == "warning")
      return console::ConsoleMessageLevel::WARNING;
    if (string_value == "error")
      return console::ConsoleMessageLevel::ERROR;
    if (string_value == "debug")
      return console::ConsoleMessageLevel::DEBUG;
    if (string_value == "info")
      return console::ConsoleMessageLevel::INFO;
    if (string_value == "revokedError")
      return console::ConsoleMessageLevel::REVOKED_ERROR;
    errors->AddError("invalid enum value");
    return console::ConsoleMessageLevel::LOG;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const console::ConsoleMessageLevel& value, T*) {
  switch (value) {
    case console::ConsoleMessageLevel::LOG:
      return base::WrapUnique(new base::StringValue("log"));
    case console::ConsoleMessageLevel::WARNING:
      return base::WrapUnique(new base::StringValue("warning"));
    case console::ConsoleMessageLevel::ERROR:
      return base::WrapUnique(new base::StringValue("error"));
    case console::ConsoleMessageLevel::DEBUG:
      return base::WrapUnique(new base::StringValue("debug"));
    case console::ConsoleMessageLevel::INFO:
      return base::WrapUnique(new base::StringValue("info"));
    case console::ConsoleMessageLevel::REVOKED_ERROR:
      return base::WrapUnique(new base::StringValue("revokedError"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<console::ConsoleMessageType> {
  static console::ConsoleMessageType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return console::ConsoleMessageType::LOG;
    }
    if (string_value == "log")
      return console::ConsoleMessageType::LOG;
    if (string_value == "dir")
      return console::ConsoleMessageType::DIR;
    if (string_value == "dirxml")
      return console::ConsoleMessageType::DIRXML;
    if (string_value == "table")
      return console::ConsoleMessageType::TABLE;
    if (string_value == "trace")
      return console::ConsoleMessageType::TRACE;
    if (string_value == "clear")
      return console::ConsoleMessageType::CLEAR;
    if (string_value == "startGroup")
      return console::ConsoleMessageType::START_GROUP;
    if (string_value == "startGroupCollapsed")
      return console::ConsoleMessageType::START_GROUP_COLLAPSED;
    if (string_value == "endGroup")
      return console::ConsoleMessageType::END_GROUP;
    if (string_value == "assert")
      return console::ConsoleMessageType::ASSERT;
    if (string_value == "profile")
      return console::ConsoleMessageType::PROFILE;
    if (string_value == "profileEnd")
      return console::ConsoleMessageType::PROFILE_END;
    errors->AddError("invalid enum value");
    return console::ConsoleMessageType::LOG;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const console::ConsoleMessageType& value, T*) {
  switch (value) {
    case console::ConsoleMessageType::LOG:
      return base::WrapUnique(new base::StringValue("log"));
    case console::ConsoleMessageType::DIR:
      return base::WrapUnique(new base::StringValue("dir"));
    case console::ConsoleMessageType::DIRXML:
      return base::WrapUnique(new base::StringValue("dirxml"));
    case console::ConsoleMessageType::TABLE:
      return base::WrapUnique(new base::StringValue("table"));
    case console::ConsoleMessageType::TRACE:
      return base::WrapUnique(new base::StringValue("trace"));
    case console::ConsoleMessageType::CLEAR:
      return base::WrapUnique(new base::StringValue("clear"));
    case console::ConsoleMessageType::START_GROUP:
      return base::WrapUnique(new base::StringValue("startGroup"));
    case console::ConsoleMessageType::START_GROUP_COLLAPSED:
      return base::WrapUnique(new base::StringValue("startGroupCollapsed"));
    case console::ConsoleMessageType::END_GROUP:
      return base::WrapUnique(new base::StringValue("endGroup"));
    case console::ConsoleMessageType::ASSERT:
      return base::WrapUnique(new base::StringValue("assert"));
    case console::ConsoleMessageType::PROFILE:
      return base::WrapUnique(new base::StringValue("profile"));
    case console::ConsoleMessageType::PROFILE_END:
      return base::WrapUnique(new base::StringValue("profileEnd"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<security::SecurityState> {
  static security::SecurityState Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return security::SecurityState::UNKNOWN;
    }
    if (string_value == "unknown")
      return security::SecurityState::UNKNOWN;
    if (string_value == "neutral")
      return security::SecurityState::NEUTRAL;
    if (string_value == "insecure")
      return security::SecurityState::INSECURE;
    if (string_value == "warning")
      return security::SecurityState::WARNING;
    if (string_value == "secure")
      return security::SecurityState::SECURE;
    if (string_value == "info")
      return security::SecurityState::INFO;
    errors->AddError("invalid enum value");
    return security::SecurityState::UNKNOWN;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const security::SecurityState& value, T*) {
  switch (value) {
    case security::SecurityState::UNKNOWN:
      return base::WrapUnique(new base::StringValue("unknown"));
    case security::SecurityState::NEUTRAL:
      return base::WrapUnique(new base::StringValue("neutral"));
    case security::SecurityState::INSECURE:
      return base::WrapUnique(new base::StringValue("insecure"));
    case security::SecurityState::WARNING:
      return base::WrapUnique(new base::StringValue("warning"));
    case security::SecurityState::SECURE:
      return base::WrapUnique(new base::StringValue("secure"));
    case security::SecurityState::INFO:
      return base::WrapUnique(new base::StringValue("info"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<security::SecurityStateExplanation> {
  static std::unique_ptr<security::SecurityStateExplanation> Parse(const base::Value& value, ErrorReporter* errors) {
    return security::SecurityStateExplanation::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const security::SecurityStateExplanation& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<security::MixedContentStatus> {
  static std::unique_ptr<security::MixedContentStatus> Parse(const base::Value& value, ErrorReporter* errors) {
    return security::MixedContentStatus::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const security::MixedContentStatus& value, T*) {
  return value.Serialize();
}






template <>
struct FromValue<network::ResourceTiming> {
  static std::unique_ptr<network::ResourceTiming> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::ResourceTiming::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::ResourceTiming& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<network::ResourcePriority> {
  static network::ResourcePriority Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return network::ResourcePriority::VERY_LOW;
    }
    if (string_value == "VeryLow")
      return network::ResourcePriority::VERY_LOW;
    if (string_value == "Low")
      return network::ResourcePriority::LOW;
    if (string_value == "Medium")
      return network::ResourcePriority::MEDIUM;
    if (string_value == "High")
      return network::ResourcePriority::HIGH;
    if (string_value == "VeryHigh")
      return network::ResourcePriority::VERY_HIGH;
    errors->AddError("invalid enum value");
    return network::ResourcePriority::VERY_LOW;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::ResourcePriority& value, T*) {
  switch (value) {
    case network::ResourcePriority::VERY_LOW:
      return base::WrapUnique(new base::StringValue("VeryLow"));
    case network::ResourcePriority::LOW:
      return base::WrapUnique(new base::StringValue("Low"));
    case network::ResourcePriority::MEDIUM:
      return base::WrapUnique(new base::StringValue("Medium"));
    case network::ResourcePriority::HIGH:
      return base::WrapUnique(new base::StringValue("High"));
    case network::ResourcePriority::VERY_HIGH:
      return base::WrapUnique(new base::StringValue("VeryHigh"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<network::Request> {
  static std::unique_ptr<network::Request> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::Request::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::Request& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<network::CertificateSubject> {
  static std::unique_ptr<network::CertificateSubject> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::CertificateSubject::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CertificateSubject& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::CertificateDetails> {
  static std::unique_ptr<network::CertificateDetails> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::CertificateDetails::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CertificateDetails& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::CertificateValidationDetails> {
  static std::unique_ptr<network::CertificateValidationDetails> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::CertificateValidationDetails::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CertificateValidationDetails& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::SecurityDetails> {
  static std::unique_ptr<network::SecurityDetails> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::SecurityDetails::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::SecurityDetails& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<network::BlockedReason> {
  static network::BlockedReason Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return network::BlockedReason::CSP;
    }
    if (string_value == "csp")
      return network::BlockedReason::CSP;
    if (string_value == "mixed-content")
      return network::BlockedReason::MIXED_CONTENT;
    if (string_value == "origin")
      return network::BlockedReason::ORIGIN;
    if (string_value == "inspector")
      return network::BlockedReason::INSPECTOR;
    if (string_value == "other")
      return network::BlockedReason::OTHER;
    errors->AddError("invalid enum value");
    return network::BlockedReason::CSP;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::BlockedReason& value, T*) {
  switch (value) {
    case network::BlockedReason::CSP:
      return base::WrapUnique(new base::StringValue("csp"));
    case network::BlockedReason::MIXED_CONTENT:
      return base::WrapUnique(new base::StringValue("mixed-content"));
    case network::BlockedReason::ORIGIN:
      return base::WrapUnique(new base::StringValue("origin"));
    case network::BlockedReason::INSPECTOR:
      return base::WrapUnique(new base::StringValue("inspector"));
    case network::BlockedReason::OTHER:
      return base::WrapUnique(new base::StringValue("other"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<network::Response> {
  static std::unique_ptr<network::Response> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::Response::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::Response& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::WebSocketRequest> {
  static std::unique_ptr<network::WebSocketRequest> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::WebSocketRequest::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::WebSocketRequest& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::WebSocketResponse> {
  static std::unique_ptr<network::WebSocketResponse> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::WebSocketResponse::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::WebSocketResponse& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::WebSocketFrame> {
  static std::unique_ptr<network::WebSocketFrame> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::WebSocketFrame::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::WebSocketFrame& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::CachedResource> {
  static std::unique_ptr<network::CachedResource> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::CachedResource::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CachedResource& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::Initiator> {
  static std::unique_ptr<network::Initiator> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::Initiator::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::Initiator& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::Cookie> {
  static std::unique_ptr<network::Cookie> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::Cookie::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::Cookie& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<network::RequestMixedContentType> {
  static network::RequestMixedContentType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return network::RequestMixedContentType::BLOCKABLE;
    }
    if (string_value == "blockable")
      return network::RequestMixedContentType::BLOCKABLE;
    if (string_value == "optionally-blockable")
      return network::RequestMixedContentType::OPTIONALLY_BLOCKABLE;
    if (string_value == "none")
      return network::RequestMixedContentType::NONE;
    errors->AddError("invalid enum value");
    return network::RequestMixedContentType::BLOCKABLE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::RequestMixedContentType& value, T*) {
  switch (value) {
    case network::RequestMixedContentType::BLOCKABLE:
      return base::WrapUnique(new base::StringValue("blockable"));
    case network::RequestMixedContentType::OPTIONALLY_BLOCKABLE:
      return base::WrapUnique(new base::StringValue("optionally-blockable"));
    case network::RequestMixedContentType::NONE:
      return base::WrapUnique(new base::StringValue("none"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<network::InitiatorType> {
  static network::InitiatorType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return network::InitiatorType::PARSER;
    }
    if (string_value == "parser")
      return network::InitiatorType::PARSER;
    if (string_value == "script")
      return network::InitiatorType::SCRIPT;
    if (string_value == "other")
      return network::InitiatorType::OTHER;
    errors->AddError("invalid enum value");
    return network::InitiatorType::PARSER;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::InitiatorType& value, T*) {
  switch (value) {
    case network::InitiatorType::PARSER:
      return base::WrapUnique(new base::StringValue("parser"));
    case network::InitiatorType::SCRIPT:
      return base::WrapUnique(new base::StringValue("script"));
    case network::InitiatorType::OTHER:
      return base::WrapUnique(new base::StringValue("other"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<network::CookieSameSite> {
  static network::CookieSameSite Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return network::CookieSameSite::STRICT;
    }
    if (string_value == "Strict")
      return network::CookieSameSite::STRICT;
    if (string_value == "Lax")
      return network::CookieSameSite::LAX;
    errors->AddError("invalid enum value");
    return network::CookieSameSite::STRICT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CookieSameSite& value, T*) {
  switch (value) {
    case network::CookieSameSite::STRICT:
      return base::WrapUnique(new base::StringValue("Strict"));
    case network::CookieSameSite::LAX:
      return base::WrapUnique(new base::StringValue("Lax"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<network::EnableParams> {
  static std::unique_ptr<network::EnableParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::EnableParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::EnableParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::SetUserAgentOverrideParams> {
  static std::unique_ptr<network::SetUserAgentOverrideParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::SetUserAgentOverrideParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::SetUserAgentOverrideParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::SetExtraHTTPHeadersParams> {
  static std::unique_ptr<network::SetExtraHTTPHeadersParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::SetExtraHTTPHeadersParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::SetExtraHTTPHeadersParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::GetResponseBodyParams> {
  static std::unique_ptr<network::GetResponseBodyParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::GetResponseBodyParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::GetResponseBodyParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::GetResponseBodyResult> {
  static std::unique_ptr<network::GetResponseBodyResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::GetResponseBodyResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::GetResponseBodyResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::AddBlockedURLParams> {
  static std::unique_ptr<network::AddBlockedURLParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::AddBlockedURLParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::AddBlockedURLParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::RemoveBlockedURLParams> {
  static std::unique_ptr<network::RemoveBlockedURLParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::RemoveBlockedURLParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::RemoveBlockedURLParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::ReplayXHRParams> {
  static std::unique_ptr<network::ReplayXHRParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::ReplayXHRParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::ReplayXHRParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::SetMonitoringXHREnabledParams> {
  static std::unique_ptr<network::SetMonitoringXHREnabledParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::SetMonitoringXHREnabledParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::SetMonitoringXHREnabledParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::CanClearBrowserCacheResult> {
  static std::unique_ptr<network::CanClearBrowserCacheResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::CanClearBrowserCacheResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CanClearBrowserCacheResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::CanClearBrowserCookiesResult> {
  static std::unique_ptr<network::CanClearBrowserCookiesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::CanClearBrowserCookiesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CanClearBrowserCookiesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::GetCookiesResult> {
  static std::unique_ptr<network::GetCookiesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::GetCookiesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::GetCookiesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::DeleteCookieParams> {
  static std::unique_ptr<network::DeleteCookieParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::DeleteCookieParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::DeleteCookieParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::CanEmulateNetworkConditionsResult> {
  static std::unique_ptr<network::CanEmulateNetworkConditionsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::CanEmulateNetworkConditionsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::CanEmulateNetworkConditionsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::EmulateNetworkConditionsParams> {
  static std::unique_ptr<network::EmulateNetworkConditionsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::EmulateNetworkConditionsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::EmulateNetworkConditionsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::SetCacheDisabledParams> {
  static std::unique_ptr<network::SetCacheDisabledParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::SetCacheDisabledParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::SetCacheDisabledParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::SetDataSizeLimitsForTestParams> {
  static std::unique_ptr<network::SetDataSizeLimitsForTestParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::SetDataSizeLimitsForTestParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::SetDataSizeLimitsForTestParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::GetCertificateDetailsParams> {
  static std::unique_ptr<network::GetCertificateDetailsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::GetCertificateDetailsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::GetCertificateDetailsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::GetCertificateDetailsResult> {
  static std::unique_ptr<network::GetCertificateDetailsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::GetCertificateDetailsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::GetCertificateDetailsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<network::ShowCertificateViewerParams> {
  static std::unique_ptr<network::ShowCertificateViewerParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return network::ShowCertificateViewerParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const network::ShowCertificateViewerParams& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<database::Database> {
  static std::unique_ptr<database::Database> Parse(const base::Value& value, ErrorReporter* errors) {
    return database::Database::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const database::Database& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<database::Error> {
  static std::unique_ptr<database::Error> Parse(const base::Value& value, ErrorReporter* errors) {
    return database::Error::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const database::Error& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<database::GetDatabaseTableNamesParams> {
  static std::unique_ptr<database::GetDatabaseTableNamesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return database::GetDatabaseTableNamesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const database::GetDatabaseTableNamesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<database::GetDatabaseTableNamesResult> {
  static std::unique_ptr<database::GetDatabaseTableNamesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return database::GetDatabaseTableNamesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const database::GetDatabaseTableNamesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<database::ExecuteSQLParams> {
  static std::unique_ptr<database::ExecuteSQLParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return database::ExecuteSQLParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const database::ExecuteSQLParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<database::ExecuteSQLResult> {
  static std::unique_ptr<database::ExecuteSQLResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return database::ExecuteSQLResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const database::ExecuteSQLResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::DatabaseWithObjectStores> {
  static std::unique_ptr<indexeddb::DatabaseWithObjectStores> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::DatabaseWithObjectStores::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::DatabaseWithObjectStores& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::ObjectStore> {
  static std::unique_ptr<indexeddb::ObjectStore> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::ObjectStore::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::ObjectStore& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::ObjectStoreIndex> {
  static std::unique_ptr<indexeddb::ObjectStoreIndex> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::ObjectStoreIndex::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::ObjectStoreIndex& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::Key> {
  static std::unique_ptr<indexeddb::Key> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::Key::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::Key& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::KeyRange> {
  static std::unique_ptr<indexeddb::KeyRange> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::KeyRange::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::KeyRange& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::DataEntry> {
  static std::unique_ptr<indexeddb::DataEntry> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::DataEntry::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::DataEntry& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::KeyPath> {
  static std::unique_ptr<indexeddb::KeyPath> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::KeyPath::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::KeyPath& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<indexeddb::KeyType> {
  static indexeddb::KeyType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return indexeddb::KeyType::NUMBER;
    }
    if (string_value == "number")
      return indexeddb::KeyType::NUMBER;
    if (string_value == "string")
      return indexeddb::KeyType::STRING;
    if (string_value == "date")
      return indexeddb::KeyType::DATE;
    if (string_value == "array")
      return indexeddb::KeyType::ARRAY;
    errors->AddError("invalid enum value");
    return indexeddb::KeyType::NUMBER;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::KeyType& value, T*) {
  switch (value) {
    case indexeddb::KeyType::NUMBER:
      return base::WrapUnique(new base::StringValue("number"));
    case indexeddb::KeyType::STRING:
      return base::WrapUnique(new base::StringValue("string"));
    case indexeddb::KeyType::DATE:
      return base::WrapUnique(new base::StringValue("date"));
    case indexeddb::KeyType::ARRAY:
      return base::WrapUnique(new base::StringValue("array"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<indexeddb::KeyPathType> {
  static indexeddb::KeyPathType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return indexeddb::KeyPathType::NONE;
    }
    if (string_value == "null")
      return indexeddb::KeyPathType::NONE;
    if (string_value == "string")
      return indexeddb::KeyPathType::STRING;
    if (string_value == "array")
      return indexeddb::KeyPathType::ARRAY;
    errors->AddError("invalid enum value");
    return indexeddb::KeyPathType::NONE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::KeyPathType& value, T*) {
  switch (value) {
    case indexeddb::KeyPathType::NONE:
      return base::WrapUnique(new base::StringValue("null"));
    case indexeddb::KeyPathType::STRING:
      return base::WrapUnique(new base::StringValue("string"));
    case indexeddb::KeyPathType::ARRAY:
      return base::WrapUnique(new base::StringValue("array"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<indexeddb::RequestDatabaseNamesParams> {
  static std::unique_ptr<indexeddb::RequestDatabaseNamesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::RequestDatabaseNamesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::RequestDatabaseNamesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::RequestDatabaseNamesResult> {
  static std::unique_ptr<indexeddb::RequestDatabaseNamesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::RequestDatabaseNamesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::RequestDatabaseNamesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::RequestDatabaseParams> {
  static std::unique_ptr<indexeddb::RequestDatabaseParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::RequestDatabaseParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::RequestDatabaseParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::RequestDatabaseResult> {
  static std::unique_ptr<indexeddb::RequestDatabaseResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::RequestDatabaseResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::RequestDatabaseResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::RequestDataParams> {
  static std::unique_ptr<indexeddb::RequestDataParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::RequestDataParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::RequestDataParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::RequestDataResult> {
  static std::unique_ptr<indexeddb::RequestDataResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::RequestDataResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::RequestDataResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::ClearObjectStoreParams> {
  static std::unique_ptr<indexeddb::ClearObjectStoreParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::ClearObjectStoreParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::ClearObjectStoreParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<indexeddb::ClearObjectStoreResult> {
  static std::unique_ptr<indexeddb::ClearObjectStoreResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return indexeddb::ClearObjectStoreResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const indexeddb::ClearObjectStoreResult& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<cache_storage::DataEntry> {
  static std::unique_ptr<cache_storage::DataEntry> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::DataEntry::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::DataEntry& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<cache_storage::Cache> {
  static std::unique_ptr<cache_storage::Cache> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::Cache::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::Cache& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<cache_storage::RequestCacheNamesParams> {
  static std::unique_ptr<cache_storage::RequestCacheNamesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::RequestCacheNamesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::RequestCacheNamesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<cache_storage::RequestCacheNamesResult> {
  static std::unique_ptr<cache_storage::RequestCacheNamesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::RequestCacheNamesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::RequestCacheNamesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<cache_storage::RequestEntriesParams> {
  static std::unique_ptr<cache_storage::RequestEntriesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::RequestEntriesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::RequestEntriesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<cache_storage::RequestEntriesResult> {
  static std::unique_ptr<cache_storage::RequestEntriesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::RequestEntriesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::RequestEntriesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<cache_storage::DeleteCacheParams> {
  static std::unique_ptr<cache_storage::DeleteCacheParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::DeleteCacheParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::DeleteCacheParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<cache_storage::DeleteEntryParams> {
  static std::unique_ptr<cache_storage::DeleteEntryParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return cache_storage::DeleteEntryParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const cache_storage::DeleteEntryParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_storage::StorageId> {
  static std::unique_ptr<dom_storage::StorageId> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_storage::StorageId::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_storage::StorageId& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<dom_storage::GetDOMStorageItemsParams> {
  static std::unique_ptr<dom_storage::GetDOMStorageItemsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_storage::GetDOMStorageItemsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_storage::GetDOMStorageItemsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_storage::GetDOMStorageItemsResult> {
  static std::unique_ptr<dom_storage::GetDOMStorageItemsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_storage::GetDOMStorageItemsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_storage::GetDOMStorageItemsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_storage::SetDOMStorageItemParams> {
  static std::unique_ptr<dom_storage::SetDOMStorageItemParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_storage::SetDOMStorageItemParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_storage::SetDOMStorageItemParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_storage::RemoveDOMStorageItemParams> {
  static std::unique_ptr<dom_storage::RemoveDOMStorageItemParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_storage::RemoveDOMStorageItemParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_storage::RemoveDOMStorageItemParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::ApplicationCacheResource> {
  static std::unique_ptr<application_cache::ApplicationCacheResource> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::ApplicationCacheResource::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::ApplicationCacheResource& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::ApplicationCache> {
  static std::unique_ptr<application_cache::ApplicationCache> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::ApplicationCache::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::ApplicationCache& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::FrameWithManifest> {
  static std::unique_ptr<application_cache::FrameWithManifest> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::FrameWithManifest::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::FrameWithManifest& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::GetFramesWithManifestsResult> {
  static std::unique_ptr<application_cache::GetFramesWithManifestsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::GetFramesWithManifestsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::GetFramesWithManifestsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::GetManifestForFrameParams> {
  static std::unique_ptr<application_cache::GetManifestForFrameParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::GetManifestForFrameParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::GetManifestForFrameParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::GetManifestForFrameResult> {
  static std::unique_ptr<application_cache::GetManifestForFrameResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::GetManifestForFrameResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::GetManifestForFrameResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::GetApplicationCacheForFrameParams> {
  static std::unique_ptr<application_cache::GetApplicationCacheForFrameParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::GetApplicationCacheForFrameParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::GetApplicationCacheForFrameParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<application_cache::GetApplicationCacheForFrameResult> {
  static std::unique_ptr<application_cache::GetApplicationCacheForFrameResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return application_cache::GetApplicationCacheForFrameResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const application_cache::GetApplicationCacheForFrameResult& value, T*) {
  return value.Serialize();
}




template <>
struct FromValue<dom::BackendNode> {
  static std::unique_ptr<dom::BackendNode> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::BackendNode::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::BackendNode& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<dom::PseudoType> {
  static dom::PseudoType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return dom::PseudoType::FIRST_LINE;
    }
    if (string_value == "first-line")
      return dom::PseudoType::FIRST_LINE;
    if (string_value == "first-letter")
      return dom::PseudoType::FIRST_LETTER;
    if (string_value == "before")
      return dom::PseudoType::BEFORE;
    if (string_value == "after")
      return dom::PseudoType::AFTER;
    if (string_value == "backdrop")
      return dom::PseudoType::BACKDROP;
    if (string_value == "selection")
      return dom::PseudoType::SELECTION;
    if (string_value == "first-line-inherited")
      return dom::PseudoType::FIRST_LINE_INHERITED;
    if (string_value == "scrollbar")
      return dom::PseudoType::SCROLLBAR;
    if (string_value == "scrollbar-thumb")
      return dom::PseudoType::SCROLLBAR_THUMB;
    if (string_value == "scrollbar-button")
      return dom::PseudoType::SCROLLBAR_BUTTON;
    if (string_value == "scrollbar-track")
      return dom::PseudoType::SCROLLBAR_TRACK;
    if (string_value == "scrollbar-track-piece")
      return dom::PseudoType::SCROLLBAR_TRACK_PIECE;
    if (string_value == "scrollbar-corner")
      return dom::PseudoType::SCROLLBAR_CORNER;
    if (string_value == "resizer")
      return dom::PseudoType::RESIZER;
    if (string_value == "input-list-button")
      return dom::PseudoType::INPUT_LIST_BUTTON;
    errors->AddError("invalid enum value");
    return dom::PseudoType::FIRST_LINE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::PseudoType& value, T*) {
  switch (value) {
    case dom::PseudoType::FIRST_LINE:
      return base::WrapUnique(new base::StringValue("first-line"));
    case dom::PseudoType::FIRST_LETTER:
      return base::WrapUnique(new base::StringValue("first-letter"));
    case dom::PseudoType::BEFORE:
      return base::WrapUnique(new base::StringValue("before"));
    case dom::PseudoType::AFTER:
      return base::WrapUnique(new base::StringValue("after"));
    case dom::PseudoType::BACKDROP:
      return base::WrapUnique(new base::StringValue("backdrop"));
    case dom::PseudoType::SELECTION:
      return base::WrapUnique(new base::StringValue("selection"));
    case dom::PseudoType::FIRST_LINE_INHERITED:
      return base::WrapUnique(new base::StringValue("first-line-inherited"));
    case dom::PseudoType::SCROLLBAR:
      return base::WrapUnique(new base::StringValue("scrollbar"));
    case dom::PseudoType::SCROLLBAR_THUMB:
      return base::WrapUnique(new base::StringValue("scrollbar-thumb"));
    case dom::PseudoType::SCROLLBAR_BUTTON:
      return base::WrapUnique(new base::StringValue("scrollbar-button"));
    case dom::PseudoType::SCROLLBAR_TRACK:
      return base::WrapUnique(new base::StringValue("scrollbar-track"));
    case dom::PseudoType::SCROLLBAR_TRACK_PIECE:
      return base::WrapUnique(new base::StringValue("scrollbar-track-piece"));
    case dom::PseudoType::SCROLLBAR_CORNER:
      return base::WrapUnique(new base::StringValue("scrollbar-corner"));
    case dom::PseudoType::RESIZER:
      return base::WrapUnique(new base::StringValue("resizer"));
    case dom::PseudoType::INPUT_LIST_BUTTON:
      return base::WrapUnique(new base::StringValue("input-list-button"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<dom::ShadowRootType> {
  static dom::ShadowRootType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return dom::ShadowRootType::USER_AGENT;
    }
    if (string_value == "user-agent")
      return dom::ShadowRootType::USER_AGENT;
    if (string_value == "open")
      return dom::ShadowRootType::OPEN;
    if (string_value == "closed")
      return dom::ShadowRootType::CLOSED;
    errors->AddError("invalid enum value");
    return dom::ShadowRootType::USER_AGENT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::ShadowRootType& value, T*) {
  switch (value) {
    case dom::ShadowRootType::USER_AGENT:
      return base::WrapUnique(new base::StringValue("user-agent"));
    case dom::ShadowRootType::OPEN:
      return base::WrapUnique(new base::StringValue("open"));
    case dom::ShadowRootType::CLOSED:
      return base::WrapUnique(new base::StringValue("closed"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<dom::Node> {
  static std::unique_ptr<dom::Node> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::Node::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::Node& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::RGBA> {
  static std::unique_ptr<dom::RGBA> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::RGBA::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::RGBA& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<dom::BoxModel> {
  static std::unique_ptr<dom::BoxModel> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::BoxModel::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::BoxModel& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::ShapeOutsideInfo> {
  static std::unique_ptr<dom::ShapeOutsideInfo> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::ShapeOutsideInfo::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::ShapeOutsideInfo& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::Rect> {
  static std::unique_ptr<dom::Rect> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::Rect::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::Rect& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::HighlightConfig> {
  static std::unique_ptr<dom::HighlightConfig> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::HighlightConfig::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::HighlightConfig& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<dom::InspectMode> {
  static dom::InspectMode Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return dom::InspectMode::SEARCH_FOR_NODE;
    }
    if (string_value == "searchForNode")
      return dom::InspectMode::SEARCH_FOR_NODE;
    if (string_value == "searchForUAShadowDOM")
      return dom::InspectMode::SEARCH_FORUA_SHADOWDOM;
    if (string_value == "showLayoutEditor")
      return dom::InspectMode::SHOW_LAYOUT_EDITOR;
    if (string_value == "none")
      return dom::InspectMode::NONE;
    errors->AddError("invalid enum value");
    return dom::InspectMode::SEARCH_FOR_NODE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::InspectMode& value, T*) {
  switch (value) {
    case dom::InspectMode::SEARCH_FOR_NODE:
      return base::WrapUnique(new base::StringValue("searchForNode"));
    case dom::InspectMode::SEARCH_FORUA_SHADOWDOM:
      return base::WrapUnique(new base::StringValue("searchForUAShadowDOM"));
    case dom::InspectMode::SHOW_LAYOUT_EDITOR:
      return base::WrapUnique(new base::StringValue("showLayoutEditor"));
    case dom::InspectMode::NONE:
      return base::WrapUnique(new base::StringValue("none"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<dom::GetDocumentResult> {
  static std::unique_ptr<dom::GetDocumentResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetDocumentResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetDocumentResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::RequestChildNodesParams> {
  static std::unique_ptr<dom::RequestChildNodesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::RequestChildNodesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::RequestChildNodesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::QuerySelectorParams> {
  static std::unique_ptr<dom::QuerySelectorParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::QuerySelectorParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::QuerySelectorParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::QuerySelectorResult> {
  static std::unique_ptr<dom::QuerySelectorResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::QuerySelectorResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::QuerySelectorResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::QuerySelectorAllParams> {
  static std::unique_ptr<dom::QuerySelectorAllParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::QuerySelectorAllParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::QuerySelectorAllParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::QuerySelectorAllResult> {
  static std::unique_ptr<dom::QuerySelectorAllResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::QuerySelectorAllResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::QuerySelectorAllResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetNodeNameParams> {
  static std::unique_ptr<dom::SetNodeNameParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetNodeNameParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetNodeNameParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetNodeNameResult> {
  static std::unique_ptr<dom::SetNodeNameResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetNodeNameResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetNodeNameResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetNodeValueParams> {
  static std::unique_ptr<dom::SetNodeValueParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetNodeValueParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetNodeValueParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::RemoveNodeParams> {
  static std::unique_ptr<dom::RemoveNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::RemoveNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::RemoveNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetAttributeValueParams> {
  static std::unique_ptr<dom::SetAttributeValueParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetAttributeValueParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetAttributeValueParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetAttributesAsTextParams> {
  static std::unique_ptr<dom::SetAttributesAsTextParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetAttributesAsTextParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetAttributesAsTextParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::RemoveAttributeParams> {
  static std::unique_ptr<dom::RemoveAttributeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::RemoveAttributeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::RemoveAttributeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetOuterHTMLParams> {
  static std::unique_ptr<dom::GetOuterHTMLParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetOuterHTMLParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetOuterHTMLParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetOuterHTMLResult> {
  static std::unique_ptr<dom::GetOuterHTMLResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetOuterHTMLResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetOuterHTMLResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetOuterHTMLParams> {
  static std::unique_ptr<dom::SetOuterHTMLParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetOuterHTMLParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetOuterHTMLParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::PerformSearchParams> {
  static std::unique_ptr<dom::PerformSearchParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::PerformSearchParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::PerformSearchParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::PerformSearchResult> {
  static std::unique_ptr<dom::PerformSearchResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::PerformSearchResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::PerformSearchResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetSearchResultsParams> {
  static std::unique_ptr<dom::GetSearchResultsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetSearchResultsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetSearchResultsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetSearchResultsResult> {
  static std::unique_ptr<dom::GetSearchResultsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetSearchResultsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetSearchResultsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::DiscardSearchResultsParams> {
  static std::unique_ptr<dom::DiscardSearchResultsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::DiscardSearchResultsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::DiscardSearchResultsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::RequestNodeParams> {
  static std::unique_ptr<dom::RequestNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::RequestNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::RequestNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::RequestNodeResult> {
  static std::unique_ptr<dom::RequestNodeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::RequestNodeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::RequestNodeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetInspectModeParams> {
  static std::unique_ptr<dom::SetInspectModeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetInspectModeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetInspectModeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::HighlightRectParams> {
  static std::unique_ptr<dom::HighlightRectParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::HighlightRectParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::HighlightRectParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::HighlightQuadParams> {
  static std::unique_ptr<dom::HighlightQuadParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::HighlightQuadParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::HighlightQuadParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::HighlightNodeParams> {
  static std::unique_ptr<dom::HighlightNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::HighlightNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::HighlightNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::HighlightFrameParams> {
  static std::unique_ptr<dom::HighlightFrameParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::HighlightFrameParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::HighlightFrameParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::PushNodeByPathToFrontendParams> {
  static std::unique_ptr<dom::PushNodeByPathToFrontendParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::PushNodeByPathToFrontendParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::PushNodeByPathToFrontendParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::PushNodeByPathToFrontendResult> {
  static std::unique_ptr<dom::PushNodeByPathToFrontendResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::PushNodeByPathToFrontendResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::PushNodeByPathToFrontendResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::PushNodesByBackendIdsToFrontendParams> {
  static std::unique_ptr<dom::PushNodesByBackendIdsToFrontendParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::PushNodesByBackendIdsToFrontendParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::PushNodesByBackendIdsToFrontendParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::PushNodesByBackendIdsToFrontendResult> {
  static std::unique_ptr<dom::PushNodesByBackendIdsToFrontendResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::PushNodesByBackendIdsToFrontendResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::PushNodesByBackendIdsToFrontendResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetInspectedNodeParams> {
  static std::unique_ptr<dom::SetInspectedNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetInspectedNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetInspectedNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::ResolveNodeParams> {
  static std::unique_ptr<dom::ResolveNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::ResolveNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::ResolveNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::ResolveNodeResult> {
  static std::unique_ptr<dom::ResolveNodeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::ResolveNodeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::ResolveNodeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetAttributesParams> {
  static std::unique_ptr<dom::GetAttributesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetAttributesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetAttributesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetAttributesResult> {
  static std::unique_ptr<dom::GetAttributesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetAttributesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetAttributesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::CopyToParams> {
  static std::unique_ptr<dom::CopyToParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::CopyToParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::CopyToParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::CopyToResult> {
  static std::unique_ptr<dom::CopyToResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::CopyToResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::CopyToResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::MoveToParams> {
  static std::unique_ptr<dom::MoveToParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::MoveToParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::MoveToParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::MoveToResult> {
  static std::unique_ptr<dom::MoveToResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::MoveToResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::MoveToResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::FocusParams> {
  static std::unique_ptr<dom::FocusParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::FocusParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::FocusParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::SetFileInputFilesParams> {
  static std::unique_ptr<dom::SetFileInputFilesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::SetFileInputFilesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::SetFileInputFilesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetBoxModelParams> {
  static std::unique_ptr<dom::GetBoxModelParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetBoxModelParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetBoxModelParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetBoxModelResult> {
  static std::unique_ptr<dom::GetBoxModelResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetBoxModelResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetBoxModelResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetNodeForLocationParams> {
  static std::unique_ptr<dom::GetNodeForLocationParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetNodeForLocationParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetNodeForLocationParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetNodeForLocationResult> {
  static std::unique_ptr<dom::GetNodeForLocationResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetNodeForLocationResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetNodeForLocationResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetRelayoutBoundaryParams> {
  static std::unique_ptr<dom::GetRelayoutBoundaryParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetRelayoutBoundaryParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetRelayoutBoundaryParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetRelayoutBoundaryResult> {
  static std::unique_ptr<dom::GetRelayoutBoundaryResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetRelayoutBoundaryResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetRelayoutBoundaryResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetHighlightObjectForTestParams> {
  static std::unique_ptr<dom::GetHighlightObjectForTestParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetHighlightObjectForTestParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetHighlightObjectForTestParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom::GetHighlightObjectForTestResult> {
  static std::unique_ptr<dom::GetHighlightObjectForTestResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom::GetHighlightObjectForTestResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom::GetHighlightObjectForTestResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::StyleSheetOrigin> {
  static css::StyleSheetOrigin Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return css::StyleSheetOrigin::INJECTED;
    }
    if (string_value == "injected")
      return css::StyleSheetOrigin::INJECTED;
    if (string_value == "user-agent")
      return css::StyleSheetOrigin::USER_AGENT;
    if (string_value == "inspector")
      return css::StyleSheetOrigin::INSPECTOR;
    if (string_value == "regular")
      return css::StyleSheetOrigin::REGULAR;
    errors->AddError("invalid enum value");
    return css::StyleSheetOrigin::INJECTED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::StyleSheetOrigin& value, T*) {
  switch (value) {
    case css::StyleSheetOrigin::INJECTED:
      return base::WrapUnique(new base::StringValue("injected"));
    case css::StyleSheetOrigin::USER_AGENT:
      return base::WrapUnique(new base::StringValue("user-agent"));
    case css::StyleSheetOrigin::INSPECTOR:
      return base::WrapUnique(new base::StringValue("inspector"));
    case css::StyleSheetOrigin::REGULAR:
      return base::WrapUnique(new base::StringValue("regular"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<css::PseudoElementMatches> {
  static std::unique_ptr<css::PseudoElementMatches> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::PseudoElementMatches::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::PseudoElementMatches& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::InheritedStyleEntry> {
  static std::unique_ptr<css::InheritedStyleEntry> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::InheritedStyleEntry::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::InheritedStyleEntry& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::RuleMatch> {
  static std::unique_ptr<css::RuleMatch> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::RuleMatch::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::RuleMatch& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::Value> {
  static std::unique_ptr<css::Value> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::Value::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::Value& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SelectorList> {
  static std::unique_ptr<css::SelectorList> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SelectorList::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SelectorList& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSStyleSheetHeader> {
  static std::unique_ptr<css::CSSStyleSheetHeader> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSStyleSheetHeader::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSStyleSheetHeader& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSRule> {
  static std::unique_ptr<css::CSSRule> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSRule::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSRule& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SourceRange> {
  static std::unique_ptr<css::SourceRange> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SourceRange::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SourceRange& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::ShorthandEntry> {
  static std::unique_ptr<css::ShorthandEntry> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::ShorthandEntry::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::ShorthandEntry& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSComputedStyleProperty> {
  static std::unique_ptr<css::CSSComputedStyleProperty> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSComputedStyleProperty::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSComputedStyleProperty& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSStyle> {
  static std::unique_ptr<css::CSSStyle> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSStyle::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSStyle& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSProperty> {
  static std::unique_ptr<css::CSSProperty> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSProperty::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSProperty& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSMedia> {
  static std::unique_ptr<css::CSSMedia> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSMedia::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSMedia& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::MediaQuery> {
  static std::unique_ptr<css::MediaQuery> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::MediaQuery::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::MediaQuery& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::MediaQueryExpression> {
  static std::unique_ptr<css::MediaQueryExpression> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::MediaQueryExpression::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::MediaQueryExpression& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::PlatformFontUsage> {
  static std::unique_ptr<css::PlatformFontUsage> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::PlatformFontUsage::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::PlatformFontUsage& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSKeyframesRule> {
  static std::unique_ptr<css::CSSKeyframesRule> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSKeyframesRule::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSKeyframesRule& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CSSKeyframeRule> {
  static std::unique_ptr<css::CSSKeyframeRule> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CSSKeyframeRule::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSKeyframeRule& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::StyleDeclarationEdit> {
  static std::unique_ptr<css::StyleDeclarationEdit> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::StyleDeclarationEdit::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::StyleDeclarationEdit& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<css::CSSMediaSource> {
  static css::CSSMediaSource Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return css::CSSMediaSource::MEDIA_RULE;
    }
    if (string_value == "mediaRule")
      return css::CSSMediaSource::MEDIA_RULE;
    if (string_value == "importRule")
      return css::CSSMediaSource::IMPORT_RULE;
    if (string_value == "linkedSheet")
      return css::CSSMediaSource::LINKED_SHEET;
    if (string_value == "inlineSheet")
      return css::CSSMediaSource::INLINE_SHEET;
    errors->AddError("invalid enum value");
    return css::CSSMediaSource::MEDIA_RULE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CSSMediaSource& value, T*) {
  switch (value) {
    case css::CSSMediaSource::MEDIA_RULE:
      return base::WrapUnique(new base::StringValue("mediaRule"));
    case css::CSSMediaSource::IMPORT_RULE:
      return base::WrapUnique(new base::StringValue("importRule"));
    case css::CSSMediaSource::LINKED_SHEET:
      return base::WrapUnique(new base::StringValue("linkedSheet"));
    case css::CSSMediaSource::INLINE_SHEET:
      return base::WrapUnique(new base::StringValue("inlineSheet"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<css::GetMatchedStylesForNodeParams> {
  static std::unique_ptr<css::GetMatchedStylesForNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetMatchedStylesForNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetMatchedStylesForNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetMatchedStylesForNodeResult> {
  static std::unique_ptr<css::GetMatchedStylesForNodeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetMatchedStylesForNodeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetMatchedStylesForNodeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetInlineStylesForNodeParams> {
  static std::unique_ptr<css::GetInlineStylesForNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetInlineStylesForNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetInlineStylesForNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetInlineStylesForNodeResult> {
  static std::unique_ptr<css::GetInlineStylesForNodeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetInlineStylesForNodeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetInlineStylesForNodeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetComputedStyleForNodeParams> {
  static std::unique_ptr<css::GetComputedStyleForNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetComputedStyleForNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetComputedStyleForNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetComputedStyleForNodeResult> {
  static std::unique_ptr<css::GetComputedStyleForNodeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetComputedStyleForNodeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetComputedStyleForNodeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetPlatformFontsForNodeParams> {
  static std::unique_ptr<css::GetPlatformFontsForNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetPlatformFontsForNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetPlatformFontsForNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetPlatformFontsForNodeResult> {
  static std::unique_ptr<css::GetPlatformFontsForNodeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetPlatformFontsForNodeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetPlatformFontsForNodeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetStyleSheetTextParams> {
  static std::unique_ptr<css::GetStyleSheetTextParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetStyleSheetTextParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetStyleSheetTextParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetStyleSheetTextResult> {
  static std::unique_ptr<css::GetStyleSheetTextResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetStyleSheetTextResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetStyleSheetTextResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetStyleSheetTextParams> {
  static std::unique_ptr<css::SetStyleSheetTextParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetStyleSheetTextParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetStyleSheetTextParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetStyleSheetTextResult> {
  static std::unique_ptr<css::SetStyleSheetTextResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetStyleSheetTextResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetStyleSheetTextResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetRuleSelectorParams> {
  static std::unique_ptr<css::SetRuleSelectorParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetRuleSelectorParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetRuleSelectorParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetRuleSelectorResult> {
  static std::unique_ptr<css::SetRuleSelectorResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetRuleSelectorResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetRuleSelectorResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetKeyframeKeyParams> {
  static std::unique_ptr<css::SetKeyframeKeyParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetKeyframeKeyParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetKeyframeKeyParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetKeyframeKeyResult> {
  static std::unique_ptr<css::SetKeyframeKeyResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetKeyframeKeyResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetKeyframeKeyResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetStyleTextsParams> {
  static std::unique_ptr<css::SetStyleTextsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetStyleTextsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetStyleTextsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetStyleTextsResult> {
  static std::unique_ptr<css::SetStyleTextsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetStyleTextsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetStyleTextsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetMediaTextParams> {
  static std::unique_ptr<css::SetMediaTextParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetMediaTextParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetMediaTextParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetMediaTextResult> {
  static std::unique_ptr<css::SetMediaTextResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetMediaTextResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetMediaTextResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CreateStyleSheetParams> {
  static std::unique_ptr<css::CreateStyleSheetParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CreateStyleSheetParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CreateStyleSheetParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::CreateStyleSheetResult> {
  static std::unique_ptr<css::CreateStyleSheetResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::CreateStyleSheetResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::CreateStyleSheetResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::AddRuleParams> {
  static std::unique_ptr<css::AddRuleParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::AddRuleParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::AddRuleParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::AddRuleResult> {
  static std::unique_ptr<css::AddRuleResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::AddRuleResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::AddRuleResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::ForcePseudoStateParams> {
  static std::unique_ptr<css::ForcePseudoStateParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::ForcePseudoStateParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::ForcePseudoStateParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetMediaQueriesResult> {
  static std::unique_ptr<css::GetMediaQueriesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetMediaQueriesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetMediaQueriesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::SetEffectivePropertyValueForNodeParams> {
  static std::unique_ptr<css::SetEffectivePropertyValueForNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::SetEffectivePropertyValueForNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::SetEffectivePropertyValueForNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetBackgroundColorsParams> {
  static std::unique_ptr<css::GetBackgroundColorsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetBackgroundColorsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetBackgroundColorsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<css::GetBackgroundColorsResult> {
  static std::unique_ptr<css::GetBackgroundColorsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return css::GetBackgroundColorsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const css::GetBackgroundColorsResult& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<io::ReadParams> {
  static std::unique_ptr<io::ReadParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return io::ReadParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const io::ReadParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<io::ReadResult> {
  static std::unique_ptr<io::ReadResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return io::ReadResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const io::ReadResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<io::CloseParams> {
  static std::unique_ptr<io::CloseParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return io::CloseParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const io::CloseParams& value, T*) {
  return value.Serialize();
}




template <>
struct FromValue<debugger::Location> {
  static std::unique_ptr<debugger::Location> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::Location::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::Location& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::ScriptPosition> {
  static std::unique_ptr<debugger::ScriptPosition> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::ScriptPosition::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::ScriptPosition& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::FunctionDetails> {
  static std::unique_ptr<debugger::FunctionDetails> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::FunctionDetails::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::FunctionDetails& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GeneratorObjectDetails> {
  static std::unique_ptr<debugger::GeneratorObjectDetails> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GeneratorObjectDetails::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GeneratorObjectDetails& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::CollectionEntry> {
  static std::unique_ptr<debugger::CollectionEntry> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::CollectionEntry::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::CollectionEntry& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::CallFrame> {
  static std::unique_ptr<debugger::CallFrame> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::CallFrame::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::CallFrame& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::Scope> {
  static std::unique_ptr<debugger::Scope> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::Scope::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::Scope& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetScriptSourceError> {
  static std::unique_ptr<debugger::SetScriptSourceError> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetScriptSourceError::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetScriptSourceError& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SearchMatch> {
  static std::unique_ptr<debugger::SearchMatch> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SearchMatch::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SearchMatch& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<debugger::GeneratorObjectDetailsStatus> {
  static debugger::GeneratorObjectDetailsStatus Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return debugger::GeneratorObjectDetailsStatus::RUNNING;
    }
    if (string_value == "running")
      return debugger::GeneratorObjectDetailsStatus::RUNNING;
    if (string_value == "suspended")
      return debugger::GeneratorObjectDetailsStatus::SUSPENDED;
    if (string_value == "closed")
      return debugger::GeneratorObjectDetailsStatus::CLOSED;
    errors->AddError("invalid enum value");
    return debugger::GeneratorObjectDetailsStatus::RUNNING;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GeneratorObjectDetailsStatus& value, T*) {
  switch (value) {
    case debugger::GeneratorObjectDetailsStatus::RUNNING:
      return base::WrapUnique(new base::StringValue("running"));
    case debugger::GeneratorObjectDetailsStatus::SUSPENDED:
      return base::WrapUnique(new base::StringValue("suspended"));
    case debugger::GeneratorObjectDetailsStatus::CLOSED:
      return base::WrapUnique(new base::StringValue("closed"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<debugger::ScopeType> {
  static debugger::ScopeType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return debugger::ScopeType::GLOBAL;
    }
    if (string_value == "global")
      return debugger::ScopeType::GLOBAL;
    if (string_value == "local")
      return debugger::ScopeType::LOCAL;
    if (string_value == "with")
      return debugger::ScopeType::WITH;
    if (string_value == "closure")
      return debugger::ScopeType::CLOSURE;
    if (string_value == "catch")
      return debugger::ScopeType::CATCH;
    if (string_value == "block")
      return debugger::ScopeType::BLOCK;
    if (string_value == "script")
      return debugger::ScopeType::SCRIPT;
    errors->AddError("invalid enum value");
    return debugger::ScopeType::GLOBAL;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::ScopeType& value, T*) {
  switch (value) {
    case debugger::ScopeType::GLOBAL:
      return base::WrapUnique(new base::StringValue("global"));
    case debugger::ScopeType::LOCAL:
      return base::WrapUnique(new base::StringValue("local"));
    case debugger::ScopeType::WITH:
      return base::WrapUnique(new base::StringValue("with"));
    case debugger::ScopeType::CLOSURE:
      return base::WrapUnique(new base::StringValue("closure"));
    case debugger::ScopeType::CATCH:
      return base::WrapUnique(new base::StringValue("catch"));
    case debugger::ScopeType::BLOCK:
      return base::WrapUnique(new base::StringValue("block"));
    case debugger::ScopeType::SCRIPT:
      return base::WrapUnique(new base::StringValue("script"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<debugger::SetBreakpointsActiveParams> {
  static std::unique_ptr<debugger::SetBreakpointsActiveParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetBreakpointsActiveParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetBreakpointsActiveParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetSkipAllPausesParams> {
  static std::unique_ptr<debugger::SetSkipAllPausesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetSkipAllPausesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetSkipAllPausesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetBreakpointByUrlParams> {
  static std::unique_ptr<debugger::SetBreakpointByUrlParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetBreakpointByUrlParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetBreakpointByUrlParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetBreakpointByUrlResult> {
  static std::unique_ptr<debugger::SetBreakpointByUrlResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetBreakpointByUrlResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetBreakpointByUrlResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetBreakpointParams> {
  static std::unique_ptr<debugger::SetBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetBreakpointResult> {
  static std::unique_ptr<debugger::SetBreakpointResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetBreakpointResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetBreakpointResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::RemoveBreakpointParams> {
  static std::unique_ptr<debugger::RemoveBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::RemoveBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::RemoveBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::ContinueToLocationParams> {
  static std::unique_ptr<debugger::ContinueToLocationParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::ContinueToLocationParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::ContinueToLocationParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SearchInContentParams> {
  static std::unique_ptr<debugger::SearchInContentParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SearchInContentParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SearchInContentParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SearchInContentResult> {
  static std::unique_ptr<debugger::SearchInContentResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SearchInContentResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SearchInContentResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::CanSetScriptSourceResult> {
  static std::unique_ptr<debugger::CanSetScriptSourceResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::CanSetScriptSourceResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::CanSetScriptSourceResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetScriptSourceParams> {
  static std::unique_ptr<debugger::SetScriptSourceParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetScriptSourceParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetScriptSourceParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetScriptSourceResult> {
  static std::unique_ptr<debugger::SetScriptSourceResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetScriptSourceResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetScriptSourceResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::RestartFrameParams> {
  static std::unique_ptr<debugger::RestartFrameParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::RestartFrameParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::RestartFrameParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::RestartFrameResult> {
  static std::unique_ptr<debugger::RestartFrameResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::RestartFrameResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::RestartFrameResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetScriptSourceParams> {
  static std::unique_ptr<debugger::GetScriptSourceParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetScriptSourceParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetScriptSourceParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetScriptSourceResult> {
  static std::unique_ptr<debugger::GetScriptSourceResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetScriptSourceResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetScriptSourceResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetFunctionDetailsParams> {
  static std::unique_ptr<debugger::GetFunctionDetailsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetFunctionDetailsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetFunctionDetailsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetFunctionDetailsResult> {
  static std::unique_ptr<debugger::GetFunctionDetailsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetFunctionDetailsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetFunctionDetailsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetGeneratorObjectDetailsParams> {
  static std::unique_ptr<debugger::GetGeneratorObjectDetailsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetGeneratorObjectDetailsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetGeneratorObjectDetailsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetGeneratorObjectDetailsResult> {
  static std::unique_ptr<debugger::GetGeneratorObjectDetailsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetGeneratorObjectDetailsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetGeneratorObjectDetailsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetCollectionEntriesParams> {
  static std::unique_ptr<debugger::GetCollectionEntriesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetCollectionEntriesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetCollectionEntriesParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetCollectionEntriesResult> {
  static std::unique_ptr<debugger::GetCollectionEntriesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetCollectionEntriesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetCollectionEntriesResult& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<debugger::SetPauseOnExceptionsState> {
  static debugger::SetPauseOnExceptionsState Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return debugger::SetPauseOnExceptionsState::NONE;
    }
    if (string_value == "none")
      return debugger::SetPauseOnExceptionsState::NONE;
    if (string_value == "uncaught")
      return debugger::SetPauseOnExceptionsState::UNCAUGHT;
    if (string_value == "all")
      return debugger::SetPauseOnExceptionsState::ALL;
    errors->AddError("invalid enum value");
    return debugger::SetPauseOnExceptionsState::NONE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetPauseOnExceptionsState& value, T*) {
  switch (value) {
    case debugger::SetPauseOnExceptionsState::NONE:
      return base::WrapUnique(new base::StringValue("none"));
    case debugger::SetPauseOnExceptionsState::UNCAUGHT:
      return base::WrapUnique(new base::StringValue("uncaught"));
    case debugger::SetPauseOnExceptionsState::ALL:
      return base::WrapUnique(new base::StringValue("all"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<debugger::SetPauseOnExceptionsParams> {
  static std::unique_ptr<debugger::SetPauseOnExceptionsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetPauseOnExceptionsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetPauseOnExceptionsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::EvaluateOnCallFrameParams> {
  static std::unique_ptr<debugger::EvaluateOnCallFrameParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::EvaluateOnCallFrameParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::EvaluateOnCallFrameParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::EvaluateOnCallFrameResult> {
  static std::unique_ptr<debugger::EvaluateOnCallFrameResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::EvaluateOnCallFrameResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::EvaluateOnCallFrameResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetVariableValueParams> {
  static std::unique_ptr<debugger::SetVariableValueParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetVariableValueParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetVariableValueParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::GetBacktraceResult> {
  static std::unique_ptr<debugger::GetBacktraceResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::GetBacktraceResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::GetBacktraceResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetAsyncCallStackDepthParams> {
  static std::unique_ptr<debugger::SetAsyncCallStackDepthParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetAsyncCallStackDepthParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetAsyncCallStackDepthParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<debugger::SetBlackboxedRangesParams> {
  static std::unique_ptr<debugger::SetBlackboxedRangesParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return debugger::SetBlackboxedRangesParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const debugger::SetBlackboxedRangesParams& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<dom_debugger::DOMBreakpointType> {
  static dom_debugger::DOMBreakpointType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return dom_debugger::DOMBreakpointType::SUBTREE_MODIFIED;
    }
    if (string_value == "subtree-modified")
      return dom_debugger::DOMBreakpointType::SUBTREE_MODIFIED;
    if (string_value == "attribute-modified")
      return dom_debugger::DOMBreakpointType::ATTRIBUTE_MODIFIED;
    if (string_value == "node-removed")
      return dom_debugger::DOMBreakpointType::NODE_REMOVED;
    errors->AddError("invalid enum value");
    return dom_debugger::DOMBreakpointType::SUBTREE_MODIFIED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::DOMBreakpointType& value, T*) {
  switch (value) {
    case dom_debugger::DOMBreakpointType::SUBTREE_MODIFIED:
      return base::WrapUnique(new base::StringValue("subtree-modified"));
    case dom_debugger::DOMBreakpointType::ATTRIBUTE_MODIFIED:
      return base::WrapUnique(new base::StringValue("attribute-modified"));
    case dom_debugger::DOMBreakpointType::NODE_REMOVED:
      return base::WrapUnique(new base::StringValue("node-removed"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<dom_debugger::EventListener> {
  static std::unique_ptr<dom_debugger::EventListener> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::EventListener::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::EventListener& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::SetDOMBreakpointParams> {
  static std::unique_ptr<dom_debugger::SetDOMBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::SetDOMBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::SetDOMBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::RemoveDOMBreakpointParams> {
  static std::unique_ptr<dom_debugger::RemoveDOMBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::RemoveDOMBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::RemoveDOMBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::SetEventListenerBreakpointParams> {
  static std::unique_ptr<dom_debugger::SetEventListenerBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::SetEventListenerBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::SetEventListenerBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::RemoveEventListenerBreakpointParams> {
  static std::unique_ptr<dom_debugger::RemoveEventListenerBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::RemoveEventListenerBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::RemoveEventListenerBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::SetInstrumentationBreakpointParams> {
  static std::unique_ptr<dom_debugger::SetInstrumentationBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::SetInstrumentationBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::SetInstrumentationBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::RemoveInstrumentationBreakpointParams> {
  static std::unique_ptr<dom_debugger::RemoveInstrumentationBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::RemoveInstrumentationBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::RemoveInstrumentationBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::SetXHRBreakpointParams> {
  static std::unique_ptr<dom_debugger::SetXHRBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::SetXHRBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::SetXHRBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::RemoveXHRBreakpointParams> {
  static std::unique_ptr<dom_debugger::RemoveXHRBreakpointParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::RemoveXHRBreakpointParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::RemoveXHRBreakpointParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::GetEventListenersParams> {
  static std::unique_ptr<dom_debugger::GetEventListenersParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::GetEventListenersParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::GetEventListenersParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<dom_debugger::GetEventListenersResult> {
  static std::unique_ptr<dom_debugger::GetEventListenersResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return dom_debugger::GetEventListenersResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const dom_debugger::GetEventListenersResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<profiler::CPUProfileNode> {
  static std::unique_ptr<profiler::CPUProfileNode> Parse(const base::Value& value, ErrorReporter* errors) {
    return profiler::CPUProfileNode::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const profiler::CPUProfileNode& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<profiler::CPUProfile> {
  static std::unique_ptr<profiler::CPUProfile> Parse(const base::Value& value, ErrorReporter* errors) {
    return profiler::CPUProfile::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const profiler::CPUProfile& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<profiler::PositionTickInfo> {
  static std::unique_ptr<profiler::PositionTickInfo> Parse(const base::Value& value, ErrorReporter* errors) {
    return profiler::PositionTickInfo::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const profiler::PositionTickInfo& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<profiler::SetSamplingIntervalParams> {
  static std::unique_ptr<profiler::SetSamplingIntervalParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return profiler::SetSamplingIntervalParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const profiler::SetSamplingIntervalParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<profiler::StopResult> {
  static std::unique_ptr<profiler::StopResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return profiler::StopResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const profiler::StopResult& value, T*) {
  return value.Serialize();
}



template <>
struct FromValue<heap_profiler::SamplingHeapProfileNode> {
  static std::unique_ptr<heap_profiler::SamplingHeapProfileNode> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::SamplingHeapProfileNode::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::SamplingHeapProfileNode& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::SamplingHeapProfile> {
  static std::unique_ptr<heap_profiler::SamplingHeapProfile> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::SamplingHeapProfile::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::SamplingHeapProfile& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::StartTrackingHeapObjectsParams> {
  static std::unique_ptr<heap_profiler::StartTrackingHeapObjectsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::StartTrackingHeapObjectsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::StartTrackingHeapObjectsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::StopTrackingHeapObjectsParams> {
  static std::unique_ptr<heap_profiler::StopTrackingHeapObjectsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::StopTrackingHeapObjectsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::StopTrackingHeapObjectsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::TakeHeapSnapshotParams> {
  static std::unique_ptr<heap_profiler::TakeHeapSnapshotParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::TakeHeapSnapshotParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::TakeHeapSnapshotParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::GetObjectByHeapObjectIdParams> {
  static std::unique_ptr<heap_profiler::GetObjectByHeapObjectIdParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::GetObjectByHeapObjectIdParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::GetObjectByHeapObjectIdParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::GetObjectByHeapObjectIdResult> {
  static std::unique_ptr<heap_profiler::GetObjectByHeapObjectIdResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::GetObjectByHeapObjectIdResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::GetObjectByHeapObjectIdResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::AddInspectedHeapObjectParams> {
  static std::unique_ptr<heap_profiler::AddInspectedHeapObjectParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::AddInspectedHeapObjectParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::AddInspectedHeapObjectParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::GetHeapObjectIdParams> {
  static std::unique_ptr<heap_profiler::GetHeapObjectIdParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::GetHeapObjectIdParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::GetHeapObjectIdParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::GetHeapObjectIdResult> {
  static std::unique_ptr<heap_profiler::GetHeapObjectIdResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::GetHeapObjectIdResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::GetHeapObjectIdResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<heap_profiler::StopSamplingResult> {
  static std::unique_ptr<heap_profiler::StopSamplingResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return heap_profiler::StopSamplingResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const heap_profiler::StopSamplingResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<worker::SendMessageToWorkerParams> {
  static std::unique_ptr<worker::SendMessageToWorkerParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return worker::SendMessageToWorkerParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const worker::SendMessageToWorkerParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<worker::SetWaitForDebuggerOnStartParams> {
  static std::unique_ptr<worker::SetWaitForDebuggerOnStartParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return worker::SetWaitForDebuggerOnStartParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const worker::SetWaitForDebuggerOnStartParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::ServiceWorkerRegistration> {
  static std::unique_ptr<service_worker::ServiceWorkerRegistration> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::ServiceWorkerRegistration::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::ServiceWorkerRegistration& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<service_worker::ServiceWorkerVersionRunningStatus> {
  static service_worker::ServiceWorkerVersionRunningStatus Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return service_worker::ServiceWorkerVersionRunningStatus::STOPPED;
    }
    if (string_value == "stopped")
      return service_worker::ServiceWorkerVersionRunningStatus::STOPPED;
    if (string_value == "starting")
      return service_worker::ServiceWorkerVersionRunningStatus::STARTING;
    if (string_value == "running")
      return service_worker::ServiceWorkerVersionRunningStatus::RUNNING;
    if (string_value == "stopping")
      return service_worker::ServiceWorkerVersionRunningStatus::STOPPING;
    errors->AddError("invalid enum value");
    return service_worker::ServiceWorkerVersionRunningStatus::STOPPED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::ServiceWorkerVersionRunningStatus& value, T*) {
  switch (value) {
    case service_worker::ServiceWorkerVersionRunningStatus::STOPPED:
      return base::WrapUnique(new base::StringValue("stopped"));
    case service_worker::ServiceWorkerVersionRunningStatus::STARTING:
      return base::WrapUnique(new base::StringValue("starting"));
    case service_worker::ServiceWorkerVersionRunningStatus::RUNNING:
      return base::WrapUnique(new base::StringValue("running"));
    case service_worker::ServiceWorkerVersionRunningStatus::STOPPING:
      return base::WrapUnique(new base::StringValue("stopping"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<service_worker::ServiceWorkerVersionStatus> {
  static service_worker::ServiceWorkerVersionStatus Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return service_worker::ServiceWorkerVersionStatus::NEW;
    }
    if (string_value == "new")
      return service_worker::ServiceWorkerVersionStatus::NEW;
    if (string_value == "installing")
      return service_worker::ServiceWorkerVersionStatus::INSTALLING;
    if (string_value == "installed")
      return service_worker::ServiceWorkerVersionStatus::INSTALLED;
    if (string_value == "activating")
      return service_worker::ServiceWorkerVersionStatus::ACTIVATING;
    if (string_value == "activated")
      return service_worker::ServiceWorkerVersionStatus::ACTIVATED;
    if (string_value == "redundant")
      return service_worker::ServiceWorkerVersionStatus::REDUNDANT;
    errors->AddError("invalid enum value");
    return service_worker::ServiceWorkerVersionStatus::NEW;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::ServiceWorkerVersionStatus& value, T*) {
  switch (value) {
    case service_worker::ServiceWorkerVersionStatus::NEW:
      return base::WrapUnique(new base::StringValue("new"));
    case service_worker::ServiceWorkerVersionStatus::INSTALLING:
      return base::WrapUnique(new base::StringValue("installing"));
    case service_worker::ServiceWorkerVersionStatus::INSTALLED:
      return base::WrapUnique(new base::StringValue("installed"));
    case service_worker::ServiceWorkerVersionStatus::ACTIVATING:
      return base::WrapUnique(new base::StringValue("activating"));
    case service_worker::ServiceWorkerVersionStatus::ACTIVATED:
      return base::WrapUnique(new base::StringValue("activated"));
    case service_worker::ServiceWorkerVersionStatus::REDUNDANT:
      return base::WrapUnique(new base::StringValue("redundant"));
  };
  NOTREACHED();
  return nullptr;
}


template <>
struct FromValue<service_worker::ServiceWorkerVersion> {
  static std::unique_ptr<service_worker::ServiceWorkerVersion> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::ServiceWorkerVersion::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::ServiceWorkerVersion& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::ServiceWorkerErrorMessage> {
  static std::unique_ptr<service_worker::ServiceWorkerErrorMessage> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::ServiceWorkerErrorMessage::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::ServiceWorkerErrorMessage& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::TargetInfo> {
  static std::unique_ptr<service_worker::TargetInfo> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::TargetInfo::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::TargetInfo& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::SendMessageParams> {
  static std::unique_ptr<service_worker::SendMessageParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::SendMessageParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::SendMessageParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::StopParams> {
  static std::unique_ptr<service_worker::StopParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::StopParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::StopParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::UnregisterParams> {
  static std::unique_ptr<service_worker::UnregisterParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::UnregisterParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::UnregisterParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::UpdateRegistrationParams> {
  static std::unique_ptr<service_worker::UpdateRegistrationParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::UpdateRegistrationParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::UpdateRegistrationParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::StartWorkerParams> {
  static std::unique_ptr<service_worker::StartWorkerParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::StartWorkerParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::StartWorkerParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::StopWorkerParams> {
  static std::unique_ptr<service_worker::StopWorkerParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::StopWorkerParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::StopWorkerParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::InspectWorkerParams> {
  static std::unique_ptr<service_worker::InspectWorkerParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::InspectWorkerParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::InspectWorkerParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::SetForceUpdateOnPageLoadParams> {
  static std::unique_ptr<service_worker::SetForceUpdateOnPageLoadParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::SetForceUpdateOnPageLoadParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::SetForceUpdateOnPageLoadParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::DeliverPushMessageParams> {
  static std::unique_ptr<service_worker::DeliverPushMessageParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::DeliverPushMessageParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::DeliverPushMessageParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::GetTargetInfoParams> {
  static std::unique_ptr<service_worker::GetTargetInfoParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::GetTargetInfoParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::GetTargetInfoParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::GetTargetInfoResult> {
  static std::unique_ptr<service_worker::GetTargetInfoResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::GetTargetInfoResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::GetTargetInfoResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<service_worker::ActivateTargetParams> {
  static std::unique_ptr<service_worker::ActivateTargetParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return service_worker::ActivateTargetParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const service_worker::ActivateTargetParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<input::TouchPoint> {
  static std::unique_ptr<input::TouchPoint> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::TouchPoint::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::TouchPoint& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<input::GestureSourceType> {
  static input::GestureSourceType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::GestureSourceType::DEFAULT;
    }
    if (string_value == "default")
      return input::GestureSourceType::DEFAULT;
    if (string_value == "touch")
      return input::GestureSourceType::TOUCH;
    if (string_value == "mouse")
      return input::GestureSourceType::MOUSE;
    errors->AddError("invalid enum value");
    return input::GestureSourceType::DEFAULT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::GestureSourceType& value, T*) {
  switch (value) {
    case input::GestureSourceType::DEFAULT:
      return base::WrapUnique(new base::StringValue("default"));
    case input::GestureSourceType::TOUCH:
      return base::WrapUnique(new base::StringValue("touch"));
    case input::GestureSourceType::MOUSE:
      return base::WrapUnique(new base::StringValue("mouse"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<input::TouchPointState> {
  static input::TouchPointState Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::TouchPointState::TOUCH_PRESSED;
    }
    if (string_value == "touchPressed")
      return input::TouchPointState::TOUCH_PRESSED;
    if (string_value == "touchReleased")
      return input::TouchPointState::TOUCH_RELEASED;
    if (string_value == "touchMoved")
      return input::TouchPointState::TOUCH_MOVED;
    if (string_value == "touchStationary")
      return input::TouchPointState::TOUCH_STATIONARY;
    if (string_value == "touchCancelled")
      return input::TouchPointState::TOUCH_CANCELLED;
    errors->AddError("invalid enum value");
    return input::TouchPointState::TOUCH_PRESSED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::TouchPointState& value, T*) {
  switch (value) {
    case input::TouchPointState::TOUCH_PRESSED:
      return base::WrapUnique(new base::StringValue("touchPressed"));
    case input::TouchPointState::TOUCH_RELEASED:
      return base::WrapUnique(new base::StringValue("touchReleased"));
    case input::TouchPointState::TOUCH_MOVED:
      return base::WrapUnique(new base::StringValue("touchMoved"));
    case input::TouchPointState::TOUCH_STATIONARY:
      return base::WrapUnique(new base::StringValue("touchStationary"));
    case input::TouchPointState::TOUCH_CANCELLED:
      return base::WrapUnique(new base::StringValue("touchCancelled"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<input::DispatchKeyEventType> {
  static input::DispatchKeyEventType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::DispatchKeyEventType::KEY_DOWN;
    }
    if (string_value == "keyDown")
      return input::DispatchKeyEventType::KEY_DOWN;
    if (string_value == "keyUp")
      return input::DispatchKeyEventType::KEY_UP;
    if (string_value == "rawKeyDown")
      return input::DispatchKeyEventType::RAW_KEY_DOWN;
    if (string_value == "char")
      return input::DispatchKeyEventType::CHAR;
    errors->AddError("invalid enum value");
    return input::DispatchKeyEventType::KEY_DOWN;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::DispatchKeyEventType& value, T*) {
  switch (value) {
    case input::DispatchKeyEventType::KEY_DOWN:
      return base::WrapUnique(new base::StringValue("keyDown"));
    case input::DispatchKeyEventType::KEY_UP:
      return base::WrapUnique(new base::StringValue("keyUp"));
    case input::DispatchKeyEventType::RAW_KEY_DOWN:
      return base::WrapUnique(new base::StringValue("rawKeyDown"));
    case input::DispatchKeyEventType::CHAR:
      return base::WrapUnique(new base::StringValue("char"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<input::DispatchKeyEventParams> {
  static std::unique_ptr<input::DispatchKeyEventParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::DispatchKeyEventParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::DispatchKeyEventParams& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<input::DispatchMouseEventType> {
  static input::DispatchMouseEventType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::DispatchMouseEventType::MOUSE_PRESSED;
    }
    if (string_value == "mousePressed")
      return input::DispatchMouseEventType::MOUSE_PRESSED;
    if (string_value == "mouseReleased")
      return input::DispatchMouseEventType::MOUSE_RELEASED;
    if (string_value == "mouseMoved")
      return input::DispatchMouseEventType::MOUSE_MOVED;
    errors->AddError("invalid enum value");
    return input::DispatchMouseEventType::MOUSE_PRESSED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::DispatchMouseEventType& value, T*) {
  switch (value) {
    case input::DispatchMouseEventType::MOUSE_PRESSED:
      return base::WrapUnique(new base::StringValue("mousePressed"));
    case input::DispatchMouseEventType::MOUSE_RELEASED:
      return base::WrapUnique(new base::StringValue("mouseReleased"));
    case input::DispatchMouseEventType::MOUSE_MOVED:
      return base::WrapUnique(new base::StringValue("mouseMoved"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<input::DispatchMouseEventButton> {
  static input::DispatchMouseEventButton Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::DispatchMouseEventButton::NONE;
    }
    if (string_value == "none")
      return input::DispatchMouseEventButton::NONE;
    if (string_value == "left")
      return input::DispatchMouseEventButton::LEFT;
    if (string_value == "middle")
      return input::DispatchMouseEventButton::MIDDLE;
    if (string_value == "right")
      return input::DispatchMouseEventButton::RIGHT;
    errors->AddError("invalid enum value");
    return input::DispatchMouseEventButton::NONE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::DispatchMouseEventButton& value, T*) {
  switch (value) {
    case input::DispatchMouseEventButton::NONE:
      return base::WrapUnique(new base::StringValue("none"));
    case input::DispatchMouseEventButton::LEFT:
      return base::WrapUnique(new base::StringValue("left"));
    case input::DispatchMouseEventButton::MIDDLE:
      return base::WrapUnique(new base::StringValue("middle"));
    case input::DispatchMouseEventButton::RIGHT:
      return base::WrapUnique(new base::StringValue("right"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<input::DispatchMouseEventParams> {
  static std::unique_ptr<input::DispatchMouseEventParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::DispatchMouseEventParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::DispatchMouseEventParams& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<input::DispatchTouchEventType> {
  static input::DispatchTouchEventType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::DispatchTouchEventType::TOUCH_START;
    }
    if (string_value == "touchStart")
      return input::DispatchTouchEventType::TOUCH_START;
    if (string_value == "touchEnd")
      return input::DispatchTouchEventType::TOUCH_END;
    if (string_value == "touchMove")
      return input::DispatchTouchEventType::TOUCH_MOVE;
    errors->AddError("invalid enum value");
    return input::DispatchTouchEventType::TOUCH_START;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::DispatchTouchEventType& value, T*) {
  switch (value) {
    case input::DispatchTouchEventType::TOUCH_START:
      return base::WrapUnique(new base::StringValue("touchStart"));
    case input::DispatchTouchEventType::TOUCH_END:
      return base::WrapUnique(new base::StringValue("touchEnd"));
    case input::DispatchTouchEventType::TOUCH_MOVE:
      return base::WrapUnique(new base::StringValue("touchMove"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<input::DispatchTouchEventParams> {
  static std::unique_ptr<input::DispatchTouchEventParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::DispatchTouchEventParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::DispatchTouchEventParams& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<input::EmulateTouchFromMouseEventType> {
  static input::EmulateTouchFromMouseEventType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::EmulateTouchFromMouseEventType::MOUSE_PRESSED;
    }
    if (string_value == "mousePressed")
      return input::EmulateTouchFromMouseEventType::MOUSE_PRESSED;
    if (string_value == "mouseReleased")
      return input::EmulateTouchFromMouseEventType::MOUSE_RELEASED;
    if (string_value == "mouseMoved")
      return input::EmulateTouchFromMouseEventType::MOUSE_MOVED;
    if (string_value == "mouseWheel")
      return input::EmulateTouchFromMouseEventType::MOUSE_WHEEL;
    errors->AddError("invalid enum value");
    return input::EmulateTouchFromMouseEventType::MOUSE_PRESSED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::EmulateTouchFromMouseEventType& value, T*) {
  switch (value) {
    case input::EmulateTouchFromMouseEventType::MOUSE_PRESSED:
      return base::WrapUnique(new base::StringValue("mousePressed"));
    case input::EmulateTouchFromMouseEventType::MOUSE_RELEASED:
      return base::WrapUnique(new base::StringValue("mouseReleased"));
    case input::EmulateTouchFromMouseEventType::MOUSE_MOVED:
      return base::WrapUnique(new base::StringValue("mouseMoved"));
    case input::EmulateTouchFromMouseEventType::MOUSE_WHEEL:
      return base::WrapUnique(new base::StringValue("mouseWheel"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<input::EmulateTouchFromMouseEventButton> {
  static input::EmulateTouchFromMouseEventButton Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return input::EmulateTouchFromMouseEventButton::NONE;
    }
    if (string_value == "none")
      return input::EmulateTouchFromMouseEventButton::NONE;
    if (string_value == "left")
      return input::EmulateTouchFromMouseEventButton::LEFT;
    if (string_value == "middle")
      return input::EmulateTouchFromMouseEventButton::MIDDLE;
    if (string_value == "right")
      return input::EmulateTouchFromMouseEventButton::RIGHT;
    errors->AddError("invalid enum value");
    return input::EmulateTouchFromMouseEventButton::NONE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::EmulateTouchFromMouseEventButton& value, T*) {
  switch (value) {
    case input::EmulateTouchFromMouseEventButton::NONE:
      return base::WrapUnique(new base::StringValue("none"));
    case input::EmulateTouchFromMouseEventButton::LEFT:
      return base::WrapUnique(new base::StringValue("left"));
    case input::EmulateTouchFromMouseEventButton::MIDDLE:
      return base::WrapUnique(new base::StringValue("middle"));
    case input::EmulateTouchFromMouseEventButton::RIGHT:
      return base::WrapUnique(new base::StringValue("right"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<input::EmulateTouchFromMouseEventParams> {
  static std::unique_ptr<input::EmulateTouchFromMouseEventParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::EmulateTouchFromMouseEventParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::EmulateTouchFromMouseEventParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<input::SynthesizePinchGestureParams> {
  static std::unique_ptr<input::SynthesizePinchGestureParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::SynthesizePinchGestureParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::SynthesizePinchGestureParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<input::SynthesizeScrollGestureParams> {
  static std::unique_ptr<input::SynthesizeScrollGestureParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::SynthesizeScrollGestureParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::SynthesizeScrollGestureParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<input::SynthesizeTapGestureParams> {
  static std::unique_ptr<input::SynthesizeTapGestureParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return input::SynthesizeTapGestureParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const input::SynthesizeTapGestureParams& value, T*) {
  return value.Serialize();
}




template <>
struct FromValue<layer_tree::ScrollRect> {
  static std::unique_ptr<layer_tree::ScrollRect> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::ScrollRect::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::ScrollRect& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::PictureTile> {
  static std::unique_ptr<layer_tree::PictureTile> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::PictureTile::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::PictureTile& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::Layer> {
  static std::unique_ptr<layer_tree::Layer> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::Layer::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::Layer& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::ScrollRectType> {
  static layer_tree::ScrollRectType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return layer_tree::ScrollRectType::REPAINTS_ON_SCROLL;
    }
    if (string_value == "RepaintsOnScroll")
      return layer_tree::ScrollRectType::REPAINTS_ON_SCROLL;
    if (string_value == "TouchEventHandler")
      return layer_tree::ScrollRectType::TOUCH_EVENT_HANDLER;
    if (string_value == "WheelEventHandler")
      return layer_tree::ScrollRectType::WHEEL_EVENT_HANDLER;
    errors->AddError("invalid enum value");
    return layer_tree::ScrollRectType::REPAINTS_ON_SCROLL;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::ScrollRectType& value, T*) {
  switch (value) {
    case layer_tree::ScrollRectType::REPAINTS_ON_SCROLL:
      return base::WrapUnique(new base::StringValue("RepaintsOnScroll"));
    case layer_tree::ScrollRectType::TOUCH_EVENT_HANDLER:
      return base::WrapUnique(new base::StringValue("TouchEventHandler"));
    case layer_tree::ScrollRectType::WHEEL_EVENT_HANDLER:
      return base::WrapUnique(new base::StringValue("WheelEventHandler"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<layer_tree::CompositingReasonsParams> {
  static std::unique_ptr<layer_tree::CompositingReasonsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::CompositingReasonsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::CompositingReasonsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::CompositingReasonsResult> {
  static std::unique_ptr<layer_tree::CompositingReasonsResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::CompositingReasonsResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::CompositingReasonsResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::MakeSnapshotParams> {
  static std::unique_ptr<layer_tree::MakeSnapshotParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::MakeSnapshotParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::MakeSnapshotParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::MakeSnapshotResult> {
  static std::unique_ptr<layer_tree::MakeSnapshotResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::MakeSnapshotResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::MakeSnapshotResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::LoadSnapshotParams> {
  static std::unique_ptr<layer_tree::LoadSnapshotParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::LoadSnapshotParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::LoadSnapshotParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::LoadSnapshotResult> {
  static std::unique_ptr<layer_tree::LoadSnapshotResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::LoadSnapshotResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::LoadSnapshotResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::ReleaseSnapshotParams> {
  static std::unique_ptr<layer_tree::ReleaseSnapshotParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::ReleaseSnapshotParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::ReleaseSnapshotParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::ProfileSnapshotParams> {
  static std::unique_ptr<layer_tree::ProfileSnapshotParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::ProfileSnapshotParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::ProfileSnapshotParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::ProfileSnapshotResult> {
  static std::unique_ptr<layer_tree::ProfileSnapshotResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::ProfileSnapshotResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::ProfileSnapshotResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::ReplaySnapshotParams> {
  static std::unique_ptr<layer_tree::ReplaySnapshotParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::ReplaySnapshotParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::ReplaySnapshotParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::ReplaySnapshotResult> {
  static std::unique_ptr<layer_tree::ReplaySnapshotResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::ReplaySnapshotResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::ReplaySnapshotResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::SnapshotCommandLogParams> {
  static std::unique_ptr<layer_tree::SnapshotCommandLogParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::SnapshotCommandLogParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::SnapshotCommandLogParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<layer_tree::SnapshotCommandLogResult> {
  static std::unique_ptr<layer_tree::SnapshotCommandLogResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return layer_tree::SnapshotCommandLogResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const layer_tree::SnapshotCommandLogResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<device_orientation::SetDeviceOrientationOverrideParams> {
  static std::unique_ptr<device_orientation::SetDeviceOrientationOverrideParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return device_orientation::SetDeviceOrientationOverrideParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const device_orientation::SetDeviceOrientationOverrideParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<tracing::MemoryDumpTrigger> {
  static std::unique_ptr<tracing::MemoryDumpTrigger> Parse(const base::Value& value, ErrorReporter* errors) {
    return tracing::MemoryDumpTrigger::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::MemoryDumpTrigger& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<tracing::MemoryDumpConfig> {
  static std::unique_ptr<tracing::MemoryDumpConfig> Parse(const base::Value& value, ErrorReporter* errors) {
    return tracing::MemoryDumpConfig::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::MemoryDumpConfig& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<tracing::TraceConfig> {
  static std::unique_ptr<tracing::TraceConfig> Parse(const base::Value& value, ErrorReporter* errors) {
    return tracing::TraceConfig::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::TraceConfig& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<tracing::MemoryDumpTriggerMode> {
  static tracing::MemoryDumpTriggerMode Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return tracing::MemoryDumpTriggerMode::LIGHT;
    }
    if (string_value == "light")
      return tracing::MemoryDumpTriggerMode::LIGHT;
    if (string_value == "detailed")
      return tracing::MemoryDumpTriggerMode::DETAILED;
    errors->AddError("invalid enum value");
    return tracing::MemoryDumpTriggerMode::LIGHT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::MemoryDumpTriggerMode& value, T*) {
  switch (value) {
    case tracing::MemoryDumpTriggerMode::LIGHT:
      return base::WrapUnique(new base::StringValue("light"));
    case tracing::MemoryDumpTriggerMode::DETAILED:
      return base::WrapUnique(new base::StringValue("detailed"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<tracing::TraceConfigRecordMode> {
  static tracing::TraceConfigRecordMode Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return tracing::TraceConfigRecordMode::RECORD_UNTIL_FULL;
    }
    if (string_value == "recordUntilFull")
      return tracing::TraceConfigRecordMode::RECORD_UNTIL_FULL;
    if (string_value == "recordContinuously")
      return tracing::TraceConfigRecordMode::RECORD_CONTINUOUSLY;
    if (string_value == "recordAsMuchAsPossible")
      return tracing::TraceConfigRecordMode::RECORD_AS_MUCH_AS_POSSIBLE;
    if (string_value == "echoToConsole")
      return tracing::TraceConfigRecordMode::ECHO_TO_CONSOLE;
    errors->AddError("invalid enum value");
    return tracing::TraceConfigRecordMode::RECORD_UNTIL_FULL;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::TraceConfigRecordMode& value, T*) {
  switch (value) {
    case tracing::TraceConfigRecordMode::RECORD_UNTIL_FULL:
      return base::WrapUnique(new base::StringValue("recordUntilFull"));
    case tracing::TraceConfigRecordMode::RECORD_CONTINUOUSLY:
      return base::WrapUnique(new base::StringValue("recordContinuously"));
    case tracing::TraceConfigRecordMode::RECORD_AS_MUCH_AS_POSSIBLE:
      return base::WrapUnique(new base::StringValue("recordAsMuchAsPossible"));
    case tracing::TraceConfigRecordMode::ECHO_TO_CONSOLE:
      return base::WrapUnique(new base::StringValue("echoToConsole"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<tracing::StartTransferMode> {
  static tracing::StartTransferMode Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return tracing::StartTransferMode::REPORT_EVENTS;
    }
    if (string_value == "ReportEvents")
      return tracing::StartTransferMode::REPORT_EVENTS;
    if (string_value == "ReturnAsStream")
      return tracing::StartTransferMode::RETURN_AS_STREAM;
    errors->AddError("invalid enum value");
    return tracing::StartTransferMode::REPORT_EVENTS;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::StartTransferMode& value, T*) {
  switch (value) {
    case tracing::StartTransferMode::REPORT_EVENTS:
      return base::WrapUnique(new base::StringValue("ReportEvents"));
    case tracing::StartTransferMode::RETURN_AS_STREAM:
      return base::WrapUnique(new base::StringValue("ReturnAsStream"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<tracing::StartParams> {
  static std::unique_ptr<tracing::StartParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return tracing::StartParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::StartParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<tracing::GetCategoriesResult> {
  static std::unique_ptr<tracing::GetCategoriesResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return tracing::GetCategoriesResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::GetCategoriesResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<tracing::RequestMemoryDumpResult> {
  static std::unique_ptr<tracing::RequestMemoryDumpResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return tracing::RequestMemoryDumpResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::RequestMemoryDumpResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<tracing::RecordClockSyncMarkerParams> {
  static std::unique_ptr<tracing::RecordClockSyncMarkerParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return tracing::RecordClockSyncMarkerParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const tracing::RecordClockSyncMarkerParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::Animation> {
  static std::unique_ptr<animation::Animation> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::Animation::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::Animation& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::AnimationEffect> {
  static std::unique_ptr<animation::AnimationEffect> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::AnimationEffect::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::AnimationEffect& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::KeyframesRule> {
  static std::unique_ptr<animation::KeyframesRule> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::KeyframesRule::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::KeyframesRule& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::KeyframeStyle> {
  static std::unique_ptr<animation::KeyframeStyle> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::KeyframeStyle::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::KeyframeStyle& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<animation::AnimationType> {
  static animation::AnimationType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return animation::AnimationType::CSS_TRANSITION;
    }
    if (string_value == "CSSTransition")
      return animation::AnimationType::CSS_TRANSITION;
    if (string_value == "CSSAnimation")
      return animation::AnimationType::CSS_ANIMATION;
    if (string_value == "WebAnimation")
      return animation::AnimationType::WEB_ANIMATION;
    errors->AddError("invalid enum value");
    return animation::AnimationType::CSS_TRANSITION;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::AnimationType& value, T*) {
  switch (value) {
    case animation::AnimationType::CSS_TRANSITION:
      return base::WrapUnique(new base::StringValue("CSSTransition"));
    case animation::AnimationType::CSS_ANIMATION:
      return base::WrapUnique(new base::StringValue("CSSAnimation"));
    case animation::AnimationType::WEB_ANIMATION:
      return base::WrapUnique(new base::StringValue("WebAnimation"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<animation::GetPlaybackRateResult> {
  static std::unique_ptr<animation::GetPlaybackRateResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::GetPlaybackRateResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::GetPlaybackRateResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::SetPlaybackRateParams> {
  static std::unique_ptr<animation::SetPlaybackRateParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::SetPlaybackRateParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::SetPlaybackRateParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::GetCurrentTimeParams> {
  static std::unique_ptr<animation::GetCurrentTimeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::GetCurrentTimeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::GetCurrentTimeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::GetCurrentTimeResult> {
  static std::unique_ptr<animation::GetCurrentTimeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::GetCurrentTimeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::GetCurrentTimeResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::SetPausedParams> {
  static std::unique_ptr<animation::SetPausedParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::SetPausedParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::SetPausedParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::SetTimingParams> {
  static std::unique_ptr<animation::SetTimingParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::SetTimingParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::SetTimingParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::SeekAnimationsParams> {
  static std::unique_ptr<animation::SeekAnimationsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::SeekAnimationsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::SeekAnimationsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::ReleaseAnimationsParams> {
  static std::unique_ptr<animation::ReleaseAnimationsParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::ReleaseAnimationsParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::ReleaseAnimationsParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::ResolveAnimationParams> {
  static std::unique_ptr<animation::ResolveAnimationParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::ResolveAnimationParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::ResolveAnimationParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<animation::ResolveAnimationResult> {
  static std::unique_ptr<animation::ResolveAnimationResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return animation::ResolveAnimationResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const animation::ResolveAnimationResult& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<accessibility::AXValueType> {
  static accessibility::AXValueType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXValueType::BOOLEAN;
    }
    if (string_value == "boolean")
      return accessibility::AXValueType::BOOLEAN;
    if (string_value == "tristate")
      return accessibility::AXValueType::TRISTATE;
    if (string_value == "booleanOrUndefined")
      return accessibility::AXValueType::BOOLEAN_OR_UNDEFINED;
    if (string_value == "idref")
      return accessibility::AXValueType::IDREF;
    if (string_value == "idrefList")
      return accessibility::AXValueType::IDREF_LIST;
    if (string_value == "integer")
      return accessibility::AXValueType::INTEGER;
    if (string_value == "node")
      return accessibility::AXValueType::NODE;
    if (string_value == "nodeList")
      return accessibility::AXValueType::NODE_LIST;
    if (string_value == "number")
      return accessibility::AXValueType::NUMBER;
    if (string_value == "string")
      return accessibility::AXValueType::STRING;
    if (string_value == "computedString")
      return accessibility::AXValueType::COMPUTED_STRING;
    if (string_value == "token")
      return accessibility::AXValueType::TOKEN;
    if (string_value == "tokenList")
      return accessibility::AXValueType::TOKEN_LIST;
    if (string_value == "domRelation")
      return accessibility::AXValueType::DOM_RELATION;
    if (string_value == "role")
      return accessibility::AXValueType::ROLE;
    if (string_value == "internalRole")
      return accessibility::AXValueType::INTERNAL_ROLE;
    if (string_value == "valueUndefined")
      return accessibility::AXValueType::VALUE_UNDEFINED;
    errors->AddError("invalid enum value");
    return accessibility::AXValueType::BOOLEAN;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXValueType& value, T*) {
  switch (value) {
    case accessibility::AXValueType::BOOLEAN:
      return base::WrapUnique(new base::StringValue("boolean"));
    case accessibility::AXValueType::TRISTATE:
      return base::WrapUnique(new base::StringValue("tristate"));
    case accessibility::AXValueType::BOOLEAN_OR_UNDEFINED:
      return base::WrapUnique(new base::StringValue("booleanOrUndefined"));
    case accessibility::AXValueType::IDREF:
      return base::WrapUnique(new base::StringValue("idref"));
    case accessibility::AXValueType::IDREF_LIST:
      return base::WrapUnique(new base::StringValue("idrefList"));
    case accessibility::AXValueType::INTEGER:
      return base::WrapUnique(new base::StringValue("integer"));
    case accessibility::AXValueType::NODE:
      return base::WrapUnique(new base::StringValue("node"));
    case accessibility::AXValueType::NODE_LIST:
      return base::WrapUnique(new base::StringValue("nodeList"));
    case accessibility::AXValueType::NUMBER:
      return base::WrapUnique(new base::StringValue("number"));
    case accessibility::AXValueType::STRING:
      return base::WrapUnique(new base::StringValue("string"));
    case accessibility::AXValueType::COMPUTED_STRING:
      return base::WrapUnique(new base::StringValue("computedString"));
    case accessibility::AXValueType::TOKEN:
      return base::WrapUnique(new base::StringValue("token"));
    case accessibility::AXValueType::TOKEN_LIST:
      return base::WrapUnique(new base::StringValue("tokenList"));
    case accessibility::AXValueType::DOM_RELATION:
      return base::WrapUnique(new base::StringValue("domRelation"));
    case accessibility::AXValueType::ROLE:
      return base::WrapUnique(new base::StringValue("role"));
    case accessibility::AXValueType::INTERNAL_ROLE:
      return base::WrapUnique(new base::StringValue("internalRole"));
    case accessibility::AXValueType::VALUE_UNDEFINED:
      return base::WrapUnique(new base::StringValue("valueUndefined"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<accessibility::AXValueSourceType> {
  static accessibility::AXValueSourceType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXValueSourceType::ATTRIBUTE;
    }
    if (string_value == "attribute")
      return accessibility::AXValueSourceType::ATTRIBUTE;
    if (string_value == "implicit")
      return accessibility::AXValueSourceType::IMPLICIT;
    if (string_value == "style")
      return accessibility::AXValueSourceType::STYLE;
    if (string_value == "contents")
      return accessibility::AXValueSourceType::CONTENTS;
    if (string_value == "placeholder")
      return accessibility::AXValueSourceType::PLACEHOLDER;
    if (string_value == "relatedElement")
      return accessibility::AXValueSourceType::RELATED_ELEMENT;
    errors->AddError("invalid enum value");
    return accessibility::AXValueSourceType::ATTRIBUTE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXValueSourceType& value, T*) {
  switch (value) {
    case accessibility::AXValueSourceType::ATTRIBUTE:
      return base::WrapUnique(new base::StringValue("attribute"));
    case accessibility::AXValueSourceType::IMPLICIT:
      return base::WrapUnique(new base::StringValue("implicit"));
    case accessibility::AXValueSourceType::STYLE:
      return base::WrapUnique(new base::StringValue("style"));
    case accessibility::AXValueSourceType::CONTENTS:
      return base::WrapUnique(new base::StringValue("contents"));
    case accessibility::AXValueSourceType::PLACEHOLDER:
      return base::WrapUnique(new base::StringValue("placeholder"));
    case accessibility::AXValueSourceType::RELATED_ELEMENT:
      return base::WrapUnique(new base::StringValue("relatedElement"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<accessibility::AXValueNativeSourceType> {
  static accessibility::AXValueNativeSourceType Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXValueNativeSourceType::FIGCAPTION;
    }
    if (string_value == "figcaption")
      return accessibility::AXValueNativeSourceType::FIGCAPTION;
    if (string_value == "label")
      return accessibility::AXValueNativeSourceType::LABEL;
    if (string_value == "labelfor")
      return accessibility::AXValueNativeSourceType::LABELFOR;
    if (string_value == "labelwrapped")
      return accessibility::AXValueNativeSourceType::LABELWRAPPED;
    if (string_value == "legend")
      return accessibility::AXValueNativeSourceType::LEGEND;
    if (string_value == "tablecaption")
      return accessibility::AXValueNativeSourceType::TABLECAPTION;
    if (string_value == "title")
      return accessibility::AXValueNativeSourceType::TITLE;
    if (string_value == "other")
      return accessibility::AXValueNativeSourceType::OTHER;
    errors->AddError("invalid enum value");
    return accessibility::AXValueNativeSourceType::FIGCAPTION;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXValueNativeSourceType& value, T*) {
  switch (value) {
    case accessibility::AXValueNativeSourceType::FIGCAPTION:
      return base::WrapUnique(new base::StringValue("figcaption"));
    case accessibility::AXValueNativeSourceType::LABEL:
      return base::WrapUnique(new base::StringValue("label"));
    case accessibility::AXValueNativeSourceType::LABELFOR:
      return base::WrapUnique(new base::StringValue("labelfor"));
    case accessibility::AXValueNativeSourceType::LABELWRAPPED:
      return base::WrapUnique(new base::StringValue("labelwrapped"));
    case accessibility::AXValueNativeSourceType::LEGEND:
      return base::WrapUnique(new base::StringValue("legend"));
    case accessibility::AXValueNativeSourceType::TABLECAPTION:
      return base::WrapUnique(new base::StringValue("tablecaption"));
    case accessibility::AXValueNativeSourceType::TITLE:
      return base::WrapUnique(new base::StringValue("title"));
    case accessibility::AXValueNativeSourceType::OTHER:
      return base::WrapUnique(new base::StringValue("other"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<accessibility::AXValueSource> {
  static std::unique_ptr<accessibility::AXValueSource> Parse(const base::Value& value, ErrorReporter* errors) {
    return accessibility::AXValueSource::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXValueSource& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<accessibility::AXRelatedNode> {
  static std::unique_ptr<accessibility::AXRelatedNode> Parse(const base::Value& value, ErrorReporter* errors) {
    return accessibility::AXRelatedNode::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXRelatedNode& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<accessibility::AXProperty> {
  static std::unique_ptr<accessibility::AXProperty> Parse(const base::Value& value, ErrorReporter* errors) {
    return accessibility::AXProperty::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXProperty& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<accessibility::AXValue> {
  static std::unique_ptr<accessibility::AXValue> Parse(const base::Value& value, ErrorReporter* errors) {
    return accessibility::AXValue::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXValue& value, T*) {
  return value.Serialize();
}

template <>
struct FromValue<accessibility::AXGlobalStates> {
  static accessibility::AXGlobalStates Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXGlobalStates::DISABLED;
    }
    if (string_value == "disabled")
      return accessibility::AXGlobalStates::DISABLED;
    if (string_value == "hidden")
      return accessibility::AXGlobalStates::HIDDEN;
    if (string_value == "hiddenRoot")
      return accessibility::AXGlobalStates::HIDDEN_ROOT;
    if (string_value == "invalid")
      return accessibility::AXGlobalStates::INVALID;
    errors->AddError("invalid enum value");
    return accessibility::AXGlobalStates::DISABLED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXGlobalStates& value, T*) {
  switch (value) {
    case accessibility::AXGlobalStates::DISABLED:
      return base::WrapUnique(new base::StringValue("disabled"));
    case accessibility::AXGlobalStates::HIDDEN:
      return base::WrapUnique(new base::StringValue("hidden"));
    case accessibility::AXGlobalStates::HIDDEN_ROOT:
      return base::WrapUnique(new base::StringValue("hiddenRoot"));
    case accessibility::AXGlobalStates::INVALID:
      return base::WrapUnique(new base::StringValue("invalid"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<accessibility::AXLiveRegionAttributes> {
  static accessibility::AXLiveRegionAttributes Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXLiveRegionAttributes::LIVE;
    }
    if (string_value == "live")
      return accessibility::AXLiveRegionAttributes::LIVE;
    if (string_value == "atomic")
      return accessibility::AXLiveRegionAttributes::ATOMIC;
    if (string_value == "relevant")
      return accessibility::AXLiveRegionAttributes::RELEVANT;
    if (string_value == "busy")
      return accessibility::AXLiveRegionAttributes::BUSY;
    if (string_value == "root")
      return accessibility::AXLiveRegionAttributes::ROOT;
    errors->AddError("invalid enum value");
    return accessibility::AXLiveRegionAttributes::LIVE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXLiveRegionAttributes& value, T*) {
  switch (value) {
    case accessibility::AXLiveRegionAttributes::LIVE:
      return base::WrapUnique(new base::StringValue("live"));
    case accessibility::AXLiveRegionAttributes::ATOMIC:
      return base::WrapUnique(new base::StringValue("atomic"));
    case accessibility::AXLiveRegionAttributes::RELEVANT:
      return base::WrapUnique(new base::StringValue("relevant"));
    case accessibility::AXLiveRegionAttributes::BUSY:
      return base::WrapUnique(new base::StringValue("busy"));
    case accessibility::AXLiveRegionAttributes::ROOT:
      return base::WrapUnique(new base::StringValue("root"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<accessibility::AXWidgetAttributes> {
  static accessibility::AXWidgetAttributes Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXWidgetAttributes::AUTOCOMPLETE;
    }
    if (string_value == "autocomplete")
      return accessibility::AXWidgetAttributes::AUTOCOMPLETE;
    if (string_value == "haspopup")
      return accessibility::AXWidgetAttributes::HASPOPUP;
    if (string_value == "level")
      return accessibility::AXWidgetAttributes::LEVEL;
    if (string_value == "multiselectable")
      return accessibility::AXWidgetAttributes::MULTISELECTABLE;
    if (string_value == "orientation")
      return accessibility::AXWidgetAttributes::ORIENTATION;
    if (string_value == "multiline")
      return accessibility::AXWidgetAttributes::MULTILINE;
    if (string_value == "readonly")
      return accessibility::AXWidgetAttributes::READONLY;
    if (string_value == "required")
      return accessibility::AXWidgetAttributes::REQUIRED;
    if (string_value == "valuemin")
      return accessibility::AXWidgetAttributes::VALUEMIN;
    if (string_value == "valuemax")
      return accessibility::AXWidgetAttributes::VALUEMAX;
    if (string_value == "valuetext")
      return accessibility::AXWidgetAttributes::VALUETEXT;
    errors->AddError("invalid enum value");
    return accessibility::AXWidgetAttributes::AUTOCOMPLETE;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXWidgetAttributes& value, T*) {
  switch (value) {
    case accessibility::AXWidgetAttributes::AUTOCOMPLETE:
      return base::WrapUnique(new base::StringValue("autocomplete"));
    case accessibility::AXWidgetAttributes::HASPOPUP:
      return base::WrapUnique(new base::StringValue("haspopup"));
    case accessibility::AXWidgetAttributes::LEVEL:
      return base::WrapUnique(new base::StringValue("level"));
    case accessibility::AXWidgetAttributes::MULTISELECTABLE:
      return base::WrapUnique(new base::StringValue("multiselectable"));
    case accessibility::AXWidgetAttributes::ORIENTATION:
      return base::WrapUnique(new base::StringValue("orientation"));
    case accessibility::AXWidgetAttributes::MULTILINE:
      return base::WrapUnique(new base::StringValue("multiline"));
    case accessibility::AXWidgetAttributes::READONLY:
      return base::WrapUnique(new base::StringValue("readonly"));
    case accessibility::AXWidgetAttributes::REQUIRED:
      return base::WrapUnique(new base::StringValue("required"));
    case accessibility::AXWidgetAttributes::VALUEMIN:
      return base::WrapUnique(new base::StringValue("valuemin"));
    case accessibility::AXWidgetAttributes::VALUEMAX:
      return base::WrapUnique(new base::StringValue("valuemax"));
    case accessibility::AXWidgetAttributes::VALUETEXT:
      return base::WrapUnique(new base::StringValue("valuetext"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<accessibility::AXWidgetStates> {
  static accessibility::AXWidgetStates Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXWidgetStates::CHECKED;
    }
    if (string_value == "checked")
      return accessibility::AXWidgetStates::CHECKED;
    if (string_value == "expanded")
      return accessibility::AXWidgetStates::EXPANDED;
    if (string_value == "pressed")
      return accessibility::AXWidgetStates::PRESSED;
    if (string_value == "selected")
      return accessibility::AXWidgetStates::SELECTED;
    errors->AddError("invalid enum value");
    return accessibility::AXWidgetStates::CHECKED;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXWidgetStates& value, T*) {
  switch (value) {
    case accessibility::AXWidgetStates::CHECKED:
      return base::WrapUnique(new base::StringValue("checked"));
    case accessibility::AXWidgetStates::EXPANDED:
      return base::WrapUnique(new base::StringValue("expanded"));
    case accessibility::AXWidgetStates::PRESSED:
      return base::WrapUnique(new base::StringValue("pressed"));
    case accessibility::AXWidgetStates::SELECTED:
      return base::WrapUnique(new base::StringValue("selected"));
  };
  NOTREACHED();
  return nullptr;
}
template <>
struct FromValue<accessibility::AXRelationshipAttributes> {
  static accessibility::AXRelationshipAttributes Parse(const base::Value& value, ErrorReporter* errors) {
    std::string string_value;
    if (!value.GetAsString(&string_value)) {
      errors->AddError("string enum value expected");
      return accessibility::AXRelationshipAttributes::ACTIVEDESCENDANT;
    }
    if (string_value == "activedescendant")
      return accessibility::AXRelationshipAttributes::ACTIVEDESCENDANT;
    if (string_value == "flowto")
      return accessibility::AXRelationshipAttributes::FLOWTO;
    if (string_value == "controls")
      return accessibility::AXRelationshipAttributes::CONTROLS;
    if (string_value == "describedby")
      return accessibility::AXRelationshipAttributes::DESCRIBEDBY;
    if (string_value == "labelledby")
      return accessibility::AXRelationshipAttributes::LABELLEDBY;
    if (string_value == "owns")
      return accessibility::AXRelationshipAttributes::OWNS;
    errors->AddError("invalid enum value");
    return accessibility::AXRelationshipAttributes::ACTIVEDESCENDANT;
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXRelationshipAttributes& value, T*) {
  switch (value) {
    case accessibility::AXRelationshipAttributes::ACTIVEDESCENDANT:
      return base::WrapUnique(new base::StringValue("activedescendant"));
    case accessibility::AXRelationshipAttributes::FLOWTO:
      return base::WrapUnique(new base::StringValue("flowto"));
    case accessibility::AXRelationshipAttributes::CONTROLS:
      return base::WrapUnique(new base::StringValue("controls"));
    case accessibility::AXRelationshipAttributes::DESCRIBEDBY:
      return base::WrapUnique(new base::StringValue("describedby"));
    case accessibility::AXRelationshipAttributes::LABELLEDBY:
      return base::WrapUnique(new base::StringValue("labelledby"));
    case accessibility::AXRelationshipAttributes::OWNS:
      return base::WrapUnique(new base::StringValue("owns"));
  };
  NOTREACHED();
  return nullptr;
}

template <>
struct FromValue<accessibility::AXNode> {
  static std::unique_ptr<accessibility::AXNode> Parse(const base::Value& value, ErrorReporter* errors) {
    return accessibility::AXNode::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::AXNode& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<accessibility::GetAXNodeParams> {
  static std::unique_ptr<accessibility::GetAXNodeParams> Parse(const base::Value& value, ErrorReporter* errors) {
    return accessibility::GetAXNodeParams::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::GetAXNodeParams& value, T*) {
  return value.Serialize();
}


template <>
struct FromValue<accessibility::GetAXNodeResult> {
  static std::unique_ptr<accessibility::GetAXNodeResult> Parse(const base::Value& value, ErrorReporter* errors) {
    return accessibility::GetAXNodeResult::Parse(value, errors);
  }
};

template <typename T>
std::unique_ptr<base::Value> ToValueImpl(const accessibility::GetAXNodeResult& value, T*) {
  return value.Serialize();
}


template <typename T>
std::unique_ptr<base::Value> ToValue(const T& value) {
  return ToValueImpl(value, static_cast<T*>(nullptr));
}

}  // namespace internal
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_TYPE_CONVERSIONS_H_
