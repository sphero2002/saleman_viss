// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_MEMORY_H_
#define HEADLESS_PUBLIC_DOMAINS_MEMORY_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace memory {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  void GetDOMCounters(base::Callback<void(std::unique_ptr<GetDOMCountersResult>)> callback = base::Callback<void(std::unique_ptr<GetDOMCountersResult>)>());
  // Enable/disable suppressing memory pressure notifications in all processes.
  void SetPressureNotificationsSuppressed(std::unique_ptr<SetPressureNotificationsSuppressedParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetPressureNotificationsSuppressed(bool suppressed, base::Callback<void()> callback = base::Callback<void()>());
  // Simulate a memory pressure notification in all processes.
  void SimulatePressureNotification(std::unique_ptr<SimulatePressureNotificationParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SimulatePressureNotification(headless::memory::PressureLevel level, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleGetDOMCountersResponse(base::Callback<void(std::unique_ptr<GetDOMCountersResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace memory
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_MEMORY_H_
