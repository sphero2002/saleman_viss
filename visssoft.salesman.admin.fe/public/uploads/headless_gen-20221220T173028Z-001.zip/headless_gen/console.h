// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_CONSOLE_H_
#define HEADLESS_PUBLIC_DOMAINS_CONSOLE_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace console {

// Console domain defines methods and events for interaction with the JavaScript console. Console collects messages created by means of the <a href='http://getfirebug.com/wiki/index.php/Console_API'>JavaScript Console API</a>. One needs to enable this domain using <code>enable</code> command in order to start receiving the console messages. Browser collects messages issued while console domain is not enabled as well and reports them using <code>messageAdded</code> notification upon enabling.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables console domain, sends the messages collected so far to the client by means of the <code>messageAdded</code> notification.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables console domain, prevents further console messages from being reported to the client.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  // Clears console messages collected in the browser.
  void ClearMessages(base::Callback<void()> callback = base::Callback<void()>());
 private:

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace console
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_CONSOLE_H_
