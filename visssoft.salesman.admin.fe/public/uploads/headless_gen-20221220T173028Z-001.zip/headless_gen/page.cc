// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/page.h"

#include "base/bind.h"

namespace headless {

namespace page {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Enable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.enable", std::move(callback));
}

void Domain::Disable(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.disable", std::move(callback));
}

void Domain::AddScriptToEvaluateOnLoad(std::unique_ptr<AddScriptToEvaluateOnLoadParams> params, base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)> callback) {
  dispatcher_->SendMessage("Page.addScriptToEvaluateOnLoad", params->Serialize(), base::Bind(&Domain::HandleAddScriptToEvaluateOnLoadResponse, callback));
}

void Domain::RemoveScriptToEvaluateOnLoad(std::unique_ptr<RemoveScriptToEvaluateOnLoadParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.removeScriptToEvaluateOnLoad", params->Serialize(), std::move(callback));
}

void Domain::SetAutoAttachToCreatedPages(std::unique_ptr<SetAutoAttachToCreatedPagesParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.setAutoAttachToCreatedPages", params->Serialize(), std::move(callback));
}

void Domain::Reload(std::unique_ptr<ReloadParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.reload", params->Serialize(), std::move(callback));
}

void Domain::Navigate(std::unique_ptr<NavigateParams> params, base::Callback<void(std::unique_ptr<NavigateResult>)> callback) {
  dispatcher_->SendMessage("Page.navigate", params->Serialize(), base::Bind(&Domain::HandleNavigateResponse, callback));
}

void Domain::GetNavigationHistory(base::Callback<void(std::unique_ptr<GetNavigationHistoryResult>)> callback) {
  dispatcher_->SendMessage("Page.getNavigationHistory", base::Bind(&Domain::HandleGetNavigationHistoryResponse, callback));
}

void Domain::NavigateToHistoryEntry(std::unique_ptr<NavigateToHistoryEntryParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.navigateToHistoryEntry", params->Serialize(), std::move(callback));
}

void Domain::GetResourceTree(base::Callback<void(std::unique_ptr<GetResourceTreeResult>)> callback) {
  dispatcher_->SendMessage("Page.getResourceTree", base::Bind(&Domain::HandleGetResourceTreeResponse, callback));
}

void Domain::GetResourceContent(std::unique_ptr<GetResourceContentParams> params, base::Callback<void(std::unique_ptr<GetResourceContentResult>)> callback) {
  dispatcher_->SendMessage("Page.getResourceContent", params->Serialize(), base::Bind(&Domain::HandleGetResourceContentResponse, callback));
}

void Domain::SearchInResource(std::unique_ptr<SearchInResourceParams> params, base::Callback<void(std::unique_ptr<SearchInResourceResult>)> callback) {
  dispatcher_->SendMessage("Page.searchInResource", params->Serialize(), base::Bind(&Domain::HandleSearchInResourceResponse, callback));
}

void Domain::SetDocumentContent(std::unique_ptr<SetDocumentContentParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.setDocumentContent", params->Serialize(), std::move(callback));
}

void Domain::CaptureScreenshot(base::Callback<void(std::unique_ptr<CaptureScreenshotResult>)> callback) {
  dispatcher_->SendMessage("Page.captureScreenshot", base::Bind(&Domain::HandleCaptureScreenshotResponse, callback));
}

void Domain::StartScreencast(std::unique_ptr<StartScreencastParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.startScreencast", params->Serialize(), std::move(callback));
}

void Domain::StopScreencast(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.stopScreencast", std::move(callback));
}

void Domain::ScreencastFrameAck(std::unique_ptr<ScreencastFrameAckParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.screencastFrameAck", params->Serialize(), std::move(callback));
}

void Domain::HandleJavaScriptDialog(std::unique_ptr<HandleJavaScriptDialogParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.handleJavaScriptDialog", params->Serialize(), std::move(callback));
}

void Domain::SetColorPickerEnabled(std::unique_ptr<SetColorPickerEnabledParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.setColorPickerEnabled", params->Serialize(), std::move(callback));
}

void Domain::SetOverlayMessage(std::unique_ptr<SetOverlayMessageParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.setOverlayMessage", params->Serialize(), std::move(callback));
}

void Domain::RequestAppBanner(base::Callback<void()> callback) {
  dispatcher_->SendMessage("Page.requestAppBanner", std::move(callback));
}


// static
void Domain::HandleAddScriptToEvaluateOnLoadResponse(base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<AddScriptToEvaluateOnLoadResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<AddScriptToEvaluateOnLoadResult> result = AddScriptToEvaluateOnLoadResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleNavigateResponse(base::Callback<void(std::unique_ptr<NavigateResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<NavigateResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<NavigateResult> result = NavigateResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetNavigationHistoryResponse(base::Callback<void(std::unique_ptr<GetNavigationHistoryResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetNavigationHistoryResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetNavigationHistoryResult> result = GetNavigationHistoryResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetCookiesResponse(base::Callback<void(std::unique_ptr<GetCookiesResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetCookiesResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetCookiesResult> result = GetCookiesResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetResourceTreeResponse(base::Callback<void(std::unique_ptr<GetResourceTreeResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetResourceTreeResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetResourceTreeResult> result = GetResourceTreeResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleGetResourceContentResponse(base::Callback<void(std::unique_ptr<GetResourceContentResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<GetResourceContentResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<GetResourceContentResult> result = GetResourceContentResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleSearchInResourceResponse(base::Callback<void(std::unique_ptr<SearchInResourceResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<SearchInResourceResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<SearchInResourceResult> result = SearchInResourceResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

// static
void Domain::HandleCaptureScreenshotResponse(base::Callback<void(std::unique_ptr<CaptureScreenshotResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<CaptureScreenshotResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<CaptureScreenshotResult> result = CaptureScreenshotResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace page

} // namespace headless
