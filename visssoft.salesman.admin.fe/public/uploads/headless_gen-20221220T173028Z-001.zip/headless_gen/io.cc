// This file is generated

// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "headless/public/domains/io.h"

#include "base/bind.h"

namespace headless {

namespace io {

Domain::Domain(internal::MessageDispatcher* dispatcher) : dispatcher_(dispatcher) {}

Domain::~Domain() {}

void Domain::Read(std::unique_ptr<ReadParams> params, base::Callback<void(std::unique_ptr<ReadResult>)> callback) {
  dispatcher_->SendMessage("IO.read", params->Serialize(), base::Bind(&Domain::HandleReadResponse, callback));
}

void Domain::Close(std::unique_ptr<CloseParams> params, base::Callback<void()> callback) {
  dispatcher_->SendMessage("IO.close", params->Serialize(), std::move(callback));
}


// static
void Domain::HandleReadResponse(base::Callback<void(std::unique_ptr<ReadResult>)> callback, const base::Value& response) {
  if (callback.Equals(base::Callback<void(std::unique_ptr<ReadResult>)>()))
    return;
  ErrorReporter errors;
  std::unique_ptr<ReadResult> result = ReadResult::Parse(response, &errors);
  DCHECK(!errors.HasErrors());
  callback.Run(std::move(result));
}

}  // namespace io

} // namespace headless
