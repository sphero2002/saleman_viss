// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_INPUT_H_
#define HEADLESS_PUBLIC_DOMAINS_INPUT_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace input {

class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Dispatches a key event to the page.
  void DispatchKeyEvent(std::unique_ptr<DispatchKeyEventParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DispatchKeyEvent(headless::input::DispatchKeyEventType type, base::Callback<void()> callback = base::Callback<void()>());
  // Dispatches a mouse event to the page.
  void DispatchMouseEvent(std::unique_ptr<DispatchMouseEventParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DispatchMouseEvent(headless::input::DispatchMouseEventType type, int x, int y, base::Callback<void()> callback = base::Callback<void()>());
  // Dispatches a touch event to the page.
  void DispatchTouchEvent(std::unique_ptr<DispatchTouchEventParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void DispatchTouchEvent(headless::input::DispatchTouchEventType type, std::vector<std::unique_ptr<headless::input::TouchPoint>> touchPoints, base::Callback<void()> callback = base::Callback<void()>());
  // Emulates touch event from the mouse event parameters.
  void EmulateTouchFromMouseEvent(std::unique_ptr<EmulateTouchFromMouseEventParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void EmulateTouchFromMouseEvent(headless::input::EmulateTouchFromMouseEventType type, int x, int y, double timestamp, headless::input::EmulateTouchFromMouseEventButton button, base::Callback<void()> callback = base::Callback<void()>());
  // Synthesizes a pinch gesture over a time period by issuing appropriate touch events.
  void SynthesizePinchGesture(std::unique_ptr<SynthesizePinchGestureParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SynthesizePinchGesture(int x, int y, double scaleFactor, base::Callback<void()> callback = base::Callback<void()>());
  // Synthesizes a scroll gesture over a time period by issuing appropriate touch events.
  void SynthesizeScrollGesture(std::unique_ptr<SynthesizeScrollGestureParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SynthesizeScrollGesture(int x, int y, base::Callback<void()> callback = base::Callback<void()>());
  // Synthesizes a tap gesture over a time period by issuing appropriate touch events.
  void SynthesizeTapGesture(std::unique_ptr<SynthesizeTapGestureParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SynthesizeTapGesture(int x, int y, base::Callback<void()> callback = base::Callback<void()>());
 private:

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace input
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_INPUT_H_
