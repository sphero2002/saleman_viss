// This file is generated

// Copyright (c) 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef HEADLESS_PUBLIC_DOMAINS_DOM_STORAGE_H_
#define HEADLESS_PUBLIC_DOMAINS_DOM_STORAGE_H_

#include "base/callback.h"
#include "base/values.h"
#include "headless/public/domains/types.h"
#include "headless/public/headless_export.h"
#include "headless/public/internal/message_dispatcher.h"

namespace headless {
namespace dom_storage {

// Query and modify DOM storage.
class HEADLESS_EXPORT Domain {
 public:
  Domain(internal::MessageDispatcher* dispatcher);
  ~Domain();

  // Enables storage tracking, storage events will now be delivered to the client.
  void Enable(base::Callback<void()> callback = base::Callback<void()>());
  // Disables storage tracking, prevents storage events from being sent to the client.
  void Disable(base::Callback<void()> callback = base::Callback<void()>());
  void GetDOMStorageItems(std::unique_ptr<GetDOMStorageItemsParams> params, base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)> callback = base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)>());
  void GetDOMStorageItems(std::unique_ptr<headless::dom_storage::StorageId> storageId, base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)> callback = base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)>());
  void SetDOMStorageItem(std::unique_ptr<SetDOMStorageItemParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void SetDOMStorageItem(std::unique_ptr<headless::dom_storage::StorageId> storageId, std::string key, std::string value, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveDOMStorageItem(std::unique_ptr<RemoveDOMStorageItemParams> params, base::Callback<void()> callback = base::Callback<void()>());
  void RemoveDOMStorageItem(std::unique_ptr<headless::dom_storage::StorageId> storageId, std::string key, base::Callback<void()> callback = base::Callback<void()>());
 private:
  static void HandleGetDOMStorageItemsResponse(base::Callback<void(std::unique_ptr<GetDOMStorageItemsResult>)> callback, const base::Value& response);

  internal::MessageDispatcher* dispatcher_;  // Not owned.

  DISALLOW_COPY_AND_ASSIGN(Domain);
};

}  // namespace dom_storage
}  // namespace headless

#endif  // HEADLESS_PUBLIC_DOMAINS_DOM_STORAGE_H_
